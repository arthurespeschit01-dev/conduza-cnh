
-- 1. Add SELECT policy to public_instructor_profiles view for public access
-- This view already filters out sensitive data, so public access is safe
CREATE POLICY "Anyone can view public instructor profiles"
ON public.profiles
FOR SELECT
USING (
  -- Allow viewing only approved instructors with limited fields through the view
  -- Or allow users to view their own profile
  id = auth.uid() OR
  (registration_status = 'approved' AND has_role(id, 'instructor'))
);

-- 2. Drop the overly permissive policy on instructor_reviews
DROP POLICY IF EXISTS "Authenticated users can view reviews" ON public.instructor_reviews;

-- 3. Create a more restrictive policy for viewing reviews
-- Reviews should be viewable by:
-- - The instructor being reviewed
-- - The student who wrote the review
-- - Anyone viewing a specific instructor's public profile (for decision making)
CREATE POLICY "Users can view reviews for public instructor profiles"
ON public.instructor_reviews
FOR SELECT
USING (
  -- Instructor can see their reviews
  instructor_id = auth.uid() OR
  -- Student can see their own reviews
  student_id = auth.uid() OR
  -- Anyone can see reviews for approved instructors (for choosing instructors)
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = instructor_id
    AND p.registration_status = 'approved'
    AND has_role(p.id, 'instructor')
  )
);

-- 4. Create a public view for reviews that hides student_id
CREATE OR REPLACE VIEW public.public_reviews AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  -- Only show first name for privacy
  split_part(p.full_name, ' ', 1) as reviewer_name
FROM public.instructor_reviews ir
JOIN public.profiles p ON p.id = ir.student_id;

-- 5. Grant SELECT on the public_reviews view
GRANT SELECT ON public.public_reviews TO anon, authenticated;
