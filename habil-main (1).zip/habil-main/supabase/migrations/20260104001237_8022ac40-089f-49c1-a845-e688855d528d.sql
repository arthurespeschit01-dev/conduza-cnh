
-- Drop and recreate the view without the auth.uid() IS NOT NULL restriction
-- This restriction is not needed since the view already filters by approved status
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles AS
SELECT 
  id,
  full_name,
  bio,
  avatar_url,
  uf,
  city,
  neighborhood,
  years_of_experience,
  price_per_hour,
  available_days,
  available_start_time,
  available_end_time,
  cnh_category,
  certifications,
  CASE 
    WHEN whatsapp IS NOT NULL THEN '****' || RIGHT(whatsapp, 4)
    ELSE NULL 
  END AS whatsapp,
  ROUND(latitude::numeric, 2)::double precision AS latitude,
  ROUND(longitude::numeric, 2)::double precision AS longitude
FROM profiles p
WHERE 
  registration_status = 'approved' 
  AND payment_status = 'active'
  AND EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = p.id AND ur.role = 'instructor'
  );

-- Grant select access to authenticated and anon users
GRANT SELECT ON public_instructor_profiles TO authenticated;
GRANT SELECT ON public_instructor_profiles TO anon;
