-- =====================================================
-- MIGRAÇÃO DE SEGURANÇA: Remover dados sensíveis das views públicas
-- =====================================================

-- 1. Recriar a view public_instructor_profiles SEM o WhatsApp
-- O WhatsApp só deve ser acessado via edge function get-instructor-contact
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles AS
SELECT 
    id,
    full_name,
    bio,
    avatar_url,
    uf,
    city,
    neighborhood,
    years_of_experience,
    price_per_hour,
    available_days,
    available_start_time,
    available_end_time,
    cnh_category,
    certifications,
    -- Reduzir precisão das coordenadas para privacidade
    round(latitude::numeric, 2)::double precision AS latitude,
    round(longitude::numeric, 2)::double precision AS longitude
    -- WhatsApp REMOVIDO - deve ser obtido via edge function segura
FROM profiles p
WHERE 
    registration_status = 'approved' 
    AND has_role(id, 'instructor'::app_role)
    AND payment_status = 'active';

-- 2. Recriar a view safe_public_profiles (já está sem WhatsApp, mas vamos garantir)
DROP VIEW IF EXISTS safe_public_profiles;

CREATE VIEW safe_public_profiles AS
SELECT 
    id,
    full_name,
    bio,
    avatar_url,
    uf,
    city,
    neighborhood,
    years_of_experience,
    price_per_hour,
    available_days,
    available_start_time,
    available_end_time,
    cnh_category,
    certifications,
    subscription_plan,
    -- Coordenadas com precisão reduzida
    round(latitude::numeric, 2)::double precision AS latitude,
    round(longitude::numeric, 2)::double precision AS longitude
FROM profiles
WHERE 
    registration_status = 'approved' 
    AND has_role(id, 'instructor'::app_role)
    AND payment_status = 'active';

-- 3. Garantir que a view public_reviews não expõe o nome completo
DROP VIEW IF EXISTS public_reviews;

CREATE VIEW public_reviews AS
SELECT 
    ir.id,
    ir.instructor_id,
    ir.rating,
    ir.comment,
    ir.created_at,
    -- Usar apenas o primeiro nome para anonimato
    split_part(p.full_name, ' ', 1) AS reviewer_name
FROM instructor_reviews ir
JOIN profiles p ON p.id = ir.student_id
WHERE EXISTS (
    SELECT 1 FROM profiles instructor 
    WHERE instructor.id = ir.instructor_id 
    AND instructor.registration_status = 'approved'
    AND has_role(instructor.id, 'instructor'::app_role)
);

-- 4. Criar trigger para auditoria quando admin acessa dados sensíveis
CREATE OR REPLACE FUNCTION public.audit_sensitive_data_access()
RETURNS TRIGGER AS $$
BEGIN
    -- Registrar acesso na tabela de auditoria
    INSERT INTO public.audit_log (
        table_name,
        action,
        user_id,
        record_id,
        details
    ) VALUES (
        TG_TABLE_NAME,
        'SELECT',
        auth.uid(),
        NEW.id,
        jsonb_build_object(
            'accessed_at', now(),
            'user_role', 'admin'
        )
    );
    
    -- Atualizar campos de rastreamento
    NEW.last_accessed_at := now();
    NEW.accessed_by := auth.uid();
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 5. Criar função para validar que o solicitante tem relação com o instrutor antes de ver contato
CREATE OR REPLACE FUNCTION public.can_access_instructor_contact(instructor_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        -- É o próprio instrutor
        SELECT 1 WHERE instructor_id = auth.uid()
        UNION
        -- Aluno vinculado
        SELECT 1 FROM profiles 
        WHERE id = auth.uid() 
        AND (linked_instructor_id = instructor_id OR pending_instructor_id = instructor_id)
        UNION
        -- Admin
        SELECT 1 WHERE has_role(auth.uid(), 'admin'::app_role)
    )
$$;

-- 6. Adicionar comentário de segurança nas views
COMMENT ON VIEW public_instructor_profiles IS 'View segura para perfis de instrutores. WhatsApp removido - usar edge function get-instructor-contact.';
COMMENT ON VIEW safe_public_profiles IS 'View segura para perfis públicos sem dados sensíveis.';
COMMENT ON VIEW public_reviews IS 'Reviews públicas com nomes anonimizados (apenas primeiro nome).';