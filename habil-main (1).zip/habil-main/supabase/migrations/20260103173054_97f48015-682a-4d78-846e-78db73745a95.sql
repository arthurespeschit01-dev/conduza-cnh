-- CORREÇÃO DE SEGURANÇA: Remover política permissiva demais
-- A política "Require authentication for profiles access" permite qualquer usuário autenticado
-- acessar QUALQUER perfil, o que é uma vulnerabilidade crítica.

-- Remover a política problemática
DROP POLICY IF EXISTS "Require authentication for profiles access" ON public.profiles;

-- As políticas restantes são seguras:
-- 1. "Users can view own profile" - SELECT usando (id = auth.uid())
-- 2. "Users can update own profile" - UPDATE usando (id = auth.uid())
-- 3. "Users can insert own profile" - INSERT com check (id = auth.uid())
-- 4. "Admins can view/update all profiles" - usando has_role admin
-- 5. "Only admins can delete profiles" - usando has_role admin

-- Estas políticas garantem que:
-- - Usuários normais só podem ver/editar SEU PRÓPRIO perfil
-- - Apenas admins podem ver/editar todos os perfis
-- - Dados sensíveis (CPF, CNH, documentos) ficam protegidos