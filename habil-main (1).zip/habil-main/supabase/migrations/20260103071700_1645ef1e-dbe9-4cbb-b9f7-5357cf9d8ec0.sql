-- Drop existing views
DROP VIEW IF EXISTS public.public_instructor_profiles;
DROP VIEW IF EXISTS public.public_reviews;

-- Recreate public_instructor_profiles with SECURITY INVOKER
CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true, security_barrier = true)
AS
SELECT 
    p.id,
    p.full_name,
    p.bio,
    p.avatar_url,
    p.uf,
    p.city,
    p.neighborhood,
    p.years_of_experience,
    p.price_per_hour,
    p.available_days,
    p.available_start_time,
    p.available_end_time,
    p.cnh_category,
    p.certifications,
    p.whatsapp,
    p.latitude,
    p.longitude
FROM profiles p
JOIN user_roles ur ON (p.id = ur.user_id)
WHERE ur.role = 'instructor'::app_role 
  AND p.registration_status = 'approved'::text 
  AND p.payment_status = 'active'::text;

-- Recreate public_reviews with SECURITY INVOKER
CREATE VIEW public.public_reviews 
WITH (security_invoker = true, security_barrier = true)
AS
SELECT 
    ir.id,
    ir.instructor_id,
    ir.rating,
    ir.comment,
    ir.created_at,
    split_part(p.full_name, ' '::text, 1) AS reviewer_name
FROM instructor_reviews ir
JOIN profiles p ON (p.id = ir.student_id);

-- Grant SELECT to anon and authenticated for public access
GRANT SELECT ON public.public_instructor_profiles TO anon, authenticated;
GRANT SELECT ON public.public_reviews TO anon, authenticated;