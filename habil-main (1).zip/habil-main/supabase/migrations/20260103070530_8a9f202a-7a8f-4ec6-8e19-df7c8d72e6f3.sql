-- Add coordinates columns to profiles table for proximity search
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION;

-- Update the public_instructor_profiles view to include coordinates
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  p.whatsapp,
  p.latitude,
  p.longitude
FROM public.profiles p
INNER JOIN public.user_roles ur ON p.id = ur.user_id
WHERE ur.role = 'instructor'
  AND p.registration_status = 'approved'
  AND p.payment_status = 'active';

-- Create function to calculate distance in km using Haversine formula
CREATE OR REPLACE FUNCTION public.calculate_distance_km(
  lat1 DOUBLE PRECISION,
  lon1 DOUBLE PRECISION,
  lat2 DOUBLE PRECISION,
  lon2 DOUBLE PRECISION
) RETURNS DOUBLE PRECISION AS $$
DECLARE
  R CONSTANT DOUBLE PRECISION := 6371; -- Earth's radius in km
  dlat DOUBLE PRECISION;
  dlon DOUBLE PRECISION;
  a DOUBLE PRECISION;
  c DOUBLE PRECISION;
BEGIN
  -- Return NULL if any coordinate is NULL
  IF lat1 IS NULL OR lon1 IS NULL OR lat2 IS NULL OR lon2 IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Convert to radians
  dlat := radians(lat2 - lat1);
  dlon := radians(lon2 - lon1);
  
  -- Haversine formula
  a := sin(dlat / 2) * sin(dlat / 2) + 
       cos(radians(lat1)) * cos(radians(lat2)) * 
       sin(dlon / 2) * sin(dlon / 2);
  c := 2 * atan2(sqrt(a), sqrt(1 - a));
  
  RETURN R * c;
END;
$$ LANGUAGE plpgsql IMMUTABLE SET search_path = public;

-- Create function to get instructors sorted by distance
CREATE OR REPLACE FUNCTION public.get_instructors_by_proximity(
  user_lat DOUBLE PRECISION,
  user_lon DOUBLE PRECISION,
  filter_uf TEXT DEFAULT NULL,
  filter_city TEXT DEFAULT NULL,
  max_distance_km DOUBLE PRECISION DEFAULT NULL
) RETURNS TABLE (
  id UUID,
  full_name TEXT,
  bio TEXT,
  avatar_url TEXT,
  uf TEXT,
  city TEXT,
  neighborhood TEXT,
  years_of_experience INTEGER,
  price_per_hour NUMERIC,
  available_days TEXT[],
  available_start_time TIME,
  available_end_time TIME,
  cnh_category TEXT,
  certifications TEXT[],
  whatsapp TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  distance_km DOUBLE PRECISION
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pip.id,
    pip.full_name,
    pip.bio,
    pip.avatar_url,
    pip.uf,
    pip.city,
    pip.neighborhood,
    pip.years_of_experience,
    pip.price_per_hour,
    pip.available_days,
    pip.available_start_time,
    pip.available_end_time,
    pip.cnh_category::TEXT,
    pip.certifications,
    pip.whatsapp,
    pip.latitude,
    pip.longitude,
    public.calculate_distance_km(user_lat, user_lon, pip.latitude, pip.longitude) AS distance_km
  FROM public_instructor_profiles pip
  WHERE 
    (filter_uf IS NULL OR pip.uf = filter_uf)
    AND (filter_city IS NULL OR pip.city = filter_city)
    AND (
      max_distance_km IS NULL 
      OR pip.latitude IS NULL 
      OR pip.longitude IS NULL
      OR public.calculate_distance_km(user_lat, user_lon, pip.latitude, pip.longitude) <= max_distance_km
    )
  ORDER BY 
    CASE 
      WHEN pip.latitude IS NOT NULL AND pip.longitude IS NOT NULL 
      THEN public.calculate_distance_km(user_lat, user_lon, pip.latitude, pip.longitude)
      ELSE 999999
    END ASC;
END;
$$ LANGUAGE plpgsql STABLE SET search_path = public;