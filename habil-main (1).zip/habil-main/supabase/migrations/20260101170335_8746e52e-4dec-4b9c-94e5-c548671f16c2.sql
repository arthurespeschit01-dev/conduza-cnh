-- Remover a política que expõe dados sensíveis
DROP POLICY IF EXISTS "Public can view approved instructor basic data" ON public.profiles;

-- Agora a tabela profiles só pode ser acessada por:
-- 1. O próprio usuário (via "Users can view own profile")
-- 2. Admins (via outras políticas existentes)
-- 3. Via a view public_instructor_profiles que só expõe campos não-sensíveis