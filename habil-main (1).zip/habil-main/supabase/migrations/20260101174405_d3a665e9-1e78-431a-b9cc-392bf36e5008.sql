-- Tornar o bucket de documentos de instrutores público para permitir visualização
UPDATE storage.buckets 
SET public = true 
WHERE id = 'instructor-documents';

-- Adicionar política para admins visualizarem todos os documentos
CREATE POLICY "Admins can view all instructor documents" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'instructor-documents' 
  AND public.has_role(auth.uid(), 'admin')
);