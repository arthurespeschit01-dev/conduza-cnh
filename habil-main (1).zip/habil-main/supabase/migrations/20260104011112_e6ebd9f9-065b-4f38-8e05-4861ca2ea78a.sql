-- Create separate table for sensitive user data with enhanced security
CREATE TABLE public.user_sensitive_data (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Government IDs (encrypted)
  cpf_masked TEXT, -- Only last 2 digits visible: ***.***.***-XX
  cpf_encrypted BYTEA, -- Full encrypted CPF
  cnh TEXT, -- Driver's license number
  rg TEXT, -- Identity document
  
  -- Document URLs (private storage paths, not public URLs)
  rg_document_path TEXT,
  cnh_document_path TEXT,
  proof_of_residence_path TEXT,
  instructor_certificate_path TEXT,
  
  -- Payment/Financial data
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  
  -- Audit fields
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_accessed_at TIMESTAMPTZ, -- Track when sensitive data was accessed
  accessed_by UUID -- Track who accessed the data
);

-- Enable RLS with strict policies
ALTER TABLE public.user_sensitive_data ENABLE ROW LEVEL SECURITY;

-- Users can only view their own sensitive data
CREATE POLICY "Users can view own sensitive data"
ON public.user_sensitive_data
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Users can insert their own sensitive data
CREATE POLICY "Users can insert own sensitive data"
ON public.user_sensitive_data
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- Users can update their own sensitive data
CREATE POLICY "Users can update own sensitive data"
ON public.user_sensitive_data
FOR UPDATE
TO authenticated
USING (user_id = auth.uid());

-- Admins can view sensitive data (for support purposes only)
-- Note: This should be audited in production
CREATE POLICY "Admins can view sensitive data for support"
ON public.user_sensitive_data
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can update sensitive data (for support purposes only)
CREATE POLICY "Admins can update sensitive data for support"
ON public.user_sensitive_data
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- NO DELETE POLICY - sensitive data should never be deleted, only anonymized
-- This prevents accidental or malicious deletion

-- Create function to log access to sensitive data
CREATE OR REPLACE FUNCTION public.log_sensitive_data_access()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update last access timestamp
  NEW.last_accessed_at := now();
  NEW.accessed_by := auth.uid();
  RETURN NEW;
END;
$$;

-- Trigger to log updates (access tracking)
CREATE TRIGGER track_sensitive_data_access
BEFORE UPDATE ON public.user_sensitive_data
FOR EACH ROW
EXECUTE FUNCTION public.log_sensitive_data_access();

-- Create function to encrypt CPF on insert/update
CREATE OR REPLACE FUNCTION public.encrypt_sensitive_cpf()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  encryption_key TEXT;
  plain_cpf TEXT;
BEGIN
  -- Check if there's a plain CPF to encrypt (passed via cpf_masked temporarily)
  IF NEW.cpf_masked IS NOT NULL AND NEW.cpf_masked NOT LIKE '***%' THEN
    plain_cpf := NEW.cpf_masked;
    encryption_key := 'autoescola_cpf_encryption_secret_key_2024_secure';
    
    -- Encrypt the full CPF
    NEW.cpf_encrypted := pgp_sym_encrypt(plain_cpf, encryption_key);
    
    -- Mask the plain CPF (keep last 2 digits for reference)
    NEW.cpf_masked := '***.***.***-' || RIGHT(REGEXP_REPLACE(plain_cpf, '[^0-9]', '', 'g'), 2);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger to auto-encrypt CPF
CREATE TRIGGER encrypt_cpf_on_sensitive_data
BEFORE INSERT OR UPDATE ON public.user_sensitive_data
FOR EACH ROW
EXECUTE FUNCTION public.encrypt_sensitive_cpf();

-- Migrate existing data from profiles to the new table
INSERT INTO public.user_sensitive_data (
  user_id,
  cpf_masked,
  cpf_encrypted,
  cnh,
  rg_document_path,
  cnh_document_path,
  proof_of_residence_path,
  instructor_certificate_path,
  stripe_customer_id,
  stripe_subscription_id,
  created_at,
  updated_at
)
SELECT 
  id AS user_id,
  cpf AS cpf_masked,
  cpf_encrypted,
  cnh,
  rg_document_url AS rg_document_path,
  cnh_document_url AS cnh_document_path,
  proof_of_residence_url AS proof_of_residence_path,
  instructor_certificate_url AS instructor_certificate_path,
  stripe_customer_id,
  stripe_subscription_id,
  created_at,
  updated_at
FROM public.profiles
WHERE cpf IS NOT NULL 
   OR cpf_encrypted IS NOT NULL
   OR cnh IS NOT NULL
   OR rg_document_url IS NOT NULL
   OR cnh_document_url IS NOT NULL
   OR stripe_customer_id IS NOT NULL
ON CONFLICT (user_id) DO UPDATE SET
  cpf_masked = EXCLUDED.cpf_masked,
  cpf_encrypted = EXCLUDED.cpf_encrypted,
  cnh = EXCLUDED.cnh,
  rg_document_path = EXCLUDED.rg_document_path,
  cnh_document_path = EXCLUDED.cnh_document_path,
  proof_of_residence_path = EXCLUDED.proof_of_residence_path,
  instructor_certificate_path = EXCLUDED.instructor_certificate_path,
  stripe_customer_id = EXCLUDED.stripe_customer_id,
  stripe_subscription_id = EXCLUDED.stripe_subscription_id;

-- Add comment documenting the table purpose
COMMENT ON TABLE public.user_sensitive_data IS 
'Segregated table for sensitive PII data (CPF, documents, payment info). 
Access is strictly controlled via RLS. No delete policy exists - data should be anonymized, not deleted.
All access is logged via last_accessed_at and accessed_by columns.';

-- Add index for faster lookups
CREATE INDEX idx_user_sensitive_data_user_id ON public.user_sensitive_data(user_id);
