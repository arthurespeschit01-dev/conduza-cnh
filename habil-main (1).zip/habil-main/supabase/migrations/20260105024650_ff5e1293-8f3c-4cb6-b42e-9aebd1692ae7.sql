
-- Create table for DETRAN exam questions
CREATE TABLE public.exam_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question TEXT NOT NULL,
  options JSONB NOT NULL, -- Array of options
  correct_option INTEGER NOT NULL, -- Index of correct answer (0-3)
  category TEXT NOT NULL, -- 'legislacao', 'direcao_defensiva', 'primeiros_socorros', 'mecanica', 'meio_ambiente'
  difficulty TEXT NOT NULL DEFAULT 'medium', -- 'easy', 'medium', 'hard'
  explanation TEXT, -- Explanation for the correct answer
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for user simulation attempts
CREATE TABLE public.simulation_attempts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  total_questions INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  score DECIMAL NOT NULL, -- Percentage score
  passed BOOLEAN NOT NULL, -- 70% or more = passed
  time_taken_seconds INTEGER, -- Time to complete
  answers JSONB, -- Record of user answers
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.exam_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.simulation_attempts ENABLE ROW LEVEL SECURITY;

-- RLS for exam_questions (public read)
CREATE POLICY "Anyone can view exam questions" 
ON public.exam_questions 
FOR SELECT 
USING (true);

-- RLS for simulation_attempts
CREATE POLICY "Users can view own attempts" 
ON public.simulation_attempts 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own attempts" 
ON public.simulation_attempts 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

-- Insert real DETRAN questions
INSERT INTO public.exam_questions (question, options, correct_option, category, explanation) VALUES
-- Legislação de Trânsito
('Qual é a velocidade máxima permitida em vias locais urbanas, quando não houver sinalização regulamentadora?', 
 '["30 km/h", "40 km/h", "50 km/h", "60 km/h"]', 
 0, 'legislacao', 
 'Conforme o CTB, Art. 61, a velocidade máxima em vias locais é de 30 km/h quando não há sinalização.'),

('Em caso de acidente de trânsito sem vítimas, qual é a primeira providência que os condutores devem tomar?',
 '["Acionar a polícia imediatamente", "Sinalizar o local e remover os veículos", "Aguardar no local sem mover nada", "Chamar o seguro antes de qualquer ação"]',
 1, 'legislacao',
 'O CTB determina que, não havendo vítimas, os condutores devem sinalizar e liberar a via.'),

('A Carteira Nacional de Habilitação (CNH) tem validade de quantos anos para condutores com menos de 50 anos?',
 '["3 anos", "5 anos", "10 anos", "Indeterminada"]',
 2, 'legislacao',
 'A CNH tem validade de 10 anos para condutores com menos de 50 anos de idade.'),

('Ao estacionar em um aclive, o condutor deve:',
 '["Deixar as rodas alinhadas", "Virar as rodas para o meio-fio", "Virar as rodas para o lado oposto ao meio-fio", "Não há necessidade de virar as rodas"]',
 2, 'legislacao',
 'Em aclive, as rodas devem ser viradas para o lado oposto ao meio-fio para evitar que o veículo desça.'),

('Qual documento é obrigatório portar durante a condução de veículo automotor?',
 '["RG, CPF e comprovante de residência", "CNH e CRLV", "Apenas a CNH", "CRLV e comprovante de seguro"]',
 1, 'legislacao',
 'O condutor deve portar a CNH e o CRLV do veículo, conforme Art. 133 do CTB.'),

-- Direção Defensiva
('O que significa dirigir defensivamente?',
 '["Dirigir apenas em baixa velocidade", "Dirigir prevendo situações de risco e agindo para evitá-las", "Dirigir usando sempre o freio motor", "Dirigir apenas durante o dia"]',
 1, 'direcao_defensiva',
 'Direção defensiva é prever riscos e tomar atitudes para evitar acidentes.'),

('Qual é a distância mínima de seguimento recomendada em condições normais?',
 '["1 segundo do veículo à frente", "2 segundos do veículo à frente", "3 metros do veículo à frente", "5 metros do veículo à frente"]',
 1, 'direcao_defensiva',
 'A regra dos 2 segundos garante distância segura em condições normais.'),

('Em caso de aquaplanagem, o condutor deve:',
 '["Frear bruscamente", "Acelerar para sair da água", "Tirar o pé do acelerador e segurar firme o volante", "Fazer manobras bruscas de direção"]',
 2, 'direcao_defensiva',
 'Na aquaplanagem, deve-se manter a calma, tirar o pé do acelerador e segurar firme o volante.'),

('O que é "ponto cego" do veículo?',
 '["Área não coberta pelos retrovisores", "Faróis queimados", "Para-brisa sujo", "Pneus desgastados"]',
 0, 'direcao_defensiva',
 'Ponto cego é a área ao redor do veículo que não é visível pelos retrovisores.'),

('Ao perceber que está sonolento ao volante, o condutor deve:',
 '["Ligar o rádio bem alto", "Abrir as janelas", "Parar em local seguro e descansar", "Aumentar a velocidade para chegar logo"]',
 2, 'direcao_defensiva',
 'A única solução eficaz contra o sono é parar e descansar.'),

-- Primeiros Socorros
('Em caso de acidente com vítima inconsciente, a primeira ação é:',
 '["Dar água para a vítima", "Verificar se a via está segura e sinalizar", "Remover a vítima imediatamente", "Aplicar respiração boca a boca"]',
 1, 'primeiros_socorros',
 'A segurança do socorrista e sinalização são prioridades antes de qualquer ação.'),

('O que significa a sigla SAMU?',
 '["Serviço de Atendimento Municipal Urgente", "Serviço de Atendimento Móvel de Urgência", "Sistema de Apoio Médico Universal", "Serviço de Ambulância Móvel Urbana"]',
 1, 'primeiros_socorros',
 'SAMU = Serviço de Atendimento Móvel de Urgência, acessado pelo 192.'),

('Em caso de hemorragia externa, o procedimento correto é:',
 '["Lavar o ferimento com água", "Fazer torniquete imediatamente", "Aplicar pressão direta no local com pano limpo", "Não tocar na vítima"]',
 2, 'primeiros_socorros',
 'A pressão direta no local da hemorragia é o procedimento correto.'),

('Qual número de telefone aciona o SAMU?',
 '["190", "191", "192", "193"]',
 2, 'primeiros_socorros',
 '192 é o número do SAMU. 190=Polícia, 191=PRF, 193=Bombeiros.'),

('Em um acidente, NÃO se deve retirar o capacete de um motociclista porque:',
 '["O capacete pode estar preso", "Pode agravar lesões na coluna", "O capacete protege do sol", "O motociclista pode estar consciente"]',
 1, 'primeiros_socorros',
 'Retirar o capacete pode causar ou agravar lesões na coluna cervical.'),

-- Mecânica Básica
('O que indica a luz do óleo acesa no painel?',
 '["Nível de óleo baixo ou pressão insuficiente", "Hora de trocar o óleo", "Motor superaquecido", "Bateria fraca"]',
 0, 'mecanica',
 'A luz do óleo indica problema na pressão ou nível do óleo lubrificante.'),

('Qual a função do sistema de arrefecimento?',
 '["Lubrificar o motor", "Controlar a temperatura do motor", "Alimentar o motor com combustível", "Gerar energia elétrica"]',
 1, 'mecanica',
 'O sistema de arrefecimento mantém a temperatura do motor em níveis seguros.'),

('O que indica o superaquecimento do motor?',
 '["Fumaça branca pelo escapamento e temperatura alta", "Ruído no motor", "Consumo elevado de combustível", "Dificuldade de partida"]',
 0, 'mecanica',
 'Temperatura alta e fumaça branca indicam superaquecimento.'),

('Os pneus devem ser calibrados:',
 '["Com os pneus quentes", "Com os pneus frios", "Após rodar 50 km", "Não importa a temperatura"]',
 1, 'mecanica',
 'A calibragem deve ser feita com os pneus frios para medição correta.'),

('A função dos amortecedores é:',
 '["Sustentar o peso do veículo", "Controlar as oscilações das molas", "Conectar as rodas ao chassi", "Alinhar as rodas"]',
 1, 'mecanica',
 'Os amortecedores controlam as oscilações das molas da suspensão.'),

-- Meio Ambiente
('Qual gás emitido pelos veículos contribui para o efeito estufa?',
 '["Oxigênio", "Nitrogênio", "Dióxido de Carbono (CO2)", "Hidrogênio"]',
 2, 'meio_ambiente',
 'O CO2 é o principal gás de efeito estufa emitido pelos veículos.'),

('A inspeção veicular periódica avalia principalmente:',
 '["A cor do veículo", "Emissões de poluentes e segurança", "O ano de fabricação", "A marca do veículo"]',
 1, 'meio_ambiente',
 'A inspeção veicular verifica segurança e níveis de emissões.'),

('O que é poluição sonora no trânsito?',
 '["Fumaça dos veículos", "Ruído excessivo causado por buzinas e motores", "Óleo derramado na pista", "Lixo jogado nas ruas"]',
 1, 'meio_ambiente',
 'Poluição sonora é o ruído excessivo, incluindo buzinas e escapamentos.'),

('Veículos mal regulados causam:',
 '["Maior economia de combustível", "Maior emissão de poluentes", "Menor desgaste de pneus", "Melhor desempenho"]',
 1, 'meio_ambiente',
 'Veículos desregulados emitem mais poluentes e consomem mais combustível.'),

('A manutenção preventiva do veículo contribui para:',
 '["Aumentar a poluição", "Reduzir emissões e preservar o meio ambiente", "Gastar mais combustível", "Diminuir a vida útil do motor"]',
 1, 'meio_ambiente',
 'A manutenção preventiva reduz emissões e preserva o meio ambiente.');
