-- Add explicit denial policies for anonymous access to sensitive tables
-- These ensure that only authenticated users can access the data

-- Policy to deny anonymous access to profiles (require authentication)
CREATE POLICY "require_auth_for_profiles" ON public.profiles 
FOR SELECT USING (auth.uid() IS NOT NULL);

-- Policy to deny anonymous access to schedules (require authentication)  
CREATE POLICY "require_auth_for_schedules" ON public.schedules 
FOR SELECT USING (auth.uid() IS NOT NULL);

-- Policy to deny anonymous access to vehicles (require authentication)
CREATE POLICY "require_auth_for_vehicles" ON public.vehicles 
FOR SELECT USING (auth.uid() IS NOT NULL);