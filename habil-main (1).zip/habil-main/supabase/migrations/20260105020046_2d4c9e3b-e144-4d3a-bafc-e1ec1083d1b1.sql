-- Add weekly lesson frequency preference to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS weekly_lesson_frequency integer DEFAULT 2;

-- Add comment for documentation
COMMENT ON COLUMN public.profiles.weekly_lesson_frequency IS 'Student preference for weekly lesson frequency (1-5 lessons per week)';