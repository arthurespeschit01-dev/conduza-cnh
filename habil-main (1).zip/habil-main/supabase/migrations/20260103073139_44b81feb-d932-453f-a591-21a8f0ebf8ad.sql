-- Política para bloquear acesso anônimo à tabela profiles
-- Requer que o usuário esteja autenticado para qualquer operação
CREATE POLICY "Require authentication for profiles access"
ON public.profiles
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);