-- =============================================
-- PART 2: FIX RLS POLICIES FOR PUBLIC_USER_DATA 
-- =============================================

-- 1. REMOVE the dangerous permissive "Require authentication for profiles" policy
-- This policy allows ANY authenticated user to see ALL profiles
DROP POLICY IF EXISTS "Require authentication for profiles" ON public.profiles;

-- 2. CREATE function to check if user can view an instructor profile (for public listings)
CREATE OR REPLACE FUNCTION public.can_view_instructor_profile(profile_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = profile_id
    AND p.registration_status = 'approved'
    AND public.has_role(p.id, 'instructor')
    AND p.payment_status = 'active'
  );
$$;

-- 3. ADD policy for instructors to view their linked/pending students
CREATE POLICY "Instructors can view their linked students"
ON public.profiles FOR SELECT TO authenticated
USING (
  linked_instructor_id = auth.uid()
  OR pending_instructor_id = auth.uid()
);

-- 4. ADD policy for users to view approved instructor profiles (public data only)
CREATE POLICY "Users can view approved instructors"
ON public.profiles FOR SELECT TO authenticated
USING (
  public.can_view_instructor_profile(id)
);

-- 5. ADD policy for students to view their own instructor
CREATE POLICY "Students can view their own instructor"
ON public.profiles FOR SELECT TO authenticated
USING (
  id = (SELECT linked_instructor_id FROM profiles WHERE id = auth.uid())
  OR id = (SELECT pending_instructor_id FROM profiles WHERE id = auth.uid())
);