-- Add link/binding status fields to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS pending_instructor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS pending_instructor_name text,
ADD COLUMN IF NOT EXISTS pending_contact_at timestamptz,
ADD COLUMN IF NOT EXISTS linked_instructor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS linked_at timestamptz;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_profiles_pending_instructor ON public.profiles(pending_instructor_id) WHERE pending_instructor_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_profiles_linked_instructor ON public.profiles(linked_instructor_id) WHERE linked_instructor_id IS NOT NULL;