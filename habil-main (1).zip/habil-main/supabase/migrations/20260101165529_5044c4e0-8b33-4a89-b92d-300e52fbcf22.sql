
-- Fix the security definer view issue by recreating with security_invoker = true
DROP VIEW IF EXISTS public.public_reviews;

CREATE VIEW public.public_reviews 
WITH (security_invoker = true)
AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  split_part(p.full_name, ' ', 1) as reviewer_name
FROM public.instructor_reviews ir
JOIN public.profiles p ON p.id = ir.student_id;

-- Grant SELECT on the public_reviews view
GRANT SELECT ON public.public_reviews TO anon, authenticated;
