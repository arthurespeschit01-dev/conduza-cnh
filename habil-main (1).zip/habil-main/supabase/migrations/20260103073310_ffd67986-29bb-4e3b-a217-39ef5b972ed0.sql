-- Política para bloquear acesso anônimo à tabela schedules
-- Requer que o usuário esteja autenticado para qualquer operação
CREATE POLICY "Require authentication for schedules access"
ON public.schedules
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);