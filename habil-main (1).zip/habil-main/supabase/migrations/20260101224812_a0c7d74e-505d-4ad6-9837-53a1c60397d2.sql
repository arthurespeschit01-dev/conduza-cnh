-- Atualizar a view public_instructor_profiles para incluir o campo whatsapp
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles
WITH (security_invoker = on)
AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  p.whatsapp
FROM profiles p
WHERE p.registration_status = 'approved'
  AND EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = p.id AND ur.role = 'instructor'
  );