-- Create instructor_reviews table for student ratings
CREATE TABLE public.instructor_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  instructor_id UUID NOT NULL,
  student_id UUID NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(instructor_id, student_id) -- One review per student per instructor
);

-- Enable Row Level Security
ALTER TABLE public.instructor_reviews ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Students can create reviews for instructors they had classes with"
ON public.instructor_reviews
FOR INSERT
WITH CHECK (student_id = auth.uid());

CREATE POLICY "Students can update their own reviews"
ON public.instructor_reviews
FOR UPDATE
USING (student_id = auth.uid());

CREATE POLICY "Students can delete their own reviews"
ON public.instructor_reviews
FOR DELETE
USING (student_id = auth.uid());

CREATE POLICY "Everyone can view reviews"
ON public.instructor_reviews
FOR SELECT
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_instructor_reviews_updated_at
BEFORE UPDATE ON public.instructor_reviews
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();