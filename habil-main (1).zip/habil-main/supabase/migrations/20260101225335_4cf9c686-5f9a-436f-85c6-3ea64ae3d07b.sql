-- Recriar view public_instructor_profiles com SECURITY DEFINER
-- Isso permite que qualquer usuário (incluindo anônimos) veja os instrutores aprovados
-- A view já filtra apenas dados públicos (sem email, cpf, cnh, etc)

DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles
WITH (security_barrier = true)
AS
SELECT 
  id,
  full_name,
  bio,
  avatar_url,
  uf,
  city,
  neighborhood,
  years_of_experience,
  price_per_hour,
  available_days,
  available_start_time,
  available_end_time,
  cnh_category,
  certifications,
  whatsapp
FROM profiles p
WHERE registration_status = 'approved'
  AND EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = p.id 
    AND ur.role = 'instructor'
  );

-- Garantir acesso público à view (sem RLS, já que é uma view segura)
GRANT SELECT ON public_instructor_profiles TO anon, authenticated;