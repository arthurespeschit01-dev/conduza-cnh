-- =============================================
-- COMPREHENSIVE SECURITY FIX FOR PUBLIC_USER_DATA & EXPOSED_SENSITIVE_DATA
-- =============================================

-- 1. CREATE function to generate secure randomized document paths (using gen_random_uuid instead)
CREATE OR REPLACE FUNCTION public.generate_secure_document_path(user_id uuid, doc_type text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT user_id::text || '/' || gen_random_uuid()::text || '_' || doc_type;
$$;

-- 2. CREATE safe public profiles view with only non-sensitive data
DROP VIEW IF EXISTS public.safe_public_profiles;

CREATE VIEW public.safe_public_profiles
WITH (security_invoker = true) AS
SELECT 
  id,
  full_name,
  bio,
  avatar_url,
  uf,
  city,
  neighborhood,
  years_of_experience,
  price_per_hour,
  available_days,
  available_start_time,
  available_end_time,
  cnh_category,
  certifications,
  subscription_plan,
  ROUND(latitude::numeric, 2)::double precision as latitude,
  ROUND(longitude::numeric, 2)::double precision as longitude
FROM public.profiles
WHERE registration_status = 'approved'
  AND public.has_role(id, 'instructor')
  AND payment_status = 'active';

GRANT SELECT ON public.safe_public_profiles TO authenticated;

-- 3. Add text length limits to prevent abuse (via trigger)
CREATE OR REPLACE FUNCTION public.validate_profile_text_limits()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  -- Validate bio length (max 1000 chars)
  IF NEW.bio IS NOT NULL AND length(NEW.bio) > 1000 THEN
    RAISE EXCEPTION 'Bio cannot exceed 1000 characters';
  END IF;
  
  -- Validate full_name length (max 100 chars)
  IF NEW.full_name IS NOT NULL AND length(NEW.full_name) > 100 THEN
    RAISE EXCEPTION 'Full name cannot exceed 100 characters';
  END IF;
  
  -- Validate neighborhood length (max 100 chars)
  IF NEW.neighborhood IS NOT NULL AND length(NEW.neighborhood) > 100 THEN
    RAISE EXCEPTION 'Neighborhood cannot exceed 100 characters';
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_profile_text_limits_trigger ON public.profiles;
CREATE TRIGGER validate_profile_text_limits_trigger
BEFORE INSERT OR UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.validate_profile_text_limits();

-- 4. Add scheduled cleanup for old rate limits (to be called periodically)
CREATE OR REPLACE FUNCTION public.cleanup_expired_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Clean rate limits older than 24 hours
  DELETE FROM public.rate_limits
  WHERE attempted_at < now() - interval '24 hours';
  
  -- Clean old access attempts older than 30 days
  DELETE FROM public.access_attempts
  WHERE attempted_at < now() - interval '30 days';
  
  -- Clean read notifications older than 90 days
  DELETE FROM public.notifications
  WHERE is_read = true AND created_at < now() - interval '90 days';
END;
$$;