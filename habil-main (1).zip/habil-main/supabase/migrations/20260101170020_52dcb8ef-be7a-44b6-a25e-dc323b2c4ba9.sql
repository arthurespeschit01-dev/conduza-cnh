-- 1. Remover políticas RLS problemáticas que expõem dados sensíveis
DROP POLICY IF EXISTS "Anyone can view public instructor profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile or public instructor data" ON public.profiles;

-- 2. Criar política segura: usuários autenticados só veem próprio perfil
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (id = auth.uid());

-- 3. Recriar view public_instructor_profiles com segurança adequada
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = false)
AS
SELECT 
  p.id,
  p.full_name,
  p.avatar_url,
  p.bio,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.cnh_category,
  p.certifications,
  p.available_days,
  p.available_start_time,
  p.available_end_time
FROM public.profiles p
JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor'::app_role 
AND p.registration_status = 'approved';

-- 4. Conceder acesso à view para anônimos e autenticados
GRANT SELECT ON public.public_instructor_profiles TO anon, authenticated;