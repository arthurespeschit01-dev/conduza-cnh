-- Corrigir VIEWs para não usar SECURITY DEFINER (padrão do PostgreSQL)
-- Views já são SECURITY INVOKER por padrão, então precisamos garantir isso

-- Recriar public_instructor_profiles com SECURITY INVOKER explícito
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles 
WITH (security_invoker = on) AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  CASE 
    WHEN p.whatsapp IS NOT NULL AND LENGTH(p.whatsapp) > 4 
    THEN '****' || RIGHT(p.whatsapp, 4)
    ELSE NULL
  END as whatsapp,
  CASE WHEN p.latitude IS NOT NULL THEN ROUND(p.latitude::numeric, 2)::double precision ELSE NULL END as latitude,
  CASE WHEN p.longitude IS NOT NULL THEN ROUND(p.longitude::numeric, 2)::double precision ELSE NULL END as longitude
FROM profiles p
JOIN user_roles ur ON ur.user_id = p.id
WHERE 
  ur.role = 'instructor'
  AND p.registration_status = 'approved'
  AND p.payment_status = 'active';

-- Recriar public_reviews com SECURITY INVOKER explícito
DROP VIEW IF EXISTS public_reviews;

CREATE VIEW public_reviews 
WITH (security_invoker = on) AS
SELECT 
  r.id,
  r.instructor_id,
  r.rating,
  CASE 
    WHEN p.full_name IS NOT NULL AND LENGTH(p.full_name) > 0 
    THEN SPLIT_PART(p.full_name, ' ', 1) || ' ' || LEFT(COALESCE(SPLIT_PART(p.full_name, ' ', 2), ''), 1) || '.'
    ELSE 'Anônimo'
  END as reviewer_name,
  r.comment,
  r.created_at
FROM instructor_reviews r
LEFT JOIN profiles p ON r.student_id = p.id;

-- Conceder permissões para usuários anônimos e autenticados
GRANT SELECT ON public_instructor_profiles TO anon, authenticated;
GRANT SELECT ON public_reviews TO anon, authenticated;