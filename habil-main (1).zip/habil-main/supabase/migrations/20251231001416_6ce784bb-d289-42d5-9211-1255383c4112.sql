-- Add new columns to profiles for instructor registration
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS neighborhood text,
ADD COLUMN IF NOT EXISTS address text,
ADD COLUMN IF NOT EXISTS available_days text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS available_start_time time DEFAULT '08:00',
ADD COLUMN IF NOT EXISTS available_end_time time DEFAULT '18:00',
ADD COLUMN IF NOT EXISTS is_independent boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS registration_status text DEFAULT 'pending';

-- Add comments for clarity
COMMENT ON COLUMN public.profiles.neighborhood IS 'Bairro do instrutor';
COMMENT ON COLUMN public.profiles.address IS 'Endereço completo do instrutor';
COMMENT ON COLUMN public.profiles.available_days IS 'Dias da semana disponíveis para aulas';
COMMENT ON COLUMN public.profiles.available_start_time IS 'Horário de início de disponibilidade';
COMMENT ON COLUMN public.profiles.available_end_time IS 'Horário de fim de disponibilidade';
COMMENT ON COLUMN public.profiles.is_independent IS 'Se é instrutor independente (não vinculado a autoescola)';
COMMENT ON COLUMN public.profiles.registration_status IS 'Status do cadastro: pending, approved, rejected';