
-- ===========================================
-- SECURITY FIX: Remover triggers e colunas sensíveis
-- ===========================================

-- Primeiro, dropar o trigger dependente de CPF
DROP TRIGGER IF EXISTS encrypt_cpf_on_change ON public.profiles;
DROP FUNCTION IF EXISTS public.encrypt_cpf_trigger();

-- Agora remover colunas sensíveis da tabela profiles
-- (Dados já migrados para user_sensitive_data)
ALTER TABLE public.profiles DROP COLUMN IF EXISTS cpf CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS cpf_encrypted CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS cnh CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS rg_document_url CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS cnh_document_url CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS proof_of_residence_url CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS instructor_certificate_url CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS stripe_customer_id CASCADE;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS stripe_subscription_id CASCADE;

-- ===========================================
-- SECURITY FIX: Audit log para dados sensíveis
-- ===========================================

CREATE TABLE IF NOT EXISTS public.audit_log (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid,
    action text NOT NULL,
    table_name text NOT NULL,
    record_id uuid,
    details jsonb,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Índice para queries por usuário
CREATE INDEX IF NOT EXISTS idx_audit_log_user 
ON public.audit_log(user_id, created_at DESC);

-- RLS para audit_log
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Apenas admins podem visualizar audit log
CREATE POLICY "Only admins can view audit log" ON public.audit_log
FOR SELECT USING (has_role(auth.uid(), 'admin'));

-- Sistema pode inserir (via service role)
CREATE POLICY "System can insert audit entries" ON public.audit_log
FOR INSERT WITH CHECK (true);

-- ===========================================
-- SECURITY FIX: Criar tabela para rate limiting
-- ===========================================

CREATE TABLE IF NOT EXISTS public.access_attempts (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    ip_address text NOT NULL,
    endpoint text NOT NULL,
    user_id uuid,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    success boolean DEFAULT false
);

-- Índice para queries rápidas de rate limiting
CREATE INDEX IF NOT EXISTS idx_access_attempts_ip_endpoint 
ON public.access_attempts(ip_address, endpoint, attempted_at DESC);

-- RLS para access_attempts
ALTER TABLE public.access_attempts ENABLE ROW LEVEL SECURITY;

-- Permitir inserção para tracking
CREATE POLICY "Allow insert for tracking" ON public.access_attempts
FOR INSERT WITH CHECK (true);

-- Apenas admins podem visualizar
CREATE POLICY "Only admins can view attempts" ON public.access_attempts
FOR SELECT USING (has_role(auth.uid(), 'admin'));

-- ===========================================
-- SECURITY FIX: Trigger para audit de acesso a dados sensíveis
-- ===========================================

CREATE OR REPLACE FUNCTION public.audit_sensitive_data_access()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Atualizar last_accessed_at e accessed_by
    NEW.last_accessed_at = now();
    NEW.accessed_by = auth.uid();
    
    -- Log no audit
    INSERT INTO public.audit_log (user_id, action, table_name, record_id, details)
    VALUES (
        COALESCE(auth.uid(), '00000000-0000-0000-0000-000000000000'::uuid),
        TG_OP,
        TG_TABLE_NAME,
        NEW.id,
        jsonb_build_object('accessed_user_id', NEW.user_id)
    );
    
    RETURN NEW;
END;
$$;

-- Aplicar trigger para user_sensitive_data
DROP TRIGGER IF EXISTS audit_sensitive_access ON public.user_sensitive_data;
CREATE TRIGGER audit_sensitive_access
    BEFORE UPDATE ON public.user_sensitive_data
    FOR EACH ROW
    EXECUTE FUNCTION public.audit_sensitive_data_access();
