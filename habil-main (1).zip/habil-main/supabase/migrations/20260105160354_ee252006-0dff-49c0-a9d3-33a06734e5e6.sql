-- Create table for instructor blocked time slots
CREATE TABLE public.instructor_blocked_slots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  instructor_id UUID NOT NULL,
  blocked_date DATE NOT NULL,
  blocked_time TIME WITHOUT TIME ZONE NOT NULL,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.instructor_blocked_slots ENABLE ROW LEVEL SECURITY;

-- Create unique constraint to prevent duplicate blocks
ALTER TABLE public.instructor_blocked_slots 
ADD CONSTRAINT unique_instructor_blocked_slot 
UNIQUE (instructor_id, blocked_date, blocked_time);

-- RLS Policies
CREATE POLICY "Instructors can view own blocked slots"
ON public.instructor_blocked_slots
FOR SELECT
USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can insert own blocked slots"
ON public.instructor_blocked_slots
FOR INSERT
WITH CHECK (instructor_id = auth.uid());

CREATE POLICY "Instructors can delete own blocked slots"
ON public.instructor_blocked_slots
FOR DELETE
USING (instructor_id = auth.uid());

-- Students can view blocked slots of instructors they're linked to (for scheduling)
CREATE POLICY "Students can view instructor blocked slots for scheduling"
ON public.instructor_blocked_slots
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid()
    AND (p.linked_instructor_id = instructor_blocked_slots.instructor_id 
         OR p.pending_instructor_id = instructor_blocked_slots.instructor_id)
  )
);

-- Create index for faster lookups
CREATE INDEX idx_blocked_slots_instructor_date 
ON public.instructor_blocked_slots (instructor_id, blocked_date);