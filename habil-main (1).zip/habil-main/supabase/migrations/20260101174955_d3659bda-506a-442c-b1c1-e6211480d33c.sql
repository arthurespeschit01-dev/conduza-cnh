-- Tornar bucket instructor-documents privado
UPDATE storage.buckets 
SET public = false 
WHERE id = 'instructor-documents';