-- ============================================
-- CORREÇÕES DE SEGURANÇA ABRANGENTES
-- ============================================

-- 1. Atualizar a VIEW public_instructor_profiles para remover coordenadas precisas
-- e usar apenas bairro para localização
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  -- Mascarar WhatsApp: mostrar apenas últimos 4 dígitos
  CASE 
    WHEN p.whatsapp IS NOT NULL AND LENGTH(p.whatsapp) > 4 
    THEN '****' || RIGHT(p.whatsapp, 4)
    ELSE NULL
  END as whatsapp,
  -- Arredondar coordenadas para privacidade (precisão de ~1km)
  CASE WHEN p.latitude IS NOT NULL THEN ROUND(p.latitude::numeric, 2)::double precision ELSE NULL END as latitude,
  CASE WHEN p.longitude IS NOT NULL THEN ROUND(p.longitude::numeric, 2)::double precision ELSE NULL END as longitude
FROM profiles p
JOIN user_roles ur ON ur.user_id = p.id
WHERE 
  ur.role = 'instructor'
  AND p.registration_status = 'approved'
  AND p.payment_status = 'active';

-- 2. Atualizar a VIEW public_reviews para mascarar nomes
DROP VIEW IF EXISTS public_reviews;

CREATE VIEW public_reviews AS
SELECT 
  r.id,
  r.instructor_id,
  r.rating,
  -- Mascarar nome do avaliador: "João S."
  CASE 
    WHEN p.full_name IS NOT NULL AND LENGTH(p.full_name) > 0 
    THEN SPLIT_PART(p.full_name, ' ', 1) || ' ' || LEFT(COALESCE(SPLIT_PART(p.full_name, ' ', 2), ''), 1) || '.'
    ELSE 'Anônimo'
  END as reviewer_name,
  r.comment,
  r.created_at
FROM instructor_reviews r
LEFT JOIN profiles p ON r.student_id = p.id;

-- 3. Adicionar política para admin acessar exams
CREATE POLICY "Admins can view all exams"
ON public.exams
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all exams"
ON public.exams
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- 4. Adicionar política para admin acessar instructor_packages
CREATE POLICY "Admins can view all packages"
ON public.instructor_packages
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all packages"
ON public.instructor_packages
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- 5. Adicionar política para estudantes verem veículos do instrutor (aulas confirmadas)
CREATE POLICY "Students can view instructor vehicles for confirmed lessons"
ON public.vehicles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM schedules s
    WHERE s.instructor_id = vehicles.instructor_id
    AND s.student_id = auth.uid()
    AND s.status IN ('confirmed', 'completed')
  )
);

-- 6. Atualizar função get_instructors_by_proximity para arredondar coordenadas
CREATE OR REPLACE FUNCTION public.get_instructors_by_proximity(
  user_lat double precision, 
  user_lon double precision, 
  filter_uf text DEFAULT NULL, 
  filter_city text DEFAULT NULL, 
  max_distance_km double precision DEFAULT NULL
)
RETURNS TABLE(
  id uuid, 
  full_name text, 
  bio text, 
  avatar_url text, 
  uf text, 
  city text, 
  neighborhood text, 
  years_of_experience integer, 
  price_per_hour numeric, 
  available_days text[], 
  available_start_time time without time zone, 
  available_end_time time without time zone, 
  cnh_category text, 
  certifications text[], 
  whatsapp text,
  latitude double precision, 
  longitude double precision, 
  distance_km double precision
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pip.id,
    pip.full_name,
    pip.bio,
    pip.avatar_url,
    pip.uf,
    pip.city,
    pip.neighborhood,
    pip.years_of_experience,
    pip.price_per_hour,
    pip.available_days,
    pip.available_start_time,
    pip.available_end_time,
    pip.cnh_category::TEXT,
    pip.certifications,
    pip.whatsapp,
    -- Retornar coordenadas arredondadas da VIEW
    pip.latitude,
    pip.longitude,
    public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude) AS distance_km
  FROM public_instructor_profiles pip
  JOIN profiles p ON p.id = pip.id
  WHERE 
    (filter_uf IS NULL OR pip.uf = filter_uf)
    AND (filter_city IS NULL OR pip.city = filter_city)
    AND (
      max_distance_km IS NULL 
      OR p.latitude IS NULL 
      OR p.longitude IS NULL
      OR public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude) <= max_distance_km
    )
  ORDER BY 
    CASE 
      WHEN p.latitude IS NOT NULL AND p.longitude IS NOT NULL 
      THEN public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude)
      ELSE 999999
    END ASC;
END;
$$;