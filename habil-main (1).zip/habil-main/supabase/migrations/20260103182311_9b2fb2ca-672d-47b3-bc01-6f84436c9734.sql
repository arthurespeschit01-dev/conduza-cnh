-- Fix search_path for hash_backup_code function to include extensions
CREATE OR REPLACE FUNCTION public.hash_backup_code(plain_code TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
SET search_path = public, extensions
AS $$
  SELECT encode(extensions.digest(plain_code, 'sha256'), 'hex');
$$;