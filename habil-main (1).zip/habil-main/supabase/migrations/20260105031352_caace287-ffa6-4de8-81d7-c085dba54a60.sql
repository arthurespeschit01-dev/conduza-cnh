-- =====================================================
-- SECURITY IMPROVEMENTS MIGRATION - CORRECTED
-- =====================================================

-- 1. RESTRICT EXAM QUESTIONS - Only authenticated users
DROP POLICY IF EXISTS "Anyone can view exam questions" ON public.exam_questions;

CREATE POLICY "Authenticated users can view exam questions"
ON public.exam_questions
FOR SELECT
TO authenticated
USING (true);

-- 2. RESTRICT ACHIEVEMENTS to authenticated users only
DROP POLICY IF EXISTS "Anyone can view achievements" ON public.achievements;

CREATE POLICY "Authenticated users can view achievements"
ON public.achievements
FOR SELECT
TO authenticated
USING (true);

-- 3. Restrict exam_questions INSERT/UPDATE/DELETE to admins only
CREATE POLICY "Only admins can insert exam questions"
ON public.exam_questions
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can update exam questions"
ON public.exam_questions
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can delete exam questions"
ON public.exam_questions
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 4. Restrict achievements INSERT/UPDATE/DELETE to admins only
CREATE POLICY "Only admins can insert achievements"
ON public.achievements
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can update achievements"
ON public.achievements
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can delete achievements"
ON public.achievements
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 5. Add rate limiting table for security-sensitive operations
CREATE TABLE IF NOT EXISTS public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  ip_address text,
  attempted_at timestamp with time zone DEFAULT now(),
  success boolean DEFAULT false
);

ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

-- Only system can insert rate limits
CREATE POLICY "System can insert rate limits"
ON public.rate_limits
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Only admins can view rate limits
CREATE POLICY "Only admins can view rate limits"
ON public.rate_limits
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 6. Create a secure function for MFA code verification with rate limiting
CREATE OR REPLACE FUNCTION public.verify_mfa_code_secure(p_user_id uuid, p_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_recent_attempts integer;
  v_result boolean;
BEGIN
  -- Check rate limit (max 5 attempts per 15 minutes)
  SELECT COUNT(*) INTO v_recent_attempts
  FROM public.rate_limits
  WHERE user_id = p_user_id
    AND action_type = 'mfa_verify'
    AND attempted_at > now() - interval '15 minutes';
  
  IF v_recent_attempts >= 5 THEN
    INSERT INTO public.rate_limits (user_id, action_type, success)
    VALUES (p_user_id, 'mfa_verify_blocked', false);
    RETURN false;
  END IF;
  
  v_result := public.verify_backup_code(p_user_id, p_code);
  
  INSERT INTO public.rate_limits (user_id, action_type, success)
  VALUES (p_user_id, 'mfa_verify', v_result);
  
  RETURN v_result;
END;
$$;

-- 7. Create index for rate limit lookups
CREATE INDEX IF NOT EXISTS idx_rate_limits_user_action_time 
ON public.rate_limits (user_id, action_type, attempted_at);

-- 8. Improve package visibility policy
DROP POLICY IF EXISTS "Students can view packages of their instructors" ON public.instructor_packages;

CREATE POLICY "Authenticated users can view active packages of approved instructors"
ON public.instructor_packages
FOR SELECT
TO authenticated
USING (
  is_active = true 
  AND EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = instructor_packages.instructor_id
    AND p.registration_status = 'approved'
    AND public.has_role(p.id, 'instructor')
  )
);

CREATE POLICY "Instructors can view all own packages"
ON public.instructor_packages
FOR SELECT
TO authenticated
USING (instructor_id = auth.uid());

-- 9. Recreate public_instructor_profiles VIEW with privacy improvements
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  -- Round coordinates to ~1km precision for privacy
  ROUND(p.latitude::numeric, 2)::double precision as latitude,
  ROUND(p.longitude::numeric, 2)::double precision as longitude,
  -- Only show WhatsApp link format (not raw number)
  CASE 
    WHEN p.whatsapp IS NOT NULL THEN 'https://wa.me/' || regexp_replace(p.whatsapp, '[^0-9]', '', 'g')
    ELSE NULL
  END as whatsapp
FROM public.profiles p
WHERE p.registration_status = 'approved'
  AND public.has_role(p.id, 'instructor')
  AND p.payment_status = 'active';

GRANT SELECT ON public.public_instructor_profiles TO authenticated;

-- 10. Recreate public_reviews VIEW  
DROP VIEW IF EXISTS public.public_reviews;

CREATE VIEW public.public_reviews AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  split_part(p.full_name, ' ', 1) as reviewer_name
FROM public.instructor_reviews ir
JOIN public.profiles p ON p.id = ir.student_id
WHERE EXISTS (
  SELECT 1 FROM public.profiles instructor
  WHERE instructor.id = ir.instructor_id
  AND instructor.registration_status = 'approved'
  AND public.has_role(instructor.id, 'instructor')
);

GRANT SELECT ON public.public_reviews TO authenticated;

-- 11. Cleanup function for old rate limit records
CREATE OR REPLACE FUNCTION public.cleanup_old_rate_limits()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.rate_limits
  WHERE attempted_at < now() - interval '24 hours';
END;
$$;

-- 12. Enhanced audit trigger for sensitive data updates only
CREATE OR REPLACE FUNCTION public.log_sensitive_data_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_log (user_id, action, table_name, record_id, details)
  VALUES (
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    NEW.id,
    jsonb_build_object(
      'accessed_user_id', NEW.user_id,
      'timestamp', now()
    )
  );
  
  NEW.last_accessed_at := now();
  NEW.accessed_by := auth.uid();
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS audit_sensitive_update ON public.user_sensitive_data;

CREATE TRIGGER audit_sensitive_update
  BEFORE UPDATE ON public.user_sensitive_data
  FOR EACH ROW
  EXECUTE FUNCTION public.log_sensitive_data_update();