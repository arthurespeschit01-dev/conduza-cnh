
-- ===========================================
-- SECURITY FIX: Corrigir views SECURITY DEFINER
-- ===========================================

-- Drop as views existentes com SECURITY DEFINER
DROP VIEW IF EXISTS public.public_instructor_profiles;
DROP VIEW IF EXISTS public.public_reviews;

-- Recriar public_instructor_profiles SEM SECURITY DEFINER (usando SECURITY INVOKER)
CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true)
AS
SELECT 
    p.id,
    p.full_name,
    p.bio,
    p.avatar_url,
    p.uf,
    p.city,
    p.neighborhood,
    p.years_of_experience,
    p.price_per_hour,
    p.available_days,
    p.available_start_time,
    p.available_end_time,
    p.cnh_category,
    p.certifications,
    -- Mascarar WhatsApp para proteger privacidade
    CASE 
        WHEN p.whatsapp IS NOT NULL THEN '****' || RIGHT(p.whatsapp, 4)
        ELSE NULL 
    END AS whatsapp,
    -- Arredondar coordenadas para área aproximada (menos precisão)
    ROUND(p.latitude::numeric, 2)::double precision AS latitude,
    ROUND(p.longitude::numeric, 2)::double precision AS longitude
FROM profiles p
WHERE 
    p.registration_status = 'approved' 
    AND p.payment_status = 'active'
    AND EXISTS (
        SELECT 1 FROM user_roles ur 
        WHERE ur.user_id = p.id AND ur.role = 'instructor'
    );

-- Recriar public_reviews SEM SECURITY DEFINER
CREATE VIEW public.public_reviews 
WITH (security_invoker = true)
AS
SELECT 
    r.id,
    r.instructor_id,
    r.rating,
    -- Mascarar nome do avaliador
    CASE 
        WHEN p.full_name IS NOT NULL AND LENGTH(p.full_name) > 0 
        THEN SPLIT_PART(p.full_name, ' ', 1) || ' ' || LEFT(COALESCE(SPLIT_PART(p.full_name, ' ', 2), ''), 1) || '.'
        ELSE 'Anônimo' 
    END AS reviewer_name,
    r.comment,
    r.created_at
FROM instructor_reviews r
LEFT JOIN profiles p ON r.student_id = p.id
-- Apenas reviews de instrutores aprovados
WHERE EXISTS (
    SELECT 1 FROM profiles ip 
    WHERE ip.id = r.instructor_id 
    AND ip.registration_status = 'approved'
    AND ip.payment_status = 'active'
);

-- Garantir acesso público às views
GRANT SELECT ON public.public_instructor_profiles TO anon;
GRANT SELECT ON public.public_instructor_profiles TO authenticated;
GRANT SELECT ON public.public_reviews TO anon;
GRANT SELECT ON public.public_reviews TO authenticated;
