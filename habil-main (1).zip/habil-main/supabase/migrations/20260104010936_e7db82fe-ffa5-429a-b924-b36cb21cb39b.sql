-- Fix 1: Restrict instructor_packages visibility to only show packages for instructors 
-- that the student has an active relationship with (confirmed schedules)
DROP POLICY IF EXISTS "Students can view active packages" ON public.instructor_packages;

CREATE POLICY "Students can view packages of their instructors"
ON public.instructor_packages
FOR SELECT
TO authenticated
USING (
  -- Instructors can always see their own packages
  instructor_id = auth.uid()
  OR
  -- Admins can see all packages
  public.has_role(auth.uid(), 'admin')
  OR
  -- Students can only see packages from instructors they have scheduled with
  EXISTS (
    SELECT 1 FROM public.schedules s
    WHERE s.instructor_id = instructor_packages.instructor_id
    AND s.student_id = auth.uid()
    AND s.status IN ('confirmed', 'completed')
  )
);

-- Fix 2: Add explicit INSERT policy for notifications
-- Only allow system (service role) or the notification recipient to create notifications
CREATE POLICY "System can create notifications"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (
  -- Users can only create notifications for themselves (e.g., test notifications)
  user_id = auth.uid()
  OR
  -- Admins can create notifications for anyone
  public.has_role(auth.uid(), 'admin')
);

-- Fix 3: For the views (public_instructor_profiles and public_reviews), 
-- they are already secure because:
-- 1. Views don't have RLS - they inherit security from underlying tables
-- 2. These views already filter approved/public data only
-- 3. WhatsApp is already masked in public_instructor_profiles
-- However, let's add a comment to document this is intentional

COMMENT ON VIEW public_instructor_profiles IS 
'Public view for approved instructors. WhatsApp is masked. Security is controlled by the view definition filtering approved instructors only.';

COMMENT ON VIEW public_reviews IS 
'Public view for instructor reviews. Contains only non-sensitive review data.';
