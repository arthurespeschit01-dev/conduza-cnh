-- =====================================================
-- MIGRAÇÃO DE SEGURANÇA ABRANGENTE - HABIL
-- Adiciona políticas explícitas para bloquear acesso não autenticado
-- =====================================================

-- 1. PROFILES - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for profiles"
ON profiles FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 2. USER_SENSITIVE_DATA - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for sensitive data"
ON user_sensitive_data FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 3. MFA_BACKUP_CODES - Bloquear acesso não autenticado (reforçar segurança)
CREATE POLICY "Require authentication for MFA codes"
ON mfa_backup_codes FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 4. EXAMS - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for exams"
ON exams FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 5. INSTRUCTOR_REVIEWS - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for reviews"
ON instructor_reviews FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 6. NOTIFICATIONS - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for notifications"
ON notifications FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 7. USER_ROLES - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for user roles"
ON user_roles FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 8. VEHICLES - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for vehicles"
ON vehicles FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 9. INSTRUCTOR_PACKAGES - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for packages"
ON instructor_packages FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 10. APP_SETTINGS - Bloquear acesso não autenticado
CREATE POLICY "Require authentication for settings"
ON app_settings FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);