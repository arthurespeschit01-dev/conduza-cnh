-- Add subscription_plan to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS subscription_plan TEXT DEFAULT 'basic';

-- Create vehicles table for instructors
CREATE TABLE public.vehicles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  instructor_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  plate TEXT NOT NULL,
  color TEXT,
  vehicle_type TEXT NOT NULL DEFAULT 'car',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on vehicles
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;

-- RLS policies for vehicles
CREATE POLICY "Instructors can view own vehicles" ON public.vehicles
  FOR SELECT USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can insert own vehicles" ON public.vehicles
  FOR INSERT WITH CHECK (instructor_id = auth.uid());

CREATE POLICY "Instructors can update own vehicles" ON public.vehicles
  FOR UPDATE USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can delete own vehicles" ON public.vehicles
  FOR DELETE USING (instructor_id = auth.uid());

-- Create packages table for instructors
CREATE TABLE public.instructor_packages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  instructor_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  lesson_count INTEGER NOT NULL,
  duration_type TEXT NOT NULL DEFAULT 'custom',
  price NUMERIC NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on packages
ALTER TABLE public.instructor_packages ENABLE ROW LEVEL SECURITY;

-- RLS policies for packages
CREATE POLICY "Instructors can view own packages" ON public.instructor_packages
  FOR SELECT USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can insert own packages" ON public.instructor_packages
  FOR INSERT WITH CHECK (instructor_id = auth.uid());

CREATE POLICY "Instructors can update own packages" ON public.instructor_packages
  FOR UPDATE USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can delete own packages" ON public.instructor_packages
  FOR DELETE USING (instructor_id = auth.uid());

CREATE POLICY "Students can view active packages" ON public.instructor_packages
  FOR SELECT USING (is_active = true);

-- Add triggers for updated_at
CREATE TRIGGER update_vehicles_updated_at
  BEFORE UPDATE ON public.vehicles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_instructor_packages_updated_at
  BEFORE UPDATE ON public.instructor_packages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();