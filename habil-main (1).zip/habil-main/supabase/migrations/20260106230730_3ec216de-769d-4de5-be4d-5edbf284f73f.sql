-- Create a security definer function to get linked instructor IDs without triggering RLS
CREATE OR REPLACE FUNCTION public.get_user_instructor_ids(user_id uuid)
RETURNS TABLE(linked_id uuid, pending_id uuid)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT linked_instructor_id, pending_instructor_id
  FROM profiles
  WHERE id = user_id
$$;

-- Drop the problematic policy that causes infinite recursion
DROP POLICY IF EXISTS "Students can view their own instructor" ON profiles;

-- Recreate the policy using the security definer function
CREATE POLICY "Students can view their own instructor" 
ON profiles 
FOR SELECT 
USING (
  id IN (
    SELECT linked_id FROM get_user_instructor_ids(auth.uid())
    UNION
    SELECT pending_id FROM get_user_instructor_ids(auth.uid())
  )
);