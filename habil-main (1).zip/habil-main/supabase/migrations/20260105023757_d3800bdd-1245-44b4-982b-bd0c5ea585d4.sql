-- Create gamification stats table
CREATE TABLE public.gamification_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  points INTEGER NOT NULL DEFAULT 0,
  current_streak INTEGER NOT NULL DEFAULT 0,
  longest_streak INTEGER NOT NULL DEFAULT 0,
  last_access_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create achievements table
CREATE TABLE public.achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  icon TEXT NOT NULL,
  points_required INTEGER DEFAULT 0,
  lessons_required INTEGER DEFAULT 0,
  streak_required INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user achievements junction table
CREATE TABLE public.user_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  achievement_id UUID NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Enable RLS
ALTER TABLE public.gamification_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- Gamification stats policies
CREATE POLICY "Users can view own stats"
ON public.gamification_stats FOR SELECT
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own stats"
ON public.gamification_stats FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own stats"
ON public.gamification_stats FOR UPDATE
USING (user_id = auth.uid());

-- Achievements policies (public read)
CREATE POLICY "Anyone can view achievements"
ON public.achievements FOR SELECT
USING (true);

-- User achievements policies
CREATE POLICY "Users can view own achievements"
ON public.user_achievements FOR SELECT
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own achievements"
ON public.user_achievements FOR INSERT
WITH CHECK (user_id = auth.uid());

-- Insert default achievements
INSERT INTO public.achievements (code, title, description, icon, lessons_required, streak_required, points_required) VALUES
('first_lesson', 'Primeira Aula', 'Complete sua primeira aula prática', '🚗', 1, 0, 0),
('week_streak', '1ª Semana Completa', 'Acesse o app por 7 dias seguidos', '📅', 0, 7, 0),
('ten_lessons', '10 Aulas Feitas', 'Complete 10 aulas práticas', '🎓', 10, 0, 0),
('theory_passed', 'Exame Teórico Aprovado', 'Seja aprovado no exame teórico', '📝', 0, 0, 0),
('practical_passed', 'Exame Prático Aprovado', 'Seja aprovado no exame prático', '✅', 0, 0, 0),
('hundred_points', 'Centurião', 'Acumule 100 pontos', '💯', 0, 0, 100),
('month_streak', 'Dedicação Total', 'Acesse por 30 dias seguidos', '🔥', 0, 30, 0);

-- Create function to update streak on access
CREATE OR REPLACE FUNCTION public.update_user_streak()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- If last access was yesterday, increment streak
  IF OLD.last_access_date = CURRENT_DATE - INTERVAL '1 day' THEN
    NEW.current_streak := OLD.current_streak + 1;
    IF NEW.current_streak > OLD.longest_streak THEN
      NEW.longest_streak := NEW.current_streak;
    END IF;
  -- If last access was today, keep streak
  ELSIF OLD.last_access_date = CURRENT_DATE THEN
    NEW.current_streak := OLD.current_streak;
  -- Otherwise reset streak
  ELSE
    NEW.current_streak := 1;
  END IF;
  
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- Create trigger for streak updates
CREATE TRIGGER update_streak_on_access
BEFORE UPDATE ON public.gamification_stats
FOR EACH ROW
WHEN (NEW.last_access_date IS DISTINCT FROM OLD.last_access_date)
EXECUTE FUNCTION public.update_user_streak();