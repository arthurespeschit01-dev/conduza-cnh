-- Fix SECURITY DEFINER views - convert to SECURITY INVOKER
-- This ensures the views respect the calling user's permissions

-- 1. Recreate public_instructor_profiles as SECURITY INVOKER
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true) AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  -- Round coordinates to ~1km precision for privacy
  ROUND(p.latitude::numeric, 2)::double precision as latitude,
  ROUND(p.longitude::numeric, 2)::double precision as longitude,
  -- Only show WhatsApp link format (not raw number)
  CASE 
    WHEN p.whatsapp IS NOT NULL THEN 'https://wa.me/' || regexp_replace(p.whatsapp, '[^0-9]', '', 'g')
    ELSE NULL
  END as whatsapp
FROM public.profiles p
WHERE p.registration_status = 'approved'
  AND public.has_role(p.id, 'instructor')
  AND p.payment_status = 'active';

GRANT SELECT ON public.public_instructor_profiles TO authenticated;

-- 2. Recreate public_reviews as SECURITY INVOKER
DROP VIEW IF EXISTS public.public_reviews;

CREATE VIEW public.public_reviews 
WITH (security_invoker = true) AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  split_part(p.full_name, ' ', 1) as reviewer_name
FROM public.instructor_reviews ir
JOIN public.profiles p ON p.id = ir.student_id
WHERE EXISTS (
  SELECT 1 FROM public.profiles instructor
  WHERE instructor.id = ir.instructor_id
  AND instructor.registration_status = 'approved'
  AND public.has_role(instructor.id, 'instructor')
);

GRANT SELECT ON public.public_reviews TO authenticated;