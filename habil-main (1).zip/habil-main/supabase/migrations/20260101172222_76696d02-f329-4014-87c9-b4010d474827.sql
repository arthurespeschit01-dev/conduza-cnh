-- Adicionar novos campos de documentos na tabela profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS rg_document_url text,
ADD COLUMN IF NOT EXISTS proof_of_residence_url text;

-- Atualizar a view public_instructor_profiles (sem alterações nos campos expostos)
-- A view não precisa expor URLs de documentos pois são privados