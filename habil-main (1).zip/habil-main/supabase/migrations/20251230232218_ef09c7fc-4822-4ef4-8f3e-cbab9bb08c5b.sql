-- Criar enum para roles
CREATE TYPE public.app_role AS ENUM ('student', 'instructor', 'admin');

-- Criar enum para categoria CNH
CREATE TYPE public.cnh_category AS ENUM ('A', 'B', 'AB');

-- Criar enum para tipo de exame
CREATE TYPE public.exam_type AS ENUM ('theoretical', 'practical');

-- Criar enum para status de exame
CREATE TYPE public.exam_status AS ENUM ('pending', 'approved', 'failed');

-- Criar enum para tipo de aula
CREATE TYPE public.lesson_type AS ENUM ('theoretical', 'practical_car', 'practical_motorcycle');

-- Criar enum para status de agendamento
CREATE TYPE public.schedule_status AS ENUM ('pending', 'confirmed', 'completed', 'cancelled');

-- Tabela de perfis
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  cpf TEXT,
  cnh TEXT,
  cnh_category cnh_category,
  bio TEXT,
  avatar_url TEXT,
  uf TEXT NOT NULL DEFAULT 'SP',
  city TEXT NOT NULL DEFAULT 'São Paulo',
  price_per_hour DECIMAL(10,2),
  certifications TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tabela de roles (separada para segurança)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE(user_id, role)
);

-- Tabela de agendamentos
CREATE TABLE public.schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  instructor_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  lesson_type lesson_type NOT NULL,
  status schedule_status NOT NULL DEFAULT 'pending',
  price DECIMAL(10,2) NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tabela de exames com dupla confirmação
CREATE TABLE public.exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  instructor_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  exam_type exam_type NOT NULL,
  category cnh_category NOT NULL,
  exam_date DATE NOT NULL,
  status exam_status NOT NULL DEFAULT 'pending',
  confirmed_by_student BOOLEAN NOT NULL DEFAULT false,
  confirmed_by_instructor BOOLEAN NOT NULL DEFAULT false,
  student_passed BOOLEAN,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;

-- Função de segurança para verificar role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Policies para profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid());

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());

-- Policies para user_roles
CREATE POLICY "Users can view own roles" ON public.user_roles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all roles" ON public.user_roles
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Policies para schedules
CREATE POLICY "Students can view own schedules" ON public.schedules
  FOR SELECT TO authenticated
  USING (student_id = auth.uid());

CREATE POLICY "Instructors can view their schedules" ON public.schedules
  FOR SELECT TO authenticated
  USING (instructor_id = auth.uid());

CREATE POLICY "Students can create schedules" ON public.schedules
  FOR INSERT TO authenticated
  WITH CHECK (student_id = auth.uid());

CREATE POLICY "Students can update own schedules" ON public.schedules
  FOR UPDATE TO authenticated
  USING (student_id = auth.uid());

CREATE POLICY "Instructors can update their schedules" ON public.schedules
  FOR UPDATE TO authenticated
  USING (instructor_id = auth.uid());

-- Policies para exams
CREATE POLICY "Students can view own exams" ON public.exams
  FOR SELECT TO authenticated
  USING (student_id = auth.uid());

CREATE POLICY "Instructors can view their exams" ON public.exams
  FOR SELECT TO authenticated
  USING (instructor_id = auth.uid());

CREATE POLICY "Students can create exams" ON public.exams
  FOR INSERT TO authenticated
  WITH CHECK (student_id = auth.uid());

CREATE POLICY "Students can update own exams" ON public.exams
  FOR UPDATE TO authenticated
  USING (student_id = auth.uid());

CREATE POLICY "Instructors can update their exams" ON public.exams
  FOR UPDATE TO authenticated
  USING (instructor_id = auth.uid());

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_schedules_updated_at
  BEFORE UPDATE ON public.schedules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_exams_updated_at
  BEFORE UPDATE ON public.exams
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Função para criar profile e role automaticamente no signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, uf, city)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Usuário'),
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'uf', 'SP'),
    COALESCE(NEW.raw_user_meta_data ->> 'city', 'São Paulo')
  );
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data ->> 'role')::app_role, 'student')
  );
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();