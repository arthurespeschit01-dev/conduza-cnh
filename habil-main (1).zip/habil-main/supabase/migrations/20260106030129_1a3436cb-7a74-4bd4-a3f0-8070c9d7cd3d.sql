-- Dropar e recriar a função get_instructors_by_proximity sem o campo whatsapp

DROP FUNCTION IF EXISTS public.get_instructors_by_proximity(double precision, double precision, text, text, double precision);

CREATE OR REPLACE FUNCTION public.get_instructors_by_proximity(
  user_lat double precision, 
  user_lon double precision, 
  filter_uf text DEFAULT NULL, 
  filter_city text DEFAULT NULL, 
  max_distance_km double precision DEFAULT NULL
)
RETURNS TABLE(
  id uuid, 
  full_name text, 
  bio text, 
  avatar_url text, 
  uf text, 
  city text, 
  neighborhood text, 
  years_of_experience integer, 
  price_per_hour numeric, 
  available_days text[], 
  available_start_time time without time zone, 
  available_end_time time without time zone, 
  cnh_category text, 
  certifications text[], 
  latitude double precision, 
  longitude double precision, 
  distance_km double precision
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pip.id,
    pip.full_name,
    pip.bio,
    pip.avatar_url,
    pip.uf,
    pip.city,
    pip.neighborhood,
    pip.years_of_experience,
    pip.price_per_hour,
    pip.available_days,
    pip.available_start_time,
    pip.available_end_time,
    pip.cnh_category::TEXT,
    pip.certifications,
    pip.latitude,
    pip.longitude,
    public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude) AS distance_km
  FROM public_instructor_profiles pip
  JOIN profiles p ON p.id = pip.id
  WHERE 
    (filter_uf IS NULL OR pip.uf = filter_uf)
    AND (filter_city IS NULL OR pip.city = filter_city)
    AND (
      max_distance_km IS NULL 
      OR p.latitude IS NULL 
      OR p.longitude IS NULL
      OR public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude) <= max_distance_km
    )
  ORDER BY 
    CASE 
      WHEN p.latitude IS NOT NULL AND p.longitude IS NOT NULL 
      THEN public.calculate_distance_km(user_lat, user_lon, p.latitude, p.longitude)
      ELSE 999999
    END ASC;
END;
$$;

COMMENT ON FUNCTION public.get_instructors_by_proximity IS 'Retorna instrutores ordenados por proximidade. WhatsApp removido - usar edge function get-instructor-contact.';