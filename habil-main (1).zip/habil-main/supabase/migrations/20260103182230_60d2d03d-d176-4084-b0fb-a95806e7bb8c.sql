-- Create table for MFA backup codes
CREATE TABLE public.mfa_backup_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.mfa_backup_codes ENABLE ROW LEVEL SECURITY;

-- Users can only view their own backup codes
CREATE POLICY "Users can view their own backup codes"
ON public.mfa_backup_codes
FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert their own backup codes
CREATE POLICY "Users can insert their own backup codes"
ON public.mfa_backup_codes
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own backup codes (mark as used)
CREATE POLICY "Users can update their own backup codes"
ON public.mfa_backup_codes
FOR UPDATE
USING (auth.uid() = user_id);

-- Users can delete their own backup codes
CREATE POLICY "Users can delete their own backup codes"
ON public.mfa_backup_codes
FOR DELETE
USING (auth.uid() = user_id);

-- Create index for faster lookups
CREATE INDEX idx_mfa_backup_codes_user_id ON public.mfa_backup_codes(user_id);

-- Function to hash backup codes using pgcrypto
CREATE OR REPLACE FUNCTION public.hash_backup_code(plain_code TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT encode(digest(plain_code, 'sha256'), 'hex');
$$;

-- Function to verify backup code
CREATE OR REPLACE FUNCTION public.verify_backup_code(p_user_id UUID, p_code TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_code_id UUID;
BEGIN
  -- Find unused code that matches
  SELECT id INTO v_code_id
  FROM public.mfa_backup_codes
  WHERE user_id = p_user_id
    AND code_hash = public.hash_backup_code(p_code)
    AND used_at IS NULL
  LIMIT 1;
  
  IF v_code_id IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Mark code as used
  UPDATE public.mfa_backup_codes
  SET used_at = now()
  WHERE id = v_code_id;
  
  RETURN TRUE;
END;
$$;