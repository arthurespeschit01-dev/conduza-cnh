-- Remove the overly permissive policy that allows any authenticated user to read all profiles
DROP POLICY IF EXISTS "require_auth_for_profiles" ON public.profiles;