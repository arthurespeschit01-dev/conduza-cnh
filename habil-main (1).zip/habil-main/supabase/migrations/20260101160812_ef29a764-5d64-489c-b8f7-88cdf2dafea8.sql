-- Corrigir VIEWs para usar SECURITY INVOKER (padrão seguro)
-- Isso garante que as permissões RLS do usuário que consulta sejam respeitadas

-- Recriar VIEW de instrutores públicos com SECURITY INVOKER
DROP VIEW IF EXISTS public.public_instructor_profiles;
CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications
FROM public.profiles p
INNER JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor'
  AND p.registration_status = 'approved';

-- Recriar VIEW de reviews públicas com SECURITY INVOKER
DROP VIEW IF EXISTS public.public_reviews;
CREATE VIEW public.public_reviews 
WITH (security_invoker = true)
AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  -- Anonimizar nome do estudante (mostrar apenas inicial)
  SUBSTRING(COALESCE(p.full_name, 'Anônimo') FROM 1 FOR 1) || '***' as reviewer_name
FROM public.instructor_reviews ir
LEFT JOIN public.profiles p ON p.id = ir.student_id;