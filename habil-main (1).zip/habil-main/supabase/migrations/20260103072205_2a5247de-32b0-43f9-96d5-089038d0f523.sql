-- Remove overly permissive policies that allow any authenticated user to read all data
DROP POLICY IF EXISTS "require_auth_for_schedules" ON public.schedules;
DROP POLICY IF EXISTS "require_auth_for_vehicles" ON public.vehicles;