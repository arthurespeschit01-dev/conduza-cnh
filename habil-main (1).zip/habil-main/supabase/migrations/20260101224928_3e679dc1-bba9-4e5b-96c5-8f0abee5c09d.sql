-- Criar trigger para notificar instrutor quando novo aluno agenda aula
CREATE OR REPLACE FUNCTION public.notify_instructor_on_new_schedule()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  student_name TEXT;
  lesson_date TEXT;
BEGIN
  -- Get student name
  SELECT full_name INTO student_name
  FROM public.profiles
  WHERE id = NEW.student_id;
  
  -- Format lesson date
  lesson_date := to_char(NEW.scheduled_date, 'DD/MM/YYYY');
  
  -- Insert notification for instructor
  INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
  VALUES (
    NEW.instructor_id,
    'Novo agendamento!',
    'O aluno ' || COALESCE(student_name, 'Novo aluno') || ' agendou uma aula para ' || lesson_date || ' às ' || NEW.scheduled_time || '.',
    'new_schedule',
    NEW.id,
    'schedule'
  );
  
  RETURN NEW;
END;
$$;

-- Criar trigger para novos agendamentos
DROP TRIGGER IF EXISTS on_new_schedule ON public.schedules;
CREATE TRIGGER on_new_schedule
  AFTER INSERT ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_instructor_on_new_schedule();

-- Criar trigger para notificar quando status de cadastro muda (para instrutor)
DROP TRIGGER IF EXISTS on_instructor_status_change ON public.profiles;
CREATE TRIGGER on_instructor_status_change
  AFTER UPDATE OF registration_status ON public.profiles
  FOR EACH ROW
  WHEN (OLD.registration_status IS DISTINCT FROM NEW.registration_status)
  EXECUTE FUNCTION public.notify_instructor_on_approval();

-- Criar função para notificar aluno quando aula é confirmada pelo instrutor
CREATE OR REPLACE FUNCTION public.notify_student_on_schedule_confirmed()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  instructor_name TEXT;
  lesson_date TEXT;
BEGIN
  -- Only trigger when status changes to 'confirmed'
  IF NEW.status = 'confirmed' AND (OLD.status IS NULL OR OLD.status != 'confirmed') THEN
    -- Get instructor name
    SELECT full_name INTO instructor_name
    FROM public.profiles
    WHERE id = NEW.instructor_id;
    
    -- Format lesson date
    lesson_date := to_char(NEW.scheduled_date, 'DD/MM/YYYY');
    
    -- Insert notification for student
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.student_id,
      'Aula confirmada!',
      'O instrutor ' || COALESCE(instructor_name, 'seu instrutor') || ' confirmou sua aula do dia ' || lesson_date || '.',
      'schedule_confirmed',
      NEW.id,
      'schedule'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Criar trigger para confirmação de aula
DROP TRIGGER IF EXISTS on_schedule_confirmed ON public.schedules;
CREATE TRIGGER on_schedule_confirmed
  AFTER UPDATE OF status ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_student_on_schedule_confirmed();