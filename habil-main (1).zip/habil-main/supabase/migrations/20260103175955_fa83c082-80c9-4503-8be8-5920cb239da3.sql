-- 1. Remove the policy that exposes ALL profile fields to authenticated users
DROP POLICY IF EXISTS "Authenticated users can view approved instructor profiles" ON public.profiles;

-- 2. Enable RLS on the public_instructor_profiles view
ALTER VIEW public.public_instructor_profiles SET (security_invoker = true);

-- We need to recreate the view to enable RLS properly
-- First, let's drop and recreate with proper security

DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  -- Mask WhatsApp: show only last 4 digits
  CASE 
    WHEN p.whatsapp IS NOT NULL THEN '****' || RIGHT(p.whatsapp, 4)
    ELSE NULL
  END as whatsapp,
  -- Round coordinates to ~1km precision for privacy
  ROUND(p.latitude::numeric, 2)::double precision as latitude,
  ROUND(p.longitude::numeric, 2)::double precision as longitude
FROM profiles p
WHERE 
  p.registration_status = 'approved'
  AND p.payment_status = 'active'
  AND EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = p.id 
    AND ur.role = 'instructor'
  )
  -- Require authentication to access
  AND auth.uid() IS NOT NULL;

-- 3. Add a new policy to profiles that only allows viewing PUBLIC fields via a helper function
-- Users can see their own full profile (already exists: "Users can view own profile")
-- Admins can see all (already exists: "Admins can view all profiles")
-- For viewing other instructors, they must use the public_instructor_profiles view

COMMENT ON VIEW public.public_instructor_profiles IS 'Public view of instructor profiles with masked sensitive data. Requires authentication.';