-- Adicionar campo whatsapp na tabela profiles para instrutores
ALTER TABLE public.profiles 
ADD COLUMN whatsapp text;

-- Comentário explicativo
COMMENT ON COLUMN public.profiles.whatsapp IS 'Número de WhatsApp do instrutor para contato direto';