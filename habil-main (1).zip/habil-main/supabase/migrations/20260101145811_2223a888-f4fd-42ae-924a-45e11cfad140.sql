-- Add document_url column to exams table for proof documents
ALTER TABLE public.exams 
ADD COLUMN document_url TEXT;

-- Create storage bucket for exam documents if not exists
INSERT INTO storage.buckets (id, name, public)
VALUES ('exam-documents', 'exam-documents', false)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for exam-documents bucket
CREATE POLICY "Students can upload their own exam documents"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'exam-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Students can view their own exam documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'exam-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Instructors can view student exam documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'exam-documents'
  AND EXISTS (
    SELECT 1 FROM public.exams
    WHERE exams.instructor_id = auth.uid()
    AND exams.document_url LIKE '%' || storage.objects.name
  )
);