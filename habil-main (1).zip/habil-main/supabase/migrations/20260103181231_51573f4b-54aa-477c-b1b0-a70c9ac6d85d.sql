-- Enable pgcrypto extension for encryption
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Add encrypted CPF column
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS cpf_encrypted bytea;

-- Create a secure encryption key stored in vault (we'll use a fixed derived key)
-- The key is derived from a secret that should be stored securely
-- For production, use Supabase Vault or environment variables

-- Create function to encrypt CPF using AES-256
CREATE OR REPLACE FUNCTION public.encrypt_cpf(plain_cpf text)
RETURNS bytea
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key bytea;
BEGIN
  IF plain_cpf IS NULL OR plain_cpf = '' THEN
    RETURN NULL;
  END IF;
  
  -- Generate a consistent key from a secret (in production, use Vault)
  -- This uses a SHA-256 hash of a secret phrase as the encryption key
  encryption_key := digest('autoescola_cpf_encryption_secret_key_2024', 'sha256');
  
  -- Encrypt using AES-256-CBC with random IV
  RETURN pgp_sym_encrypt(
    plain_cpf,
    encode(encryption_key, 'hex'),
    'cipher-algo=aes256'
  );
END;
$$;

-- Create function to decrypt CPF
CREATE OR REPLACE FUNCTION public.decrypt_cpf(encrypted_cpf bytea)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key bytea;
BEGIN
  IF encrypted_cpf IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Use the same key derivation
  encryption_key := digest('autoescola_cpf_encryption_secret_key_2024', 'sha256');
  
  -- Decrypt
  RETURN pgp_sym_decrypt(
    encrypted_cpf,
    encode(encryption_key, 'hex')
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Return NULL if decryption fails (corrupted data, wrong key, etc.)
    RETURN NULL;
END;
$$;

-- Create trigger to auto-encrypt CPF on insert/update
CREATE OR REPLACE FUNCTION public.encrypt_cpf_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- If CPF is being set or updated and it's not already masked
  IF NEW.cpf IS NOT NULL AND NEW.cpf != '' AND NEW.cpf NOT LIKE '***%' THEN
    -- Encrypt the full CPF
    NEW.cpf_encrypted := public.encrypt_cpf(NEW.cpf);
    -- Mask the plain CPF (keep last 2 digits for reference)
    NEW.cpf := '***.***.***-' || RIGHT(REGEXP_REPLACE(NEW.cpf, '[^0-9]', '', 'g'), 2);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Apply trigger for new inserts/updates
DROP TRIGGER IF EXISTS encrypt_cpf_on_change ON public.profiles;
CREATE TRIGGER encrypt_cpf_on_change
BEFORE INSERT OR UPDATE OF cpf ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.encrypt_cpf_trigger();