-- Create function to notify instructor when a lesson is cancelled
CREATE OR REPLACE FUNCTION public.notify_instructor_on_lesson_cancelled()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  student_name TEXT;
  lesson_date TEXT;
BEGIN
  -- Only trigger when status changes to 'cancelled'
  IF NEW.status = 'cancelled' AND (OLD.status IS NULL OR OLD.status != 'cancelled') THEN
    -- Get student name
    SELECT full_name INTO student_name
    FROM public.profiles
    WHERE id = NEW.student_id;
    
    -- Format lesson date
    lesson_date := to_char(NEW.scheduled_date, 'DD/MM/YYYY');
    
    -- Insert notification for instructor
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.instructor_id,
      'Aula cancelada',
      COALESCE(student_name, 'Um aluno') || ' cancelou a aula do dia ' || lesson_date || ' às ' || NEW.scheduled_time || '.',
      'lesson_cancelled',
      NEW.id,
      'schedule'
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for lesson cancellation notification
DROP TRIGGER IF EXISTS on_lesson_cancelled ON public.schedules;
CREATE TRIGGER on_lesson_cancelled
  AFTER UPDATE ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_instructor_on_lesson_cancelled();