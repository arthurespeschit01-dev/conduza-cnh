-- 1. Remover política atual de SELECT em profiles que expõe todos os dados
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;

-- 2. Nova política: controle granular de acesso a profiles
CREATE POLICY "Users can view own profile or public instructor data"
ON public.profiles FOR SELECT
TO authenticated
USING (
  -- Próprio perfil
  id = auth.uid()
  -- Ou é admin
  OR has_role(auth.uid(), 'admin')
  -- Ou é instrutor aprovado (dados básicos visíveis para agendamento)
  OR (
    id IN (SELECT user_id FROM public.user_roles WHERE role = 'instructor')
    AND registration_status = 'approved'
  )
);

-- 3. Criar VIEW segura para dados públicos de instrutores (sem dados sensíveis)
CREATE OR REPLACE VIEW public.public_instructor_profiles AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications
FROM public.profiles p
INNER JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor'
  AND p.registration_status = 'approved';

-- 4. Criar VIEW anonimizada para reviews públicas
CREATE OR REPLACE VIEW public.public_reviews AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  -- Anonimizar nome do estudante (mostrar apenas inicial)
  SUBSTRING(COALESCE(p.full_name, 'Anônimo') FROM 1 FOR 1) || '***' as reviewer_name
FROM public.instructor_reviews ir
LEFT JOIN public.profiles p ON p.id = ir.student_id;

-- 5. Atualizar política de reviews para usuários autenticados
DROP POLICY IF EXISTS "Everyone can view reviews" ON public.instructor_reviews;

CREATE POLICY "Authenticated users can view reviews"
ON public.instructor_reviews FOR SELECT
TO authenticated
USING (true);

-- 6. Adicionar políticas DELETE faltantes para schedules
CREATE POLICY "Students can delete pending schedules"
ON public.schedules FOR DELETE
TO authenticated
USING (
  student_id = auth.uid() 
  AND status = 'pending'
);

CREATE POLICY "Instructors can delete pending schedules"
ON public.schedules FOR DELETE
TO authenticated
USING (
  instructor_id = auth.uid() 
  AND status = 'pending'
);

-- 7. Adicionar políticas DELETE para exams
CREATE POLICY "Students can delete pending exams"
ON public.exams FOR DELETE
TO authenticated
USING (
  student_id = auth.uid() 
  AND status = 'pending'
);

CREATE POLICY "Instructors can delete pending exams"
ON public.exams FOR DELETE
TO authenticated
USING (
  instructor_id = auth.uid() 
  AND status = 'pending'
);

-- 8. Adicionar moderação de admin para reviews
CREATE POLICY "Admins can delete reviews"
ON public.instructor_reviews FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update reviews"
ON public.instructor_reviews FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'))
WITH CHECK (has_role(auth.uid(), 'admin'));

-- 9. Adicionar política DELETE para app_settings (admin)
CREATE POLICY "Admins can delete settings"
ON public.app_settings FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- 10. Garantir que apenas o próprio usuário e admin podem ver documentos sensíveis
-- Isso é feito através da VIEW public_instructor_profiles que NÃO inclui:
-- - email, phone, cpf (dados pessoais)
-- - cnh_document_url, instructor_certificate_url (documentos)