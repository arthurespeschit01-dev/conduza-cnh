-- Drop existing policy that allows indefinite access
DROP POLICY IF EXISTS "Students can view instructor vehicles for confirmed lessons" ON public.vehicles;

-- Create improved policy with 90-day time restriction
-- Students can only see vehicle info for instructors with recent lessons (last 90 days)
CREATE POLICY "Students can view instructor vehicles for recent lessons"
ON public.vehicles 
FOR SELECT
USING (
  EXISTS (
    SELECT 1 
    FROM public.schedules s
    WHERE s.instructor_id = vehicles.instructor_id 
      AND s.student_id = auth.uid() 
      AND s.status IN ('confirmed', 'completed')
      AND s.scheduled_date >= (CURRENT_DATE - INTERVAL '90 days')
  )
);

-- Also update other policies to use authenticated role instead of public for better security
DROP POLICY IF EXISTS "Instructors can view own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Instructors can insert own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Instructors can update own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Instructors can delete own vehicles" ON public.vehicles;

-- Recreate with authenticated role
CREATE POLICY "Instructors can view own vehicles"
ON public.vehicles FOR SELECT TO authenticated
USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can insert own vehicles"
ON public.vehicles FOR INSERT TO authenticated
WITH CHECK (instructor_id = auth.uid());

CREATE POLICY "Instructors can update own vehicles"
ON public.vehicles FOR UPDATE TO authenticated
USING (instructor_id = auth.uid());

CREATE POLICY "Instructors can delete own vehicles"
ON public.vehicles FOR DELETE TO authenticated
USING (instructor_id = auth.uid());