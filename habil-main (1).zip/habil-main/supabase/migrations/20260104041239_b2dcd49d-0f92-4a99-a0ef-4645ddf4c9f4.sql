
-- =====================================================
-- MIGRAÇÃO DE DADOS SENSÍVEIS: profiles → user_sensitive_data
-- Isola CPF, CNH, URLs de documentos e Stripe IDs
-- =====================================================

-- 1. Migrar dados existentes de profiles para user_sensitive_data
INSERT INTO user_sensitive_data (
  user_id,
  cpf_encrypted,
  cpf_masked,
  cnh,
  rg_document_path,
  cnh_document_path,
  instructor_certificate_path,
  proof_of_residence_path,
  stripe_customer_id,
  stripe_subscription_id
)
SELECT 
  id as user_id,
  cpf_encrypted,
  cpf as cpf_masked,
  cnh,
  rg_document_url as rg_document_path,
  cnh_document_url as cnh_document_path,
  instructor_certificate_url as instructor_certificate_path,
  proof_of_residence_url as proof_of_residence_path,
  stripe_customer_id,
  stripe_subscription_id
FROM profiles
WHERE id NOT IN (SELECT user_id FROM user_sensitive_data)
  AND (
    cpf IS NOT NULL OR 
    cpf_encrypted IS NOT NULL OR 
    cnh IS NOT NULL OR 
    rg_document_url IS NOT NULL OR 
    cnh_document_url IS NOT NULL OR
    instructor_certificate_url IS NOT NULL OR
    proof_of_residence_url IS NOT NULL OR
    stripe_customer_id IS NOT NULL OR
    stripe_subscription_id IS NOT NULL
  );

-- 2. Atualizar registros existentes em user_sensitive_data com dados de profiles
UPDATE user_sensitive_data usd
SET 
  cpf_encrypted = COALESCE(usd.cpf_encrypted, p.cpf_encrypted),
  cpf_masked = COALESCE(usd.cpf_masked, p.cpf),
  cnh = COALESCE(usd.cnh, p.cnh),
  rg_document_path = COALESCE(usd.rg_document_path, p.rg_document_url),
  cnh_document_path = COALESCE(usd.cnh_document_path, p.cnh_document_url),
  instructor_certificate_path = COALESCE(usd.instructor_certificate_path, p.instructor_certificate_url),
  proof_of_residence_path = COALESCE(usd.proof_of_residence_path, p.proof_of_residence_url),
  stripe_customer_id = COALESCE(usd.stripe_customer_id, p.stripe_customer_id),
  stripe_subscription_id = COALESCE(usd.stripe_subscription_id, p.stripe_subscription_id),
  updated_at = now()
FROM profiles p
WHERE usd.user_id = p.id;

-- 3. Limpar dados sensíveis da tabela profiles (manter estrutura para compatibilidade)
UPDATE profiles
SET 
  cpf_encrypted = NULL,
  cpf = NULL,
  cnh = NULL,
  rg_document_url = NULL,
  cnh_document_url = NULL,
  instructor_certificate_url = NULL,
  proof_of_residence_url = NULL,
  stripe_customer_id = NULL,
  stripe_subscription_id = NULL
WHERE cpf IS NOT NULL 
   OR cpf_encrypted IS NOT NULL 
   OR cnh IS NOT NULL 
   OR rg_document_url IS NOT NULL
   OR cnh_document_url IS NOT NULL
   OR instructor_certificate_url IS NOT NULL
   OR proof_of_residence_url IS NOT NULL
   OR stripe_customer_id IS NOT NULL
   OR stripe_subscription_id IS NOT NULL;

-- 4. Adicionar comentários nas colunas para documentar a depreciação
COMMENT ON COLUMN profiles.cpf IS 'DEPRECATED: Migrado para user_sensitive_data.cpf_masked';
COMMENT ON COLUMN profiles.cpf_encrypted IS 'DEPRECATED: Migrado para user_sensitive_data.cpf_encrypted';
COMMENT ON COLUMN profiles.cnh IS 'DEPRECATED: Migrado para user_sensitive_data.cnh';
COMMENT ON COLUMN profiles.rg_document_url IS 'DEPRECATED: Migrado para user_sensitive_data.rg_document_path';
COMMENT ON COLUMN profiles.cnh_document_url IS 'DEPRECATED: Migrado para user_sensitive_data.cnh_document_path';
COMMENT ON COLUMN profiles.instructor_certificate_url IS 'DEPRECATED: Migrado para user_sensitive_data.instructor_certificate_path';
COMMENT ON COLUMN profiles.proof_of_residence_url IS 'DEPRECATED: Migrado para user_sensitive_data.proof_of_residence_path';
COMMENT ON COLUMN profiles.stripe_customer_id IS 'DEPRECATED: Migrado para user_sensitive_data.stripe_customer_id';
COMMENT ON COLUMN profiles.stripe_subscription_id IS 'DEPRECATED: Migrado para user_sensitive_data.stripe_subscription_id';
