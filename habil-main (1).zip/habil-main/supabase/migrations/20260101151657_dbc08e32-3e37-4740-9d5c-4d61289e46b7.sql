-- Atualizar role do usuário admin@habil.com para admin
UPDATE public.user_roles 
SET role = 'admin' 
WHERE user_id = '6b32d566-1ff5-41ef-b5e6-1edd513cbae3';