-- Enable realtime for profiles table to sync instructor approvals
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;