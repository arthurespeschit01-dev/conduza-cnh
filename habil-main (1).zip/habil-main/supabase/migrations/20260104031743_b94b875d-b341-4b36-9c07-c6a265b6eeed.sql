-- Fix mfa_backup_codes: Change all policies to use 'authenticated' role instead of 'public'
DROP POLICY IF EXISTS "Users can view their own backup codes" ON public.mfa_backup_codes;
DROP POLICY IF EXISTS "Users can insert their own backup codes" ON public.mfa_backup_codes;
DROP POLICY IF EXISTS "Users can update their own backup codes" ON public.mfa_backup_codes;
DROP POLICY IF EXISTS "Users can delete their own backup codes" ON public.mfa_backup_codes;

CREATE POLICY "Users can view their own backup codes"
ON public.mfa_backup_codes FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own backup codes"
ON public.mfa_backup_codes FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own backup codes"
ON public.mfa_backup_codes FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own backup codes"
ON public.mfa_backup_codes FOR DELETE TO authenticated
USING (auth.uid() = user_id);

-- Fix vehicles: Change student view policy to use 'authenticated' role and reduce window to 30 days
DROP POLICY IF EXISTS "Students can view instructor vehicles for recent lessons" ON public.vehicles;

CREATE POLICY "Students can view instructor vehicles for recent lessons"
ON public.vehicles FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM schedules s
    WHERE s.instructor_id = vehicles.instructor_id
    AND s.student_id = auth.uid()
    AND s.status IN ('confirmed', 'completed')
    AND s.scheduled_date >= (CURRENT_DATE - INTERVAL '30 days')
  )
);