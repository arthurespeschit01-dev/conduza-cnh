-- Create storage bucket for instructor documents and avatars
INSERT INTO storage.buckets (id, name, public) VALUES ('instructor-documents', 'instructor-documents', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);

-- Policies for instructor-documents bucket (private - only owner can access)
CREATE POLICY "Instructors can upload their own documents"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'instructor-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Instructors can view their own documents"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'instructor-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Instructors can update their own documents"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'instructor-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Instructors can delete their own documents"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'instructor-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Policies for avatars bucket (public viewing, but only owner can modify)
CREATE POLICY "Avatars are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload their own avatar"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can update their own avatar"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own avatar"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Add new columns to profiles for instructor documents
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS cnh_document_url text,
ADD COLUMN IF NOT EXISTS instructor_certificate_url text,
ADD COLUMN IF NOT EXISTS years_of_experience integer DEFAULT 0;