-- Corrigir Security Definer View - recriar views como SECURITY INVOKER (padrão)
-- As views devem usar as permissões do usuário que está consultando

-- Recriar public_instructor_profiles sem security definer
DROP VIEW IF EXISTS public_instructor_profiles;

CREATE VIEW public_instructor_profiles 
WITH (security_invoker = true) AS
SELECT 
    id,
    full_name,
    bio,
    avatar_url,
    uf,
    city,
    neighborhood,
    years_of_experience,
    price_per_hour,
    available_days,
    available_start_time,
    available_end_time,
    cnh_category,
    certifications,
    round(latitude::numeric, 2)::double precision AS latitude,
    round(longitude::numeric, 2)::double precision AS longitude
FROM profiles p
WHERE 
    registration_status = 'approved' 
    AND has_role(id, 'instructor'::app_role)
    AND payment_status = 'active';

-- Recriar safe_public_profiles sem security definer
DROP VIEW IF EXISTS safe_public_profiles;

CREATE VIEW safe_public_profiles 
WITH (security_invoker = true) AS
SELECT 
    id,
    full_name,
    bio,
    avatar_url,
    uf,
    city,
    neighborhood,
    years_of_experience,
    price_per_hour,
    available_days,
    available_start_time,
    available_end_time,
    cnh_category,
    certifications,
    subscription_plan,
    round(latitude::numeric, 2)::double precision AS latitude,
    round(longitude::numeric, 2)::double precision AS longitude
FROM profiles
WHERE 
    registration_status = 'approved' 
    AND has_role(id, 'instructor'::app_role)
    AND payment_status = 'active';

-- Recriar public_reviews sem security definer
DROP VIEW IF EXISTS public_reviews;

CREATE VIEW public_reviews 
WITH (security_invoker = true) AS
SELECT 
    ir.id,
    ir.instructor_id,
    ir.rating,
    ir.comment,
    ir.created_at,
    split_part(p.full_name, ' ', 1) AS reviewer_name
FROM instructor_reviews ir
JOIN profiles p ON p.id = ir.student_id
WHERE EXISTS (
    SELECT 1 FROM profiles instructor 
    WHERE instructor.id = ir.instructor_id 
    AND instructor.registration_status = 'approved'
    AND has_role(instructor.id, 'instructor'::app_role)
);

-- Adicionar comentários
COMMENT ON VIEW public_instructor_profiles IS 'View segura para perfis de instrutores. WhatsApp removido - usar edge function get-instructor-contact.';
COMMENT ON VIEW safe_public_profiles IS 'View segura para perfis públicos sem dados sensíveis.';
COMMENT ON VIEW public_reviews IS 'Reviews públicas com nomes anonimizados (apenas primeiro nome).';