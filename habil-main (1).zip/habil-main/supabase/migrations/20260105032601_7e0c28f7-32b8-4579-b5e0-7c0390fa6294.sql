-- =============================================
-- PART 3: FINAL SECURITY FIXES
-- =============================================

-- 1. Grant SELECT on views only to authenticated users (RLS is handled via underlying tables)
GRANT SELECT ON public.public_instructor_profiles TO authenticated;
REVOKE ALL ON public.public_instructor_profiles FROM anon;

GRANT SELECT ON public.public_reviews TO authenticated;
REVOKE ALL ON public.public_reviews FROM anon;

GRANT SELECT ON public.safe_public_profiles TO authenticated;
REVOKE ALL ON public.safe_public_profiles FROM anon;

-- 2. Update the policy for viewing instructor profiles to use the safe view
-- The profiles table SELECT for approved instructors is already restricted by can_view_instructor_profile()
-- But we need to ensure the function doesn't expose sensitive data

-- 3. Create a more restrictive function that only allows viewing if:
--    a) User has a schedule with the instructor, OR
--    b) Instructor is publicly approved
CREATE OR REPLACE FUNCTION public.can_view_instructor_profile(profile_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = profile_id
    AND (
      -- Approved instructors with active payment (public listing)
      (p.registration_status = 'approved' 
       AND public.has_role(p.id, 'instructor') 
       AND p.payment_status = 'active')
      OR
      -- User has a schedule with this instructor
      EXISTS (
        SELECT 1 FROM schedules s
        WHERE s.instructor_id = p.id 
        AND s.student_id = auth.uid()
      )
      OR
      -- User has an exam with this instructor
      EXISTS (
        SELECT 1 FROM exams e
        WHERE e.instructor_id = p.id 
        AND e.student_id = auth.uid()
      )
    )
  );
$$;

-- 4. Add policy to ensure linked_instructor_id can't be arbitrarily set
-- Users can only set their own linked_instructor_id, not be "linked" to by others
DROP POLICY IF EXISTS "Instructors can view their linked students" ON public.profiles;

CREATE POLICY "Instructors can view verified linked students"
ON public.profiles FOR SELECT TO authenticated
USING (
  (linked_instructor_id = auth.uid() OR pending_instructor_id = auth.uid())
  AND
  -- Verify there's an actual schedule/exam relationship
  (
    EXISTS (
      SELECT 1 FROM schedules s
      WHERE s.instructor_id = auth.uid() 
      AND s.student_id = profiles.id
    )
    OR
    EXISTS (
      SELECT 1 FROM exams e
      WHERE e.instructor_id = auth.uid() 
      AND e.student_id = profiles.id
    )
  )
);