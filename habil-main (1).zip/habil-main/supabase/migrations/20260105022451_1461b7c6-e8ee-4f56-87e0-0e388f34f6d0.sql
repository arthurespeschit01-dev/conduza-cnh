-- Create function to notify on lesson reschedule
CREATE OR REPLACE FUNCTION public.notify_on_lesson_rescheduled()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  instructor_name TEXT;
  student_name TEXT;
  old_lesson_date TEXT;
  new_lesson_date TEXT;
BEGIN
  -- Only trigger when date or time changes and status is reset to pending (indicates reschedule)
  IF (NEW.scheduled_date != OLD.scheduled_date OR NEW.scheduled_time != OLD.scheduled_time) 
     AND NEW.status = 'pending' AND OLD.status != 'pending' THEN
    
    -- Get instructor name
    SELECT full_name INTO instructor_name
    FROM public.profiles
    WHERE id = NEW.instructor_id;
    
    -- Get student name
    SELECT full_name INTO student_name
    FROM public.profiles
    WHERE id = NEW.student_id;
    
    -- Format dates
    old_lesson_date := to_char(OLD.scheduled_date, 'DD/MM/YYYY');
    new_lesson_date := to_char(NEW.scheduled_date, 'DD/MM/YYYY');
    
    -- Notify student about reschedule
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.student_id,
      'Aula reagendada',
      'Sua aula do dia ' || old_lesson_date || ' foi reagendada para ' || new_lesson_date || ' às ' || NEW.scheduled_time || '.',
      'lesson_rescheduled',
      NEW.id,
      'schedule'
    );
    
    -- Notify instructor about reschedule (in case student rescheduled)
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.instructor_id,
      'Aula reagendada',
      COALESCE(student_name, 'Um aluno') || ' reagendou a aula do dia ' || old_lesson_date || ' para ' || new_lesson_date || ' às ' || NEW.scheduled_time || '.',
      'lesson_rescheduled',
      NEW.id,
      'schedule'
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for reschedule notifications
DROP TRIGGER IF EXISTS on_lesson_rescheduled ON public.schedules;
CREATE TRIGGER on_lesson_rescheduled
  AFTER UPDATE ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_on_lesson_rescheduled();