-- Fix the encryption functions to use correct pgcrypto function calls
CREATE OR REPLACE FUNCTION public.encrypt_cpf(plain_cpf text)
RETURNS bytea
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  encryption_key text;
BEGIN
  IF plain_cpf IS NULL OR plain_cpf = '' THEN
    RETURN NULL;
  END IF;
  
  -- Use a fixed passphrase for symmetric encryption
  encryption_key := 'autoescola_cpf_encryption_secret_key_2024_secure';
  
  -- Encrypt using PGP symmetric encryption (AES-256)
  RETURN pgp_sym_encrypt(plain_cpf, encryption_key);
END;
$$;

-- Fix decrypt function
CREATE OR REPLACE FUNCTION public.decrypt_cpf(encrypted_cpf bytea)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  encryption_key text;
BEGIN
  IF encrypted_cpf IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Use the same passphrase
  encryption_key := 'autoescola_cpf_encryption_secret_key_2024_secure';
  
  -- Decrypt
  RETURN pgp_sym_decrypt(encrypted_cpf, encryption_key);
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;