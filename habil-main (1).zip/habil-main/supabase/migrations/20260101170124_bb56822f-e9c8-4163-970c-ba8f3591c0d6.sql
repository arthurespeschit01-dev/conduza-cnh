-- Recriar view public_instructor_profiles com security_invoker = true
-- A view só acessa dados não-sensíveis, então pode usar security invoker
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.full_name,
  p.avatar_url,
  p.bio,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.cnh_category,
  p.certifications,
  p.available_days,
  p.available_start_time,
  p.available_end_time
FROM public.profiles p
JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor'::app_role 
AND p.registration_status = 'approved';

-- Conceder acesso à view
GRANT SELECT ON public.public_instructor_profiles TO anon, authenticated;

-- Adicionar política RLS em profiles para permitir acesso via view aos instrutores aprovados
-- Esta política permite SELECT apenas nos campos que a view expõe
CREATE POLICY "Public can view approved instructor basic data"
ON public.profiles
FOR SELECT
TO anon, authenticated
USING (
  registration_status = 'approved' 
  AND has_role(id, 'instructor'::app_role)
);