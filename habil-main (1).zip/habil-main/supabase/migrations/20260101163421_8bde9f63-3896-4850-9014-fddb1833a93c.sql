-- =====================================================
-- FIX: Change views to SECURITY INVOKER (default, safer)
-- =====================================================

-- Recreate public_instructor_profiles view with SECURITY INVOKER
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.full_name,
  p.avatar_url,
  p.bio,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.cnh_category,
  p.certifications,
  p.available_days,
  p.available_start_time,
  p.available_end_time
FROM public.profiles p
INNER JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor' 
  AND p.registration_status = 'approved';

-- Grant access to the view
GRANT SELECT ON public.public_instructor_profiles TO authenticated;
GRANT SELECT ON public.public_instructor_profiles TO anon;

-- Recreate public_reviews view with SECURITY INVOKER
DROP VIEW IF EXISTS public.public_reviews;

CREATE VIEW public.public_reviews
WITH (security_invoker = true)
AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  p.full_name as reviewer_name
FROM public.instructor_reviews ir
LEFT JOIN public.profiles p ON p.id = ir.student_id;

-- Grant access to the view
GRANT SELECT ON public.public_reviews TO authenticated;
GRANT SELECT ON public.public_reviews TO anon;