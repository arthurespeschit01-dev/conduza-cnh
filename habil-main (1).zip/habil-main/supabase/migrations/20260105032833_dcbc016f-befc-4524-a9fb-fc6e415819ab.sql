-- =============================================
-- PART 4: DOCUMENT SECURITY MODEL
-- =============================================

-- Add comments to document the security model
COMMENT ON VIEW public.public_instructor_profiles IS 
'Secure view for public instructor listings. Exposes only non-PII fields: name, bio, city, price, availability. GPS rounded to ~1km. WhatsApp as wa.me link only. Email/phone NOT exposed. Access: authenticated users only.';

COMMENT ON VIEW public.safe_public_profiles IS 
'Alternative secure view without WhatsApp field. For maximum privacy contexts.';

COMMENT ON FUNCTION public.can_view_instructor_profile(uuid) IS 
'Security function to check if user can view instructor profile. Allows: approved instructors (public), users with schedules/exams with the instructor.';