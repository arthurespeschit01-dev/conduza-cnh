-- Create storage bucket for exam documents if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'exam-documents',
  'exam-documents',
  false,
  5242880, -- 5MB limit
  ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for exam documents
CREATE POLICY "Users can upload their own exam documents"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'exam-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own exam documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'exam-documents' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admins can view all exam documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'exam-documents' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Instructors can view exam documents for their students"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'exam-documents' 
  AND EXISTS (
    SELECT 1 FROM exams e
    WHERE e.instructor_id = auth.uid()
    AND e.document_url = name
  )
);