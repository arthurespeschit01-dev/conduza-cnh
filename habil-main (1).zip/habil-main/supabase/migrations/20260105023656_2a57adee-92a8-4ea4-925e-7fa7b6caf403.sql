-- Create trigger function to notify instructor on exam result registration
CREATE OR REPLACE FUNCTION public.notify_instructor_on_exam_result()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  student_name TEXT;
  exam_date TEXT;
  result_text TEXT;
BEGIN
  -- Get student name
  SELECT full_name INTO student_name
  FROM public.profiles
  WHERE id = NEW.student_id;
  
  -- Format exam date
  exam_date := to_char(NEW.exam_date, 'DD/MM/YYYY');
  
  -- Determine result text
  IF NEW.result = 'approved' THEN
    result_text := 'foi APROVADO(A)';
  ELSE
    result_text := 'foi REPROVADO(A)';
  END IF;
  
  -- Insert notification for instructor
  INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
  VALUES (
    NEW.instructor_id,
    'Resultado de exame registrado',
    COALESCE(student_name, 'Um aluno') || ' registrou o resultado do exame prático do dia ' || exam_date || ' e ' || result_text || '.',
    'exam_result',
    NEW.id,
    'exam'
  );
  
  RETURN NEW;
END;
$function$;

-- Create trigger
CREATE TRIGGER notify_instructor_on_exam_result
AFTER INSERT ON public.exams
FOR EACH ROW
EXECUTE FUNCTION public.notify_instructor_on_exam_result();