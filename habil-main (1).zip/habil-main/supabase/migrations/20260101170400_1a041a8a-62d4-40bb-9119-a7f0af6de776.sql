-- Recriar view com security_invoker = false para bypass de RLS
-- Isso é seguro porque a view só expõe campos não-sensíveis
DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = false)
AS
SELECT 
  p.id,
  p.full_name,
  p.avatar_url,
  p.bio,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.cnh_category,
  p.certifications,
  p.available_days,
  p.available_start_time,
  p.available_end_time
FROM public.profiles p
JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor'::app_role 
AND p.registration_status = 'approved';

-- Conceder acesso à view
GRANT SELECT ON public.public_instructor_profiles TO anon, authenticated;