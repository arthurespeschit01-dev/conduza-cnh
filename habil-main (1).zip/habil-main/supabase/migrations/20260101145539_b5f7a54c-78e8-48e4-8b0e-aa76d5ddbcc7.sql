-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  is_read BOOLEAN NOT NULL DEFAULT false,
  related_id UUID,
  related_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users can only view their own notifications
CREATE POLICY "Users can view own notifications"
ON public.notifications
FOR SELECT
USING (user_id = auth.uid());

-- Users can update their own notifications (mark as read)
CREATE POLICY "Users can update own notifications"
ON public.notifications
FOR UPDATE
USING (user_id = auth.uid());

-- Users can delete their own notifications
CREATE POLICY "Users can delete own notifications"
ON public.notifications
FOR DELETE
USING (user_id = auth.uid());

-- System can insert notifications (via service role)
CREATE POLICY "System can insert notifications"
ON public.notifications
FOR INSERT
WITH CHECK (true);

-- Create function to notify instructor when lesson is completed
CREATE OR REPLACE FUNCTION public.notify_instructor_on_lesson_complete()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  student_name TEXT;
  lesson_date TEXT;
BEGIN
  -- Only trigger when status changes to 'completed'
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Get student name
    SELECT full_name INTO student_name
    FROM public.profiles
    WHERE id = NEW.student_id;
    
    -- Format lesson date
    lesson_date := to_char(NEW.scheduled_date, 'DD/MM/YYYY');
    
    -- Insert notification for instructor
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.instructor_id,
      'Aula concluída',
      student_name || ' marcou a aula de ' || lesson_date || ' como concluída.',
      'lesson_completed',
      NEW.id,
      'schedule'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger on schedules table
CREATE TRIGGER on_lesson_completed
  AFTER UPDATE ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_instructor_on_lesson_complete();