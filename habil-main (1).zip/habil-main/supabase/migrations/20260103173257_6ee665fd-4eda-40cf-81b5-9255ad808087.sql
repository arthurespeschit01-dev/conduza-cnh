-- CORREÇÃO DE SEGURANÇA: Restringir acesso à view public_instructor_profiles
-- Problema: A view permite acesso anônimo aos dados de instrutores

-- Primeiro, drop a view existente
DROP VIEW IF EXISTS public.public_instructor_profiles;

-- Recriar a view com SECURITY INVOKER para respeitar RLS
CREATE VIEW public.public_instructor_profiles 
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.full_name,
  p.bio,
  p.avatar_url,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.available_days,
  p.available_start_time,
  p.available_end_time,
  p.cnh_category,
  p.certifications,
  -- WhatsApp mascarado para proteção (completo apenas via edge function autenticada)
  CASE 
    WHEN p.whatsapp IS NOT NULL AND length(p.whatsapp) > 4 
    THEN '****' || right(p.whatsapp, 4)
    ELSE NULL
  END AS whatsapp,
  -- Coordenadas arredondadas para privacidade de localização exata
  CASE 
    WHEN p.latitude IS NOT NULL 
    THEN round(p.latitude::numeric, 2)::double precision
    ELSE NULL
  END AS latitude,
  CASE 
    WHEN p.longitude IS NOT NULL 
    THEN round(p.longitude::numeric, 2)::double precision
    ELSE NULL
  END AS longitude
FROM profiles p
JOIN user_roles ur ON ur.user_id = p.id
WHERE 
  ur.role = 'instructor'
  AND p.registration_status = 'approved'
  AND p.payment_status = 'active';

-- Adicionar política RLS para a view (requer que seja materializada ou use RLS na tabela base)
-- Como a view usa SECURITY INVOKER, ela respeitará as políticas RLS da tabela profiles

-- Criar uma política específica para permitir visualização de perfis públicos de instrutores
-- Apenas usuários autenticados podem ver perfis de instrutores aprovados
CREATE POLICY "Authenticated users can view approved instructor profiles"
ON public.profiles
FOR SELECT
USING (
  -- O próprio usuário sempre pode ver seu perfil
  id = auth.uid()
  OR 
  -- Usuários autenticados podem ver perfis de instrutores aprovados (apenas campos públicos via view)
  (
    auth.uid() IS NOT NULL 
    AND registration_status = 'approved'
    AND payment_status = 'active'
    AND EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_roles.user_id = profiles.id 
      AND user_roles.role = 'instructor'
    )
  )
);