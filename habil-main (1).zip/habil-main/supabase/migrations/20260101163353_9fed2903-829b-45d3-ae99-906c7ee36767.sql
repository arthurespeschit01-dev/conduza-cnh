-- =====================================================
-- SECURITY FIX: Protect notifications table INSERT
-- =====================================================

-- Drop the insecure INSERT policy
DROP POLICY IF EXISTS "Users can create own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can insert own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can create notifications" ON public.notifications;
DROP POLICY IF EXISTS "System can insert notifications" ON public.notifications;

-- Create SECURITY DEFINER function for system notifications
CREATE OR REPLACE FUNCTION public.create_system_notification(
  p_user_id UUID,
  p_title TEXT,
  p_message TEXT,
  p_type TEXT DEFAULT 'info',
  p_related_id UUID DEFAULT NULL,
  p_related_type TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_notification_id UUID;
BEGIN
  INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
  VALUES (p_user_id, p_title, p_message, p_type, p_related_id, p_related_type)
  RETURNING id INTO v_notification_id;
  
  RETURN v_notification_id;
END;
$$;

-- Allow only SECURITY DEFINER functions and triggers to insert notifications
-- No user can directly insert notifications
-- Triggers already bypass RLS when defined with SECURITY DEFINER

-- =====================================================
-- Add DELETE policy for profiles table
-- =====================================================

-- Add explicit DELETE policy - only admins can delete profiles
DROP POLICY IF EXISTS "Only admins can delete profiles" ON public.profiles;

CREATE POLICY "Only admins can delete profiles"
ON public.profiles
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- =====================================================
-- Recreate public_instructor_profiles view with correct columns
-- =====================================================

DROP VIEW IF EXISTS public.public_instructor_profiles;

CREATE VIEW public.public_instructor_profiles AS
SELECT 
  p.id,
  p.full_name,
  p.avatar_url,
  p.bio,
  p.uf,
  p.city,
  p.neighborhood,
  p.years_of_experience,
  p.price_per_hour,
  p.cnh_category,
  p.certifications,
  p.available_days,
  p.available_start_time,
  p.available_end_time
FROM public.profiles p
INNER JOIN public.user_roles ur ON ur.user_id = p.id
WHERE ur.role = 'instructor' 
  AND p.registration_status = 'approved';

-- Grant access to the view
GRANT SELECT ON public.public_instructor_profiles TO authenticated;
GRANT SELECT ON public.public_instructor_profiles TO anon;

-- =====================================================
-- Recreate public_reviews view with correct columns
-- =====================================================

DROP VIEW IF EXISTS public.public_reviews;

CREATE VIEW public.public_reviews AS
SELECT 
  ir.id,
  ir.instructor_id,
  ir.rating,
  ir.comment,
  ir.created_at,
  p.full_name as reviewer_name
FROM public.instructor_reviews ir
LEFT JOIN public.profiles p ON p.id = ir.student_id;

-- Grant access to the view
GRANT SELECT ON public.public_reviews TO authenticated;
GRANT SELECT ON public.public_reviews TO anon;