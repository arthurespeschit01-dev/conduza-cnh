-- Create function to notify instructor on approval
CREATE OR REPLACE FUNCTION public.notify_instructor_on_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Only trigger when status changes to 'approved'
  IF NEW.registration_status = 'approved' AND (OLD.registration_status IS NULL OR OLD.registration_status != 'approved') THEN
    -- Insert notification for the instructor
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.id,
      'Cadastro aprovado!',
      'Parabéns! Seu cadastro foi aprovado. Agora você já pode receber alunos na plataforma.',
      'approval',
      NEW.id,
      'profile'
    );
  END IF;
  
  -- Also notify when rejected
  IF NEW.registration_status = 'rejected' AND (OLD.registration_status IS NULL OR OLD.registration_status != 'rejected') THEN
    INSERT INTO public.notifications (user_id, title, message, type, related_id, related_type)
    VALUES (
      NEW.id,
      'Cadastro não aprovado',
      'Infelizmente seu cadastro não foi aprovado. Entre em contato com o suporte para mais informações.',
      'rejection',
      NEW.id,
      'profile'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger on profiles table
DROP TRIGGER IF EXISTS on_instructor_approval ON public.profiles;
CREATE TRIGGER on_instructor_approval
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_instructor_on_approval();