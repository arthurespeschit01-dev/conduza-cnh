-- Remover políticas RLS duplicadas/conflitantes da tabela profiles
DROP POLICY IF EXISTS "Anyone can view public instructor profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile or public instructor data" ON public.profiles;