-- Add payment_status column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS payment_status text NOT NULL DEFAULT 'pending' 
CHECK (payment_status IN ('active', 'pending', 'expired'));

-- Update subscription_plan to use new values if needed
-- Ensure subscription_plan has correct values
ALTER TABLE public.profiles 
DROP CONSTRAINT IF EXISTS profiles_subscription_plan_check;

ALTER TABLE public.profiles 
ADD CONSTRAINT profiles_subscription_plan_check 
CHECK (subscription_plan IN ('basic', 'professional', 'premium'));

-- Set default values for existing instructors
UPDATE public.profiles 
SET payment_status = 'active' 
WHERE subscription_plan IS NOT NULL 
AND payment_status = 'pending';