import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEED-SCHEDULES] ${step}${detailsStr}`);
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Starting schedules seed process");

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // SECURITY: Require admin authentication for seed functions
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("ERROR: No authorization header");
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !userData?.user) {
      logStep("ERROR: Invalid token", { error: userError?.message });
      return new Response(
        JSON.stringify({ error: "Invalid authentication token" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    // Verify admin role
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id)
      .eq("role", "admin")
      .maybeSingle();
    
    if (roleError || !roleData) {
      logStep("ERROR: Not an admin", { userId: userData.user.id });
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 403,
        }
      );
    }

    logStep("Admin verified", { userId: userData.user.id });

    // Get test students
    const { data: students, error: studentsError } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email")
      .in("email", ["maria@teste.conduza.com", "pedro@teste.conduza.com", "lucas@teste.conduza.com"]);

    if (studentsError || !students?.length) {
      throw new Error(`Error fetching students: ${studentsError?.message || "No students found"}`);
    }
    logStep(`Found ${students.length} test students`);

    // Get test instructors
    const { data: instructors, error: instructorsError } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email, price_per_hour")
      .in("email", [
        "carlos@teste.conduza.com",
        "ana@teste.conduza.com", 
        "roberto@teste.conduza.com",
        "fernanda@teste.conduza.com",
        "joao@teste.conduza.com"
      ]);

    if (instructorsError || !instructors?.length) {
      throw new Error(`Error fetching instructors: ${instructorsError?.message || "No instructors found"}`);
    }
    logStep(`Found ${instructors.length} test instructors`);

    const schedulesCreated: Array<{
      student: string;
      instructor: string;
      date: string;
      time: string;
      status: string;
      type: string;
    }> = [];
    const today = new Date();
    
    // Schedule configurations
    const scheduleConfigs = [
      // Past completed lessons
      { daysOffset: -14, status: "completed", time: "09:00", lessonType: "practical_car" },
      { daysOffset: -10, status: "completed", time: "10:00", lessonType: "practical_car" },
      { daysOffset: -7, status: "completed", time: "14:00", lessonType: "practical_car" },
      { daysOffset: -5, status: "completed", time: "11:00", lessonType: "theoretical" },
      { daysOffset: -3, status: "completed", time: "15:00", lessonType: "practical_car" },
      
      // Recent confirmed lessons
      { daysOffset: -1, status: "confirmed", time: "08:00", lessonType: "practical_car" },
      { daysOffset: 0, status: "confirmed", time: "10:00", lessonType: "practical_car" },
      { daysOffset: 1, status: "confirmed", time: "14:00", lessonType: "practical_car" },
      { daysOffset: 2, status: "confirmed", time: "09:00", lessonType: "theoretical" },
      
      // Upcoming pending lessons
      { daysOffset: 3, status: "pending", time: "11:00", lessonType: "practical_car" },
      { daysOffset: 5, status: "pending", time: "15:00", lessonType: "practical_car" },
      { daysOffset: 7, status: "pending", time: "08:00", lessonType: "practical_car" },
      { daysOffset: 10, status: "pending", time: "16:00", lessonType: "theoretical" },
      
      // Some cancelled for variety
      { daysOffset: -2, status: "cancelled", time: "13:00", lessonType: "practical_car" },
    ];

    const notes = [
      "Aula prática - estacionamento",
      "Foco em baliza e ladeira",
      "Revisão geral para prova",
      "Primeira aula - conhecendo o veículo",
      "Treino de percurso",
      "Aula de simulador - situações de risco",
      "Prática em ruas movimentadas",
      "Revisão teórica - placas de trânsito",
      null,
      null,
    ];

    let configIndex = 0;

    // Create schedules pairing students with instructors
    for (const student of students) {
      // Each student gets lessons with 2 different instructors
      const assignedInstructors = instructors.slice(0, 2);
      
      for (const instructor of assignedInstructors) {
        // Create 3-4 schedules per student-instructor pair
        const numSchedules = Math.floor(Math.random() * 2) + 3;
        
        for (let i = 0; i < numSchedules; i++) {
          const config = scheduleConfigs[configIndex % scheduleConfigs.length];
          configIndex++;
          
          const scheduleDate = new Date(today);
          scheduleDate.setDate(scheduleDate.getDate() + config.daysOffset);
          const dateStr = scheduleDate.toISOString().split("T")[0];
          
          // Check if schedule already exists
          const { data: existing } = await supabaseAdmin
            .from("schedules")
            .select("id")
            .eq("student_id", student.id)
            .eq("instructor_id", instructor.id)
            .eq("scheduled_date", dateStr)
            .eq("scheduled_time", config.time)
            .maybeSingle();

          if (existing) {
            logStep(`Schedule already exists for ${student.full_name} with ${instructor.full_name} on ${dateStr}`);
            continue;
          }

          const { error: scheduleError } = await supabaseAdmin
            .from("schedules")
            .insert({
              student_id: student.id,
              instructor_id: instructor.id,
              scheduled_date: dateStr,
              scheduled_time: config.time,
              status: config.status,
              lesson_type: config.lessonType,
              price: instructor.price_per_hour || 80,
              notes: notes[Math.floor(Math.random() * notes.length)],
            });

          if (scheduleError) {
            logStep(`Error creating schedule: ${scheduleError.message}`);
          } else {
            schedulesCreated.push({
              student: student.full_name,
              instructor: instructor.full_name,
              date: dateStr,
              time: config.time,
              status: config.status,
              type: config.lessonType,
            });
            logStep(`Created schedule: ${student.full_name} → ${instructor.full_name} (${config.status})`);
          }
        }
      }
    }

    // Summary by status
    const summary = {
      pending: schedulesCreated.filter(s => s.status === "pending").length,
      confirmed: schedulesCreated.filter(s => s.status === "confirmed").length,
      completed: schedulesCreated.filter(s => s.status === "completed").length,
      cancelled: schedulesCreated.filter(s => s.status === "cancelled").length,
    };

    logStep("Schedules seed completed", { total: schedulesCreated.length, summary });

    return new Response(
      JSON.stringify({
        success: true,
        message: `Criados ${schedulesCreated.length} agendamentos de teste`,
        summary,
        schedules: schedulesCreated,
      }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Fatal error", { error: errorMessage });
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
