import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";
import {
  getClientIp,
  checkRateLimit,
  logAccessAttempt,
  createRateLimitResponse,
} from "../_shared/security.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  // Only log in development - avoid exposing details in production
  if (Deno.env.get("ENVIRONMENT") === "development") {
    const detailsStr = details ? ` - ${JSON.stringify(details)}` : "";
    console.log(`[GET-INSTRUCTOR-CONTACT] ${step}${detailsStr}`);
  }
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
  const clientIp = getClientIp(req);

  try {
    logStep("Function started");

    // Rate limiting check
    const rateLimit = checkRateLimit(clientIp, "get-instructor-contact");
    if (!rateLimit.allowed) {
      return createRateLimitResponse(rateLimit.retryAfter!);
    }

    // Validate request body
    const { instructorId } = await req.json();
    if (!instructorId || typeof instructorId !== "string") {
      throw new Error("instructorId is required and must be a valid UUID");
    }

    // Validate UUID format
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(instructorId)) {
      throw new Error("Invalid instructor ID format");
    }

    // Initialize Supabase client for auth
    const supabaseClient = createClient(
      supabaseUrl,
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      await logAccessAttempt(supabaseUrl, serviceRoleKey, clientIp, "get-instructor-contact", null, false);
      throw new Error("Authentication required");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    
    if (userError || !userData?.user) {
      await logAccessAttempt(supabaseUrl, serviceRoleKey, clientIp, "get-instructor-contact", null, false);
      throw new Error("Invalid or expired authentication token");
    }

    const userId = userData.user.id;
    logStep("User authenticated");

    // Use service role to verify authorization and get instructor data
    const supabaseAdmin = createClient(
      supabaseUrl,
      serviceRoleKey,
      { auth: { persistSession: false } }
    );

    // SECURITY: Verify the user has a legitimate relationship with the instructor
    // They must be:
    // 1. An admin
    // 2. The instructor themselves
    // 3. A student linked to or pending with this instructor
    const { data: canAccess } = await supabaseAdmin.rpc('can_access_instructor_contact', {
      instructor_id: instructorId
    });

    if (!canAccess) {
      await logAccessAttempt(supabaseUrl, serviceRoleKey, clientIp, "get-instructor-contact", userId, false);
      return new Response(
        JSON.stringify({ error: "Você não tem permissão para acessar o contato deste instrutor" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 403,
        }
      );
    }

    // Get instructor profile (only approved and active instructors)
    const { data: instructor, error: instructorError } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, whatsapp, registration_status, payment_status")
      .eq("id", instructorId)
      .maybeSingle();

    if (instructorError) {
      throw new Error("Error fetching instructor data");
    }

    if (!instructor) {
      throw new Error("Instructor not found");
    }

    // Verify instructor is approved and has active payment
    if (instructor.registration_status !== "approved") {
      throw new Error("Instructor is not approved");
    }

    if (instructor.payment_status !== "active") {
      throw new Error("Instructor subscription is not active");
    }

    // Verify this is actually an instructor
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", instructorId)
      .eq("role", "instructor")
      .maybeSingle();

    if (roleError || !roleData) {
      throw new Error("User is not an instructor");
    }

    // Log successful access
    await logAccessAttempt(supabaseUrl, serviceRoleKey, clientIp, "get-instructor-contact", userId, true);
    logStep("Instructor contact retrieved successfully");

    // Return only the WhatsApp contact
    return new Response(
      JSON.stringify({ 
        whatsapp: instructor.whatsapp || null,
        name: instructor.full_name 
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: error instanceof Error && error.message.includes("Authentication") ? 401 : 400,
      }
    );
  }
});
