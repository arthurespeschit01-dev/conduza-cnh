import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, stripe-signature",
};

// Stripe product IDs for each plan
const PRODUCT_TO_PLAN: Record<string, string> = {
  "prod_TipBxLzxpa1cLn": "basic",
  "prod_TipBbXIdK9S4x4": "professional",
  "prod_TipCMea8R0Whpe": "premium",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[STRIPE-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Webhook received");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    if (!webhookSecret) throw new Error("STRIPE_WEBHOOK_SECRET is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const signature = req.headers.get("stripe-signature");
    if (!signature) {
      throw new Error("No Stripe signature found");
    }

    const body = await req.text();
    let event: Stripe.Event;

    try {
      event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      logStep("Webhook signature verification failed", { error: errorMessage });
      return new Response(JSON.stringify({ error: `Webhook signature verification failed: ${errorMessage}` }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    logStep("Event verified", { type: event.type, id: event.id });

    // Handle different event types
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        logStep("Checkout session completed", { sessionId: session.id, customerEmail: session.customer_email });

        if (session.mode === "subscription" && session.subscription) {
          const subscription = await stripe.subscriptions.retrieve(session.subscription as string);
          const customerId = session.customer as string;
          const customerEmail = session.customer_email || session.customer_details?.email;

          if (customerEmail) {
            const productId = subscription.items.data[0]?.price?.product as string;
            const plan = PRODUCT_TO_PLAN[productId] || "basic";

            // Update profiles for plan info
            const { error } = await supabaseClient
              .from("profiles")
              .update({
                subscription_plan: plan,
                payment_status: "active",
              })
              .eq("email", customerEmail);

            // Update user_sensitive_data with Stripe IDs
            const { data: profile } = await supabaseClient
              .from("profiles")
              .select("id")
              .eq("email", customerEmail)
              .single();
            
            if (profile) {
              await supabaseClient
                .from("user_sensitive_data")
                .upsert({
                  user_id: profile.id,
                  stripe_customer_id: customerId,
                  stripe_subscription_id: subscription.id,
                }, { onConflict: "user_id" });
            }

            if (error) {
              logStep("Error updating profile after checkout", { error: error.message });
            } else {
              logStep("Profile updated after checkout", { email: customerEmail, plan });
            }
          }
        }
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;
        
        logStep("Subscription updated", { 
          subscriptionId: subscription.id, 
          status: subscription.status,
          customerId 
        });

        // Get customer email
        const customer = await stripe.customers.retrieve(customerId);
        if (customer.deleted) {
          logStep("Customer was deleted, skipping update");
          break;
        }

        const customerEmail = customer.email;
        if (!customerEmail) {
          logStep("No customer email found, skipping update");
          break;
        }

        const productId = subscription.items.data[0]?.price?.product as string;
        const plan = PRODUCT_TO_PLAN[productId] || "basic";

        let paymentStatus = "pending";
        if (subscription.status === "active" || subscription.status === "trialing") {
          paymentStatus = "active";
        } else if (subscription.status === "canceled" || subscription.status === "unpaid") {
          paymentStatus = "expired";
        } else if (subscription.status === "past_due") {
          paymentStatus = "past_due";
        }

        // Update profiles for plan info
        const { error } = await supabaseClient
          .from("profiles")
          .update({
            subscription_plan: plan,
            payment_status: paymentStatus,
          })
          .eq("email", customerEmail);

        // Update user_sensitive_data with Stripe IDs
        const { data: profile } = await supabaseClient
          .from("profiles")
          .select("id")
          .eq("email", customerEmail)
          .single();
        
        if (profile) {
          await supabaseClient
            .from("user_sensitive_data")
            .upsert({
              user_id: profile.id,
              stripe_customer_id: customerId,
              stripe_subscription_id: subscription.id,
            }, { onConflict: "user_id" });
        }

        if (error) {
          logStep("Error updating profile", { error: error.message });
        } else {
          logStep("Profile updated", { email: customerEmail, plan, paymentStatus });
        }
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;
        
        logStep("Subscription deleted", { subscriptionId: subscription.id, customerId });

        const customer = await stripe.customers.retrieve(customerId);
        if (customer.deleted) {
          logStep("Customer was deleted, skipping update");
          break;
        }

        const customerEmail = customer.email;
        if (!customerEmail) {
          logStep("No customer email found, skipping update");
          break;
        }

        // Update profiles for payment status
        const { error } = await supabaseClient
          .from("profiles")
          .update({
            payment_status: "expired",
          })
          .eq("email", customerEmail);

        // Clear subscription ID in user_sensitive_data
        const { data: profile } = await supabaseClient
          .from("profiles")
          .select("id")
          .eq("email", customerEmail)
          .single();
        
        if (profile) {
          await supabaseClient
            .from("user_sensitive_data")
            .update({ stripe_subscription_id: null })
            .eq("user_id", profile.id);
        }

        if (error) {
          logStep("Error updating profile after cancellation", { error: error.message });
        } else {
          logStep("Profile updated after cancellation", { email: customerEmail });
        }
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;
        
        logStep("Invoice payment succeeded", { 
          invoiceId: invoice.id, 
          customerId,
          amountPaid: invoice.amount_paid 
        });

        if (invoice.subscription) {
          const customer = await stripe.customers.retrieve(customerId);
          if (customer.deleted) break;

          const customerEmail = customer.email;
          if (!customerEmail) break;

          const { error } = await supabaseClient
            .from("profiles")
            .update({
              payment_status: "active",
            })
            .eq("email", customerEmail);

          if (error) {
            logStep("Error updating profile after payment", { error: error.message });
          } else {
            logStep("Profile payment status updated to active", { email: customerEmail });
          }
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;
        
        logStep("Invoice payment failed", { 
          invoiceId: invoice.id, 
          customerId,
          attemptCount: invoice.attempt_count 
        });

        if (invoice.subscription) {
          const customer = await stripe.customers.retrieve(customerId);
          if (customer.deleted) break;

          const customerEmail = customer.email;
          if (!customerEmail) break;

          const { error } = await supabaseClient
            .from("profiles")
            .update({
              payment_status: "past_due",
            })
            .eq("email", customerEmail);

          if (error) {
            logStep("Error updating profile after failed payment", { error: error.message });
          } else {
            logStep("Profile payment status updated to past_due", { email: customerEmail });
          }
        }
        break;
      }

      default:
        logStep("Unhandled event type", { type: event.type });
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
