import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[GET-MRR-DATA] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    logStep("Stripe key verified");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");
    logStep("Authorization header found");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    
    const user = userData.user;
    if (!user?.id) throw new Error("User not authenticated");
    logStep("User authenticated", { userId: user.id });

    // Check if user is admin
    const { data: roleData, error: roleError } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .single();

    if (roleError || !roleData) {
      throw new Error("Unauthorized: Admin access required");
    }
    logStep("Admin access verified");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    // Get current date info
    const now = new Date();
    const thirtyDaysAgo = Math.floor(new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).getTime() / 1000);

    // Fetch all active subscriptions
    logStep("Fetching active subscriptions");
    const activeSubscriptions = await stripe.subscriptions.list({
      status: "active",
      limit: 100,
    });

    // Fetch recently canceled subscriptions
    logStep("Fetching canceled subscriptions");
    const canceledSubscriptions = await stripe.subscriptions.list({
      status: "canceled",
      limit: 100,
    });

    // Fetch payment intents for completed/failed payments
    logStep("Fetching payment intents");
    const paymentIntents = await stripe.paymentIntents.list({
      created: { gte: thirtyDaysAgo },
      limit: 100,
    });

    // Count completed and failed payments
    let completedPayments = 0;
    let failedPayments = 0;
    let completedAmount = 0;

    for (const pi of paymentIntents.data) {
      if (pi.status === "succeeded") {
        completedPayments++;
        completedAmount += (pi.amount || 0) / 100;
      } else if (pi.status === "canceled" || pi.status === "requires_payment_method") {
        failedPayments++;
      }
    }
    logStep("Payment intents counted", { completedPayments, failedPayments });

    // Calculate current MRR from active subscriptions
    let totalMRR = 0;
    let activeCount = 0;
    const planBreakdown: Record<string, { count: number; mrr: number }> = {
      basic: { count: 0, mrr: 0 },
      professional: { count: 0, mrr: 0 },
      premium: { count: 0, mrr: 0 },
    };

    // Stripe product IDs mapping
    const PRODUCT_TO_PLAN: Record<string, string> = {
      "prod_TipBxLzxpa1cLn": "basic",
      "prod_TipBbXIdK9S4x4": "professional",
      "prod_TipCMea8R0Whpe": "premium",
    };

    for (const sub of activeSubscriptions.data) {
      activeCount++;
      const priceItem = sub.items.data[0];
      
      // Get monthly amount (convert from cents)
      let monthlyAmount = 0;
      if (priceItem.price.recurring?.interval === "month") {
        monthlyAmount = (priceItem.price.unit_amount || 0) / 100;
      } else if (priceItem.price.recurring?.interval === "year") {
        monthlyAmount = (priceItem.price.unit_amount || 0) / 100 / 12;
      }
      
      totalMRR += monthlyAmount;

      // Categorize by plan
      const productId = priceItem.price.product as string;
      const plan = PRODUCT_TO_PLAN[productId] || "basic";
      if (planBreakdown[plan]) {
        planBreakdown[plan].count++;
        planBreakdown[plan].mrr += monthlyAmount;
      }
    }

    logStep("Active subscriptions calculated", { totalMRR, activeCount });

    // Calculate New MRR (subscriptions created in last 30 days)
    let newMRR = 0;
    let newCount = 0;
    for (const sub of activeSubscriptions.data) {
      if (sub.created >= thirtyDaysAgo) {
        const priceItem = sub.items.data[0];
        let monthlyAmount = 0;
        if (priceItem.price.recurring?.interval === "month") {
          monthlyAmount = (priceItem.price.unit_amount || 0) / 100;
        } else if (priceItem.price.recurring?.interval === "year") {
          monthlyAmount = (priceItem.price.unit_amount || 0) / 100 / 12;
        }
        newMRR += monthlyAmount;
        newCount++;
      }
    }
    logStep("New MRR calculated", { newMRR, newCount });

    // Calculate Churn (subscriptions canceled in last 30 days)
    let churn = 0;
    let churnCount = 0;
    let canceledCount = canceledSubscriptions.data.length;

    for (const sub of canceledSubscriptions.data) {
      if (sub.canceled_at && sub.canceled_at >= thirtyDaysAgo) {
        const priceItem = sub.items.data[0];
        let monthlyAmount = 0;
        if (priceItem.price.recurring?.interval === "month") {
          monthlyAmount = (priceItem.price.unit_amount || 0) / 100;
        } else if (priceItem.price.recurring?.interval === "year") {
          monthlyAmount = (priceItem.price.unit_amount || 0) / 100 / 12;
        }
        churn += monthlyAmount;
        churnCount++;
      }
    }
    logStep("Churn calculated", { churn, churnCount });

    // Expansion/Contraction MRR from invoice prorations
    let expansion = 0;
    let contraction = 0;
    let upgradeCount = 0;
    let downgradeCount = 0;

    try {
      const invoices = await stripe.invoices.list({
        created: { gte: thirtyDaysAgo },
        limit: 100,
      });

      for (const invoice of invoices.data) {
        const lines = invoice.lines?.data || [];
        for (const line of lines) {
          if (line.proration) {
            if (line.amount > 0) {
              expansion += line.amount / 100;
              upgradeCount++;
            } else if (line.amount < 0) {
              contraction += Math.abs(line.amount) / 100;
              downgradeCount++;
            }
          }
        }
      }
    } catch (e) {
      logStep("Could not fetch expansion data", { error: e });
    }
    logStep("Expansion/Contraction calculated", { expansion, contraction, upgradeCount, downgradeCount });

    const netMRR = newMRR + expansion - churn - contraction;

    // Calculate conversion rate (completed payments / total payment attempts)
    const totalPaymentAttempts = completedPayments + failedPayments;
    const conversionRate = totalPaymentAttempts > 0 
      ? Math.round((completedPayments / totalPaymentAttempts) * 10000) / 100 
      : 0;
    logStep("Conversion rate calculated", { conversionRate, totalPaymentAttempts });

    // Calculate retention rate (active subs / (active + recently canceled))
    const totalCustomersInPeriod = activeCount + churnCount;
    const retentionRate = totalCustomersInPeriod > 0 
      ? Math.round((activeCount / totalCustomersInPeriod) * 10000) / 100 
      : 100;
    
    // Churn rate is the inverse
    const churnRate = Math.round((100 - retentionRate) * 100) / 100;
    logStep("Retention/Churn rates calculated", { retentionRate, churnRate });

    const result = {
      totalMRR: Math.round(totalMRR * 100) / 100,
      activeSubscribers: activeCount,
      breakdown: {
        newMRR: Math.round(newMRR * 100) / 100,
        newCount,
        expansion: Math.round(expansion * 100) / 100,
        contraction: Math.round(contraction * 100) / 100,
        churn: Math.round(churn * 100) / 100,
        churnCount,
        netMRR: Math.round(netMRR * 100) / 100,
      },
      planBreakdown,
      payments: {
        completed: completedPayments,
        completedAmount: Math.round(completedAmount * 100) / 100,
        failed: failedPayments,
      },
      subscriptions: {
        active: activeCount,
        canceled: canceledCount,
        canceledRecent: churnCount,
        upgrades: upgradeCount,
        downgrades: downgradeCount,
      },
      rates: {
        conversion: conversionRate,
        retention: retentionRate,
        churn: churnRate,
      },
    };

    logStep("Returning result", result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});