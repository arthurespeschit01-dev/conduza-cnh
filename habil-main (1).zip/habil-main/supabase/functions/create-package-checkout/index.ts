import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: unknown) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-PACKAGE-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    logStep("Function started");

    const { packageId, instructorId } = await req.json();
    if (!packageId || !instructorId) {
      throw new Error("packageId and instructorId are required");
    }
    logStep("Request body parsed", { packageId, instructorId });

    // Get authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    logStep("User authenticated", { userId: user.id, email: user.email });

    // Fetch package details using service role key to bypass RLS
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const { data: packageData, error: packageError } = await supabaseAdmin
      .from('instructor_packages')
      .select('*')
      .eq('id', packageId)
      .eq('instructor_id', instructorId)
      .eq('is_active', true)
      .single();

    if (packageError || !packageData) {
      logStep("Package not found", { packageError });
      throw new Error("Package not found or inactive");
    }
    logStep("Package found", { packageName: packageData.name, price: packageData.price });

    // Get instructor name
    const { data: instructorData } = await supabaseAdmin
      .from('profiles')
      .select('full_name')
      .eq('id', instructorId)
      .single();

    const instructorName = instructorData?.full_name || 'Instrutor';

    // Initialize Stripe
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    
    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    // Check if customer exists
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      logStep("Found existing customer", { customerId });
    }

    // Convert price to cents
    const priceInCents = Math.round(packageData.price * 100);

    // Create a one-time payment session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: 'brl',
            product_data: {
              name: `${packageData.name} - ${instructorName}`,
              description: `${packageData.lesson_count} aulas${packageData.description ? ` | ${packageData.description}` : ''}`,
              metadata: {
                package_id: packageId,
                instructor_id: instructorId,
                student_id: user.id,
                lesson_count: String(packageData.lesson_count),
              }
            },
            unit_amount: priceInCents,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${req.headers.get("origin")}/student/dashboard?package_purchased=true`,
      cancel_url: `${req.headers.get("origin")}/student/instructors?package_cancelled=true`,
      metadata: {
        package_id: packageId,
        instructor_id: instructorId,
        student_id: user.id,
        lesson_count: String(packageData.lesson_count),
      }
    });

    logStep("Checkout session created", { sessionId: session.id, url: session.url });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
