import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEED-REVIEWS] ${step}${detailsStr}`);
};

// Test students to create
const testStudents = [
  {
    email: "maria@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Maria Fernanda Oliveira",
    uf: "SP",
    city: "São Paulo",
  },
  {
    email: "pedro@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Pedro Henrique Lima",
    uf: "RJ",
    city: "Rio de Janeiro",
  },
  {
    email: "lucas@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Lucas Gabriel Souza",
    uf: "MG",
    city: "Belo Horizonte",
  },
];

// Reviews templates - varied and realistic
const reviewTemplates = [
  { rating: 5, comment: "Excelente instrutor! Muito paciente e didático. Passei de primeira graças às aulas dele." },
  { rating: 5, comment: "Super recomendo! Explica muito bem e tem muita paciência com iniciantes." },
  { rating: 4, comment: "Ótimo profissional. As aulas são bem organizadas e aprendi bastante." },
  { rating: 5, comment: "Melhor instrutor que já tive! Fez eu perder o medo de dirigir." },
  { rating: 4, comment: "Muito bom! Pontual e profissional. Recomendo para quem quer aprender direito." },
  { rating: 5, comment: "Instrutor nota 10! Passei na prova prática sem dificuldades." },
  { rating: 4, comment: "Gostei muito das aulas. Explicações claras e ambiente tranquilo." },
  { rating: 5, comment: "Profissional incrível! Me senti segura desde a primeira aula." },
  { rating: 3, comment: "Bom instrutor, mas às vezes chegava um pouco atrasado. No geral, recomendo." },
  { rating: 5, comment: "Simplesmente o melhor! Didática excelente e muito atencioso." },
  { rating: 4, comment: "Aulas muito produtivas. Aprendi técnicas que me ajudaram muito na prova." },
  { rating: 5, comment: "Instrutor fantástico! Além de ensinar bem, é super gente boa." },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Starting reviews seed process");

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // SECURITY: Require admin authentication for seed functions
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("ERROR: No authorization header");
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !userData?.user) {
      logStep("ERROR: Invalid token", { error: userError?.message });
      return new Response(
        JSON.stringify({ error: "Invalid authentication token" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    // Verify admin role
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id)
      .eq("role", "admin")
      .maybeSingle();
    
    if (roleError || !roleData) {
      logStep("ERROR: Not an admin", { userId: userData.user.id });
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 403,
        }
      );
    }

    logStep("Admin verified", { userId: userData.user.id });

    const studentIds: string[] = [];

    // Create test students
    for (const student of testStudents) {
      logStep(`Processing student: ${student.full_name}`);

      try {
        // Check if user already exists
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers?.users?.find(u => u.email === student.email);

        let userId: string;

        if (existingUser) {
          logStep(`Student already exists: ${student.email}`);
          userId = existingUser.id;
        } else {
          // Create auth user
          const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email: student.email,
            password: student.password,
            email_confirm: true,
            user_metadata: {
              full_name: student.full_name,
              role: "student",
              uf: student.uf,
              city: student.city,
            },
          });

          if (authError) {
            throw new Error(`Auth error: ${authError.message}`);
          }

          userId = authData.user.id;
          logStep(`Created student: ${student.email}`, { id: userId });

          // Update profile
          await supabaseAdmin.from("profiles").upsert({
            id: userId,
            email: student.email,
            full_name: student.full_name,
            uf: student.uf,
            city: student.city,
          }, { onConflict: "id" });

          // Add student role
          await supabaseAdmin.from("user_roles").insert({
            user_id: userId,
            role: "student",
          });
        }

        studentIds.push(userId);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logStep(`Error creating student ${student.email}`, { error: errorMessage });
      }
    }

    logStep(`Created/found ${studentIds.length} students`);

    // Get all test instructors
    const { data: instructors, error: instructorsError } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email")
      .like("email", "%@teste.conduza.com")
      .neq("email", "maria@teste.conduza.com")
      .neq("email", "pedro@teste.conduza.com")
      .neq("email", "lucas@teste.conduza.com");

    if (instructorsError) {
      throw new Error(`Error fetching instructors: ${instructorsError.message}`);
    }

    logStep(`Found ${instructors?.length || 0} test instructors`);

    const reviewsCreated: Array<{ instructor: string; rating: number; comment: string }> = [];
    let reviewIndex = 0;

    // Create reviews for each instructor
    for (const instructor of instructors || []) {
      // Each instructor gets 2-3 reviews from different students
      const numReviews = Math.floor(Math.random() * 2) + 2; // 2-3 reviews

      for (let i = 0; i < numReviews && i < studentIds.length; i++) {
        const studentId = studentIds[i];
        const template = reviewTemplates[reviewIndex % reviewTemplates.length];
        reviewIndex++;

        // Check if review already exists
        const { data: existingReview } = await supabaseAdmin
          .from("instructor_reviews")
          .select("id")
          .eq("instructor_id", instructor.id)
          .eq("student_id", studentId)
          .maybeSingle();

        if (existingReview) {
          logStep(`Review already exists for ${instructor.full_name} from student ${i + 1}`);
          continue;
        }

        const { error: reviewError } = await supabaseAdmin
          .from("instructor_reviews")
          .insert({
            instructor_id: instructor.id,
            student_id: studentId,
            rating: template.rating,
            comment: template.comment,
          });

        if (reviewError) {
          logStep(`Error creating review: ${reviewError.message}`);
        } else {
          reviewsCreated.push({
            instructor: instructor.full_name,
            rating: template.rating,
            comment: template.comment.substring(0, 50) + "...",
          });
          logStep(`Created review for ${instructor.full_name}`);
        }
      }
    }

    logStep("Reviews seed completed", { total: reviewsCreated.length });

    return new Response(
      JSON.stringify({
        success: true,
        message: `Criados ${reviewsCreated.length} reviews de teste`,
        students: testStudents.map(s => ({ email: s.email, name: s.full_name })),
        reviews: reviewsCreated,
      }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Fatal error", { error: errorMessage });
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
