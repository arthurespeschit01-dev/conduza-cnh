import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEED-INSTRUCTORS] ${step}${detailsStr}`);
};

const testInstructors = [
  {
    email: "carlos@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Carlos Eduardo Silva",
    uf: "SP",
    city: "São Paulo",
    neighborhood: "Vila Mariana",
    subscription_plan: "premium",
    cnh_category: "AB",
    price_per_hour: 100,
    years_of_experience: 12,
    bio: "Instrutor premium com 12 anos de experiência. Especialista em habilitação para carros e motos.",
    whatsapp: "11999990001",
    latitude: -23.5874,
    longitude: -46.6426,
    available_days: ["segunda", "terça", "quarta", "quinta", "sexta"],
    available_start_time: "07:00",
    available_end_time: "19:00",
    certifications: ["Instrutor Certificado DETRAN-SP", "Especialista em Direção Defensiva", "Instrutor de Moto"],
  },
  {
    email: "ana@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Ana Paula Rodrigues",
    uf: "RJ",
    city: "Rio de Janeiro",
    neighborhood: "Copacabana",
    subscription_plan: "professional",
    cnh_category: "B",
    price_per_hour: 85,
    years_of_experience: 8,
    bio: "Instrutora profissional especializada em alunos iniciantes. Paciência e didática são meus pontos fortes.",
    whatsapp: "21999990002",
    latitude: -22.9711,
    longitude: -43.1822,
    available_days: ["segunda", "terça", "quarta", "quinta", "sexta", "sábado"],
    available_start_time: "08:00",
    available_end_time: "18:00",
    certifications: ["Instrutora Certificada DETRAN-RJ", "Curso de Primeiros Socorros"],
  },
  {
    email: "roberto@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Roberto Mendes",
    uf: "MG",
    city: "Belo Horizonte",
    neighborhood: "Savassi",
    subscription_plan: "basic",
    cnh_category: "A",
    price_per_hour: 70,
    years_of_experience: 5,
    bio: "Instrutor de moto com foco em segurança e técnica. Aulas práticas e objetivas.",
    whatsapp: "31999990003",
    latitude: -19.9352,
    longitude: -43.9308,
    available_days: ["terça", "quarta", "quinta", "sexta", "sábado"],
    available_start_time: "09:00",
    available_end_time: "17:00",
    certifications: ["Instrutor Certificado DETRAN-MG"],
  },
  {
    email: "fernanda@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "Fernanda Costa",
    uf: "RS",
    city: "Porto Alegre",
    neighborhood: "Moinhos de Vento",
    subscription_plan: "professional",
    cnh_category: "AB",
    price_per_hour: 90,
    years_of_experience: 10,
    bio: "10 anos de experiência formando motoristas seguros. Especialista em aulas para pessoas com medo de dirigir.",
    whatsapp: "51999990004",
    latitude: -30.0277,
    longitude: -51.2287,
    available_days: ["segunda", "terça", "quarta", "quinta", "sexta"],
    available_start_time: "07:30",
    available_end_time: "18:30",
    certifications: ["Instrutora Certificada DETRAN-RS", "Especialista em Direção Defensiva", "Psicologia do Trânsito"],
  },
  {
    email: "joao@teste.conduza.com",
    password: "Teste@2024!",
    full_name: "João Victor Santos",
    uf: "BA",
    city: "Salvador",
    neighborhood: "Barra",
    subscription_plan: "basic",
    cnh_category: "B",
    price_per_hour: 65,
    years_of_experience: 3,
    bio: "Jovem instrutor com didática moderna. Aulas descontraídas e eficientes.",
    whatsapp: "71999990005",
    latitude: -13.0107,
    longitude: -38.5311,
    available_days: ["segunda", "quarta", "sexta", "sábado"],
    available_start_time: "08:00",
    available_end_time: "16:00",
    certifications: ["Instrutor Certificado DETRAN-BA"],
  },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Starting seed process");

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // SECURITY: Require admin authentication for seed functions
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("ERROR: No authorization header");
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !userData?.user) {
      logStep("ERROR: Invalid token", { error: userError?.message });
      return new Response(
        JSON.stringify({ error: "Invalid authentication token" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    // Verify admin role
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id)
      .eq("role", "admin")
      .maybeSingle();
    
    if (roleError || !roleData) {
      logStep("ERROR: Not an admin", { userId: userData.user.id });
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 403,
        }
      );
    }

    logStep("Admin verified", { userId: userData.user.id });

    const results: Array<{ email: string; name: string; plan: string; uf: string; city: string; userId: string; status: string }> = [];
    const errors: Array<{ email: string; name: string; error: string }> = [];

    for (const instructor of testInstructors) {
      logStep(`Processing instructor: ${instructor.full_name}`);

      try {
        // Check if user already exists
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers?.users?.find(u => u.email === instructor.email);

        let userId: string;

        if (existingUser) {
          logStep(`User already exists: ${instructor.email}`, { id: existingUser.id });
          userId = existingUser.id;
        } else {
          // Create auth user
          const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email: instructor.email,
            password: instructor.password,
            email_confirm: true,
            user_metadata: {
              full_name: instructor.full_name,
              role: "instructor",
              uf: instructor.uf,
              city: instructor.city,
            },
          });

          if (authError) {
            throw new Error(`Auth error: ${authError.message}`);
          }

          userId = authData.user.id;
          logStep(`Created auth user: ${instructor.email}`, { id: userId });
        }

        // Update profile with all instructor data
        const { error: profileError } = await supabaseAdmin
          .from("profiles")
          .upsert({
            id: userId,
            email: instructor.email,
            full_name: instructor.full_name,
            uf: instructor.uf,
            city: instructor.city,
            neighborhood: instructor.neighborhood,
            subscription_plan: instructor.subscription_plan,
            payment_status: "active",
            registration_status: "approved",
            cnh_category: instructor.cnh_category,
            price_per_hour: instructor.price_per_hour,
            years_of_experience: instructor.years_of_experience,
            bio: instructor.bio,
            whatsapp: instructor.whatsapp,
            latitude: instructor.latitude,
            longitude: instructor.longitude,
            available_days: instructor.available_days,
            available_start_time: instructor.available_start_time,
            available_end_time: instructor.available_end_time,
            certifications: instructor.certifications,
            is_independent: true,
          }, { onConflict: "id" });

        if (profileError) {
          throw new Error(`Profile error: ${profileError.message}`);
        }
        logStep(`Updated profile: ${instructor.full_name}`);

        // Ensure instructor role exists
        const { data: existingRole } = await supabaseAdmin
          .from("user_roles")
          .select("id")
          .eq("user_id", userId)
          .eq("role", "instructor")
          .maybeSingle();

        if (!existingRole) {
          const { error: roleInsertError } = await supabaseAdmin
            .from("user_roles")
            .insert({ user_id: userId, role: "instructor" });

          if (roleInsertError && !roleInsertError.message.includes("duplicate")) {
            throw new Error(`Role error: ${roleInsertError.message}`);
          }
          logStep(`Added instructor role: ${instructor.full_name}`);
        }

        // Create sample vehicles for instructor
        const vehicles = [
          {
            instructor_id: userId,
            brand: instructor.cnh_category.includes("A") ? "Honda" : "Volkswagen",
            model: instructor.cnh_category.includes("A") ? "CG 160 Start" : "Gol 1.0",
            year: 2023,
            plate: `${instructor.uf}${Math.random().toString(36).substring(2, 5).toUpperCase()}${Math.floor(Math.random() * 9000) + 1000}`,
            color: "Branco",
            vehicle_type: instructor.cnh_category.includes("A") && !instructor.cnh_category.includes("B") ? "motorcycle" : "car",
          },
        ];

        if (instructor.cnh_category === "AB") {
          vehicles.push({
            instructor_id: userId,
            brand: "Honda",
            model: "CG 160 Start",
            year: 2022,
            plate: `${instructor.uf}${Math.random().toString(36).substring(2, 5).toUpperCase()}${Math.floor(Math.random() * 9000) + 1000}`,
            color: "Vermelho",
            vehicle_type: "motorcycle",
          });
        }

        for (const vehicle of vehicles) {
          const { error: vehicleError } = await supabaseAdmin
            .from("vehicles")
            .upsert(vehicle, { onConflict: "id", ignoreDuplicates: true });

          if (vehicleError && !vehicleError.message.includes("duplicate")) {
            logStep(`Vehicle warning: ${vehicleError.message}`);
          }
        }
        logStep(`Created vehicles for: ${instructor.full_name}`);

        // Create sample packages based on plan
        const packages = [
          {
            instructor_id: userId,
            name: "Pacote Básico",
            description: "5 aulas práticas de 50 minutos cada",
            lesson_count: 5,
            price: instructor.price_per_hour * 5 * 0.9,
            duration_type: "custom",
            is_active: true,
          },
        ];

        if (instructor.subscription_plan !== "basic") {
          packages.push({
            instructor_id: userId,
            name: "Pacote Intensivo",
            description: "10 aulas práticas + simulado incluso",
            lesson_count: 10,
            price: instructor.price_per_hour * 10 * 0.85,
            duration_type: "custom",
            is_active: true,
          });
        }

        if (instructor.subscription_plan === "premium") {
          packages.push({
            instructor_id: userId,
            name: "Pacote Premium Completo",
            description: "20 aulas práticas + 2 simulados + acompanhamento na prova",
            lesson_count: 20,
            price: instructor.price_per_hour * 20 * 0.80,
            duration_type: "custom",
            is_active: true,
          });
        }

        for (const pkg of packages) {
          const { error: packageError } = await supabaseAdmin
            .from("instructor_packages")
            .insert(pkg);

          if (packageError && !packageError.message.includes("duplicate")) {
            logStep(`Package warning: ${packageError.message}`);
          }
        }
        logStep(`Created packages for: ${instructor.full_name}`);

        results.push({
          email: instructor.email,
          name: instructor.full_name,
          plan: instructor.subscription_plan,
          uf: instructor.uf,
          city: instructor.city,
          userId,
          status: "success",
        });

      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logStep(`Error processing ${instructor.full_name}`, { error: errorMessage });
        errors.push({
          email: instructor.email,
          name: instructor.full_name,
          error: errorMessage,
        });
      }
    }

    logStep("Seed process completed", { 
      successful: results.length, 
      failed: errors.length 
    });

    return new Response(
      JSON.stringify({
        success: true,
        message: `Criados ${results.length} instrutores de teste`,
        credentials: {
          password: "Teste@2024!",
          note: "Todos usam a mesma senha",
        },
        instructors: results,
        errors: errors.length > 0 ? errors : undefined,
      }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Fatal error in seed function", { error: errorMessage });
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
