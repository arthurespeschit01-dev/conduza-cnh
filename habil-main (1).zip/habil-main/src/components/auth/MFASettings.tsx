import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useMFA } from '@/hooks/useMFA';
import { useBackupCodes } from '@/hooks/useBackupCodes';
import { useToast } from '@/hooks/use-toast';
import { MFASetupDialog } from './MFASetupDialog';
import { BackupCodesDialog } from './BackupCodesDialog';
import { Shield, ShieldCheck, ShieldOff, Loader2, Trash2, Key, RefreshCw } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export const MFASettings = () => {
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [factorId, setFactorId] = useState<string | null>(null);
  const [showSetupDialog, setShowSetupDialog] = useState(false);
  const [showDisableDialog, setShowDisableDialog] = useState(false);
  const [showRegenerateDialog, setShowRegenerateDialog] = useState(false);
  const [showNewBackupCodes, setShowNewBackupCodes] = useState(false);
  const [newBackupCodes, setNewBackupCodes] = useState<string[]>([]);
  const [isCheckingStatus, setIsCheckingStatus] = useState(true);
  const [backupCodesAvailable, setBackupCodesAvailable] = useState<number>(0);
  const { getMFAStatus, unenroll, isLoading } = useMFA();
  const { getBackupCodesStatus, regenerateBackupCodes, isLoading: isLoadingBackup } = useBackupCodes();
  const { toast } = useToast();

  const checkMFAStatus = useCallback(async () => {
    setIsCheckingStatus(true);
    const status = await getMFAStatus();
    if (status) {
      setIsEnrolled(status.isEnrolled);
      const verifiedFactor = status.factors.find(f => f.status === 'verified');
      setFactorId(verifiedFactor?.id || null);
      
      if (status.isEnrolled) {
        const backupStatus = await getBackupCodesStatus();
        if (backupStatus) {
          setBackupCodesAvailable(backupStatus.available);
        }
      }
    }
    setIsCheckingStatus(false);
  }, [getMFAStatus, getBackupCodesStatus]);

  useEffect(() => {
    checkMFAStatus();
  }, [checkMFAStatus]);

  const handleDisable = async () => {
    if (!factorId) return;

    const success = await unenroll(factorId);
    
    if (success) {
      setIsEnrolled(false);
      setFactorId(null);
      setShowDisableDialog(false);
      toast({
        title: '2FA desativado',
        description: 'A autenticação de dois fatores foi removida da sua conta.',
      });
    } else {
      toast({
        title: 'Erro',
        description: 'Não foi possível desativar o 2FA. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  const handleRegenerateBackupCodes = async () => {
    const codes = await regenerateBackupCodes();
    
    if (codes) {
      setNewBackupCodes(codes);
      setShowRegenerateDialog(false);
      setShowNewBackupCodes(true);
    } else {
      toast({
        title: 'Erro',
        description: 'Não foi possível gerar novos códigos. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  const handleBackupCodesConfirm = () => {
    setShowNewBackupCodes(false);
    setNewBackupCodes([]);
    checkMFAStatus();
    toast({
      title: 'Novos códigos gerados!',
      description: 'Seus códigos de backup anteriores foram invalidados.',
    });
  };

  if (isCheckingStatus) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Autenticação de Dois Fatores
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center gap-2">
                {isEnrolled ? (
                  <ShieldCheck className="h-5 w-5 text-green-600" />
                ) : (
                  <ShieldOff className="h-5 w-5 text-muted-foreground" />
                )}
                Autenticação de Dois Fatores (2FA)
              </CardTitle>
              <CardDescription>
                Adicione uma camada extra de segurança à sua conta
              </CardDescription>
            </div>
            <Badge variant={isEnrolled ? 'default' : 'secondary'}>
              {isEnrolled ? 'Ativado' : 'Desativado'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isEnrolled ? (
            <div className="space-y-4">
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <p className="text-sm text-green-800 dark:text-green-200">
                  Sua conta está protegida com autenticação de dois fatores. 
                  Você precisará do código do seu app autenticador sempre que fizer login.
                </p>
              </div>

              {/* Backup codes status */}
              <div className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Key className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Códigos de Backup</span>
                  </div>
                  <Badge variant={backupCodesAvailable > 3 ? 'secondary' : 'destructive'}>
                    {backupCodesAvailable} disponíveis
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Use esses códigos para acessar sua conta caso perca acesso ao seu autenticador.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowRegenerateDialog(true)}
                  disabled={isLoadingBackup}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Gerar novos códigos
                </Button>
              </div>

              <Button 
                variant="destructive" 
                onClick={() => setShowDisableDialog(true)}
                disabled={isLoading}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Desativar 2FA
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4">
                <p className="text-sm text-muted-foreground">
                  Proteja sua conta contra acessos não autorizados. 
                  Use um app autenticador como Google Authenticator ou Authy.
                </p>
              </div>
              <Button onClick={() => setShowSetupDialog(true)}>
                <Shield className="h-4 w-4 mr-2" />
                Ativar 2FA
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <MFASetupDialog
        open={showSetupDialog}
        onOpenChange={setShowSetupDialog}
        onSuccess={() => {
          checkMFAStatus();
        }}
      />

      <BackupCodesDialog
        open={showNewBackupCodes}
        onOpenChange={setShowNewBackupCodes}
        codes={newBackupCodes}
        onConfirm={handleBackupCodesConfirm}
      />

      <AlertDialog open={showDisableDialog} onOpenChange={setShowDisableDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Desativar 2FA?</AlertDialogTitle>
            <AlertDialogDescription>
              Isso vai remover a autenticação de dois fatores da sua conta. 
              Sua conta ficará menos segura. Tem certeza?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDisable}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Desativando...
                </>
              ) : (
                'Sim, desativar'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showRegenerateDialog} onOpenChange={setShowRegenerateDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Gerar novos códigos de backup?</AlertDialogTitle>
            <AlertDialogDescription>
              Isso irá invalidar todos os seus códigos de backup anteriores. 
              Certifique-se de guardar os novos códigos em um lugar seguro.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRegenerateBackupCodes}
              disabled={isLoadingBackup}
            >
              {isLoadingBackup ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Gerando...
                </>
              ) : (
                'Gerar novos códigos'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
