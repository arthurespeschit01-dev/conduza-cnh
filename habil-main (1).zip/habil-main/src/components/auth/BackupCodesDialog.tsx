import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Copy, Download, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BackupCodesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  codes: string[];
  onConfirm: () => void;
}

export const BackupCodesDialog = ({ 
  open, 
  onOpenChange, 
  codes,
  onConfirm 
}: BackupCodesDialogProps) => {
  const [hasCopied, setHasCopied] = useState(false);
  const { toast } = useToast();

  const handleCopy = () => {
    const text = codes.join('\n');
    navigator.clipboard.writeText(text);
    setHasCopied(true);
    toast({
      title: 'Códigos copiados!',
      description: 'Os códigos de backup foram copiados para a área de transferência.',
    });
  };

  const handleDownload = () => {
    const text = `CÓDIGOS DE BACKUP - CONDUZA APP\n${'='.repeat(40)}\n\nGuarde esses códigos em um lugar seguro.\nCada código só pode ser usado uma vez.\n\n${codes.map((code, i) => `${i + 1}. ${code}`).join('\n')}\n\n${'='.repeat(40)}\nGerado em: ${new Date().toLocaleString('pt-BR')}`;
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'conduza-backup-codes.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    setHasCopied(true);
    toast({
      title: 'Download iniciado!',
      description: 'O arquivo com os códigos de backup foi baixado.',
    });
  };

  const handleConfirm = () => {
    onConfirm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Códigos de Backup
          </DialogTitle>
          <DialogDescription>
            Guarde esses códigos em um lugar seguro. Eles podem ser usados para acessar sua conta caso você perca acesso ao seu app autenticador.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-muted rounded-lg p-4">
            <div className="grid grid-cols-2 gap-2">
              {codes.map((code, index) => (
                <div 
                  key={index}
                  className="font-mono text-sm bg-background rounded px-3 py-2 text-center border"
                >
                  {code}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <strong>Importante:</strong> Cada código só pode ser usado uma vez. 
              Depois de usar todos, você precisará gerar novos códigos.
            </p>
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={handleCopy}
              className="flex-1"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copiar
            </Button>
            <Button 
              variant="outline"
              onClick={handleDownload}
              className="flex-1"
            >
              <Download className="h-4 w-4 mr-2" />
              Baixar
            </Button>
          </div>

          <Button 
            onClick={handleConfirm}
            className="w-full"
            disabled={!hasCopied}
          >
            {hasCopied ? 'Concluir' : 'Copie ou baixe os códigos primeiro'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};