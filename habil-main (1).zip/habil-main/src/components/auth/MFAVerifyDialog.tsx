import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useMFA } from '@/hooks/useMFA';
import { useBackupCodes } from '@/hooks/useBackupCodes';
import { Loader2, Shield, AlertCircle, Key } from 'lucide-react';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';

interface MFAVerifyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  onCancel?: () => void;
}

type VerifyMode = 'totp' | 'backup';

export const MFAVerifyDialog = ({ 
  open, 
  onOpenChange, 
  onSuccess,
  onCancel 
}: MFAVerifyDialogProps) => {
  const [mode, setMode] = useState<VerifyMode>('totp');
  const [verificationCode, setVerificationCode] = useState('');
  const [backupCode, setBackupCode] = useState('');
  const { verifyLogin, isLoading, error, clearError } = useMFA();
  const { verifyBackupCode, isLoading: isLoadingBackup, error: backupError, clearError: clearBackupError } = useBackupCodes();

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setMode('totp');
      setVerificationCode('');
      setBackupCode('');
      clearError();
      clearBackupError();
    }
  }, [open, clearError, clearBackupError]);

  // Auto-submit when TOTP code is complete
  useEffect(() => {
    if (verificationCode.length === 6 && mode === 'totp') {
      handleVerifyTOTP();
    }
  }, [verificationCode, mode]);

  const handleVerifyTOTP = async () => {
    if (verificationCode.length !== 6) return;

    const result = await verifyLogin(verificationCode);
    
    if (result) {
      onSuccess();
      onOpenChange(false);
    } else {
      setVerificationCode('');
    }
  };

  const handleVerifyBackup = async () => {
    const cleanCode = backupCode.replace(/\s/g, '').toUpperCase();
    if (cleanCode.length !== 8) return;

    const success = await verifyBackupCode(cleanCode);
    
    if (success) {
      onSuccess();
      onOpenChange(false);
    } else {
      setBackupCode('');
    }
  };

  const handleCancel = () => {
    onCancel?.();
    onOpenChange(false);
  };

  const currentError = mode === 'totp' ? error : backupError;
  const currentLoading = mode === 'totp' ? isLoading : isLoadingBackup;

  return (
    <Dialog open={open} onOpenChange={(open) => {
      if (!open) handleCancel();
      else onOpenChange(open);
    }}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {mode === 'totp' ? (
              <Shield className="h-5 w-5 text-primary" />
            ) : (
              <Key className="h-5 w-5 text-primary" />
            )}
            {mode === 'totp' ? 'Verificação em Duas Etapas' : 'Código de Backup'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'totp' 
              ? 'Digite o código de 6 dígitos do seu app autenticador.'
              : 'Digite um dos seus códigos de backup de 8 caracteres.'
            }
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {mode === 'totp' ? (
            <div className="space-y-4">
              <Label className="sr-only">Código de verificação</Label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={verificationCode}
                  onChange={setVerificationCode}
                  disabled={isLoading}
                  autoFocus
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="backup-code">Código de backup</Label>
                <Input
                  id="backup-code"
                  placeholder="XXXXXXXX"
                  value={backupCode}
                  onChange={(e) => setBackupCode(e.target.value.toUpperCase())}
                  disabled={isLoadingBackup}
                  className="font-mono text-center text-lg tracking-widest"
                  maxLength={8}
                  autoFocus
                />
              </div>
            </div>
          )}

          {currentError && (
            <div className="flex items-center justify-center gap-2 text-destructive text-sm">
              <AlertCircle className="h-4 w-4" />
              <span>
                {mode === 'totp' ? 'Código inválido. Tente novamente.' : 'Código de backup inválido ou já usado.'}
              </span>
            </div>
          )}

          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={handleCancel}
              className="flex-1"
              disabled={currentLoading}
            >
              Cancelar
            </Button>
            <Button 
              onClick={mode === 'totp' ? handleVerifyTOTP : handleVerifyBackup}
              disabled={currentLoading || (mode === 'totp' ? verificationCode.length !== 6 : backupCode.length !== 8)}
              className="flex-1"
            >
              {currentLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Verificando...
                </>
              ) : (
                'Verificar'
              )}
            </Button>
          </div>

          <div className="text-center">
            {mode === 'totp' ? (
              <button
                type="button"
                onClick={() => setMode('backup')}
                className="text-sm text-muted-foreground hover:text-primary underline"
              >
                Perdeu acesso ao autenticador? Use um código de backup
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setMode('totp')}
                className="text-sm text-muted-foreground hover:text-primary underline"
              >
                Voltar para código do autenticador
              </button>
            )}
          </div>

          <p className="text-xs text-center text-muted-foreground">
            {mode === 'totp'
              ? 'Abra seu app autenticador (Google Authenticator, Authy, etc.) para obter o código.'
              : 'Os códigos de backup foram gerados quando você ativou o 2FA.'
            }
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
