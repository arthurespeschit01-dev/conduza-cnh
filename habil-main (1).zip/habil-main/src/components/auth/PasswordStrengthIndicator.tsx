import { useMemo } from 'react';
import { Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PasswordStrengthIndicatorProps {
  password: string;
}

interface PasswordRequirement {
  label: string;
  test: (password: string) => boolean;
}

const requirements: PasswordRequirement[] = [
  { label: 'Mínimo 8 caracteres', test: (p) => p.length >= 8 },
  { label: 'Uma letra minúscula', test: (p) => /[a-z]/.test(p) },
  { label: 'Uma letra maiúscula', test: (p) => /[A-Z]/.test(p) },
  { label: 'Um número', test: (p) => /[0-9]/.test(p) },
];

export const PasswordStrengthIndicator = ({ password }: PasswordStrengthIndicatorProps) => {
  const { passedCount, results } = useMemo(() => {
    const results = requirements.map((req) => ({
      ...req,
      passed: req.test(password),
    }));
    const passedCount = results.filter((r) => r.passed).length;
    return { passedCount, results };
  }, [password]);

  const strengthLevel = useMemo(() => {
    if (passedCount === 0) return { label: '', color: 'bg-muted' };
    if (passedCount === 1) return { label: 'Fraca', color: 'bg-destructive' };
    if (passedCount === 2) return { label: 'Regular', color: 'bg-orange-500' };
    if (passedCount === 3) return { label: 'Boa', color: 'bg-yellow-500' };
    return { label: 'Forte', color: 'bg-green-500' };
  }, [passedCount]);

  if (!password) return null;

  return (
    <div className="mt-2 space-y-3">
      {/* Strength bar */}
      <div className="space-y-1">
        <div className="flex gap-1">
          {[1, 2, 3, 4].map((level) => (
            <div
              key={level}
              className={cn(
                'h-1.5 flex-1 rounded-full transition-colors',
                passedCount >= level ? strengthLevel.color : 'bg-muted'
              )}
            />
          ))}
        </div>
        {strengthLevel.label && (
          <p className={cn(
            'text-xs font-medium',
            passedCount === 4 ? 'text-green-600' : 
            passedCount === 3 ? 'text-yellow-600' : 
            passedCount === 2 ? 'text-orange-600' : 'text-destructive'
          )}>
            Força: {strengthLevel.label}
          </p>
        )}
      </div>

      {/* Requirements list */}
      <ul className="space-y-1">
        {results.map((req, index) => (
          <li
            key={index}
            className={cn(
              'flex items-center gap-2 text-xs transition-colors',
              req.passed ? 'text-green-600' : 'text-muted-foreground'
            )}
          >
            {req.passed ? (
              <Check className="h-3.5 w-3.5" />
            ) : (
              <X className="h-3.5 w-3.5" />
            )}
            {req.label}
          </li>
        ))}
      </ul>
    </div>
  );
};
