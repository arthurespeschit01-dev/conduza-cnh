import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useMFA } from '@/hooks/useMFA';
import { useBackupCodes } from '@/hooks/useBackupCodes';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Shield, CheckCircle, Copy, AlertCircle } from 'lucide-react';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { BackupCodesDialog } from './BackupCodesDialog';

interface MFASetupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

type SetupStep = 'intro' | 'qr' | 'verify' | 'backup' | 'success';

export const MFASetupDialog = ({ open, onOpenChange, onSuccess }: MFASetupDialogProps) => {
  const [step, setStep] = useState<SetupStep>('intro');
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [factorId, setFactorId] = useState<string | null>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [showBackupDialog, setShowBackupDialog] = useState(false);
  const { enrollTOTP, verifyEnrollment, isLoading, error, clearError } = useMFA();
  const { generateCodes, saveBackupCodes, isLoading: isLoadingBackup } = useBackupCodes();
  const { toast } = useToast();

  // Reset state when dialog opens/closes
  useEffect(() => {
    if (!open) {
      setStep('intro');
      setQrCode(null);
      setSecret(null);
      setFactorId(null);
      setVerificationCode('');
      setBackupCodes([]);
      clearError();
    }
  }, [open, clearError]);

  const handleStartSetup = async () => {
    const data = await enrollTOTP('Conduza App');
    
    if (data) {
      setQrCode(data.qr_code);
      setSecret(data.secret);
      setFactorId(data.id);
      setStep('qr');
    }
  };

  const handleVerify = async () => {
    if (!factorId || verificationCode.length !== 6) return;

    const success = await verifyEnrollment(factorId, verificationCode);
    
    if (success) {
      // Generate and save backup codes
      const codes = generateCodes();
      setBackupCodes(codes);
      await saveBackupCodes(codes);
      setShowBackupDialog(true);
    }
  };

  const handleBackupConfirm = () => {
    setShowBackupDialog(false);
    setStep('success');
    toast({
      title: '2FA ativado!',
      description: 'Sua conta agora está protegida com autenticação de dois fatores.',
    });
  };

  const handleCopySecret = () => {
    if (secret) {
      navigator.clipboard.writeText(secret);
      toast({
        title: 'Copiado!',
        description: 'Código secreto copiado para a área de transferência.',
      });
    }
  };

  const handleClose = () => {
    if (step === 'success') {
      onSuccess?.();
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            {step === 'success' ? '2FA Ativado!' : 'Configurar 2FA'}
          </DialogTitle>
          <DialogDescription>
            {step === 'intro' && 'Adicione uma camada extra de segurança à sua conta.'}
            {step === 'qr' && 'Escaneie o QR code com seu app autenticador.'}
            {step === 'verify' && 'Digite o código de 6 dígitos do seu autenticador.'}
            {step === 'success' && 'Sua conta está protegida com autenticação de dois fatores.'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {step === 'intro' && (
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4 space-y-2">
                <h4 className="font-medium">Como funciona:</h4>
                <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Baixe um app autenticador (Google Authenticator, Authy, etc.)</li>
                  <li>Escaneie o QR code que vamos mostrar</li>
                  <li>Digite o código de 6 dígitos para confirmar</li>
                </ol>
              </div>
              <Button 
                onClick={handleStartSetup} 
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Preparando...
                  </>
                ) : (
                  'Começar Configuração'
                )}
              </Button>
            </div>
          )}

          {step === 'qr' && qrCode && (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="bg-white p-4 rounded-lg">
                  <img src={qrCode} alt="QR Code para 2FA" className="w-48 h-48" />
                </div>
              </div>
              
              {secret && (
                <div className="space-y-2">
                  <Label className="text-sm text-muted-foreground">
                    Ou digite o código manualmente:
                  </Label>
                  <div className="flex gap-2">
                    <Input 
                      value={secret} 
                      readOnly 
                      className="font-mono text-xs"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={handleCopySecret}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}

              <Button 
                onClick={() => setStep('verify')} 
                className="w-full"
              >
                Próximo
              </Button>
            </div>
          )}

          {step === 'verify' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Código de verificação</Label>
                <div className="flex justify-center">
                  <InputOTP
                    maxLength={6}
                    value={verificationCode}
                    onChange={setVerificationCode}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm">
                  <AlertCircle className="h-4 w-4" />
                  {error}
                </div>
              )}

              <div className="flex gap-2">
                <Button 
                  variant="outline"
                  onClick={() => setStep('qr')}
                  className="flex-1"
                >
                  Voltar
                </Button>
                <Button 
                  onClick={handleVerify}
                  disabled={isLoading || isLoadingBackup || verificationCode.length !== 6}
                  className="flex-1"
                >
                  {isLoading || isLoadingBackup ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      {isLoadingBackup ? 'Gerando códigos...' : 'Verificando...'}
                    </>
                  ) : (
                    'Verificar'
                  )}
                </Button>
              </div>
            </div>
          )}

          <BackupCodesDialog
            open={showBackupDialog}
            onOpenChange={setShowBackupDialog}
            codes={backupCodes}
            onConfirm={handleBackupConfirm}
          />

          {step === 'success' && (
            <div className="space-y-4 text-center">
              <div className="flex justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Na próxima vez que você fizer login, será solicitado um código do seu app autenticador.
              </p>
              <Button onClick={handleClose} className="w-full">
                Concluir
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
