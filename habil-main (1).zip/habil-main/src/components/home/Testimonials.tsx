import { Star, Quote } from 'lucide-react';

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  text: string;
  avatar?: string;
}

interface TestimonialsProps {
  testimonials: Testimonial[];
}

export const Testimonials = ({ testimonials }: TestimonialsProps) => {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      {testimonials.map((testimonial, index) => (
        <div 
          key={testimonial.id}
          className="card-elevated p-6 relative animate-fade-in"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <Quote className="absolute top-4 right-4 h-8 w-8 text-primary/10" />
          <div className="flex items-center gap-4 mb-4">
            <div className="h-14 w-14 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center overflow-hidden border-2 border-border">
              {testimonial.avatar ? (
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <span className="text-lg font-bold text-primary">
                  {testimonial.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </span>
              )}
            </div>
            <div>
              <p className="font-semibold text-foreground">{testimonial.name}</p>
              <p className="text-sm text-muted-foreground">{testimonial.location}</p>
            </div>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed italic">
            "{testimonial.text}"
          </p>
          <div className="flex gap-0.5 mt-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} className="h-4 w-4 fill-accent text-accent" />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
