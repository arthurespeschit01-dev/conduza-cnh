import { Check, X } from 'lucide-react';

const traditionalItems = [
  'Precisa ir até várias autoescolas',
  'Pouca transparência sobre instrutores',
  'Escolha limitada',
  'Processo mais lento',
  'Comunicação burocrática',
];

const conduzaItems = [
  'Encontre instrutores em um só lugar',
  'Compare perfis, avaliações e localização',
  'Mais autonomia na escolha',
  'Processo mais ágil',
  'Tecnologia que facilita, sem substituir o presencial',
];

export const ComparisonSection = () => {
  return (
    <div className="grid md:grid-cols-2 gap-8">
      {/* Traditional Method */}
      <div className="card-elevated p-8 border-destructive/20">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
            <X className="h-5 w-5 text-destructive" />
          </div>
          <h3 className="text-xl font-bold text-foreground">Modelo Tradicional</h3>
        </div>
        <ul className="space-y-4">
          {traditionalItems.map((item, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className="h-5 w-5 rounded-full bg-destructive/10 flex items-center justify-center mt-0.5 shrink-0">
                <X className="h-3 w-3 text-destructive" />
              </div>
              <span className="text-muted-foreground">{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* With Conduza */}
      <div className="card-elevated p-8 border-success/20 bg-success/5">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
            <Check className="h-5 w-5 text-success" />
          </div>
          <h3 className="text-xl font-bold text-foreground">Com a Conduza</h3>
        </div>
        <ul className="space-y-4">
          {conduzaItems.map((item, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className="h-5 w-5 rounded-full bg-success/10 flex items-center justify-center mt-0.5 shrink-0">
                <Check className="h-3 w-3 text-success" />
              </div>
              <span className="text-foreground">{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
