import { HelpCircle } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqItems = [
  {
    question: 'A Conduza é uma autoescola?',
    answer: 'Não. A Conduza é uma plataforma que conecta alunos a instrutores credenciados, facilitando a escolha, o contato e o início do processo da CNH.',
  },
  {
    question: 'Preciso pagar para usar a plataforma?',
    answer: 'O cadastro é simples e gratuito. Você escolhe o instrutor e combina diretamente os detalhes do serviço.',
  },
  {
    question: 'A Conduza é 100% online?',
    answer: 'Não totalmente. A plataforma é digital, mas as aulas e exames acontecem presencialmente, conforme as regras do Detran.',
  },
  {
    question: 'Posso escolher meu instrutor?',
    answer: 'Sim! Você pode comparar perfis, avaliações e localização para escolher o instrutor ideal para você.',
  },
];

export const FAQSection = () => {
  return (
    <div className="max-w-3xl mx-auto">
      <Accordion type="single" collapsible className="w-full space-y-4">
        {faqItems.map((item, index) => (
          <AccordionItem 
            key={index} 
            value={`item-${index}`}
            className="card-elevated border rounded-xl px-6 overflow-hidden"
          >
            <AccordionTrigger className="hover:no-underline py-5">
              <div className="flex items-center gap-3 text-left">
                <HelpCircle className="h-5 w-5 text-primary shrink-0" />
                <span className="font-semibold text-foreground">{item.question}</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground pb-5 pl-8">
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
};
