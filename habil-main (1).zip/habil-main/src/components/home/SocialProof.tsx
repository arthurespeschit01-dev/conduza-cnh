import { Users, MapPin, TrendingUp, Star, Shield, Lock, Eye } from 'lucide-react';
import { StatCardAnimated } from './AnimatedCounter';
import { useCountUp } from '@/hooks/useCountUp';

export const SocialProofStats = () => {
  const ratingCounter = useCountUp({ end: 4.8, duration: 2000, decimals: 1, suffix: '/5' });
  
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <div 
        ref={ratingCounter.ref}
        className="card-elevated p-6 text-center group hover:scale-[1.02] transition-transform"
      >
        <div className="h-14 w-14 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
          <Star className="h-7 w-7 text-accent" />
        </div>
        <div className="text-3xl font-bold text-foreground mb-1">
          {ratingCounter.formattedCount}
        </div>
        <p className="text-sm text-muted-foreground">Avaliação média</p>
      </div>
      
      <StatCardAnimated
        icon={<Users className="h-7 w-7" />}
        end={500}
        suffix="+"
        label="Alunos cadastrados"
        iconBgClass="bg-primary/10"
        iconClass="text-primary"
      />
      
      <StatCardAnimated
        icon={<MapPin className="h-7 w-7" />}
        end={35}
        suffix="+"
        label="Cidades atendidas"
        iconBgClass="bg-success/10"
        iconClass="text-success"
      />
      
      <div className="card-elevated p-6 text-center group hover:scale-[1.02] transition-transform">
        <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
          <TrendingUp className="h-7 w-7 text-primary" />
        </div>
        <div className="text-3xl font-bold text-foreground mb-1">Diário</div>
        <p className="text-sm text-muted-foreground">Novos cadastros</p>
      </div>
    </div>
  );
};
export const TrustBadges = () => {
  return <div className="grid sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
        <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center shrink-0">
          <Shield className="h-5 w-5 text-success" />
        </div>
        <div>
          <p className="font-medium text-foreground text-sm">Instrutores verificados</p>
          <p className="text-xs text-muted-foreground">Documentação conferida</p>
        </div>
      </div>
      
      <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
          <Lock className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="font-medium text-foreground text-sm">Dados protegidos</p>
          <p className="text-xs text-muted-foreground">Conforme LGPD</p>
        </div>
      </div>
      
      <div className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border">
        <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
          <Eye className="h-5 w-5 text-accent" />
        </div>
        <div>
          <p className="font-medium text-foreground text-sm">Transparência total</p>
          <p className="text-xs text-muted-foreground">Desde o primeiro contato</p>
        </div>
      </div>
    </div>;
};