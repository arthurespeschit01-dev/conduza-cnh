import { useCountUp } from '@/hooks/useCountUp';
import { ReactNode } from 'react';

interface AnimatedCounterProps {
  end: number;
  duration?: number;
  decimals?: number;
  suffix?: string;
  prefix?: string;
  className?: string;
}

export const AnimatedCounter = ({ 
  end, 
  duration = 2000, 
  decimals = 0, 
  suffix = '', 
  prefix = '',
  className = ''
}: AnimatedCounterProps) => {
  const { ref, formattedCount } = useCountUp({ end, duration, decimals, suffix, prefix });

  return (
    <div ref={ref} className={className}>
      {formattedCount}
    </div>
  );
};

interface StatCardAnimatedProps {
  icon: ReactNode;
  end: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
  label: string;
  iconBgClass: string;
  iconClass: string;
}

export const StatCardAnimated = ({
  icon,
  end,
  suffix = '',
  prefix = '',
  decimals = 0,
  label,
  iconBgClass,
  iconClass
}: StatCardAnimatedProps) => {
  const { ref, formattedCount } = useCountUp({ end, duration: 2000, decimals, suffix, prefix });

  return (
    <div 
      ref={ref}
      className="card-elevated p-6 text-center group hover:scale-[1.02] transition-transform"
    >
      <div className={`h-14 w-14 rounded-full ${iconBgClass} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
        <div className={iconClass}>{icon}</div>
      </div>
      <div className="text-3xl font-bold text-foreground mb-1">
        {formattedCount}
      </div>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
};
