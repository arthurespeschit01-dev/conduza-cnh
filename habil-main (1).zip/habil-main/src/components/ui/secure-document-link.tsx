import { useState } from 'react';
import { ExternalLink, Loader2 } from 'lucide-react';
import { openSecureDocument, type DocumentBucket } from '@/lib/storage';
import { toast } from '@/hooks/use-toast';

interface SecureDocumentLinkProps {
  documentUrl: string | null;
  label?: string;
  className?: string;
  bucket?: DocumentBucket;
}

export const SecureDocumentLink = ({ 
  documentUrl, 
  label = 'Ver documento',
  className = 'text-primary text-sm flex items-center gap-1 hover:underline cursor-pointer',
  bucket = 'instructor-documents'
}: SecureDocumentLinkProps) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    if (!documentUrl) return;
    
    setIsLoading(true);
    await openSecureDocument(documentUrl, bucket, () => {
      toast({
        title: 'Erro ao abrir documento',
        description: 'Não foi possível gerar a URL de acesso. Tente novamente.',
        variant: 'destructive'
      });
    });
    setIsLoading(false);
  };

  if (!documentUrl) return null;

  return (
    <button 
      onClick={handleClick}
      disabled={isLoading}
      className={className}
    >
      {isLoading ? (
        <>
          <Loader2 className="h-3 w-3 animate-spin" />
          Carregando...
        </>
      ) : (
        <>
          {label} <ExternalLink className="h-3 w-3" />
        </>
      )}
    </button>
  );
};
