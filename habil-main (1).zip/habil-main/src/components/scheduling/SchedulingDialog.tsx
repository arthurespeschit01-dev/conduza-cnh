import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { 
  CalendarIcon, 
  Clock, 
  MapPin, 
  Star, 
  MessageCircle, 
  AlertCircle, 
  Loader2,
  Package,
  Check
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useInstructorLink } from '@/hooks/useInstructorLink';

interface InstructorPackage {
  id: string;
  name: string;
  description: string | null;
  lesson_count: number;
  price: number;
  is_active: boolean;
}

interface SchedulingInstructor {
  id: string;
  name: string;
  pricePerHour: number;
  rating: number;
  uf: string;
  city: string;
  // Note: WhatsApp is fetched via secure edge function, not exposed here
}

interface SchedulingDialogProps {
  instructor: SchedulingInstructor | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const DEFAULT_AVAILABLE_HOURS = [
  '08:00', '09:00', '10:00', '11:00',
  '14:00', '15:00', '16:00', '17:00', '18:00'
];

export const SchedulingDialog = ({ instructor, open, onOpenChange }: SchedulingDialogProps) => {
  const { session, user } = useAuth();
  const { toast } = useToast();
  const { registerPendingContact } = useInstructorLink();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [lessonType, setLessonType] = useState<'practical' | 'theoretical'>('practical');
  const [isLoadingContact, setIsLoadingContact] = useState(false);
  const [activeTab, setActiveTab] = useState<'single' | 'packages'>('single');
  
  // Package states
  const [packages, setPackages] = useState<InstructorPackage[]>([]);
  const [isLoadingPackages, setIsLoadingPackages] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<InstructorPackage | null>(null);
  const [isContactingPackage, setIsContactingPackage] = useState(false);

  // Blocked slots state
  const [blockedSlots, setBlockedSlots] = useState<{ blocked_date: string; blocked_time: string }[]>([]);
  const [availableHours, setAvailableHours] = useState<string[]>(DEFAULT_AVAILABLE_HOURS);

  // Fetch instructor packages
  useEffect(() => {
    const fetchPackages = async () => {
      if (!instructor?.id || !open) return;
      
      setIsLoadingPackages(true);
      try {
        const { data, error } = await supabase
          .from('instructor_packages')
          .select('*')
          .eq('instructor_id', instructor.id)
          .eq('is_active', true)
          .order('price', { ascending: true });

        if (!error && data) {
          setPackages(data);
        }
      } catch (err) {
        console.error('Error fetching packages:', err);
      } finally {
        setIsLoadingPackages(false);
      }
    };

    fetchPackages();
  }, [instructor?.id, open]);

  // Fetch blocked slots when instructor or date changes
  useEffect(() => {
    const fetchBlockedSlots = async () => {
      if (!instructor?.id || !open) return;

      try {
        const { data, error } = await supabase
          .from('instructor_blocked_slots')
          .select('blocked_date, blocked_time')
          .eq('instructor_id', instructor.id);

        if (!error && data) {
          setBlockedSlots(data);
        }
      } catch (err) {
        console.error('Error fetching blocked slots:', err);
      }
    };

    fetchBlockedSlots();
  }, [instructor?.id, open]);

  // Filter available hours based on blocked slots for selected date
  useEffect(() => {
    if (!selectedDate) {
      setAvailableHours(DEFAULT_AVAILABLE_HOURS);
      return;
    }

    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const blockedTimesForDate = blockedSlots
      .filter(s => s.blocked_date === dateStr)
      .map(s => s.blocked_time.slice(0, 5));

    const filteredHours = DEFAULT_AVAILABLE_HOURS.filter(
      hour => !blockedTimesForDate.includes(hour)
    );

    setAvailableHours(filteredHours);
    
    // Reset selected time if it's now blocked
    if (selectedTime && blockedTimesForDate.includes(selectedTime)) {
      setSelectedTime(null);
    }
  }, [selectedDate, blockedSlots, selectedTime]);

  if (!instructor) return null;

  const handleContactWhatsApp = async () => {
    if (!selectedDate || !selectedTime) return;
    
    if (!session) {
      toast({
        title: 'Autenticação necessária',
        description: 'Faça login para entrar em contato com o instrutor.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoadingContact(true);
    
    try {
      // Fetch real WhatsApp from secure endpoint
      const { data, error } = await supabase.functions.invoke('get-instructor-contact', {
        body: { instructorId: instructor.id },
      });

      if (error || !data?.whatsapp) {
        toast({
          title: 'Erro ao obter contato',
          description: data?.error || 'Não foi possível obter o contato do instrutor.',
          variant: 'destructive',
        });
        return;
      }

      const formattedDate = format(selectedDate, "dd/MM/yyyy");
      const lessonTypeName = lessonType === 'practical' ? 'Prática' : 'Teórica';
      
      // Sanitize user inputs for URL
      const message = `Olá! Vi seu perfil na Hábil e gostaria de agendar uma aula.\n\n📅 Data: ${formattedDate}\n⏰ Horário: ${selectedTime}\n📚 Tipo: Aula ${lessonTypeName}\n💰 Valor: R$ ${instructor.pricePerHour}\n\nPodemos conversar sobre os detalhes?`;
      
      let whatsappUrl = data.whatsapp;
      
      // If the link already has a message parameter, don't add another one
      if (!whatsappUrl.includes('text=')) {
        whatsappUrl += (whatsappUrl.includes('?') ? '&' : '?') + `text=${encodeURIComponent(message)}`;
      }
      
      // Register pending contact for linking flow
      await registerPendingContact(instructor.id, instructor.name);
      
      window.open(whatsappUrl, '_blank');
      onOpenChange(false);
    } catch (err) {
      toast({
        title: 'Erro',
        description: 'Não foi possível conectar ao servidor.',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingContact(false);
    }
  };

  const handleContactPackageWhatsApp = async () => {
    if (!selectedPackage) return;
    
    if (!session) {
      toast({
        title: 'Autenticação necessária',
        description: 'Faça login para entrar em contato com o instrutor.',
        variant: 'destructive',
      });
      return;
    }

    setIsContactingPackage(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('get-instructor-contact', {
        body: { instructorId: instructor.id },
      });

      if (error || !data?.whatsapp) {
        toast({
          title: 'Erro ao obter contato',
          description: data?.error || 'Não foi possível obter o contato do instrutor.',
          variant: 'destructive',
        });
        return;
      }

      const pricePerLesson = selectedPackage.price / selectedPackage.lesson_count;
      const message = `Olá! Vi seu perfil na Hábil e tenho interesse no pacote de aulas.\n\n📦 Pacote: ${selectedPackage.name}\n📚 Quantidade: ${selectedPackage.lesson_count} aulas\n💰 Valor total: R$ ${selectedPackage.price.toFixed(2)}\n💵 Valor por aula: R$ ${pricePerLesson.toFixed(2)}\n\nGostaria de mais informações sobre como contratar esse pacote!`;
      
      let whatsappUrl = data.whatsapp;
      
      if (!whatsappUrl.includes('text=')) {
        whatsappUrl += (whatsappUrl.includes('?') ? '&' : '?') + `text=${encodeURIComponent(message)}`;
      }
      
      await registerPendingContact(instructor.id, instructor.name);
      
      window.open(whatsappUrl, '_blank');
      onOpenChange(false);
    } catch (err) {
      toast({
        title: 'Erro',
        description: 'Não foi possível conectar ao servidor.',
        variant: 'destructive',
      });
    } finally {
      setIsContactingPackage(false);
    }
  };

  // WhatsApp is always available for approved instructors (fetched via edge function)
  const hasPackages = packages.length > 0;

  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today || date.getDay() === 0;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[650px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Agendar Aula</DialogTitle>
          <DialogDescription>
            Escolha a data e horário para sua aula com {instructor.name}
          </DialogDescription>
        </DialogHeader>

        {/* Instructor Summary */}
        <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/50 border border-border">
          <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
            {instructor.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-foreground">{instructor.name}</h3>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                <span>{instructor.city}, {instructor.uf}</span>
              </div>
              <div className="flex items-center gap-1 text-accent">
                <Star className="h-3 w-3 fill-current" />
                <span>{instructor.rating.toFixed(1)}</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xl font-bold text-foreground">R$ {instructor.pricePerHour}</span>
            <span className="text-sm text-muted-foreground">/hora</span>
          </div>
        </div>

        {/* Tabs for single lesson vs packages */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'single' | 'packages')} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="single" className="gap-2">
              <CalendarIcon className="h-4 w-4" />
              Aula Avulsa
            </TabsTrigger>
            <TabsTrigger value="packages" className="gap-2" disabled={!hasPackages && !isLoadingPackages}>
              <Package className="h-4 w-4" />
              Pacotes
              {hasPackages && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                  {packages.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Single Lesson Tab */}
          <TabsContent value="single" className="space-y-4 mt-4">
            {/* Lesson Type */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-foreground">Tipo de Aula</label>
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant={lessonType === 'practical' ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => setLessonType('practical')}
                >
                  Aula Prática
                </Button>
                <Button
                  type="button"
                  variant={lessonType === 'theoretical' ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => setLessonType('theoretical')}
                >
                  Aula Teórica
                </Button>
              </div>
            </div>

            {/* Date Selection */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-foreground flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                Selecione a Data
              </label>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={isDateDisabled}
                  locale={ptBR}
                  className={cn("rounded-xl border border-border p-3 pointer-events-auto")}
                />
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div className="space-y-3 animate-fade-in">
                <label className="text-sm font-medium text-foreground flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Horários Disponíveis - {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}
                </label>
                {availableHours.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {availableHours.map((time) => (
                      <Button
                        key={time}
                        type="button"
                        variant={selectedTime === time ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        className="h-10"
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600">
                    <AlertCircle className="h-5 w-5 flex-shrink-0" />
                    <span className="text-sm">Não há horários disponíveis neste dia. Selecione outra data.</span>
                  </div>
                )}
              </div>
            )}

            {/* Summary & Contact WhatsApp */}
            {selectedDate && selectedTime && (
              <div className="space-y-4 pt-4 border-t border-border animate-fade-in">
                <div className="flex items-center justify-between p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div>
                    <p className="text-sm text-muted-foreground">Resumo do Agendamento</p>
                    <p className="font-semibold text-foreground">
                      {format(selectedDate, "dd/MM/yyyy")} às {selectedTime}
                    </p>
                    <Badge variant="secondary" className="mt-1">
                      {lessonType === 'practical' ? 'Aula Prática' : 'Aula Teórica'}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Total</p>
                    <p className="text-2xl font-bold text-primary">R$ {instructor.pricePerHour}</p>
                  </div>
                </div>

                <Button
                  variant="hero"
                  className="w-full h-12"
                  onClick={handleContactWhatsApp}
                  disabled={isLoadingContact}
                >
                  {isLoadingContact ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Carregando...
                    </>
                  ) : (
                    <>
                      <MessageCircle className="mr-2 h-5 w-5" />
                      Falar com Instrutor
                    </>
                  )}
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Packages Tab */}
          <TabsContent value="packages" className="space-y-4 mt-4">
            {isLoadingPackages ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : packages.length === 0 ? (
              <div className="text-center py-8">
                <Package className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
                <p className="text-muted-foreground">Este instrutor não possui pacotes disponíveis.</p>
              </div>
            ) : (
              <>
                <p className="text-sm text-muted-foreground">
                  Economize contratando um pacote de aulas
                </p>

                <div className="space-y-3">
                  {packages.map((pkg) => {
                    const pricePerLesson = pkg.price / pkg.lesson_count;
                    const savings = instructor.pricePerHour - pricePerLesson;
                    const savingsPercent = (savings / instructor.pricePerHour) * 100;
                    const isSelected = selectedPackage?.id === pkg.id;

                    return (
                      <button
                        key={pkg.id}
                        onClick={() => setSelectedPackage(isSelected ? null : pkg)}
                        className={cn(
                          "w-full p-4 rounded-xl border text-left transition-all",
                          "hover:border-primary/50 hover:bg-primary/5",
                          isSelected 
                            ? "border-primary bg-primary/5 ring-2 ring-primary/20" 
                            : "border-border"
                        )}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold text-foreground">{pkg.name}</h4>
                              {isSelected && (
                                <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center">
                                  <Check className="h-3 w-3 text-primary-foreground" />
                                </div>
                              )}
                            </div>
                            {pkg.description && (
                              <p className="text-sm text-muted-foreground mt-1">{pkg.description}</p>
                            )}
                            <div className="flex items-center gap-4 mt-2">
                              <Badge variant="secondary">
                                {pkg.lesson_count} aula{pkg.lesson_count > 1 ? 's' : ''}
                              </Badge>
                              {savingsPercent > 0 && (
                                <Badge variant="default" className="bg-success hover:bg-success">
                                  Economia de {savingsPercent.toFixed(0)}%
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="text-right ml-4">
                            <p className="text-2xl font-bold text-primary">
                              R$ {pkg.price.toFixed(0)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              R$ {pricePerLesson.toFixed(0)}/aula
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Package Purchase Button */}
                {selectedPackage && (
                  <div className="space-y-4 pt-4 border-t border-border animate-fade-in">
                    <div className="flex items-center justify-between p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <div>
                        <p className="text-sm text-muted-foreground">Pacote Selecionado</p>
                        <p className="font-semibold text-foreground">{selectedPackage.name}</p>
                        <Badge variant="secondary" className="mt-1">
                          {selectedPackage.lesson_count} aulas
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Total</p>
                        <p className="text-2xl font-bold text-primary">
                          R$ {selectedPackage.price.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    <Button
                      variant="hero"
                      className="w-full h-12"
                      onClick={handleContactPackageWhatsApp}
                      disabled={isContactingPackage}
                    >
                      {isContactingPackage ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Carregando...
                        </>
                      ) : (
                        <>
                          <MessageCircle className="mr-2 h-5 w-5" />
                          Contratar Pacote via WhatsApp
                        </>
                      )}
                    </Button>

                    <p className="text-xs text-center text-muted-foreground">
                      Combine o pagamento diretamente com o instrutor pelo WhatsApp.
                    </p>
                  </div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
