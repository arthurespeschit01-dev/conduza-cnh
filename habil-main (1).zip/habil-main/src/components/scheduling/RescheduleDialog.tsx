import { useState, useEffect, useMemo } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { format, addHours, isBefore } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface LessonToReschedule {
  id: string;
  instructor_id: string;
  lesson_type: string;
  scheduled_date: string;
  scheduled_time: string;
}

interface RescheduleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lesson: LessonToReschedule | null;
  onReschedule: (lessonId: string, newDate: string, newTime: string, instructorId: string) => Promise<{ success: boolean; error?: string }>;
}

export const RescheduleDialog = ({ 
  open, 
  onOpenChange, 
  lesson,
  onReschedule 
}: RescheduleDialogProps) => {
  const [newDate, setNewDate] = useState<Date | undefined>(undefined);
  const [newTime, setNewTime] = useState<string>('');
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [instructorBusyTimes, setInstructorBusyTimes] = useState<string[]>([]);
  const [instructorAvailability, setInstructorAvailability] = useState<{ start: string; end: string } | null>(null);
  const [instructorAvailableDays, setInstructorAvailableDays] = useState<string[]>([]);
  const [isLoadingAvailability, setIsLoadingAvailability] = useState(false);

  // Fetch instructor availability when dialog opens
  useEffect(() => {
    const fetchInstructorProfile = async () => {
      if (!lesson || !open) return;

      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('available_days, available_start_time, available_end_time')
          .eq('id', lesson.instructor_id)
          .single();

        if (profile) {
          setInstructorAvailableDays(profile.available_days || []);
          setInstructorAvailability({
            start: profile.available_start_time || '08:00',
            end: profile.available_end_time || '18:00',
          });
        }
      } catch (error) {
        console.error('Error fetching instructor profile:', error);
      }
    };

    fetchInstructorProfile();
  }, [lesson, open]);

  // Map day names to day of week numbers
  const dayNameToNumber: Record<string, number> = {
    'domingo': 0,
    'segunda': 1,
    'terça': 2,
    'quarta': 3,
    'quinta': 4,
    'sexta': 5,
    'sábado': 6,
  };

  // Check if a date is on an available day for the instructor
  const isDateAvailable = (date: Date) => {
    if (instructorAvailableDays.length === 0) return true;
    const dayOfWeek = date.getDay();
    return instructorAvailableDays.some(day => dayNameToNumber[day.toLowerCase()] === dayOfWeek);
  };

  // Fetch busy times when date changes
  useEffect(() => {
    const fetchBusyTimes = async () => {
      if (!lesson || !newDate) {
        setInstructorBusyTimes([]);
        return;
      }

      setIsLoadingAvailability(true);
      
      try {
        const { data: busySchedules } = await supabase
          .from('schedules')
          .select('scheduled_time')
          .eq('instructor_id', lesson.instructor_id)
          .eq('scheduled_date', format(newDate, 'yyyy-MM-dd'))
          .neq('id', lesson.id)
          .neq('status', 'cancelled');

        if (busySchedules) {
          setInstructorBusyTimes(busySchedules.map(s => s.scheduled_time));
        }
      } catch (error) {
        console.error('Error fetching busy times:', error);
      } finally {
        setIsLoadingAvailability(false);
      }
    };

    fetchBusyTimes();
  }, [lesson, newDate]);

  // Generate available time slots
  const availableTimeSlots = useMemo(() => {
    if (!instructorAvailability) return [];

    const slots: string[] = [];
    const startHour = parseInt(instructorAvailability.start.split(':')[0], 10);
    const endHour = parseInt(instructorAvailability.end.split(':')[0], 10);

    for (let hour = startHour; hour < endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00`;
      if (!instructorBusyTimes.includes(timeString)) {
        slots.push(timeString);
      }
    }

    return slots;
  }, [instructorAvailability, instructorBusyTimes]);

  const handleNewDateChange = (date: Date | undefined) => {
    setNewDate(date);
    setNewTime('');
  };

  const handleReschedule = async () => {
    if (!lesson || !newDate || !newTime) return;
    
    setIsRescheduling(true);
    const result = await onReschedule(
      lesson.id, 
      format(newDate, 'yyyy-MM-dd'), 
      newTime, 
      lesson.instructor_id
    );
    setIsRescheduling(false);
    
    if (result.success) {
      onOpenChange(false);
      setNewDate(undefined);
      setNewTime('');
    }
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setNewDate(undefined);
      setNewTime('');
      setInstructorBusyTimes([]);
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Reagendar aula</DialogTitle>
          <DialogDescription>
            Escolha uma nova data e horário para a aula.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nova data</Label>
            <p className="text-xs text-muted-foreground">
              Agendamentos devem ser feitos com no mínimo 24h de antecedência.
              {instructorAvailableDays.length > 0 && (
                <> Dias disponíveis: {instructorAvailableDays.join(', ')}.</>
              )}
            </p>
            <Calendar
              mode="single"
              selected={newDate}
              onSelect={handleNewDateChange}
              locale={ptBR}
              disabled={(date) => {
                const minDate = addHours(new Date(), 24);
                return isBefore(date, minDate) || !isDateAvailable(date);
              }}
              className="rounded-md border pointer-events-auto"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Novo horário</Label>
            {isLoadingAvailability ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">Carregando horários...</span>
              </div>
            ) : availableTimeSlots.length === 0 ? (
              <p className="text-sm text-muted-foreground py-2">
                Nenhum horário disponível nesta data. Escolha outra data.
              </p>
            ) : (
              <Select value={newTime} onValueChange={setNewTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um horário" />
                </SelectTrigger>
                <SelectContent>
                  {availableTimeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => handleOpenChange(false)}
            disabled={isRescheduling}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleReschedule}
            disabled={isRescheduling || !newDate || !newTime}
          >
            {isRescheduling ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Reagendando...
              </>
            ) : (
              'Confirmar reagendamento'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
