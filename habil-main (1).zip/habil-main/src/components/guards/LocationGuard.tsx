import { ReactNode, useEffect, useState } from 'react';
import { useNavigate, useLocation as useRouterLocation } from 'react-router-dom';
import { useLocation } from '@/contexts/LocationContext';
import { LoadingScreen } from '@/components/ui/loading-screen';

interface LocationGuardProps {
  children: ReactNode;
}

export const LocationGuard = ({ children }: LocationGuardProps) => {
  const { location } = useLocation();
  const navigate = useNavigate();
  const routerLocation = useRouterLocation();
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    // List of paths that don't require location
    const publicPaths = [
      '/', 
      '/login', 
      '/register', 
      '/register/instructor',
      '/register/instructor/form',
      '/register/student',
      '/forgot-password', 
      '/onboarding/location', 
      '/onboarding/profile', 
      '/checkout/embedded', 
      '/checkout/success'
    ];
    
    const isPublicPath = publicPaths.some(path => routerLocation.pathname === path) || routerLocation.pathname.startsWith('/checkout/');
    
    if (!isPublicPath && !location.isValid) {
      navigate('/onboarding/location', { replace: true });
    }
    
    setIsChecking(false);
  }, [location.isValid, navigate, routerLocation.pathname]);

  if (isChecking) {
    return <LoadingScreen message="Verificando localização..." />;
  }

  return <>{children}</>;
};
