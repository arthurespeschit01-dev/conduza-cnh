import { ReactNode, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { LoadingScreen } from '@/components/ui/loading-screen';
import { supabase } from '@/integrations/supabase/client';

// Obfuscated admin route mapping
const ADMIN_ROUTES = {
  dashboard: '/sys/m7x9k2',
  instructors: '/sys/p3v8n1',
  approvals: '/sys/q5w4j6',
};

interface AuthGuardProps {
  children: ReactNode;
  allowedRoles?: UserRole[];
}

export const AuthGuard = ({ children, allowedRoles }: AuthGuardProps) => {
  const { isAuthenticated, isLoading, user, session } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isValidatingRole, setIsValidatingRole] = useState(false);
  const [roleValidated, setRoleValidated] = useState(false);

  // Double-check admin role directly from database for admin routes
  useEffect(() => {
    const validateAdminRole = async () => {
      if (allowedRoles?.includes('admin') && user && session) {
        setIsValidatingRole(true);
        try {
          const { data, error } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', user.id)
            .eq('role', 'admin')
            .maybeSingle();
          
          if (error || !data) {
            // Silent redirect to home - don't reveal admin routes exist
            navigate('/', { replace: true });
            return;
          }
          setRoleValidated(true);
        } catch {
          navigate('/', { replace: true });
        } finally {
          setIsValidatingRole(false);
        }
      } else {
        setRoleValidated(true);
      }
    };

    if (!isLoading && isAuthenticated && user) {
      validateAdminRole();
    }
  }, [isLoading, isAuthenticated, user, session, allowedRoles, navigate]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      // For admin routes, redirect to home instead of login (hide existence)
      const isAdminRoute = location.pathname.startsWith('/sys/');
      navigate(isAdminRoute ? '/' : '/login', { replace: true });
      return;
    }

    if (!isLoading && isAuthenticated && allowedRoles && user && roleValidated) {
      if (!allowedRoles.includes(user.role)) {
        // Redirect to appropriate dashboard based on role
        switch (user.role) {
          case 'student':
            navigate('/student/dashboard', { replace: true });
            break;
          case 'instructor':
            navigate('/instructor/dashboard', { replace: true });
            break;
          case 'admin':
            navigate(ADMIN_ROUTES.dashboard, { replace: true });
            break;
          default:
            navigate('/', { replace: true });
        }
      }
    }
  }, [isAuthenticated, isLoading, navigate, allowedRoles, user, location.pathname, roleValidated]);

  if (isLoading || isValidatingRole) {
    return <LoadingScreen message="Verificando autenticação..." />;
  }

  if (!isAuthenticated) {
    return <LoadingScreen message="Redirecionando..." />;
  }

  if (!roleValidated && allowedRoles?.includes('admin')) {
    return <LoadingScreen message="Verificando..." />;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <LoadingScreen message="Verificando permissões..." />;
  }

  return <>{children}</>;
};

// Export admin routes for use in navigation
export { ADMIN_ROUTES };
