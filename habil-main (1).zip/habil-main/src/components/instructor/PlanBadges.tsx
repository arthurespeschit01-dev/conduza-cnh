import { Badge } from '@/components/ui/badge';
import { Crown, Sparkles, Award, Check } from 'lucide-react';
import { SubscriptionPlan, useInstructorPlan } from '@/hooks/useInstructorPlan';
import { cn } from '@/lib/utils';

interface PlanBadgeProps {
  plan?: SubscriptionPlan;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const PLAN_CONFIG = {
  basic: {
    icon: Check,
    label: 'Básico',
    className: 'bg-muted text-muted-foreground border-muted-foreground/30',
    iconColor: 'text-muted-foreground',
  },
  professional: {
    icon: Sparkles,
    label: 'Profissional',
    className: 'bg-primary/10 text-primary border-primary/30',
    iconColor: 'text-primary',
  },
  premium: {
    icon: Crown,
    label: 'Premium',
    className: 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30',
    iconColor: 'text-amber-500',
  },
};

const SIZE_CONFIG = {
  sm: {
    badge: 'text-xs py-0.5 px-2',
    icon: 'h-3 w-3',
  },
  md: {
    badge: 'text-sm py-1 px-3',
    icon: 'h-4 w-4',
  },
  lg: {
    badge: 'text-base py-1.5 px-4',
    icon: 'h-5 w-5',
  },
};

/**
 * Displays a badge indicating the instructor's subscription plan.
 * Can be used on profile cards, headers, etc.
 */
export const PlanBadge = ({ 
  plan: propPlan, 
  showLabel = true, 
  size = 'md',
  className,
}: PlanBadgeProps) => {
  const { effectivePlan } = useInstructorPlan();
  const plan = propPlan || effectivePlan;
  
  const config = PLAN_CONFIG[plan];
  const sizeConfig = SIZE_CONFIG[size];
  const IconComponent = config.icon;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.className,
        sizeConfig.badge,
        className
      )}
    >
      <IconComponent className={cn(sizeConfig.icon, config.iconColor, showLabel && 'mr-1')} />
      {showLabel && config.label}
    </Badge>
  );
};

interface ApprovalSealProps {
  approvalRate: number;
  plan: SubscriptionPlan;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * Displays the "High Approval Rate" seal for Professional+ plans.
 * Only shows if approval rate is above threshold (e.g., 85%).
 */
export const ApprovalSeal = ({
  approvalRate,
  plan,
  size = 'md',
  className,
}: ApprovalSealProps) => {
  const { hasFeature } = useInstructorPlan();
  
  // Only show for Professional+ plans with high approval rate
  if (!['professional', 'premium'].includes(plan) || approvalRate < 85) {
    return null;
  }

  // Check if user has the seal feature
  if (!hasFeature('high_approval_seal')) {
    return null;
  }

  const sizeConfig = SIZE_CONFIG[size];

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'bg-success/10 text-success border-success/30',
        sizeConfig.badge,
        className
      )}
    >
      <Award className={cn(sizeConfig.icon, 'text-success mr-1')} />
      Alta Aprovação
    </Badge>
  );
};

interface PremiumSealProps {
  plan: SubscriptionPlan;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * Displays the "Premium Instructor" seal for Premium plans.
 */
export const PremiumSeal = ({
  plan,
  size = 'md',
  className,
}: PremiumSealProps) => {
  const { hasFeature } = useInstructorPlan();
  
  // Only show for Premium plans
  if (plan !== 'premium') {
    return null;
  }

  // Check if user has the premium seal feature
  if (!hasFeature('premium_seal')) {
    return null;
  }

  const sizeConfig = SIZE_CONFIG[size];

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'bg-gradient-to-r from-amber-500 to-orange-500 text-white border-amber-500/50',
        sizeConfig.badge,
        className
      )}
    >
      <Crown className={cn(sizeConfig.icon, 'text-white mr-1')} />
      Instrutor Premium
    </Badge>
  );
};

interface InstructorSealsProps {
  plan: SubscriptionPlan;
  approvalRate?: number;
  showPlanBadge?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * Composite component that shows all applicable seals for an instructor.
 */
export const InstructorSeals = ({
  plan,
  approvalRate = 0,
  showPlanBadge = true,
  size = 'md',
  className,
}: InstructorSealsProps) => {
  return (
    <div className={cn('flex flex-wrap gap-2', className)}>
      {showPlanBadge && <PlanBadge plan={plan} size={size} />}
      <ApprovalSeal approvalRate={approvalRate} plan={plan} size={size} />
      <PremiumSeal plan={plan} size={size} />
    </div>
  );
};
