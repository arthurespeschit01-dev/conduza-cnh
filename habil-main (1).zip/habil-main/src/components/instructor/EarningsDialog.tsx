import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { DollarSign, TrendingUp, Users, Calendar, Loader2 } from 'lucide-react';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subDays, isWithinInterval, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface EarningsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type Period = 'today' | 'week' | 'month' | 'all';

interface Schedule {
  id: string;
  price: number;
  status: string;
  scheduled_date: string;
  student_id: string;
  created_at: string;
}

export const EarningsDialog = ({ open, onOpenChange }: EarningsDialogProps) => {
  const { user } = useAuth();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [period, setPeriod] = useState<Period>('month');

  useEffect(() => {
    if (open && user?.id) {
      fetchSchedules();
    }
  }, [open, user?.id]);

  const fetchSchedules = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('schedules')
      .select('*')
      .eq('instructor_id', user?.id)
      .order('scheduled_date', { ascending: false });

    if (error) {
      toast({ title: 'Erro ao carregar dados', variant: 'destructive' });
    } else {
      setSchedules(data || []);
    }
    setIsLoading(false);
  };

  const stats = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = startOfWeek(now, { weekStartsOn: 0 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 0 });
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    const filterByPeriod = (schedule: Schedule) => {
      const date = parseISO(schedule.scheduled_date);
      switch (period) {
        case 'today':
          return date >= todayStart && date <= now;
        case 'week':
          return isWithinInterval(date, { start: weekStart, end: weekEnd });
        case 'month':
          return isWithinInterval(date, { start: monthStart, end: monthEnd });
        case 'all':
          return true;
        default:
          return true;
      }
    };

    const filtered = schedules.filter(filterByPeriod);
    const completed = filtered.filter(s => s.status === 'completed');
    const confirmed = filtered.filter(s => s.status === 'confirmed');
    
    const totalEarnings = completed.reduce((sum, s) => sum + Number(s.price), 0);
    const pendingEarnings = confirmed.reduce((sum, s) => sum + Number(s.price), 0);
    const totalClasses = completed.length + confirmed.length;
    const uniqueStudents = [...new Set(filtered.map(s => s.student_id))].length;

    // New students this period
    const newStudentsThisPeriod = [...new Set(
      schedules
        .filter(s => {
          const date = parseISO(s.created_at);
          switch (period) {
            case 'today': return date >= todayStart;
            case 'week': return isWithinInterval(date, { start: weekStart, end: weekEnd });
            case 'month': return isWithinInterval(date, { start: monthStart, end: monthEnd });
            default: return true;
          }
        })
        .map(s => s.student_id)
    )].length;

    return { totalEarnings, pendingEarnings, totalClasses, uniqueStudents, newStudentsThisPeriod };
  }, [schedules, period]);

  const periodLabels: Record<Period, string> = {
    today: 'Hoje',
    week: 'Esta Semana',
    month: 'Este Mês',
    all: 'Todos'
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Meus Ganhos
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Period Selector */}
            <div className="flex gap-2">
              {(Object.keys(periodLabels) as Period[]).map((p) => (
                <Button
                  key={p}
                  variant={period === p ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setPeriod(p)}
                  className="flex-1"
                >
                  {periodLabels[p]}
                </Button>
              ))}
            </div>

            {/* Main Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-success/10 border border-success/20">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="h-4 w-4 text-success" />
                  <span className="text-sm text-muted-foreground">Faturamento</span>
                </div>
                <p className="text-2xl font-bold text-success">
                  R$ {stats.totalEarnings.toFixed(2)}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <span className="text-sm text-muted-foreground">A Receber</span>
                </div>
                <p className="text-2xl font-bold text-primary">
                  R$ {stats.pendingEarnings.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Secondary Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-muted/50 border text-center">
                <Calendar className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
                <p className="text-2xl font-bold">{stats.totalClasses}</p>
                <p className="text-xs text-muted-foreground">Aulas</p>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 border text-center">
                <Users className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
                <p className="text-2xl font-bold">{stats.uniqueStudents}</p>
                <p className="text-xs text-muted-foreground">Alunos</p>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 border text-center">
                <TrendingUp className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
                <p className="text-2xl font-bold">{stats.newStudentsThisPeriod}</p>
                <p className="text-xs text-muted-foreground">Novos</p>
              </div>
            </div>

            {/* Summary */}
            <div className="p-4 rounded-lg bg-muted/30 border">
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Resumo {periodLabels[period].toLowerCase()}:</strong>{' '}
                Você realizou {stats.totalClasses} aula{stats.totalClasses !== 1 ? 's' : ''} com{' '}
                {stats.uniqueStudents} aluno{stats.uniqueStudents !== 1 ? 's' : ''}, faturando{' '}
                <span className="text-success font-medium">R$ {stats.totalEarnings.toFixed(2)}</span>.
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
