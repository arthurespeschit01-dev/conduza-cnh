import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { Package, Plus, Trash2, Loader2, Edit2 } from 'lucide-react';

interface PackageData {
  id: string;
  name: string;
  description: string | null;
  lesson_count: number;
  duration_type: string;
  price: number;
  is_active: boolean;
}

interface PackagesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const PackagesDialog = ({ open, onOpenChange }: PackagesDialogProps) => {
  const { user } = useAuth();
  const [packages, setPackages] = useState<PackageData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    lesson_count: 1,
    duration_type: 'custom',
    price: 0,
    is_active: true
  });

  useEffect(() => {
    if (open && user?.id) {
      fetchPackages();
    }
  }, [open, user?.id]);

  const fetchPackages = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('instructor_packages')
      .select('*')
      .eq('instructor_id', user?.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Erro ao carregar pacotes', variant: 'destructive' });
    } else {
      setPackages(data || []);
    }
    setIsLoading(false);
  };

  const resetForm = () => {
    setFormData({ name: '', description: '', lesson_count: 1, duration_type: 'custom', price: 0, is_active: true });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;

    setIsSaving(true);

    if (editingId) {
      const { error } = await supabase
        .from('instructor_packages')
        .update(formData)
        .eq('id', editingId);

      if (error) {
        toast({ title: 'Erro ao atualizar pacote', variant: 'destructive' });
      } else {
        toast({ title: 'Pacote atualizado com sucesso!' });
        resetForm();
        fetchPackages();
      }
    } else {
      const { error } = await supabase
        .from('instructor_packages')
        .insert({
          instructor_id: user.id,
          ...formData
        });

      if (error) {
        toast({ title: 'Erro ao criar pacote', variant: 'destructive' });
      } else {
        toast({ title: 'Pacote criado com sucesso!' });
        resetForm();
        fetchPackages();
      }
    }
    setIsSaving(false);
  };

  const handleEdit = (pkg: PackageData) => {
    setFormData({
      name: pkg.name,
      description: pkg.description || '',
      lesson_count: pkg.lesson_count,
      duration_type: pkg.duration_type,
      price: pkg.price,
      is_active: pkg.is_active
    });
    setEditingId(pkg.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('instructor_packages').delete().eq('id', id);
    if (error) {
      toast({ title: 'Erro ao remover pacote', variant: 'destructive' });
    } else {
      toast({ title: 'Pacote removido!' });
      fetchPackages();
    }
  };

  const getDurationLabel = (type: string) => {
    const labels: Record<string, string> = {
      weekly: 'Semanal',
      biweekly: 'Quinzenal',
      monthly: 'Mensal',
      custom: 'Personalizado'
    };
    return labels[type] || type;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Gerenciar Pacotes
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-4">
            {packages.length > 0 && !showForm && (
              <div className="space-y-3">
                {packages.map((pkg) => (
                  <div key={pkg.id} className={`p-4 rounded-lg border ${pkg.is_active ? 'bg-muted/50' : 'bg-muted/20 opacity-60'}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{pkg.name}</p>
                          {!pkg.is_active && (
                            <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">Inativo</span>
                          )}
                        </div>
                        {pkg.description && (
                          <p className="text-sm text-muted-foreground mt-1">{pkg.description}</p>
                        )}
                        <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                          <span>{pkg.lesson_count} aula{pkg.lesson_count > 1 ? 's' : ''}</span>
                          <span>{getDurationLabel(pkg.duration_type)}</span>
                          <span className="font-medium text-foreground">R$ {pkg.price.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(pkg)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(pkg.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {packages.length === 0 && !showForm && (
              <div className="text-center py-6">
                <Package className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground">Nenhum pacote cadastrado</p>
              </div>
            )}

            {showForm ? (
              <form onSubmit={handleSubmit} className="space-y-4 border rounded-lg p-4">
                <div className="space-y-2">
                  <Label>Nome do Pacote</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Pacote Básico"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Descrição</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descreva o pacote..."
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Qtd. de Aulas</Label>
                    <Input
                      type="number"
                      min={1}
                      value={formData.lesson_count}
                      onChange={(e) => setFormData({ ...formData, lesson_count: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Duração</Label>
                    <Select value={formData.duration_type} onValueChange={(v) => setFormData({ ...formData, duration_type: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekly">Semanal</SelectItem>
                        <SelectItem value="biweekly">Quinzenal</SelectItem>
                        <SelectItem value="monthly">Mensal</SelectItem>
                        <SelectItem value="custom">Personalizado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Preço (R$)</Label>
                  <Input
                    type="number"
                    min={0}
                    step={0.01}
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                    required
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Pacote Ativo</Label>
                  <Switch
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                </div>

                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={isSaving} className="flex-1">
                    {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : editingId ? 'Atualizar' : 'Criar'}
                  </Button>
                </div>
              </form>
            ) : (
              <Button onClick={() => setShowForm(true)} className="w-full gap-2">
                <Plus className="h-4 w-4" />
                Criar Novo Pacote
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
