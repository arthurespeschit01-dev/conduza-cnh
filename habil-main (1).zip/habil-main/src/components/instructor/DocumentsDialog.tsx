import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { FileText, CheckCircle, XCircle, Loader2, Upload } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SecureDocumentLink } from '@/components/ui/secure-document-link';

interface DocumentsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface DocumentStatus {
  name: string;
  field: string;
  url: string | null;
  required: boolean;
}

export const DocumentsDialog = ({ open, onOpenChange }: DocumentsDialogProps) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [documents, setDocuments] = useState<DocumentStatus[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [registrationStatus, setRegistrationStatus] = useState<string | null>(null);

  useEffect(() => {
    if (open && user?.id) {
      fetchDocuments();
    }
  }, [open, user?.id]);

  const fetchDocuments = async () => {
    setIsLoading(true);
    
    // Fetch registration status from profiles
    const { data: profileData } = await supabase
      .from('profiles')
      .select('registration_status')
      .eq('id', user?.id)
      .single();
    
    // Fetch document paths from user_sensitive_data
    const { data, error } = await supabase
      .from('user_sensitive_data')
      .select('cnh_document_path, rg_document_path, proof_of_residence_path, instructor_certificate_path')
      .eq('user_id', user?.id)
      .maybeSingle();

    if (error) {
      toast({ title: 'Erro ao carregar documentos', variant: 'destructive' });
    } else {
      setRegistrationStatus(profileData?.registration_status || null);
      setDocuments([
        { name: 'CNH', field: 'cnh_document_path', url: data?.cnh_document_path || null, required: true },
        { name: 'RG', field: 'rg_document_path', url: data?.rg_document_path || null, required: true },
        { name: 'Comprovante de Residência', field: 'proof_of_residence_path', url: data?.proof_of_residence_path || null, required: true },
        { name: 'Certificado de Instrutor', field: 'instructor_certificate_path', url: data?.instructor_certificate_path || null, required: true },
      ]);
    }
    setIsLoading(false);
  };

  const allDocumentsSent = documents.filter(d => d.required).every(d => d.url);
  const missingCount = documents.filter(d => d.required && !d.url).length;

  const handleGoToUpload = () => {
    onOpenChange(false);
    navigate('/instructor/documents');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Meus Documentos
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-4">
            {/* Status Banner */}
            <div className={`p-4 rounded-lg border ${
              allDocumentsSent 
                ? registrationStatus === 'approved' 
                  ? 'bg-success/10 border-success/30'
                  : 'bg-warning/10 border-warning/30'
                : 'bg-destructive/10 border-destructive/30'
            }`}>
              <div className="flex items-center gap-3">
                {allDocumentsSent ? (
                  registrationStatus === 'approved' ? (
                    <CheckCircle className="h-5 w-5 text-success" />
                  ) : (
                    <Loader2 className="h-5 w-5 text-warning animate-spin" />
                  )
                ) : (
                  <XCircle className="h-5 w-5 text-destructive" />
                )}
                <div>
                  <p className="font-medium">
                    {allDocumentsSent 
                      ? registrationStatus === 'approved'
                        ? 'Documentação Aprovada'
                        : 'Em Análise'
                      : `Faltam ${missingCount} documento${missingCount > 1 ? 's' : ''}`}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {allDocumentsSent
                      ? registrationStatus === 'approved'
                        ? 'Seus documentos foram verificados e aprovados.'
                        : 'Seus documentos estão sendo verificados pela equipe.'
                      : 'Envie todos os documentos para aprovação do cadastro.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Document List */}
            <div className="space-y-3">
              {documents.map((doc) => (
                <div key={doc.field} className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border">
                  <div className="flex items-center gap-3">
                    {doc.url ? (
                      <CheckCircle className="h-5 w-5 text-success" />
                    ) : (
                      <XCircle className="h-5 w-5 text-destructive" />
                    )}
                    <div>
                      <p className="font-medium">{doc.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {doc.url ? 'Enviado' : 'Pendente'}
                        {doc.required && ' • Obrigatório'}
                      </p>
                    </div>
                  </div>
                  {doc.url && (
                    <SecureDocumentLink 
                      documentUrl={doc.url} 
                      label=""
                      className="text-primary p-2 hover:bg-muted rounded-md"
                    />
                  )}
                </div>
              ))}
            </div>

            {!allDocumentsSent && (
              <Button onClick={handleGoToUpload} className="w-full gap-2">
                <Upload className="h-4 w-4" />
                Enviar Documentos Pendentes
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
