import { ReactNode, useState } from 'react';
import { PlanFeature, useInstructorPlan } from '@/hooks/useInstructorPlan';
import { UpgradePrompt } from './UpgradePrompt';
import { Lock, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeatureGateProps {
  feature: PlanFeature;
  children: ReactNode;
  fallback?: 'inline' | 'card' | 'dialog' | 'hidden' | 'disabled';
  className?: string;
}

/**
 * Component that gates features based on the instructor's subscription plan.
 * If the feature is not available, it shows an upgrade prompt.
 * 
 * Usage:
 * <FeatureGate feature="metrics_dashboard">
 *   <MetricsComponent />
 * </FeatureGate>
 */
export const FeatureGate = ({ 
  feature, 
  children, 
  fallback = 'card',
  className,
}: FeatureGateProps) => {
  const { hasFeature, isLoading, getFeatureName, getRequiredPlan, getPlanName } = useInstructorPlan();
  const [dialogOpen, setDialogOpen] = useState(false);

  // Show loading state while fetching plan data
  if (isLoading) {
    return null;
  }

  // If feature is available, render children
  if (hasFeature(feature)) {
    return <>{children}</>;
  }

  // Feature not available - show appropriate fallback
  if (fallback === 'hidden') {
    return null;
  }

  if (fallback === 'disabled') {
    const requiredPlan = getRequiredPlan(feature);
    const featureName = getFeatureName(feature);
    const planName = getPlanName(requiredPlan);
    
    return (
      <div className={cn("relative group", className)}>
        <div className="pointer-events-none opacity-40 grayscale">
          {children}
        </div>
        <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-[1px] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex flex-col items-center gap-2 text-center p-4">
            <div className="p-2 rounded-full bg-muted">
              <Lock className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">{featureName}</p>
            <p className="text-xs text-muted-foreground">Requer plano {planName}</p>
          </div>
        </div>
      </div>
    );
  }

  if (fallback === 'dialog') {
    return (
      <>
        <div 
          onClick={() => setDialogOpen(true)} 
          className={cn(
            "cursor-pointer relative group",
            className
          )}
        >
          <div className="opacity-50 grayscale pointer-events-none">
            {children}
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-background/80 backdrop-blur-sm border shadow-sm group-hover:shadow-md transition-all">
              <Lock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Desbloquear</span>
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
          </div>
        </div>
        <UpgradePrompt 
          feature={feature} 
          variant="dialog" 
          open={dialogOpen} 
          onOpenChange={setDialogOpen} 
        />
      </>
    );
  }

  return <UpgradePrompt feature={feature} variant={fallback} />;
};

/**
 * Hook to check if a feature is available and get upgrade info.
 * Useful for conditional rendering and click handlers.
 */
export const useFeatureAccess = (feature: PlanFeature) => {
  const { hasFeature, requiresUpgrade, getUpgradeMessage, isLoading, getFeatureName, getRequiredPlan, getPlanName } = useInstructorPlan();
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);

  const handleFeatureClick = (callback?: () => void) => {
    if (hasFeature(feature)) {
      callback?.();
    } else {
      setShowUpgradeDialog(true);
    }
  };

  return {
    isAvailable: hasFeature(feature),
    requiresUpgrade: requiresUpgrade(feature),
    upgradeMessage: getUpgradeMessage(feature),
    featureName: getFeatureName(feature),
    requiredPlan: getRequiredPlan(feature),
    requiredPlanName: getPlanName(getRequiredPlan(feature)),
    isLoading,
    showUpgradeDialog,
    openUpgradeDialog: () => setShowUpgradeDialog(true),
    closeUpgradeDialog: () => setShowUpgradeDialog(false),
    handleFeatureClick,
    UpgradeDialog: () => (
      <UpgradePrompt 
        feature={feature} 
        variant="dialog" 
        open={showUpgradeDialog} 
        onOpenChange={setShowUpgradeDialog} 
      />
    ),
  };
};

/**
 * Locked Button component that shows upgrade dialog when clicked
 */
interface LockedButtonProps {
  feature: PlanFeature;
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
}

export const LockedButton = ({ feature, children, onClick, className, variant = 'default' }: LockedButtonProps) => {
  const { isAvailable, handleFeatureClick, UpgradeDialog, requiredPlanName } = useFeatureAccess(feature);

  if (isAvailable) {
    return (
      <button onClick={onClick} className={className}>
        {children}
      </button>
    );
  }

  return (
    <>
      <button 
        onClick={() => handleFeatureClick()} 
        className={cn(
          "relative group",
          className
        )}
      >
        <span className="opacity-60">{children}</span>
        <Lock className="h-3 w-3 ml-1 inline-block text-muted-foreground" />
      </button>
      <UpgradeDialog />
    </>
  );
};
