import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lock, Sparkles, Crown, Zap, Check, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PlanFeature, SubscriptionPlan, useInstructorPlan } from '@/hooks/useInstructorPlan';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface UpgradePromptProps {
  feature: PlanFeature;
  variant?: 'inline' | 'card' | 'dialog';
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const PLAN_ICONS: Record<SubscriptionPlan, React.ReactNode> = {
  basic: <Zap className="h-5 w-5" />,
  professional: <Sparkles className="h-5 w-5" />,
  premium: <Crown className="h-5 w-5" />,
};

const PLAN_COLORS: Record<SubscriptionPlan, string> = {
  basic: 'bg-muted text-muted-foreground',
  professional: 'bg-primary/10 text-primary',
  premium: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
};

const PLAN_BORDER_COLORS: Record<SubscriptionPlan, string> = {
  basic: 'border-muted-foreground/30',
  professional: 'border-primary/30',
  premium: 'border-amber-500/30',
};

export const UpgradePrompt = ({ 
  feature, 
  variant = 'card',
  open,
  onOpenChange,
}: UpgradePromptProps) => {
  const navigate = useNavigate();
  const { 
    getUpgradeMessage, 
    getRequiredPlan, 
    getPlanName, 
    getPlanPrice,
    getFeatureName,
    getFeatureDescription,
    getUnlockableFeatures,
    isPaymentActive,
    paymentStatus,
    effectivePlan,
  } = useInstructorPlan();

  const requiredPlan = getRequiredPlan(feature);
  const message = getUpgradeMessage(feature);
  const planName = getPlanName(requiredPlan);
  const planPrice = getPlanPrice(requiredPlan);
  const featureName = getFeatureName(feature);
  const featureDescription = getFeatureDescription(feature);
  const unlockableFeatures = getUnlockableFeatures(requiredPlan);

  const handleUpgrade = () => {
    navigate('/register/instructor');
    onOpenChange?.(false);
  };

  const content = (
    <div className="flex flex-col items-center text-center gap-4">
      <div className={`p-4 rounded-full ${PLAN_COLORS[requiredPlan]}`}>
        {PLAN_ICONS[requiredPlan]}
      </div>
      
      <div className="space-y-2">
        <h3 className="font-semibold text-lg text-foreground">{featureName}</h3>
        <p className="text-sm text-muted-foreground">{featureDescription}</p>
      </div>

      {isPaymentActive ? (
        <div className="w-full space-y-4">
          <div className={`p-4 rounded-xl border-2 ${PLAN_BORDER_COLORS[requiredPlan]} bg-card`}>
            <div className="flex items-center justify-center gap-2 mb-2">
              {PLAN_ICONS[requiredPlan]}
              <span className="font-bold text-foreground">Plano {planName}</span>
            </div>
            <div className="text-2xl font-bold text-foreground">
              R$ {planPrice}<span className="text-sm font-normal text-muted-foreground">/mês</span>
            </div>
          </div>

          {unlockableFeatures.length > 0 && (
            <div className="text-left space-y-2">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Você também desbloqueia:
              </p>
              <div className="space-y-1.5">
                {unlockableFeatures.slice(0, 4).map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Check className="h-3.5 w-3.5 text-primary flex-shrink-0" />
                    <span>{getFeatureName(f)}</span>
                  </div>
                ))}
                {unlockableFeatures.length > 4 && (
                  <p className="text-xs text-muted-foreground">
                    + {unlockableFeatures.length - 4} outras funcionalidades
                  </p>
                )}
              </div>
            </div>
          )}

          <Button onClick={handleUpgrade} className="w-full gap-2" size="lg">
            <Sparkles className="h-4 w-4" />
            Fazer Upgrade
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <div className="w-full space-y-3">
          <Badge variant="destructive" className="text-sm py-1 px-3">
            Pagamento {paymentStatus === 'pending' ? 'Pendente' : 'Expirado'}
          </Badge>
          <p className="text-sm text-muted-foreground">
            Regularize seu pagamento para continuar usando o plano {getPlanName(effectivePlan)}.
          </p>
          <Button onClick={handleUpgrade} className="w-full" size="lg">
            Regularizar Pagamento
          </Button>
        </div>
      )}
    </div>
  );

  if (variant === 'inline') {
    return (
      <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50 border border-dashed border-muted-foreground/30">
        <div className={`p-2 rounded-lg ${PLAN_COLORS[requiredPlan]}`}>
          <Lock className="h-4 w-4" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground">{featureName}</p>
          <p className="text-xs text-muted-foreground">Requer plano {planName}</p>
        </div>
        <Button size="sm" variant="outline" onClick={handleUpgrade} className="gap-1">
          <Sparkles className="h-3 w-3" />
          Upgrade
        </Button>
      </div>
    );
  }

  if (variant === 'dialog') {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-muted-foreground" />
              Upgrade Necessário
            </DialogTitle>
            <DialogDescription>
              Este recurso não está disponível no seu plano atual.
            </DialogDescription>
          </DialogHeader>
          <div className="pt-4">
            {content}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Card className="border-dashed border-2 border-muted-foreground/30 bg-muted/20">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className={`p-2 rounded-lg ${PLAN_COLORS[requiredPlan]}`}>
            <Lock className="h-4 w-4" />
          </div>
          <div>
            <CardTitle className="text-base">Recurso Bloqueado</CardTitle>
            <CardDescription>
              Requer plano {planName}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {content}
      </CardContent>
    </Card>
  );
};
