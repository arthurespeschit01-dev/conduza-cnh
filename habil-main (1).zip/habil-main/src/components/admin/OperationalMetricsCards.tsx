import { 
  Clock, 
  XCircle, 
  RefreshCw, 
  UserX, 
  MapPin,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface OperationalMetrics {
  avgApprovalTime: {
    days: number;
    hours: number;
    previousPeriodDays: number;
    trend: 'up' | 'down' | 'stable';
  };
  rejectionRate: {
    percentage: number;
    total: number;
    rejected: number;
  };
  documentResubmissions: number;
  inactiveInstructors: {
    count: number;
    instructors: Array<{
      id: string;
      full_name: string;
      lastActivity: Date | null;
      daysSinceActivity: number;
    }>;
  };
  instructorsByRegion: Array<{
    region: string;
    count: number;
    type: 'city' | 'state';
  }>;
}

interface OperationalMetricsCardsProps {
  metrics: OperationalMetrics;
}

export const OperationalMetricsCards = ({ metrics }: OperationalMetricsCardsProps) => {
  const TrendIcon = metrics.avgApprovalTime.trend === 'up' 
    ? TrendingUp 
    : metrics.avgApprovalTime.trend === 'down' 
    ? TrendingDown 
    : Minus;

  const trendColor = metrics.avgApprovalTime.trend === 'up' 
    ? 'text-destructive' 
    : metrics.avgApprovalTime.trend === 'down' 
    ? 'text-success' 
    : 'text-muted-foreground';

  const stateRegions = metrics.instructorsByRegion.filter(r => r.type === 'state');
  const cityRegions = metrics.instructorsByRegion.filter(r => r.type === 'city');

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">Métricas Operacionais</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Average Approval Time */}
          <Card className="card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Tempo Médio de Aprovação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">
                  {metrics.avgApprovalTime.days}d
                </span>
                <span className="text-lg text-muted-foreground">
                  {metrics.avgApprovalTime.hours}h
                </span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Tooltip>
                  <TooltipTrigger>
                    <div className={`flex items-center gap-1 text-xs ${trendColor}`}>
                      <TrendIcon className="h-3 w-3" />
                      <span>
                        {metrics.avgApprovalTime.previousPeriodDays > 0 
                          ? `${metrics.avgApprovalTime.previousPeriodDays}d mês anterior`
                          : 'Sem dados anteriores'}
                      </span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Comparação com o período anterior</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </CardContent>
          </Card>

          {/* Rejection Rate */}
          <Card className="card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <XCircle className="h-4 w-4" />
                Taxa de Reprovação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl font-bold ${metrics.rejectionRate.percentage > 30 ? 'text-destructive' : 'text-foreground'}`}>
                  {metrics.rejectionRate.percentage.toFixed(1)}%
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {metrics.rejectionRate.rejected} de {metrics.rejectionRate.total} analisados
              </p>
            </CardContent>
          </Card>

          {/* Document Resubmissions */}
          <Card className="card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                Reenvio de Documentos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">
                  {metrics.documentResubmissions}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Documentos atualizados
              </p>
            </CardContent>
          </Card>

          {/* Inactive Instructors */}
          <Card className="card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <UserX className="h-4 w-4" />
                Instrutores Inativos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl font-bold ${metrics.inactiveInstructors.count > 0 ? 'text-warning' : 'text-foreground'}`}>
                  {metrics.inactiveInstructors.count}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Sem atividade há 30+ dias
              </p>
            </CardContent>
          </Card>

          {/* Instructors by Region */}
          <Card className="card-elevated">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Por Região
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">
                  {stateRegions.length}
                </span>
                <span className="text-sm text-muted-foreground">estados</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {cityRegions.length} cidades ativas
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Detailed Region Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* States */}
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              Instrutores por Estado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px]">
              <div className="space-y-2">
                {stateRegions.length > 0 ? (
                  stateRegions.map((region) => (
                    <div key={region.region} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <span className="text-sm font-medium text-foreground">{region.region}</span>
                      <Badge variant="secondary">{region.count}</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum instrutor ativo
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Top Cities */}
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <MapPin className="h-4 w-4 text-accent" />
              Top Cidades
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px]">
              <div className="space-y-2">
                {cityRegions.length > 0 ? (
                  cityRegions.map((region) => (
                    <div key={region.region} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <span className="text-sm text-foreground">{region.region}</span>
                      <Badge 
                        variant={region.count < 3 ? "destructive" : "secondary"}
                        className={region.count < 3 ? "bg-warning/10 text-warning border-warning/20" : ""}
                      >
                        {region.count}
                      </Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum instrutor ativo
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
