import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  ArrowRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface ComparisonMetric {
  label: string;
  currentValue: number;
  previousValue: number;
  format?: 'number' | 'percentage' | 'currency' | 'days';
  invertTrend?: boolean; // If true, decrease is good (e.g., rejection rate)
}

interface PeriodComparisonProps {
  metrics: ComparisonMetric[];
  currentPeriodLabel: string;
  previousPeriodLabel: string;
}

const formatValue = (value: number, format: ComparisonMetric['format'] = 'number'): string => {
  switch (format) {
    case 'percentage':
      return `${value.toFixed(1)}%`;
    case 'currency':
      return `R$ ${value.toFixed(2)}`;
    case 'days':
      return `${value}d`;
    default:
      return value.toString();
  }
};

const calculateChange = (current: number, previous: number): number => {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
};

export const PeriodComparisonCard = ({ 
  metrics, 
  currentPeriodLabel, 
  previousPeriodLabel 
}: PeriodComparisonProps) => {
  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          Comparativo de Períodos
          <span className="text-sm font-normal text-muted-foreground">
            {previousPeriodLabel} <ArrowRight className="inline h-3 w-3" /> {currentPeriodLabel}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {metrics.map((metric, index) => {
            const change = calculateChange(metric.currentValue, metric.previousValue);
            const isPositive = metric.invertTrend ? change < 0 : change > 0;
            const isNegative = metric.invertTrend ? change > 0 : change < 0;
            const isStable = Math.abs(change) < 5;

            const TrendIcon = isStable ? Minus : (isPositive ? TrendingUp : TrendingDown);
            const trendColor = isStable 
              ? 'text-muted-foreground' 
              : (isPositive ? 'text-success' : 'text-destructive');
            
            // Calculate progress for visual bar
            const maxValue = Math.max(metric.currentValue, metric.previousValue, 1);
            const currentProgress = (metric.currentValue / maxValue) * 100;
            const previousProgress = (metric.previousValue / maxValue) * 100;

            return (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{metric.label}</span>
                  <div className={cn("flex items-center gap-1 text-sm", trendColor)}>
                    <TrendIcon className="h-4 w-4" />
                    <span>
                      {isStable ? 'Estável' : `${change > 0 ? '+' : ''}${change.toFixed(1)}%`}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {/* Previous Period */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Anterior</span>
                      <span className="font-medium text-muted-foreground">
                        {formatValue(metric.previousValue, metric.format)}
                      </span>
                    </div>
                    <Progress 
                      value={previousProgress} 
                      className="h-2 bg-muted"
                    />
                  </div>
                  
                  {/* Current Period */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Atual</span>
                      <span className={cn("font-semibold", trendColor)}>
                        {formatValue(metric.currentValue, metric.format)}
                      </span>
                    </div>
                    <Progress 
                      value={currentProgress} 
                      className={cn(
                        "h-2",
                        isPositive && "[&>div]:bg-success",
                        isNegative && "[&>div]:bg-destructive",
                        isStable && "[&>div]:bg-muted-foreground"
                      )}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
