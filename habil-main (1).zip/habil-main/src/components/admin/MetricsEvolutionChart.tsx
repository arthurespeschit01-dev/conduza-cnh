import { useMemo, useState, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { format, eachDayOfInterval, eachWeekOfInterval, eachMonthOfInterval, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, UserPlus, Calendar, Download, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import { toast } from 'sonner';

interface MetricsEvolutionData {
  date: Date;
  approvals: number;
  rejections: number;
  newInstructors: number;
  schedules: number;
}

interface MetricsEvolutionChartProps {
  data: MetricsEvolutionData[];
  startDate: Date;
  endDate: Date;
}

type MetricKey = 'approvals' | 'rejections' | 'newInstructors' | 'schedules';

const chartConfig = {
  approvals: {
    label: "Aprovações",
    color: "hsl(var(--success))",
    icon: CheckCircle,
  },
  rejections: {
    label: "Rejeições",
    color: "hsl(var(--destructive))",
    icon: XCircle,
  },
  newInstructors: {
    label: "Novos Instrutores",
    color: "hsl(var(--primary))",
    icon: UserPlus,
  },
  schedules: {
    label: "Agendamentos",
    color: "hsl(var(--accent))",
    icon: Calendar,
  },
};

export const MetricsEvolutionChart = ({ data, startDate, endDate }: MetricsEvolutionChartProps) => {
  const [visibleMetrics, setVisibleMetrics] = useState<MetricKey[]>([
    'approvals', 'rejections', 'newInstructors', 'schedules'
  ]);
  const [isExporting, setIsExporting] = useState(false);
  const chartRef = useRef<HTMLDivElement>(null);

  const chartData = useMemo(() => {
    const daysDiff = differenceInDays(endDate, startDate);
    
    let intervals: Date[];
    let formatStr: string;
    
    if (daysDiff <= 7) {
      intervals = eachDayOfInterval({ start: startDate, end: endDate });
      formatStr = 'dd/MM';
    } else if (daysDiff <= 60) {
      intervals = eachWeekOfInterval({ start: startDate, end: endDate }, { weekStartsOn: 0 });
      formatStr = "'Sem' w";
    } else {
      intervals = eachMonthOfInterval({ start: startDate, end: endDate });
      formatStr = 'MMM/yy';
    }
    
    return intervals.map((intervalDate, index) => {
      const nextInterval = intervals[index + 1] || endDate;
      
      const periodData = data.filter(d => {
        const date = new Date(d.date);
        return date >= intervalDate && date < nextInterval;
      });
      
      const aggregated = periodData.reduce(
        (acc, curr) => ({
          approvals: acc.approvals + curr.approvals,
          rejections: acc.rejections + curr.rejections,
          newInstructors: acc.newInstructors + curr.newInstructors,
          schedules: acc.schedules + curr.schedules,
        }),
        { approvals: 0, rejections: 0, newInstructors: 0, schedules: 0 }
      );
      
      return {
        label: format(intervalDate, formatStr, { locale: ptBR }),
        ...aggregated,
      };
    });
  }, [data, startDate, endDate]);

  const handleToggleMetric = (values: string[]) => {
    if (values.length > 0) {
      setVisibleMetrics(values as MetricKey[]);
    }
  };

  const handleExportPNG = async () => {
    if (!chartRef.current) return;
    
    setIsExporting(true);
    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
        logging: false,
      });
      
      const link = document.createElement('a');
      link.download = `evolucao-metricas-${format(new Date(), 'yyyy-MM-dd')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      
      toast.success('Gráfico exportado com sucesso!');
    } catch (error) {
      console.error('Erro ao exportar gráfico:', error);
      toast.error('Erro ao exportar gráfico');
    } finally {
      setIsExporting(false);
    }
  };

  if (chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-muted-foreground">
        Sem dados para o período selecionado
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <ToggleGroup 
          type="multiple" 
          value={visibleMetrics} 
          onValueChange={handleToggleMetric}
          className="flex flex-wrap gap-1"
        >
          {(Object.keys(chartConfig) as MetricKey[]).map((key) => {
            const config = chartConfig[key];
            const Icon = config.icon;
            const isActive = visibleMetrics.includes(key);
            return (
              <ToggleGroupItem
                key={key}
                value={key}
                aria-label={`Toggle ${config.label}`}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs data-[state=on]:bg-accent"
                style={{
                  borderColor: isActive ? config.color : undefined,
                  borderWidth: isActive ? '2px' : '1px',
                }}
              >
                <Icon 
                  className="h-3.5 w-3.5" 
                  style={{ color: config.color }}
                />
                <span>{config.label}</span>
              </ToggleGroupItem>
            );
          })}
        </ToggleGroup>

        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleExportPNG}
          disabled={isExporting}
          className="gap-2"
        >
          {isExporting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Download className="h-4 w-4" />
          )}
          Exportar PNG
        </Button>
      </div>

      <div ref={chartRef} className="bg-background p-4 rounded-lg">
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
          <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="label" 
              className="text-xs fill-muted-foreground"
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              className="text-xs fill-muted-foreground"
              tickLine={false}
              axisLine={false}
              allowDecimals={false}
            />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend 
              verticalAlign="top" 
              height={36}
              formatter={(value) => (
                <span className="text-sm text-muted-foreground">{chartConfig[value as keyof typeof chartConfig]?.label || value}</span>
              )}
            />
            {visibleMetrics.includes('approvals') && (
              <Line 
                type="monotone" 
                dataKey="approvals" 
                stroke="hsl(var(--success))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--success))', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
            {visibleMetrics.includes('rejections') && (
              <Line 
                type="monotone" 
                dataKey="rejections" 
                stroke="hsl(var(--destructive))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--destructive))', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
            {visibleMetrics.includes('newInstructors') && (
              <Line 
                type="monotone" 
                dataKey="newInstructors" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
            {visibleMetrics.includes('schedules') && (
              <Line 
                type="monotone" 
                dataKey="schedules" 
                stroke="hsl(var(--accent))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--accent))', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
          </LineChart>
        </ChartContainer>
      </div>
    </div>
  );
};
