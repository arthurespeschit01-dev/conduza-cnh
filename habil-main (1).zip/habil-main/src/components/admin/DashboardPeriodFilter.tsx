import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { CalendarIcon, CalendarDays } from 'lucide-react';
import { format, subDays, subWeeks, subMonths, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

export type DashboardPeriodType = 'today' | 'yesterday' | 'last_7_days' | 'last_30_days' | 'this_month' | 'last_month' | 'custom';

export interface DashboardPeriod {
  type: DashboardPeriodType;
  startDate: Date;
  endDate: Date;
  label: string;
}

interface DashboardPeriodFilterProps {
  period: DashboardPeriod;
  onPeriodChange: (period: DashboardPeriod) => void;
}

const periodOptions: { value: DashboardPeriodType; label: string }[] = [
  { value: 'today', label: 'Hoje' },
  { value: 'yesterday', label: 'Ontem' },
  { value: 'last_7_days', label: 'Últimos 7 dias' },
  { value: 'last_30_days', label: 'Últimos 30 dias' },
  { value: 'this_month', label: 'Este mês' },
  { value: 'last_month', label: 'Mês passado' },
  { value: 'custom', label: 'Personalizado' },
];

const getPeriodDates = (type: DashboardPeriodType): { startDate: Date; endDate: Date } => {
  const now = new Date();
  const today = startOfDay(now);
  const endOfToday = endOfDay(now);

  switch (type) {
    case 'today':
      return { startDate: today, endDate: endOfToday };
    case 'yesterday':
      return { startDate: startOfDay(subDays(now, 1)), endDate: endOfDay(subDays(now, 1)) };
    case 'last_7_days':
      return { startDate: startOfDay(subDays(now, 7)), endDate: endOfToday };
    case 'last_30_days':
      return { startDate: startOfDay(subDays(now, 30)), endDate: endOfToday };
    case 'this_month':
      return { startDate: new Date(now.getFullYear(), now.getMonth(), 1), endDate: endOfToday };
    case 'last_month':
      const lastMonth = subMonths(now, 1);
      return {
        startDate: new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1),
        endDate: new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59),
      };
    default:
      return { startDate: today, endDate: endOfToday };
  }
};

export const getDefaultPeriod = (): DashboardPeriod => {
  const dates = getPeriodDates('last_30_days');
  return {
    type: 'last_30_days',
    ...dates,
    label: 'Últimos 30 dias',
  };
};

export const DashboardPeriodFilter = ({ period, onPeriodChange }: DashboardPeriodFilterProps) => {
  const [customStartDate, setCustomStartDate] = useState<Date | undefined>(period.startDate);
  const [customEndDate, setCustomEndDate] = useState<Date | undefined>(period.endDate);
  const [startOpen, setStartOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);

  const handlePeriodTypeChange = (type: DashboardPeriodType) => {
    if (type === 'custom') {
      onPeriodChange({
        type: 'custom',
        startDate: customStartDate || new Date(),
        endDate: customEndDate || new Date(),
        label: 'Personalizado',
      });
    } else {
      const dates = getPeriodDates(type);
      const option = periodOptions.find(p => p.value === type);
      onPeriodChange({
        type,
        ...dates,
        label: option?.label || type,
      });
    }
  };

  const handleCustomStartChange = (date: Date | undefined) => {
    if (date) {
      setCustomStartDate(date);
      const start = startOfDay(date);
      onPeriodChange({
        type: 'custom',
        startDate: start,
        endDate: period.endDate,
        label: `${format(start, 'dd/MM/yy')} - ${format(period.endDate, 'dd/MM/yy')}`,
      });
      setStartOpen(false);
    }
  };

  const handleCustomEndChange = (date: Date | undefined) => {
    if (date) {
      setCustomEndDate(date);
      const end = endOfDay(date);
      onPeriodChange({
        type: 'custom',
        startDate: period.startDate,
        endDate: end,
        label: `${format(period.startDate, 'dd/MM/yy')} - ${format(end, 'dd/MM/yy')}`,
      });
      setEndOpen(false);
    }
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="flex items-center gap-2">
        <CalendarDays className="h-4 w-4 text-muted-foreground" />
        <Select value={period.type} onValueChange={(v) => handlePeriodTypeChange(v as DashboardPeriodType)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Selecione o período" />
          </SelectTrigger>
          <SelectContent>
            {periodOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {period.type === 'custom' && (
        <div className="flex items-center gap-2">
          <Popover open={startOpen} onOpenChange={setStartOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={cn(
                  'w-[130px] justify-start text-left font-normal',
                  !customStartDate && 'text-muted-foreground'
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {customStartDate ? format(customStartDate, 'dd/MM/yyyy', { locale: ptBR }) : 'Início'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={customStartDate}
                onSelect={handleCustomStartChange}
                initialFocus
                locale={ptBR}
                disabled={(date) => date > new Date()}
              />
            </PopoverContent>
          </Popover>

          <span className="text-muted-foreground">até</span>

          <Popover open={endOpen} onOpenChange={setEndOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={cn(
                  'w-[130px] justify-start text-left font-normal',
                  !customEndDate && 'text-muted-foreground'
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {customEndDate ? format(customEndDate, 'dd/MM/yyyy', { locale: ptBR }) : 'Fim'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={customEndDate}
                onSelect={handleCustomEndChange}
                initialFocus
                locale={ptBR}
                disabled={(date) => date > new Date() || (customStartDate ? date < customStartDate : false)}
              />
            </PopoverContent>
          </Popover>
        </div>
      )}

      {period.type !== 'custom' && (
        <span className="text-sm text-muted-foreground">
          {format(period.startDate, "dd/MM/yyyy", { locale: ptBR })} - {format(period.endDate, "dd/MM/yyyy", { locale: ptBR })}
        </span>
      )}
    </div>
  );
};
