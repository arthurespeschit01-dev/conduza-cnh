import { 
  Lightbulb, 
  AlertTriangle, 
  AlertCircle, 
  Info,
  TrendingUp,
  FileText,
  Users,
  Clock,
  CheckCircle,
  MapPin
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';

interface Insight {
  id: string;
  type: 'info' | 'warning' | 'critical';
  title: string;
  description: string;
  category: string;
  createdAt: Date;
}

interface SystemInsightsProps {
  insights: Insight[];
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'Aprovação':
      return Clock;
    case 'Engajamento':
      return Users;
    case 'Crescimento':
      return MapPin;
    case 'Qualidade':
      return CheckCircle;
    case 'Operacional':
      return TrendingUp;
    case 'Documentação':
      return FileText;
    case 'Tendência':
      return TrendingUp;
    default:
      return Lightbulb;
  }
};

const getTypeStyles = (type: Insight['type']) => {
  switch (type) {
    case 'critical':
      return {
        bg: 'bg-destructive/10',
        border: 'border-destructive/20',
        icon: AlertCircle,
        iconColor: 'text-destructive',
        badge: 'bg-destructive text-destructive-foreground',
        badgeText: 'Crítico',
      };
    case 'warning':
      return {
        bg: 'bg-warning/10',
        border: 'border-warning/20',
        icon: AlertTriangle,
        iconColor: 'text-warning',
        badge: 'bg-warning text-warning-foreground',
        badgeText: 'Atenção',
      };
    case 'info':
    default:
      return {
        bg: 'bg-primary/5',
        border: 'border-primary/20',
        icon: Info,
        iconColor: 'text-primary',
        badge: 'bg-primary/10 text-primary',
        badgeText: 'Info',
      };
  }
};

export const SystemInsights = ({ insights }: SystemInsightsProps) => {
  const criticalCount = insights.filter(i => i.type === 'critical').length;
  const warningCount = insights.filter(i => i.type === 'warning').length;
  const infoCount = insights.filter(i => i.type === 'info').length;

  return (
    <Card className="card-elevated">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-accent" />
            Insights do Sistema
          </CardTitle>
          <div className="flex gap-2">
            {criticalCount > 0 && (
              <Badge variant="destructive" className="flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {criticalCount}
              </Badge>
            )}
            {warningCount > 0 && (
              <Badge className="bg-warning text-warning-foreground flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                {warningCount}
              </Badge>
            )}
            {infoCount > 0 && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <Info className="h-3 w-3" />
                {infoCount}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {insights.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="h-12 w-12 rounded-full bg-success/10 flex items-center justify-center mb-4">
              <CheckCircle className="h-6 w-6 text-success" />
            </div>
            <p className="text-lg font-medium text-foreground">Tudo certo!</p>
            <p className="text-sm text-muted-foreground">
              Nenhum alerta ou insight no momento.
            </p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <AnimatePresence mode="popLayout">
              <div className="space-y-3">
                {insights.map((insight, index) => {
                  const styles = getTypeStyles(insight.type);
                  const TypeIcon = styles.icon;
                  const CategoryIcon = getCategoryIcon(insight.category);

                  return (
                    <motion.div
                      key={insight.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ delay: index * 0.05 }}
                      className={`p-4 rounded-xl ${styles.bg} border ${styles.border}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`mt-0.5 ${styles.iconColor}`}>
                          <TypeIcon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <h4 className="font-medium text-foreground">
                              {insight.title}
                            </h4>
                            <Badge className={styles.badge} variant="secondary">
                              {styles.badgeText}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {insight.description}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-xs flex items-center gap-1">
                              <CategoryIcon className="h-3 w-3" />
                              {insight.category}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </AnimatePresence>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};
