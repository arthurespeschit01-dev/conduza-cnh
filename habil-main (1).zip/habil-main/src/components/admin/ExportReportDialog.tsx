import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Download, Calendar } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

export type ReportPeriodType = 'today' | 'yesterday' | 'this_week' | 'last_week' | 'this_month' | 'last_month' | 'last_quarter' | 'last_year' | 'custom';

export interface ReportPeriodDates {
  type: ReportPeriodType;
  startDate: Date;
  endDate: Date;
}

interface ExportReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onExport: (period: ReportPeriodDates) => void;
  isLoading?: boolean;
}

const periodOptions: { value: ReportPeriodType; label: string; description: string }[] = [
  { value: 'today', label: 'Hoje', description: 'Dados do dia atual' },
  { value: 'yesterday', label: 'Ontem', description: 'Dados do dia anterior' },
  { value: 'this_week', label: 'Esta Semana', description: 'Dados da semana atual' },
  { value: 'last_week', label: 'Semana Passada', description: 'Dados da última semana completa' },
  { value: 'this_month', label: 'Este Mês', description: 'Dados do mês atual' },
  { value: 'last_month', label: 'Mês Passado', description: 'Dados do último mês completo' },
  { value: 'last_quarter', label: 'Último Trimestre', description: 'Dados dos últimos 90 dias' },
  { value: 'last_year', label: 'Último Ano', description: 'Dados dos últimos 12 meses' },
  { value: 'custom', label: 'Personalizado', description: 'Selecione um período específico' },
];

const getPeriodDates = (type: ReportPeriodType, customStart?: Date, customEnd?: Date): { start: Date; end: Date } => {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  switch (type) {
    case 'today':
      return { start: today, end: now };
    case 'yesterday':
      const yesterday = subDays(today, 1);
      return { start: yesterday, end: new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 23, 59, 59) };
    case 'this_week':
      return { start: startOfWeek(today, { weekStartsOn: 0 }), end: now };
    case 'last_week':
      const lastWeekStart = startOfWeek(subDays(today, 7), { weekStartsOn: 0 });
      return { start: lastWeekStart, end: endOfWeek(lastWeekStart, { weekStartsOn: 0 }) };
    case 'this_month':
      return { start: startOfMonth(today), end: now };
    case 'last_month':
      const lastMonth = subMonths(today, 1);
      return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
    case 'last_quarter':
      return { start: subDays(today, 90), end: now };
    case 'last_year':
      return { start: subDays(today, 365), end: now };
    case 'custom':
      return { start: customStart || subDays(today, 7), end: customEnd || now };
    default:
      return { start: today, end: now };
  }
};

export const ExportReportDialog = ({
  open,
  onOpenChange,
  onExport,
  isLoading = false,
}: ExportReportDialogProps) => {
  const [selectedPeriod, setSelectedPeriod] = useState<ReportPeriodType>('last_month');
  const [customStartDate, setCustomStartDate] = useState<Date>(subDays(new Date(), 7));
  const [customEndDate, setCustomEndDate] = useState<Date>(new Date());

  const handleExport = () => {
    const { start, end } = getPeriodDates(selectedPeriod, customStartDate, customEndDate);
    onExport({
      type: selectedPeriod,
      startDate: start,
      endDate: end,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Exportar Relatório
          </DialogTitle>
          <DialogDescription>
            Selecione o período para o relatório operacional
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <RadioGroup
            value={selectedPeriod}
            onValueChange={(value) => setSelectedPeriod(value as ReportPeriodType)}
            className="space-y-2"
          >
            {periodOptions.map((option) => (
              <div
                key={option.value}
                className={cn(
                  "flex items-start space-x-3 rounded-lg border p-3 cursor-pointer transition-colors",
                  selectedPeriod === option.value
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                )}
                onClick={() => setSelectedPeriod(option.value)}
              >
                <RadioGroupItem value={option.value} id={option.value} className="mt-0.5" />
                <Label htmlFor={option.value} className="flex-1 cursor-pointer">
                  <span className="font-medium text-foreground">{option.label}</span>
                  <p className="text-sm text-muted-foreground mt-0.5">{option.description}</p>
                </Label>
              </div>
            ))}
          </RadioGroup>

          {selectedPeriod === 'custom' && (
            <div className="mt-4 p-4 border rounded-lg bg-muted/30 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Data Inicial</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {format(customStartDate, 'dd/MM/yyyy', { locale: ptBR })}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={customStartDate}
                        onSelect={(date) => date && setCustomStartDate(date)}
                        disabled={(date) => date > customEndDate || date > new Date()}
                        initialFocus
                        locale={ptBR}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Data Final</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {format(customEndDate, 'dd/MM/yyyy', { locale: ptBR })}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={customEndDate}
                        onSelect={(date) => date && setCustomEndDate(date)}
                        disabled={(date) => date < customStartDate || date > new Date()}
                        initialFocus
                        locale={ptBR}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleExport} disabled={isLoading} className="gap-2">
            <Download className="h-4 w-4" />
            Exportar PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
