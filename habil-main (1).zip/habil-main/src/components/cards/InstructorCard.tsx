import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Users, Award, MapPin, Clock, Navigation, Crown, BadgeCheck, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface InstructorCardProps {
  instructor: {
    id: string;
    full_name: string;
    bio?: string | null;
    price_per_hour?: number | null;
    uf: string;
    city: string;
    avatar_url?: string | null;
    years_of_experience?: number | null;
    approvalRate: number;
    totalStudents: number;
    rating: number;
    reviewCount: number;
    categories: ('A' | 'B' | 'AB')[];
    distance_km?: number | null;
    subscription_plan?: 'basic' | 'professional' | 'premium' | null;
  };
  onSelect?: (instructor: InstructorCardProps['instructor']) => void;
  showDistance?: boolean;
  formatDistance?: (km: number | null) => string | null;
}

export const InstructorCard = ({ instructor, onSelect, showDistance, formatDistance }: InstructorCardProps) => {
  const distanceText = showDistance && formatDistance ? formatDistance(instructor.distance_km ?? null) : null;
  const isPremium = instructor.subscription_plan === 'premium';
  const isProfessional = instructor.subscription_plan === 'professional';
  const hasHighApproval = instructor.approvalRate >= 85;

  return (
    <div 
      className={cn(
        "card-elevated p-6 animate-fade-in relative overflow-hidden transition-all duration-300",
        isPremium && "ring-2 ring-amber-400/50 bg-gradient-to-br from-amber-50/50 to-background dark:from-amber-950/20",
        isProfessional && !isPremium && "ring-1 ring-primary/30 bg-gradient-to-br from-primary/5 to-background"
      )}
    >
      {/* Premium/Professional Badge Ribbon */}
      {isPremium && (
        <div className="absolute -right-8 top-4 rotate-45 bg-gradient-to-r from-amber-500 to-yellow-400 px-8 py-1 text-xs font-bold text-white shadow-lg">
          <Crown className="h-3 w-3 inline mr-1" />
          PREMIUM
        </div>
      )}
      {isProfessional && !isPremium && (
        <div className="absolute -right-8 top-4 rotate-45 bg-gradient-to-r from-primary to-primary/80 px-8 py-1 text-xs font-bold text-primary-foreground shadow-lg">
          <BadgeCheck className="h-3 w-3 inline mr-1" />
          VERIFICADO
        </div>
      )}

      <div className="flex items-start gap-4">
        <div className={cn(
          "h-16 w-16 rounded-xl overflow-hidden flex items-center justify-center text-xl font-bold flex-shrink-0 relative",
          isPremium ? "ring-2 ring-amber-400 shadow-lg shadow-amber-400/20" : 
          isProfessional ? "ring-2 ring-primary/50" : "gradient-primary text-primary-foreground"
        )}>
          {instructor.avatar_url ? (
            <img 
              src={instructor.avatar_url} 
              alt={instructor.full_name} 
              className="h-full w-full object-cover"
            />
          ) : (
            <div className={cn(
              "h-full w-full flex items-center justify-center",
              isPremium ? "bg-gradient-to-br from-amber-400 to-yellow-500 text-white" :
              isProfessional ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground" :
              "gradient-primary text-primary-foreground"
            )}>
              {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
          )}
          {isPremium && (
            <div className="absolute -bottom-1 -right-1 bg-amber-400 rounded-full p-1">
              <Sparkles className="h-3 w-3 text-white" />
            </div>
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground truncate">{instructor.full_name}</h3>
                {isPremium && (
                  <Badge className="bg-gradient-to-r from-amber-500 to-yellow-400 text-white border-0 text-[10px] px-1.5">
                    <Crown className="h-2.5 w-2.5 mr-0.5" />
                    Premium
                  </Badge>
                )}
                {isProfessional && !isPremium && (
                  <Badge className="bg-primary text-primary-foreground border-0 text-[10px] px-1.5">
                    <BadgeCheck className="h-2.5 w-2.5 mr-0.5" />
                    Verificado
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                <MapPin className="h-3 w-3" />
                <span>{instructor.city}, {instructor.uf}</span>
                {distanceText && (
                  <span className="flex items-center gap-1 ml-2 text-primary font-medium">
                    <Navigation className="h-3 w-3" />
                    {distanceText}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 text-accent">
              <Star className="h-4 w-4 fill-current" />
              <span className="font-semibold">{instructor.rating.toFixed(1)}</span>
              <span className="text-muted-foreground text-xs">({instructor.reviewCount})</span>
            </div>
          </div>
          
          {instructor.bio && (
            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{instructor.bio}</p>
          )}
          
          <div className="flex flex-wrap gap-2 mt-3">
            {instructor.categories.map((cat) => (
              <Badge key={cat} variant="secondary" className="text-xs">
                Categoria {cat}
              </Badge>
            ))}
            {instructor.years_of_experience && instructor.years_of_experience > 0 && (
              <Badge variant="outline" className="text-xs flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {instructor.years_of_experience} anos
              </Badge>
            )}
            {hasHighApproval && (isProfessional || isPremium) && (
              <Badge className="bg-success/10 text-success border-success/20 text-xs flex items-center gap-1">
                <Award className="h-3 w-3" />
                Alta Aprovação
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-4 mt-4 text-sm">
            <div className="flex items-center gap-1 text-success">
              <Award className="h-4 w-4" />
              <span className="font-medium">{instructor.approvalRate}% aprovação</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{instructor.totalStudents} alunos</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
            <div>
              <span className="text-2xl font-bold text-foreground">R$ {instructor.price_per_hour || 0}</span>
              <span className="text-sm text-muted-foreground">/hora</span>
            </div>
            {onSelect && (
              <Button 
                variant="hero" 
                size="sm" 
                onClick={() => onSelect(instructor)}
                className={cn(
                  isPremium && "bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-600 hover:to-yellow-500"
                )}
              >
                Contratar
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
