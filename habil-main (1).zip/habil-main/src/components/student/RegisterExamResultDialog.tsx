import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';
import { 
  Trophy, 
  CheckCircle2, 
  XCircle, 
  Loader2, 
  Upload, 
  FileText,
  X 
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface RegisterExamResultDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instructorId: string;
  onExamRegistered: () => void;
}

export const RegisterExamResultDialog = ({ 
  open, 
  onOpenChange,
  instructorId,
  onExamRegistered 
}: RegisterExamResultDialogProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedResult, setSelectedResult] = useState<'approved' | 'failed' | null>(null);
  const [examDate, setExamDate] = useState(new Date().toISOString().split('T')[0]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: 'Tipo de arquivo inválido',
          description: 'Por favor, envie um arquivo PDF ou imagem (JPG, PNG)',
          variant: 'destructive',
        });
        return;
      }
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'Arquivo muito grande',
          description: 'O arquivo deve ter no máximo 5MB',
          variant: 'destructive',
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const uploadDocument = async (file: File): Promise<string | null> => {
    if (!user) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/exam-${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('exam-documents')
      .upload(fileName, file);

    if (uploadError) {
      logger.error('Error uploading document:', uploadError);
      return null;
    }

    return fileName;
  };

  const handleSubmit = async () => {
    if (!user || !selectedResult) {
      toast({
        title: 'Selecione o resultado',
        description: 'Por favor, indique se você foi aprovado ou reprovado.',
        variant: 'destructive',
      });
      return;
    }

    if (!instructorId) {
      toast({
        title: 'Instrutor não identificado',
        description: 'Não foi possível identificar seu instrutor. Agende uma aula primeiro.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      let documentUrl: string | undefined;

      // Upload document if provided
      if (selectedFile) {
        const uploadedPath = await uploadDocument(selectedFile);
        if (!uploadedPath) {
          throw new Error('Erro ao enviar documento');
        }
        documentUrl = uploadedPath;
      }

      // Create exam record
      const { error: insertError } = await supabase
        .from('exams')
        .insert({
          student_id: user.id,
          instructor_id: instructorId,
          exam_type: 'practical',
          exam_date: examDate,
          category: 'B', // Default to B, can be made dynamic
          status: selectedResult,
          confirmed_by_student: true,
          student_passed: selectedResult === 'approved',
          document_url: documentUrl,
        });

      if (insertError) throw insertError;

      toast({
        title: selectedResult === 'approved' ? 'Parabéns! 🎉' : 'Resultado registrado',
        description: selectedResult === 'approved' 
          ? 'Você foi aprovado no exame prático!' 
          : 'Não desanime, você pode tentar novamente.',
      });

      // Reset form
      setSelectedFile(null);
      setSelectedResult(null);
      setExamDate(new Date().toISOString().split('T')[0]);
      
      onExamRegistered();
      onOpenChange(false);
    } catch (error) {
      logger.error('Error registering exam result:', error);
      toast({
        title: 'Erro ao registrar resultado',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setSelectedResult(null);
    setExamDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) resetForm();
      onOpenChange(isOpen);
    }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            Registrar Resultado do Exame
          </DialogTitle>
          <DialogDescription>
            Registre o resultado do seu exame prático. Esta informação será usada para calcular a taxa de aprovação do instrutor.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Exam Date */}
          <div className="space-y-2">
            <Label htmlFor="examDate">Data do Exame</Label>
            <Input
              id="examDate"
              type="date"
              value={examDate}
              onChange={(e) => setExamDate(e.target.value)}
              max={new Date().toISOString().split('T')[0]}
            />
          </div>

          {/* Result Selection */}
          <div className="space-y-2">
            <Label>Resultado do Exame</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => setSelectedResult('failed')}
                className={cn(
                  "h-24 flex-col gap-2 transition-all",
                  selectedResult === 'failed' 
                    ? "border-destructive bg-destructive/10" 
                    : "border-muted hover:bg-destructive/10 hover:border-destructive"
                )}
              >
                <XCircle className={cn(
                  "h-8 w-8",
                  selectedResult === 'failed' ? "text-destructive" : "text-muted-foreground"
                )} />
                <span className={cn(
                  selectedResult === 'failed' ? "text-destructive" : "text-muted-foreground"
                )}>
                  Reprovado
                </span>
              </Button>
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => setSelectedResult('approved')}
                className={cn(
                  "h-24 flex-col gap-2 transition-all",
                  selectedResult === 'approved' 
                    ? "border-success bg-success/10" 
                    : "border-muted hover:bg-success/10 hover:border-success"
                )}
              >
                <CheckCircle2 className={cn(
                  "h-8 w-8",
                  selectedResult === 'approved' ? "text-success" : "text-muted-foreground"
                )} />
                <span className={cn(
                  selectedResult === 'approved' ? "text-success" : "text-muted-foreground"
                )}>
                  Aprovado
                </span>
              </Button>
            </div>
          </div>

          {/* Document Upload */}
          <div className="space-y-2">
            <Label>Comprovante do Exame (opcional)</Label>
            <p className="text-xs text-muted-foreground mb-2">
              Envie uma foto ou PDF do resultado oficial
            </p>
            
            {!selectedFile ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-muted rounded-xl p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
              >
                <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  Clique para enviar
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  PDF, JPG ou PNG (máx. 5MB)
                </p>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
                <FileText className="h-8 w-8 text-primary" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate">
                    {selectedFile.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={removeFile}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
            
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.jpg,.jpeg,.png,.webp"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !selectedResult}
            className="w-full"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Registrando...
              </>
            ) : (
              'Registrar Resultado'
            )}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            Esta informação é importante para calcular a taxa de aprovação do seu instrutor.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
