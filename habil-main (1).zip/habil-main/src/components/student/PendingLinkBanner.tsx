import { Handshake, X, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { useInstructorLink } from '@/hooks/useInstructorLink';

export const PendingLinkBanner = () => {
  const { pendingLink, isLoading, confirmLink, cancelPendingLink } = useInstructorLink();

  if (!pendingLink) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
        className="mb-6 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-background border border-amber-500/30 rounded-xl p-4 shadow-lg"
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-amber-500/20 flex items-center justify-center">
              <Handshake className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Contato em andamento</h3>
              <p className="text-sm text-muted-foreground">
                Você entrou em contato com <span className="font-medium text-foreground">{pendingLink.instructorName}</span>. Vocês fecharam as aulas?
              </p>
            </div>
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              onClick={confirmLink}
              disabled={isLoading}
              className="flex-1 sm:flex-none bg-amber-500 hover:bg-amber-600 text-black font-semibold"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Check className="h-4 w-4 mr-2" />
              )}
              Sim, vincular instrutor
            </Button>
            <Button
              variant="outline"
              onClick={cancelPendingLink}
              disabled={isLoading}
              className="flex-1 sm:flex-none border-muted-foreground/30 hover:bg-muted"
            >
              <X className="h-4 w-4 mr-2" />
              Não, continuar procurando
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
