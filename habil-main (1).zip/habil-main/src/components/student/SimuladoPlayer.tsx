import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  CheckCircle2, 
  XCircle,
  RotateCcw,
  Trophy,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ExamQuestion } from '@/hooks/useSimulados';
import { motion, AnimatePresence } from 'framer-motion';

interface SimuladoPlayerProps {
  questions: ExamQuestion[];
  simuladoName: string;
  onComplete: (correctAnswers: number, timeTaken: number, answers: Record<string, number>) => void;
  onClose: () => void;
}

const CATEGORY_ICONS: Record<string, string> = {
  legislacao: '📜',
  direcao_defensiva: '🛡️',
  primeiros_socorros: '🏥',
  mecanica: '🔧',
  meio_ambiente: '🌱',
};

export const SimuladoPlayer = ({ 
  questions, 
  simuladoName, 
  onComplete, 
  onClose 
}: SimuladoPlayerProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResult, setShowResult] = useState(false);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;
  const answeredCount = Object.keys(answers).length;

  // Timer
  useEffect(() => {
    if (isFinished) return;
    
    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isFinished]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const selectAnswer = (optionIndex: number) => {
    if (showResult) return;
    
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: optionIndex,
    }));
    setShowResult(true);
  };

  const goToNext = useCallback(() => {
    setShowResult(false);
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  }, [currentIndex, questions.length]);

  const goToPrevious = () => {
    setShowResult(false);
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const finishSimulado = () => {
    setIsFinished(true);
    const correctCount = questions.reduce((count, q) => {
      return answers[q.id] === q.correct_option ? count + 1 : count;
    }, 0);
    onComplete(correctCount, timeElapsed, answers);
  };

  const restartSimulado = () => {
    setCurrentIndex(0);
    setAnswers({});
    setShowResult(false);
    setTimeElapsed(0);
    setIsFinished(false);
  };

  // Show final results
  if (isFinished) {
    const correctCount = questions.reduce((count, q) => {
      return answers[q.id] === q.correct_option ? count + 1 : count;
    }, 0);
    const score = (correctCount / questions.length) * 100;
    const passed = score >= 70;

    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="min-h-[500px] flex flex-col items-center justify-center text-center p-6"
      >
        <div className={cn(
          "h-24 w-24 rounded-full flex items-center justify-center mb-6",
          passed ? "bg-success/10" : "bg-destructive/10"
        )}>
          {passed ? (
            <Trophy className="h-12 w-12 text-success" />
          ) : (
            <AlertCircle className="h-12 w-12 text-destructive" />
          )}
        </div>

        <h2 className="text-2xl font-bold mb-2">
          {passed ? 'Parabéns!' : 'Continue Praticando!'}
        </h2>
        <p className="text-muted-foreground mb-6">
          {passed 
            ? 'Você foi aprovado no simulado!' 
            : 'Não desista, você precisa de 70% para aprovação.'}
        </p>

        <div className="grid grid-cols-3 gap-4 mb-8 w-full max-w-sm">
          <div className="p-4 rounded-lg bg-muted/50">
            <p className="text-2xl font-bold text-primary">{correctCount}</p>
            <p className="text-xs text-muted-foreground">Acertos</p>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
            <p className="text-2xl font-bold">{questions.length - correctCount}</p>
            <p className="text-xs text-muted-foreground">Erros</p>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
            <p className={cn(
              "text-2xl font-bold",
              passed ? "text-success" : "text-destructive"
            )}>
              {score.toFixed(0)}%
            </p>
            <p className="text-xs text-muted-foreground">Nota</p>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-6">
          Tempo total: {formatTime(timeElapsed)}
        </p>

        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose}>
            Voltar
          </Button>
          <Button onClick={restartSimulado}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Tentar Novamente
          </Button>
        </div>
      </motion.div>
    );
  }

  const selectedAnswer = answers[currentQuestion.id];
  const isAnswered = selectedAnswer !== undefined;
  const isCorrect = selectedAnswer === currentQuestion.correct_option;

  return (
    <div className="flex flex-col h-full min-h-[500px]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onClose}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            Voltar
          </Button>
          <Badge variant="outline" className="text-xs">
            {CATEGORY_ICONS[currentQuestion.category]} {currentQuestion.category.replace('_', ' ')}
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          {formatTime(timeElapsed)}
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">
            Questão {currentIndex + 1} de {questions.length}
          </span>
          <span className="text-muted-foreground">
            {answeredCount} respondidas
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="flex-1"
        >
          <h3 className="text-lg font-medium mb-6 leading-relaxed">
            {currentQuestion.question}
          </h3>

          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrectOption = index === currentQuestion.correct_option;
              
              let optionClass = "border-border/50 hover:border-primary/50 hover:bg-muted/30";
              
              if (showResult && isAnswered) {
                if (isCorrectOption) {
                  optionClass = "border-success bg-success/10";
                } else if (isSelected && !isCorrect) {
                  optionClass = "border-destructive bg-destructive/10";
                }
              } else if (isSelected) {
                optionClass = "border-primary bg-primary/5";
              }

              return (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  disabled={showResult}
                  className={cn(
                    "w-full p-4 rounded-lg border text-left transition-all",
                    "flex items-start gap-3",
                    optionClass,
                    showResult && "cursor-default"
                  )}
                >
                  <span className={cn(
                    "h-6 w-6 rounded-full border flex items-center justify-center text-xs font-medium flex-shrink-0",
                    showResult && isCorrectOption 
                      ? "bg-success text-success-foreground border-success" 
                      : showResult && isSelected && !isCorrect
                      ? "bg-destructive text-destructive-foreground border-destructive"
                      : isSelected
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-muted-foreground/30"
                  )}>
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="text-sm flex-1">{option}</span>
                  {showResult && isCorrectOption && (
                    <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0" />
                  )}
                  {showResult && isSelected && !isCorrect && (
                    <XCircle className="h-5 w-5 text-destructive flex-shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation */}
          {showResult && currentQuestion.explanation && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "mt-4 p-4 rounded-lg border",
                isCorrect 
                  ? "bg-success/5 border-success/30" 
                  : "bg-amber-500/5 border-amber-500/30"
              )}
            >
              <p className="text-sm text-muted-foreground">
                <strong className={isCorrect ? "text-success" : "text-amber-600"}>
                  {isCorrect ? '✓ Correto!' : '✗ Incorreto.'}
                </strong>{' '}
                {currentQuestion.explanation}
              </p>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-6 pt-4 border-t">
        <Button
          variant="outline"
          size="sm"
          onClick={goToPrevious}
          disabled={currentIndex === 0}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Anterior
        </Button>

        <div className="flex gap-2">
          {currentIndex === questions.length - 1 ? (
            <Button 
              onClick={finishSimulado}
              disabled={answeredCount < questions.length}
            >
              Finalizar Simulado
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={goToNext}
              disabled={!showResult}
            >
              Próxima
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
