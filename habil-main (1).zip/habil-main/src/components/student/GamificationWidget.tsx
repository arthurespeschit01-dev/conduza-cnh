import { Flame, Star, Trophy } from 'lucide-react';
import { useGamification } from '@/hooks/useGamification';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

export const GamificationWidget = () => {
  const { stats, achievements, isLoading } = useGamification();

  if (isLoading) {
    return (
      <div className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-card/50">
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-10 w-32" />
      </div>
    );
  }

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;

  return (
    <TooltipProvider>
      <div className="flex flex-wrap items-center gap-3 sm:gap-6 p-3 sm:p-4 rounded-lg border border-border/40 bg-gradient-to-r from-card/80 to-card/40 backdrop-blur-sm">
        {/* Points */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-amber-500/20 bg-amber-500/5">
              <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
              <span className="text-sm font-semibold text-amber-600 dark:text-amber-400">
                {stats.points}
              </span>
              <span className="text-xs text-muted-foreground hidden sm:inline">pts</span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-sm">
              Você acumulou <strong className="text-amber-500">{stats.points} pontos</strong>
              <br />
              <span className="text-xs text-muted-foreground">10 pontos por aula concluída</span>
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Streak */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-orange-500/20 bg-orange-500/5">
              <Flame className={cn(
                "h-4 w-4",
                stats.currentStreak >= 7 
                  ? "text-orange-500 fill-orange-500" 
                  : stats.currentStreak >= 3 
                    ? "text-orange-400" 
                    : "text-muted-foreground"
              )} />
              <span className={cn(
                "text-sm font-semibold",
                stats.currentStreak >= 7 
                  ? "text-orange-500" 
                  : stats.currentStreak >= 3 
                    ? "text-orange-400" 
                    : "text-foreground"
              )}>
                {stats.currentStreak}
              </span>
              <span className="text-xs text-muted-foreground hidden sm:inline">dias</span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-sm">
              <strong className="text-orange-500">{stats.currentStreak} dias</strong> consecutivos
              <br />
              <span className="text-xs text-muted-foreground">
                Recorde: {stats.longestStreak} dias
              </span>
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Achievements */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-border/40 bg-muted/30">
              <Trophy className={cn(
                "h-4 w-4",
                unlockedCount > 0 ? "text-amber-500" : "text-muted-foreground"
              )} />
              <span className="text-sm font-medium">
                {unlockedCount}/{totalCount}
              </span>
              <span className="text-xs text-muted-foreground hidden sm:inline">conquistas</span>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <div className="space-y-2">
              <p className="text-sm font-medium">Suas conquistas</p>
              <div className="flex flex-wrap gap-1.5">
                {achievements.map((achievement) => (
                  <span
                    key={achievement.id}
                    className={cn(
                      "text-lg transition-all",
                      achievement.unlocked 
                        ? "opacity-100 scale-100" 
                        : "opacity-30 grayscale scale-90"
                    )}
                    title={achievement.title}
                  >
                    {achievement.icon}
                  </span>
                ))}
              </div>
              {unlockedCount < totalCount && (
                <p className="text-xs text-muted-foreground">
                  {totalCount - unlockedCount} conquistas para desbloquear
                </p>
              )}
            </div>
          </TooltipContent>
        </Tooltip>

        {/* Achievement badges preview - only show unlocked */}
        <div className="hidden md:flex items-center gap-1 ml-auto">
          {achievements
            .filter(a => a.unlocked)
            .slice(0, 4)
            .map((achievement) => (
              <Tooltip key={achievement.id}>
                <TooltipTrigger asChild>
                  <span 
                    className="text-lg cursor-default hover:scale-110 transition-transform"
                  >
                    {achievement.icon}
                  </span>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-sm font-medium">{achievement.title}</p>
                  {achievement.description && (
                    <p className="text-xs text-muted-foreground">{achievement.description}</p>
                  )}
                </TooltipContent>
              </Tooltip>
            ))}
          {achievements.filter(a => a.unlocked).length > 4 && (
            <span className="text-xs text-muted-foreground ml-1">
              +{achievements.filter(a => a.unlocked).length - 4}
            </span>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
};
