import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';
import { Trophy, Lock, CheckCircle2, XCircle, Loader2, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface Exam {
  id: string;
  exam_date: string;
  exam_type: string;
  status: string;
  confirmed_by_student: boolean;
  confirmed_by_instructor: boolean;
  student_passed: boolean | null;
  instructor_id: string;
}

interface PracticalExamCardProps {
  practicalLessonsCompleted: number;
  practicalExams: Exam[];
  onExamUpdated: () => void;
}

export const PracticalExamCard = ({ 
  practicalLessonsCompleted, 
  practicalExams,
  onExamUpdated 
}: PracticalExamCardProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const REQUIRED_LESSONS = 2;
  const isUnlocked = practicalLessonsCompleted >= REQUIRED_LESSONS;
  
  // Check if there's an approved or pending practical exam
  const approvedExam = practicalExams.find(
    e => e.status === 'approved' && e.confirmed_by_student
  );
  const failedExam = practicalExams.find(
    e => e.status === 'failed' && e.confirmed_by_student
  );
  const pendingExam = practicalExams.find(
    e => !e.confirmed_by_student && e.status === 'pending'
  );

  const handleConfirmResult = async (examId: string, passed: boolean) => {
    if (!user) return;

    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('exams')
        .update({
          confirmed_by_student: true,
          student_passed: passed,
          status: passed ? 'approved' : 'failed',
        })
        .eq('id', examId)
        .eq('student_id', user.id);

      if (error) throw error;

      toast({
        title: passed ? 'Parabéns! 🎉' : 'Continue tentando!',
        description: passed 
          ? 'Você foi aprovado no exame prático!' 
          : 'Não desanime, você pode tentar novamente.',
      });

      onExamUpdated();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Error confirming exam result:', error);
      toast({
        title: 'Erro ao confirmar resultado',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusDisplay = () => {
    if (!isUnlocked) {
      return {
        label: 'Bloqueado',
        description: `Disponível após ${REQUIRED_LESSONS} aulas práticas (${practicalLessonsCompleted}/${REQUIRED_LESSONS})`,
        color: 'text-muted-foreground',
        bgColor: 'bg-muted',
      };
    }
    if (approvedExam) {
      return {
        label: 'Aprovado',
        description: `Aprovado em ${format(new Date(approvedExam.exam_date), 'dd/MM/yyyy', { locale: ptBR })}`,
        color: 'text-success',
        bgColor: 'bg-success/10',
      };
    }
    if (pendingExam) {
      return {
        label: 'Aguardando resultado',
        description: 'Confirme o resultado do seu exame',
        color: 'text-accent',
        bgColor: 'bg-accent/10',
      };
    }
    if (failedExam) {
      return {
        label: 'Disponível para retry',
        description: 'Você pode agendar um novo exame',
        color: 'text-primary',
        bgColor: 'bg-primary/10',
      };
    }
    return {
      label: 'Disponível',
      description: 'Você pode agendar seu exame prático',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    };
  };

  const status = getStatusDisplay();

  return (
    <>
      <div className={cn(
        "flex items-center gap-4 p-4 rounded-xl",
        isUnlocked ? "bg-muted/50" : "bg-muted/30 opacity-75"
      )}>
        <div className={cn(
          "h-12 w-12 rounded-xl flex items-center justify-center",
          status.bgColor
        )}>
          {!isUnlocked ? (
            <Lock className="h-6 w-6 text-muted-foreground" />
          ) : approvedExam ? (
            <CheckCircle2 className="h-6 w-6 text-success" />
          ) : (
            <Trophy className={cn("h-6 w-6", status.color)} />
          )}
        </div>
        <div className="flex-1">
          <p className={cn(
            "font-medium",
            isUnlocked ? "text-foreground" : "text-muted-foreground"
          )}>
            Exame Prático
          </p>
          <p className="text-sm text-muted-foreground">
            {status.description}
          </p>
        </div>
        {pendingExam && (
          <Button
            size="sm"
            onClick={() => setIsDialogOpen(true)}
          >
            Confirmar resultado
          </Button>
        )}
        {!isUnlocked && (
          <span className="text-sm text-muted-foreground">Bloqueado</span>
        )}
        {approvedExam && (
          <CheckCircle2 className="h-5 w-5 text-success" />
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Resultado do Exame Prático</DialogTitle>
            <DialogDescription>
              Como foi seu exame prático? Sua resposta será usada para calcular a taxa de aprovação do instrutor.
            </DialogDescription>
          </DialogHeader>

          {pendingExam && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium text-foreground">
                    Data do exame
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {format(new Date(pendingExam.exam_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleConfirmResult(pendingExam.id, false)}
                  disabled={isSubmitting}
                  className="h-24 flex-col gap-2 border-destructive/50 hover:bg-destructive/10 hover:border-destructive"
                >
                  {isSubmitting ? (
                    <Loader2 className="h-8 w-8 animate-spin" />
                  ) : (
                    <>
                      <XCircle className="h-8 w-8 text-destructive" />
                      <span className="text-destructive">Reprovado</span>
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleConfirmResult(pendingExam.id, true)}
                  disabled={isSubmitting}
                  className="h-24 flex-col gap-2 border-success/50 hover:bg-success/10 hover:border-success"
                >
                  {isSubmitting ? (
                    <Loader2 className="h-8 w-8 animate-spin" />
                  ) : (
                    <>
                      <CheckCircle2 className="h-8 w-8 text-success" />
                      <span className="text-success">Aprovado</span>
                    </>
                  )}
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center">
                Esta informação é importante para calcular a taxa de aprovação do seu instrutor.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
