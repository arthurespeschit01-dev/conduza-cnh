import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Star, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface InstructorReviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instructor: {
    id: string;
    full_name: string;
    avatar_url?: string | null;
  };
  onReviewSubmitted?: () => void;
}

export const InstructorReviewDialog = ({
  open,
  onOpenChange,
  instructor,
  onReviewSubmitted,
}: InstructorReviewDialogProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [existingReview, setExistingReview] = useState<{
    id: string;
    rating: number;
    comment: string | null;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (open && user && instructor) {
      fetchExistingReview();
    }
  }, [open, user, instructor]);

  const fetchExistingReview = async () => {
    if (!user) return;
    
    setIsLoading(true);
    const { data, error } = await supabase
      .from('instructor_reviews')
      .select('id, rating, comment')
      .eq('instructor_id', instructor.id)
      .eq('student_id', user.id)
      .maybeSingle();
    
    if (data && !error) {
      setExistingReview(data);
      setRating(data.rating);
      setComment(data.comment || '');
    } else {
      setExistingReview(null);
      setRating(0);
      setComment('');
    }
    setIsLoading(false);
  };

  const handleSubmit = async () => {
    if (!user || rating === 0) {
      toast({
        title: 'Selecione uma nota',
        description: 'Por favor, selecione de 1 a 5 estrelas.',
        variant: 'destructive',
      });
      return;
    }

    // Validate comment length
    const trimmedComment = comment.trim();
    if (trimmedComment.length > 1000) {
      toast({
        title: 'Comentário muito longo',
        description: 'O comentário deve ter no máximo 1000 caracteres.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      if (existingReview) {
        // Update existing review
        const { error } = await supabase
          .from('instructor_reviews')
          .update({
            rating,
            comment: comment || null,
          })
          .eq('id', existingReview.id);

        if (error) throw error;

        toast({
          title: 'Avaliação atualizada!',
          description: 'Sua avaliação foi atualizada com sucesso.',
        });
      } else {
        // Create new review
        const { error } = await supabase
          .from('instructor_reviews')
          .insert({
            instructor_id: instructor.id,
            student_id: user.id,
            rating,
            comment: comment || null,
          });

        if (error) throw error;

        toast({
          title: 'Avaliação enviada!',
          description: 'Obrigado por avaliar o instrutor.',
        });
      }

      onReviewSubmitted?.();
      onOpenChange(false);
    } catch (error) {
      console.error('Error submitting review:', error);
      toast({
        title: 'Erro ao enviar avaliação',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = () => {
    return (
      <div className="flex gap-2 justify-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoverRating(star)}
            onMouseLeave={() => setHoverRating(0)}
            className="transition-transform hover:scale-110 focus:outline-none"
          >
            <Star
              className={cn(
                "h-10 w-10 transition-colors",
                (hoverRating || rating) >= star
                  ? "fill-accent text-accent"
                  : "text-muted-foreground/30"
              )}
            />
          </button>
        ))}
      </div>
    );
  };

  const getRatingText = (value: number) => {
    switch (value) {
      case 1: return 'Ruim';
      case 2: return 'Regular';
      case 3: return 'Bom';
      case 4: return 'Muito bom';
      case 5: return 'Excelente';
      default: return '';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {existingReview ? 'Editar avaliação' : 'Avaliar instrutor'}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-6 py-4">
            {/* Instructor Info */}
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-xl overflow-hidden bg-muted flex items-center justify-center">
                {instructor.avatar_url ? (
                  <img
                    src={instructor.avatar_url}
                    alt={instructor.full_name}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="text-xl font-bold text-muted-foreground">
                    {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                  </span>
                )}
              </div>
              <div>
                <p className="font-semibold text-foreground">{instructor.full_name}</p>
                <p className="text-sm text-muted-foreground">Como foi sua experiência?</p>
              </div>
            </div>

            {/* Star Rating */}
            <div className="text-center space-y-2">
              {renderStars()}
              {(hoverRating || rating) > 0 && (
                <p className="text-sm font-medium text-accent">
                  {getRatingText(hoverRating || rating)}
                </p>
              )}
            </div>

            {/* Comment */}
            <div className="space-y-2">
              <Textarea
                placeholder="Deixe um comentário sobre sua experiência (opcional)"
                value={comment}
                onChange={(e) => {
                  // Limit to 1000 characters
                  if (e.target.value.length <= 1000) {
                    setComment(e.target.value);
                  }
                }}
                rows={4}
                maxLength={1000}
              />
              <p className="text-xs text-muted-foreground text-right">
                {comment.length}/1000 caracteres
              </p>
            </div>

            {/* Submit Button */}
            <Button
              variant="hero"
              onClick={handleSubmit}
              disabled={isSubmitting || rating === 0}
              className="w-full"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Enviando...
                </>
              ) : existingReview ? (
                'Atualizar avaliação'
              ) : (
                'Enviar avaliação'
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
