import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SimuladoPlayer } from './SimuladoPlayer';
import { useSimulados, SimuladoType } from '@/hooks/useSimulados';
import { Play, Clock, FileText, Trophy } from 'lucide-react';
import { toast } from 'sonner';

interface SimuladoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  simulado: SimuladoType | null;
}

export const SimuladoDialog = ({ open, onOpenChange, simulado }: SimuladoDialogProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const { getQuestionsForSimulado, saveAttempt } = useSimulados();

  if (!simulado) return null;

  const questions = getQuestionsForSimulado(simulado.id);

  const handleComplete = async (
    correctAnswers: number, 
    timeTaken: number, 
    answers: Record<string, number>
  ) => {
    const result = await saveAttempt(questions.length, correctAnswers, timeTaken, answers);
    
    if (result) {
      const passed = result.passed;
      if (passed) {
        toast.success('Parabéns! Você foi aprovado no simulado!', {
          description: `Nota: ${Number(result.score).toFixed(0)}%`,
        });
      } else {
        toast.info('Continue praticando!', {
          description: `Você precisa de 70% para aprovação. Sua nota: ${Number(result.score).toFixed(0)}%`,
        });
      }
    }
  };

  const handleClose = () => {
    setIsPlaying(false);
    onOpenChange(false);
  };

  const estimatedTime = Math.ceil(questions.length * 1.5); // 1.5 min per question

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {!isPlaying ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                {simulado.name}
              </DialogTitle>
              <DialogDescription>
                {simulado.description}
              </DialogDescription>
            </DialogHeader>

            <div className="py-6">
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="p-4 rounded-lg bg-muted/50 text-center">
                  <FileText className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">{questions.length}</p>
                  <p className="text-xs text-muted-foreground">Questões</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 text-center">
                  <Clock className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">~{estimatedTime}</p>
                  <p className="text-xs text-muted-foreground">Minutos</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 text-center">
                  <Trophy className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">70%</p>
                  <p className="text-xs text-muted-foreground">Para aprovar</p>
                </div>
              </div>

              {simulado.bestScore !== null && simulado.bestScore > 0 && (
                <div className="p-4 rounded-lg border border-primary/20 bg-primary/5 mb-6">
                  <p className="text-sm text-muted-foreground">
                    Sua melhor nota neste simulado:
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-2xl font-bold text-primary">
                      {simulado.bestScore.toFixed(0)}%
                    </span>
                    {simulado.completed && (
                      <Badge variant="default" className="bg-success">
                        Aprovado
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20">
                <h4 className="font-medium text-sm mb-2">Instruções:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Leia cada questão com atenção antes de responder</li>
                  <li>• Você deve responder todas as questões para finalizar</li>
                  <li>• Após responder, a explicação será exibida</li>
                  <li>• Você precisa acertar pelo menos 70% para aprovação</li>
                </ul>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={handleClose}>
                Cancelar
              </Button>
              <Button onClick={() => setIsPlaying(true)}>
                <Play className="h-4 w-4 mr-2" />
                Iniciar Simulado
              </Button>
            </div>
          </>
        ) : (
          <SimuladoPlayer
            questions={questions}
            simuladoName={simulado.name}
            onComplete={handleComplete}
            onClose={handleClose}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};
