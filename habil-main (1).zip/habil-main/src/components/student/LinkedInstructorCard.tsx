import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useInstructorLink } from '@/hooks/useInstructorLink';
import { useInstructorContact } from '@/hooks/useInstructorContact';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { User, MapPin, Star, Calendar, MessageCircle, ChevronRight, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { logger } from '@/lib/logger';

interface InstructorProfile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  city: string;
  neighborhood: string | null;
  price_per_hour: number | null;
  cnh_category: string | null;
}

export const LinkedInstructorCard = () => {
  const { linkedInstructor, unlinkInstructor, isLoading } = useInstructorLink();
  const { openWhatsApp, isLoading: isContactLoading } = useInstructorContact();
  const [instructor, setInstructor] = useState<InstructorProfile | null>(null);
  const [averageRating, setAverageRating] = useState<number | null>(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(false);

  useEffect(() => {
    const fetchInstructorProfile = async () => {
      if (!linkedInstructor?.instructorId) {
        setInstructor(null);
        return;
      }

      setIsLoadingProfile(true);
      try {
        // Fetch instructor profile (without whatsapp - that's fetched securely)
        const { data: profileData, error: profileError } = await supabase
          .from('public_instructor_profiles')
          .select('id, full_name, avatar_url, city, neighborhood, price_per_hour, cnh_category')
          .eq('id', linkedInstructor.instructorId)
          .single();

        if (profileError) throw profileError;
        setInstructor(profileData);

        // Fetch average rating
        const { data: reviewsData } = await supabase
          .from('public_reviews')
          .select('rating')
          .eq('instructor_id', linkedInstructor.instructorId);

        if (reviewsData && reviewsData.length > 0) {
          const avg = reviewsData.reduce((sum, r) => sum + (r.rating || 0), 0) / reviewsData.length;
          setAverageRating(Math.round(avg * 10) / 10);
        }
      } catch (err) {
        logger.error('Error fetching instructor profile:', err);
      } finally {
        setIsLoadingProfile(false);
      }
    };

    fetchInstructorProfile();
  }, [linkedInstructor?.instructorId]);

  if (!linkedInstructor || !instructor) {
    return null;
  }

  const handleWhatsAppClick = () => {
    if (instructor?.id) {
      openWhatsApp(instructor.id);
    }
  };

  const linkedDate = linkedInstructor.linkedAt 
    ? format(new Date(linkedInstructor.linkedAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
    : null;

  return (
    <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-primary" />
            <h3 className="font-semibold text-foreground">Meu Instrutor</h3>
          </div>
          <Badge variant="secondary" className="text-xs">
            Vinculado
          </Badge>
        </div>

        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16 border-2 border-primary/20">
            <AvatarImage src={instructor.avatar_url || undefined} alt={instructor.full_name} />
            <AvatarFallback className="bg-primary/10 text-primary text-lg">
              {instructor.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-foreground truncate">{instructor.full_name}</h4>
            
            <div className="flex items-center gap-2 mt-1">
              {averageRating && (
                <div className="flex items-center gap-1 text-sm">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-medium">{averageRating}</span>
                </div>
              )}
              {instructor.cnh_category && (
                <Badge variant="outline" className="text-xs">
                  Cat. {instructor.cnh_category}
                </Badge>
              )}
            </div>

            <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
              <MapPin className="h-3.5 w-3.5" />
              <span className="truncate">
                {instructor.neighborhood ? `${instructor.neighborhood}, ` : ''}{instructor.city}
              </span>
            </div>

            {linkedDate && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                <Calendar className="h-3 w-3" />
                <span>Desde {linkedDate}</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2 mt-4">
          <Link to="/student/my-instructor">
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full justify-between"
            >
              Ver perfil completo
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
          
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="default" 
              className="flex-1"
              onClick={handleWhatsAppClick}
              disabled={isContactLoading}
            >
              {isContactLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <MessageCircle className="h-4 w-4 mr-1" />
                  WhatsApp
                </>
              )}
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={unlinkInstructor}
              disabled={isLoading}
              className="text-muted-foreground"
            >
              Trocar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
