import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Car, CheckCircle2, Clock, Loader2 } from 'lucide-react';
import { format, isPast, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface Schedule {
  id: string;
  instructor_id: string;
  scheduled_date: string;
  scheduled_time: string;
  lesson_type: string;
  status: string;
  instructor?: {
    full_name: string;
    avatar_url?: string | null;
  };
}

interface PracticalLessonsCardProps {
  schedules: Schedule[];
  onLessonCompleted: () => void;
}

export const PracticalLessonsCard = ({ schedules, onLessonCompleted }: PracticalLessonsCardProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filter only practical lessons for this student
  const practicalLessons = schedules.filter(
    s => s.lesson_type !== 'theoretical'
  );

  const completedLessons = practicalLessons.filter(s => s.status === 'completed');
  const pendingLessons = practicalLessons.filter(
    s => s.status === 'pending' || s.status === 'confirmed'
  );

  // Lessons that can be marked as completed (past date/time and not already completed)
  const lessonsToComplete = pendingLessons.filter(lesson => {
    const lessonDateTime = new Date(`${lesson.scheduled_date}T${lesson.scheduled_time}`);
    return isPast(lessonDateTime);
  });

  const completedCount = completedLessons.length;
  const RECOMMENDED_LESSONS = 10;
  const progressPercent = Math.min((completedCount / RECOMMENDED_LESSONS) * 100, 100);

  const handleMarkAsCompleted = async (lessonId: string) => {
    if (!user) return;

    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('schedules')
        .update({ status: 'completed' })
        .eq('id', lessonId)
        .eq('student_id', user.id);

      if (error) throw error;

      toast({
        title: 'Aula concluída!',
        description: 'A aula foi marcada como concluída com sucesso.',
      });

      onLessonCompleted();
    } catch (error) {
      console.error('Error completing lesson:', error);
      toast({
        title: 'Erro ao marcar aula',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/50">
        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Car className="h-6 w-6 text-primary" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-1">
            <p className="font-medium text-foreground">Aulas Práticas</p>
            <span className="text-sm text-muted-foreground">{completedCount}/{RECOMMENDED_LESSONS}</span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>
        {lessonsToComplete.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsDialogOpen(true)}
            className="shrink-0"
          >
            <CheckCircle2 className="h-4 w-4 mr-1" />
            Concluir ({lessonsToComplete.length})
          </Button>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Marcar Aulas como Concluídas</DialogTitle>
            <DialogDescription>
              Selecione as aulas que você já realizou para marcar como concluídas.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-4 max-h-[400px] overflow-y-auto">
            {lessonsToComplete.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                <p className="text-muted-foreground">
                  Nenhuma aula disponível para marcar como concluída.
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  As aulas só podem ser marcadas após a data e hora agendadas.
                </p>
              </div>
            ) : (
              lessonsToComplete.map((lesson) => {
                const lessonDate = parseISO(lesson.scheduled_date);
                const typeLabel = lesson.lesson_type === 'practical_car' 
                  ? 'Carro' 
                  : 'Moto';

                return (
                  <div
                    key={lesson.id}
                    className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Car className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground text-sm">
                        Aula Prática - {typeLabel}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(lessonDate, "dd 'de' MMMM", { locale: ptBR })} às {lesson.scheduled_time.slice(0, 5)}
                      </p>
                      {lesson.instructor && (
                        <p className="text-xs text-muted-foreground">
                          Instrutor: {lesson.instructor.full_name}
                        </p>
                      )}
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleMarkAsCompleted(lesson.id)}
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <CheckCircle2 className="h-4 w-4 mr-1" />
                          Concluir
                        </>
                      )}
                    </Button>
                  </div>
                );
              })
            )}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              {completedCount} de {RECOMMENDED_LESSONS} aulas concluídas
            </p>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
