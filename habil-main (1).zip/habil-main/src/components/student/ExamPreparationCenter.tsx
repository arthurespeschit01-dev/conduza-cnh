import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  CheckSquare, 
  Lightbulb, 
  CheckCircle2, 
  Circle,
  Sparkles,
  Play,
  Trophy,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useSimulados, SimuladoType } from '@/hooks/useSimulados';
import { SimuladoDialog } from './SimuladoDialog';

interface ExamPreparationCenterProps {
  className?: string;
}

const initialChecklist = [
  { id: '1', text: 'CNH de aprendizagem em mãos', checked: false },
  { id: '2', text: 'Documento de identidade (RG/CPF)', checked: false },
  { id: '3', text: 'Comprovante de agendamento do exame', checked: false },
  { id: '4', text: 'Revisão dos comandos do veículo', checked: false },
  { id: '5', text: 'Prática de baliza e estacionamento', checked: false },
  { id: '6', text: 'Conhecimento do percurso padrão', checked: false },
  { id: '7', text: 'Descanso adequado na noite anterior', checked: false },
  { id: '8', text: 'Alimentação leve antes do exame', checked: false },
];

const dicas = [
  {
    title: 'Exame Teórico',
    tips: [
      'Leia cada questão com atenção antes de responder',
      'Foque primeiro nas questões de legislação - elas têm maior peso',
      'Não fique preso em uma questão difícil, pule e volte depois',
      'Revise todas as respostas antes de finalizar',
    ]
  },
  {
    title: 'Exame Prático',
    tips: [
      'Respire fundo e mantenha a calma',
      'Ajuste os espelhos e banco antes de iniciar',
      'Sinalize todas as suas intenções com antecedência',
      'Observe sempre os retrovisores ao fazer manobras',
      'Mantenha uma velocidade constante e segura',
    ]
  },
];

export const ExamPreparationCenter = ({ className }: ExamPreparationCenterProps) => {
  const [checklist, setChecklist] = useState(initialChecklist);
  const [selectedSimulado, setSelectedSimulado] = useState<SimuladoType | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const { simulados, loading } = useSimulados();

  const toggleChecklistItem = (id: string) => {
    setChecklist(prev =>
      prev.map(item =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const handleStartSimulado = (simulado: SimuladoType) => {
    setSelectedSimulado(simulado);
    setDialogOpen(true);
  };

  const completedSimulados = simulados.filter(s => s.completed).length;
  const checkedItems = checklist.filter(c => c.checked).length;

  return (
    <div className={cn("card-elevated p-6", className)}>
      <div className="flex items-center gap-3 mb-6">
        <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Sparkles className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-foreground">Central de Preparação</h2>
          <p className="text-sm text-muted-foreground">Prepare-se para seus exames</p>
        </div>
      </div>

      <Tabs defaultValue="simulados" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="simulados" className="text-xs sm:text-sm">
            <FileText className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Simulados
          </TabsTrigger>
          <TabsTrigger value="checklist" className="text-xs sm:text-sm">
            <CheckSquare className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Checklist
          </TabsTrigger>
          <TabsTrigger value="dicas" className="text-xs sm:text-sm">
            <Lightbulb className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Dicas
          </TabsTrigger>
        </TabsList>

        {/* Simulados Tab */}
        <TabsContent value="simulados" className="mt-0">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-muted-foreground">
                  {completedSimulados} de {simulados.length} concluídos
                </p>
                <div className="h-2 w-24 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all"
                    style={{ width: `${simulados.length > 0 ? (completedSimulados / simulados.length) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                {simulados.map((simulado) => (
                  <button
                    key={simulado.id}
                    onClick={() => handleStartSimulado(simulado)}
                    className={cn(
                      "w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left",
                      "hover:bg-muted/50 hover:border-primary/30",
                      simulado.completed 
                        ? "border-success/30 bg-success/5" 
                        : "border-border/50"
                    )}
                  >
                    {simulado.completed ? (
                      <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0" />
                    ) : (
                      <Circle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        "font-medium text-sm truncate",
                        simulado.completed ? "text-muted-foreground" : "text-foreground"
                      )}>
                        {simulado.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {simulado.questionsCount} questões
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {simulado.bestScore !== null && simulado.bestScore > 0 && (
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "text-xs",
                            simulado.completed 
                              ? "text-success border-success/30" 
                              : "text-muted-foreground"
                          )}
                        >
                          <Trophy className="h-3 w-3 mr-1" />
                          {simulado.bestScore.toFixed(0)}%
                        </Badge>
                      )}
                      <Play className="h-4 w-4 text-primary" />
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}
        </TabsContent>

        {/* Checklist Tab */}
        <TabsContent value="checklist" className="mt-0">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">
              {checkedItems} de {checklist.length} itens
            </p>
            <Badge 
              variant={checkedItems === checklist.length ? "default" : "secondary"}
              className="text-xs"
            >
              {Math.round((checkedItems / checklist.length) * 100)}%
            </Badge>
          </div>

          <div className="space-y-1">
            {checklist.map((item) => (
              <label
                key={item.id}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all",
                  "hover:bg-muted/50",
                  item.checked && "bg-success/5"
                )}
              >
                <Checkbox
                  checked={item.checked}
                  onCheckedChange={() => toggleChecklistItem(item.id)}
                  className="data-[state=checked]:bg-success data-[state=checked]:border-success"
                />
                <span className={cn(
                  "text-sm flex-1",
                  item.checked 
                    ? "text-muted-foreground line-through" 
                    : "text-foreground"
                )}>
                  {item.text}
                </span>
              </label>
            ))}
          </div>

          {checkedItems === checklist.length && (
            <div className="mt-4 p-3 rounded-lg bg-success/10 border border-success/30 text-center">
              <p className="text-sm text-success font-medium">
                ✨ Parabéns! Você está pronto para o exame!
              </p>
            </div>
          )}
        </TabsContent>

        {/* Dicas Tab */}
        <TabsContent value="dicas" className="mt-0">
          <div className="space-y-4">
            {dicas.map((section, index) => (
              <div key={index} className="space-y-2">
                <h4 className="font-medium text-sm text-foreground flex items-center gap-2">
                  <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-xs text-primary">
                    {index + 1}
                  </span>
                  {section.title}
                </h4>
                <ul className="space-y-1.5 ml-8">
                  {section.tips.map((tip, tipIndex) => (
                    <li 
                      key={tipIndex}
                      className="text-sm text-muted-foreground flex items-start gap-2"
                    >
                      <span className="text-primary mt-1.5">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            <div className="mt-4 p-4 rounded-lg bg-amber-500/5 border border-amber-500/20">
              <div className="flex items-start gap-3">
                <Lightbulb className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-600 dark:text-amber-400 mb-1">
                    Dica de Ouro
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Chegue ao local do exame com pelo menos 30 minutos de antecedência. 
                    Isso te dará tempo para se acalmar e revisar mentalmente os procedimentos.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <SimuladoDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        simulado={selectedSimulado}
      />
    </div>
  );
};
