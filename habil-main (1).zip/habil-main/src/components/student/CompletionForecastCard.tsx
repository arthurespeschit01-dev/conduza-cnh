import { useState, useEffect } from 'react';
import { Timer, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

const TOTAL_AULAS_RECOMENDADAS = 10;

interface CompletionForecastCardProps {
  aulasConcluidas: number;
}

const calcularPrevisao = (total: number, concluidas: number, frequencia: number) => {
  if (frequencia <= 0) return { diasMin: 0, diasMax: 0 };
  
  const restantes = total - concluidas;
  if (restantes <= 0) return { diasMin: 0, diasMax: 0 };
  
  const semanasRestantes = restantes / frequencia;
  const diasMin = Math.floor(semanasRestantes * 7);
  const diasMax = Math.ceil((semanasRestantes * 7) * 1.2);
  return { diasMin, diasMax };
};

const frequenciaOptions = [1, 2, 3, 4, 5];

export const CompletionForecastCard = ({ 
  aulasConcluidas 
}: CompletionForecastCardProps) => {
  const totalAulas = TOTAL_AULAS_RECOMENDADAS;
  const { user } = useAuth();
  const [frequenciaSemanal, setFrequenciaSemanal] = useState(2);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const loadFrequency = async () => {
      if (!user?.id) return;
      
      const { data, error } = await supabase
        .from('profiles')
        .select('weekly_lesson_frequency')
        .eq('id', user.id)
        .single();

      if (!error && data?.weekly_lesson_frequency) {
        setFrequenciaSemanal(data.weekly_lesson_frequency);
      }
      setIsLoading(false);
    };

    loadFrequency();
  }, [user?.id]);

  const handleFrequencyChange = async (freq: number) => {
    if (!user?.id) return;
    
    setFrequenciaSemanal(freq);
    setIsSaving(true);

    const { error } = await supabase
      .from('profiles')
      .update({ weekly_lesson_frequency: freq })
      .eq('id', user.id);

    setIsSaving(false);

    if (error) {
      toast({
        title: 'Erro ao salvar',
        description: 'Não foi possível salvar sua preferência.',
        variant: 'destructive',
      });
    }
  };

  const { diasMin, diasMax } = calcularPrevisao(totalAulas, aulasConcluidas, frequenciaSemanal);
  const isCompleted = aulasConcluidas >= totalAulas;

  return (
    <div className="card-elevated p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="space-y-1">
          <p className="text-sm font-medium text-muted-foreground">Previsão de Conclusão</p>
          {isLoading ? (
            <div className="h-8 flex items-center">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : isCompleted ? (
            <p className="text-2xl font-bold text-success">Concluído! 🎉</p>
          ) : (
            <p className="text-2xl font-bold text-foreground">
              {diasMin} - {diasMax} dias
            </p>
          )}
        </div>
        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          <Timer className="h-6 w-6" />
        </div>
      </div>

      {!isCompleted && !isLoading && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            Aulas por semana: {isSaving && <Loader2 className="inline h-3 w-3 animate-spin ml-1" />}
          </p>
          <div className="flex gap-2">
            {frequenciaOptions.map((freq) => (
              <Button
                key={freq}
                variant={frequenciaSemanal === freq ? "default" : "outline"}
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => handleFrequencyChange(freq)}
                disabled={isSaving}
              >
                {freq}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
