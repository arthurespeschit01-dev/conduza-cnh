import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Star, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { InstructorReviewDialog } from './InstructorReviewDialog';

interface CompletedLesson {
  id: string;
  instructor_id: string;
  scheduled_date: string;
  lesson_type: string;
  instructor?: {
    id: string;
    full_name: string;
    avatar_url: string | null;
  };
  hasReview?: boolean;
}

export const CompletedLessonsCard = () => {
  const { user } = useAuth();
  const [completedLessons, setCompletedLessons] = useState<CompletedLesson[]>([]);
  const [reviewedInstructors, setReviewedInstructors] = useState<Set<string>>(new Set());
  const [selectedInstructor, setSelectedInstructor] = useState<{
    id: string;
    full_name: string;
    avatar_url?: string | null;
  } | null>(null);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchCompletedLessons();
      fetchReviewedInstructors();
    }
  }, [user]);

  const fetchCompletedLessons = async () => {
    if (!user) return;

    const { data: schedulesData } = await supabase
      .from('schedules')
      .select('id, instructor_id, scheduled_date, lesson_type')
      .eq('student_id', user.id)
      .eq('status', 'completed')
      .order('scheduled_date', { ascending: false })
      .limit(10);

    if (schedulesData && schedulesData.length > 0) {
      // Get unique instructor IDs
      const instructorIds = [...new Set(schedulesData.map(s => s.instructor_id))];

      // Fetch instructor profiles
      const { data: instructors } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url')
        .in('id', instructorIds);

      const instructorMap = new Map(instructors?.map(i => [i.id, i]) || []);

      const enrichedLessons = schedulesData.map(lesson => ({
        ...lesson,
        instructor: instructorMap.get(lesson.instructor_id),
      }));

      setCompletedLessons(enrichedLessons);
    }
  };

  const fetchReviewedInstructors = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('instructor_reviews')
      .select('instructor_id')
      .eq('student_id', user.id);

    if (data) {
      setReviewedInstructors(new Set(data.map(r => r.instructor_id)));
    }
  };

  const handleOpenReview = (instructor: { id: string; full_name: string; avatar_url?: string | null }) => {
    setSelectedInstructor(instructor);
    setIsReviewDialogOpen(true);
  };

  const handleReviewSubmitted = () => {
    fetchReviewedInstructors();
  };

  // Get unique instructors from completed lessons
  const uniqueInstructors = Array.from(
    new Map(
      completedLessons
        .filter(l => l.instructor)
        .map(l => [l.instructor_id, l.instructor!])
    ).values()
  );

  if (uniqueInstructors.length === 0) {
    return null;
  }

  return (
    <>
      <div className="card-elevated p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Avaliar Instrutores</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Avalie os instrutores das suas aulas concluídas
        </p>

        <div className="space-y-3">
          {uniqueInstructors.map((instructor) => {
            const hasReview = reviewedInstructors.has(instructor.id);
            
            return (
              <div
                key={instructor.id}
                className="flex items-center gap-3 p-3 rounded-xl bg-muted/50"
              >
                <div className="h-10 w-10 rounded-lg overflow-hidden bg-muted flex items-center justify-center">
                  {instructor.avatar_url ? (
                    <img
                      src={instructor.avatar_url}
                      alt={instructor.full_name}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <span className="text-sm font-bold text-muted-foreground">
                      {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm truncate">
                    {instructor.full_name}
                  </p>
                  {hasReview && (
                    <p className="text-xs text-success flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      Avaliado
                    </p>
                  )}
                </div>
                <Button
                  variant={hasReview ? "outline" : "default"}
                  size="sm"
                  onClick={() => handleOpenReview(instructor)}
                  className="shrink-0"
                >
                  <Star className="h-4 w-4 mr-1" />
                  {hasReview ? 'Editar' : 'Avaliar'}
                </Button>
              </div>
            );
          })}
        </div>
      </div>

      {selectedInstructor && (
        <InstructorReviewDialog
          open={isReviewDialogOpen}
          onOpenChange={setIsReviewDialogOpen}
          instructor={selectedInstructor}
          onReviewSubmitted={handleReviewSubmitted}
        />
      )}
    </>
  );
};
