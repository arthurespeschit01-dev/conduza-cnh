import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { states } from '@/data/brazilLocations';
import { fetchIBGECities, IBGECity } from '@/services/ibgeService';
import { Check, Loader2 } from 'lucide-react';

interface SimpleLocationSelectorProps {
  currentUf: string;
  currentCity: string;
  onConfirm: (uf: string, city: string) => void;
}

export const SimpleLocationSelector = ({
  currentUf,
  currentCity,
  onConfirm,
}: SimpleLocationSelectorProps) => {
  const [uf, setUf] = useState(currentUf);
  const [city, setCity] = useState(currentCity);
  const [cities, setCities] = useState<IBGECity[]>([]);
  const [isLoadingCities, setIsLoadingCities] = useState(false);
  
  const isValid = Boolean(uf && city);

  // Fetch cities when UF changes
  useEffect(() => {
    if (!uf) {
      setCities([]);
      return;
    }

    const loadCities = async () => {
      setIsLoadingCities(true);
      const fetchedCities = await fetchIBGECities(uf);
      setCities(fetchedCities);
      setIsLoadingCities(false);
    };

    loadCities();
  }, [uf]);

  const handleUfChange = (newUf: string) => {
    setUf(newUf);
    setCity(''); // Reset city when UF changes
  };

  const handleConfirm = () => {
    if (isValid) {
      onConfirm(uf, city);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="uf">Estado</Label>
        <Select value={uf} onValueChange={handleUfChange}>
          <SelectTrigger className="h-12">
            <SelectValue placeholder="Selecione seu estado" />
          </SelectTrigger>
          <SelectContent>
            {states.map((state) => (
              <SelectItem key={state.uf} value={state.uf}>
                {state.name} ({state.uf})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="city">Cidade</Label>
        <Select 
          value={city} 
          onValueChange={setCity}
          disabled={!uf}
        >
          <SelectTrigger className="h-12">
            <SelectValue placeholder={uf ? "Selecione sua cidade" : "Primeiro selecione o estado"} />
          </SelectTrigger>
          <SelectContent>
            {isLoadingCities ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">Carregando cidades...</span>
              </div>
            ) : (
              cities.map((cityItem) => (
                <SelectItem key={cityItem.id} value={cityItem.nome}>
                  {cityItem.nome}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>

      <Button 
        onClick={handleConfirm} 
        disabled={!isValid}
        className="w-full"
      >
        <Check className="h-4 w-4 mr-2" />
        Confirmar localização
      </Button>
    </div>
  );
};
