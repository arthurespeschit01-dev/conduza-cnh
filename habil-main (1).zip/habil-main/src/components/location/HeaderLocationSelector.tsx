import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { MapPin, Navigation, Search, Loader2, Check, X, ChevronDown } from 'lucide-react';
import { useLocation } from '@/contexts/LocationContext';
import { useGeolocation } from '@/hooks/useGeolocation';
import { fetchAddressByCep, fetchAddressByCoordinates, formatCep } from '@/services/locationService';
import { fetchIBGEStates, fetchIBGECities, IBGEState, IBGECity } from '@/services/ibgeService';
import { AddressAutocomplete } from './AddressAutocomplete';
import { AddressSuggestion } from '@/services/nominatimService';
import { cn } from '@/lib/utils';

export const HeaderLocationSelector = () => {
  const { location, setLocationDirect, setCoordinates, resetLocation } = useLocation();
  const [open, setOpen] = useState(false);
  const [cep, setCep] = useState(location.cep || '');
  const [addressQuery, setAddressQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  // State/City selection
  const [selectedUf, setSelectedUf] = useState(location.uf);
  const [selectedCity, setSelectedCity] = useState(location.city);
  const [states, setStates] = useState<IBGEState[]>([]);
  const [cities, setCities] = useState<IBGECity[]>([]);
  const [loadingCities, setLoadingCities] = useState(false);
  
  const { getCurrentPosition, loading: gpsLoading } = useGeolocation();

  // Load states on mount
  useEffect(() => {
    fetchIBGEStates().then(setStates);
  }, []);

  // Load cities when UF changes
  useEffect(() => {
    if (selectedUf) {
      setLoadingCities(true);
      fetchIBGECities(selectedUf).then((data) => {
        setCities(data);
        setLoadingCities(false);
      });
    } else {
      setCities([]);
    }
  }, [selectedUf]);

  // Sync with context
  useEffect(() => {
    setSelectedUf(location.uf);
    setSelectedCity(location.city);
    setCep(location.cep ? formatCep(location.cep) : '');
  }, [location.uf, location.city, location.cep]);

  const handleGpsClick = async () => {
    setError('');
    setSuccess(false);
    setLoading(true);
    
    const coords = await getCurrentPosition();
    
    if (!coords) {
      setError('Não foi possível obter sua localização.');
      setLoading(false);
      return;
    }
    
    const address = await fetchAddressByCoordinates(coords.latitude, coords.longitude);
    
    if (!address) {
      setError('Não foi possível identificar sua cidade.');
      setLoading(false);
      return;
    }
    
    // Update all fields
    setSelectedUf(address.uf);
    setSelectedCity(address.city);
    setLocationDirect(address.uf, address.city, address.neighborhood, address.street);
    setCoordinates(coords.latitude, coords.longitude);
    setSuccess(true);
    setLoading(false);
    setTimeout(() => setOpen(false), 500);
  };

  const handleCepSearch = async (searchCep: string) => {
    const cleanCep = searchCep.replace(/\D/g, '');
    
    if (cleanCep.length !== 8) {
      return;
    }
    
    setError('');
    setSuccess(false);
    setLoading(true);
    
    const address = await fetchAddressByCep(cleanCep);
    
    if (!address) {
      setError('CEP não encontrado.');
      setLoading(false);
      return;
    }
    
    // Update state and city fields with CEP data
    setSelectedUf(address.uf);
    setSelectedCity(address.city);
    
    setLocationDirect(
      address.uf, 
      address.city, 
      address.neighborhood, 
      address.street, 
      cleanCep
    );
    setSuccess(true);
    setLoading(false);
  };

  const handleCepChange = (value: string) => {
    const formatted = formatCep(value);
    setCep(formatted);
    setError('');
    
    const cleanCep = value.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      handleCepSearch(value);
    }
  };

  const handleUfChange = (uf: string) => {
    setSelectedUf(uf);
    setSelectedCity('');
    setCep('');
    setError('');
  };

  const handleCityChange = (city: string) => {
    setSelectedCity(city);
    setLocationDirect(selectedUf, city);
    setSuccess(true);
    setTimeout(() => setOpen(false), 500);
  };

  const handleClear = () => {
    resetLocation();
    setCep('');
    setAddressQuery('');
    setSelectedUf('');
    setSelectedCity('');
    setError('');
    setSuccess(false);
  };

  const handleAddressSelect = (suggestion: AddressSuggestion) => {
    // Update all fields with the selected address
    setSelectedUf(suggestion.uf);
    setSelectedCity(suggestion.city);
    if (suggestion.cep) {
      setCep(formatCep(suggestion.cep));
    }
    
    setLocationDirect(
      suggestion.uf,
      suggestion.city,
      suggestion.neighborhood,
      suggestion.street,
      suggestion.cep
    );
    setSuccess(true);
    setTimeout(() => setOpen(false), 500);
  };

  const displayLocation = location.isValid 
    ? `${location.city}, ${location.uf}`
    : null;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className={cn(
            "gap-2 text-muted-foreground hover:text-foreground",
            location.isValid && "text-foreground"
          )}
        >
          <MapPin className="h-4 w-4" />
          <span className="hidden sm:inline max-w-[150px] truncate">
            {displayLocation || 'Localização'}
          </span>
          <ChevronDown className="h-3 w-3" />
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-80 p-4" align="end">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">Sua localização</h4>
            {location.isValid && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClear}
                className="h-6 px-2 text-xs text-muted-foreground hover:text-destructive"
              >
                <X className="h-3 w-3 mr-1" />
                Limpar
              </Button>
            )}
          </div>

          {/* GPS Button */}
          <Button
            type="button"
            variant="outline"
            onClick={handleGpsClick}
            disabled={loading || gpsLoading}
            className="w-full justify-start gap-2 h-10"
          >
            {loading && !cep ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Navigation className="h-4 w-4" />
            )}
            Usar minha localização
          </Button>

          <div className="flex items-center gap-2">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">ou</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Address Autocomplete */}
          <AddressAutocomplete
            value={addressQuery}
            onChange={setAddressQuery}
            onSelect={handleAddressSelect}
            placeholder="Digite rua, bairro ou cidade..."
            label="Buscar endereço"
          />

          <div className="flex items-center gap-2">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">ou</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* CEP Input */}
          <div className="space-y-2">
            <Label className="text-xs">CEP</Label>
            <div className="flex gap-2">
              <Input
                placeholder="00000-000"
                value={cep}
                onChange={(e) => handleCepChange(e.target.value)}
                maxLength={9}
                className="h-9"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => handleCepSearch(cep)}
                disabled={loading || cep.replace(/\D/g, '').length !== 8}
                className="h-9 px-3"
              >
                {loading && cep ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">ou</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Manual Selection - Estado */}
          <div className="space-y-1.5">
            <Label className="text-xs">Estado</Label>
            <Select value={selectedUf} onValueChange={handleUfChange}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Selecione o estado" />
              </SelectTrigger>
              <SelectContent>
                {states.map((state) => (
                  <SelectItem key={state.sigla} value={state.sigla}>
                    {state.nome} ({state.sigla})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Manual Selection - Cidade */}
          <div className="space-y-1.5">
            <Label className="text-xs">Cidade</Label>
            <Select 
              value={selectedCity} 
              onValueChange={handleCityChange}
              disabled={!selectedUf || loadingCities}
            >
              <SelectTrigger className="h-9">
                <SelectValue placeholder={
                  loadingCities 
                    ? "Carregando..." 
                    : selectedUf 
                      ? "Selecione a cidade" 
                      : "Selecione o estado primeiro"
                } />
              </SelectTrigger>
              <SelectContent>
                {cities.map((city) => (
                  <SelectItem key={city.id} value={city.nome}>
                    {city.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Error */}
          {error && (
            <p className="text-xs text-destructive">{error}</p>
          )}

          {/* Success */}
          {success && location.isValid && (
            <div className="flex items-center gap-2 p-2 rounded-md bg-success/10 border border-success/20">
              <Check className="h-4 w-4 text-success" />
              <div className="text-xs">
                <span className="font-medium text-success">
                  {location.city}, {location.uf}
                </span>
                {location.neighborhood && (
                  <p className="text-muted-foreground">{location.neighborhood}</p>
                )}
              </div>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
