import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MapPin, RefreshCw, CheckCircle2 } from "lucide-react";
import { GeolocationErrorType, getErrorInstructions } from "@/hooks/useGeolocation";

interface LocationHelpDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  errorType: GeolocationErrorType;
  onRetry: () => void;
}

export const LocationHelpDialog = ({
  open,
  onOpenChange,
  errorType,
  onRetry,
}: LocationHelpDialogProps) => {
  const instructions = getErrorInstructions(errorType);

  const handleRetry = () => {
    onOpenChange(false);
    onRetry();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Como habilitar a localização
          </DialogTitle>
          <DialogDescription>
            Siga os passos abaixo para permitir o acesso à sua localização
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <ol className="space-y-3">
            {instructions.map((instruction, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                  {index + 1}
                </span>
                <span className="text-sm text-muted-foreground">{instruction}</span>
              </li>
            ))}
          </ol>

          <div className="rounded-lg bg-muted/50 p-4">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Dica:</strong> Sua localização é usada apenas para encontrar instrutores próximos a você. 
              Não armazenamos dados de localização.
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Usar outra opção
          </Button>
          <Button onClick={handleRetry} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Tentar novamente
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
