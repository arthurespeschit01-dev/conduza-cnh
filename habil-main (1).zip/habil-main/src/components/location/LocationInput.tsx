import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MapPin, Navigation, Search, Loader2, Check, HelpCircle } from 'lucide-react';
import { useGeolocation, GeolocationErrorType } from '@/hooks/useGeolocation';
import { fetchAddressByCep, fetchAddressByCoordinates, formatCep } from '@/services/locationService';
import { fetchIBGEStates, fetchIBGECities, IBGEState, IBGECity } from '@/services/ibgeService';
import { AddressAutocomplete } from './AddressAutocomplete';
import { AddressSuggestion } from '@/services/nominatimService';
import { cn } from '@/lib/utils';
import { LocationHelpDialog } from './LocationHelpDialog';

interface LocationInputProps {
  uf: string;
  city: string;
  onLocationChange: (uf: string, city: string, neighborhood?: string, street?: string, cep?: string, coordinates?: { latitude: number; longitude: number }) => void;
  showGps?: boolean;
  showCep?: boolean;
  showManual?: boolean;
  showAddressSearch?: boolean;
  compact?: boolean;
  className?: string;
}

type LocationMethod = 'gps' | 'cep' | 'manual' | 'search';

export const LocationInput = ({
  uf,
  city,
  onLocationChange,
  showGps = true,
  showCep = true,
  showManual = true,
  showAddressSearch = true,
  compact = false,
  className,
}: LocationInputProps) => {
  const [activeMethod, setActiveMethod] = useState<LocationMethod | null>(null);
  const [cep, setCep] = useState('');
  const [addressQuery, setAddressQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [gpsErrorType, setGpsErrorType] = useState<GeolocationErrorType>(null);
  
  // Local state for UF/City to sync with CEP results
  const [selectedUf, setSelectedUf] = useState(uf);
  const [selectedCity, setSelectedCity] = useState(city);
  
  // State/City data from IBGE
  const [states, setStates] = useState<IBGEState[]>([]);
  const [cities, setCities] = useState<IBGECity[]>([]);
  const [loadingCities, setLoadingCities] = useState(false);
  
  const { getCurrentPosition, loading: gpsLoading, errorType, error: gpsError } = useGeolocation();
  
  const isLocationSet = Boolean(selectedUf && selectedCity);

  // Load states on mount
  useEffect(() => {
    fetchIBGEStates().then(setStates);
  }, []);

  // Load cities when UF changes
  useEffect(() => {
    if (selectedUf) {
      setLoadingCities(true);
      fetchIBGECities(selectedUf).then((data) => {
        setCities(data);
        setLoadingCities(false);
      });
    } else {
      setCities([]);
    }
  }, [selectedUf]);

  // Sync with parent props
  useEffect(() => {
    setSelectedUf(uf);
    setSelectedCity(city);
  }, [uf, city]);

  const handleGpsClick = async () => {
    setError('');
    setSuccess(false);
    setActiveMethod('gps');
    setLoading(true);
    setGpsErrorType(null);
    
    const coords = await getCurrentPosition();
    
    if (!coords) {
      setGpsErrorType(errorType);
      setError(gpsError || 'Não foi possível obter sua localização.');
      setLoading(false);
      return;
    }
    
    const address = await fetchAddressByCoordinates(coords.latitude, coords.longitude);
    
    if (!address) {
      setError('Não foi possível identificar sua cidade. Tente usar o CEP ou seleção manual.');
      setLoading(false);
      return;
    }
    
    // Update local state
    setSelectedUf(address.uf);
    setSelectedCity(address.city);
    
    // Pass coordinates with location change
    onLocationChange(address.uf, address.city, address.neighborhood, address.street, undefined, { latitude: coords.latitude, longitude: coords.longitude });
    setSuccess(true);
    setLoading(false);
  };

  const handleCepSearch = async () => {
    const cleanCep = cep.replace(/\D/g, '');
    
    if (cleanCep.length !== 8) {
      setError('Digite um CEP válido com 8 dígitos');
      return;
    }
    
    setError('');
    setSuccess(false);
    setActiveMethod('cep');
    setLoading(true);
    
    const address = await fetchAddressByCep(cleanCep);
    
    if (!address) {
      setError('CEP não encontrado. Verifique o número ou use a seleção manual.');
      setLoading(false);
      return;
    }
    
    // Update local state - this will automatically update Estado and Cidade
    setSelectedUf(address.uf);
    setSelectedCity(address.city);
    
    onLocationChange(address.uf, address.city, address.neighborhood, address.street, cleanCep);
    setSuccess(true);
    setLoading(false);
  };

  const handleCepChange = (value: string) => {
    setCep(formatCep(value));
    setError('');
    
    // Auto-search when CEP is complete
    const cleanCep = value.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      // Delay to allow formatCep to update
      setTimeout(() => handleCepSearch(), 100);
    }
  };

  const handleUfChange = (newUf: string) => {
    setActiveMethod('manual');
    setError('');
    setSelectedUf(newUf);
    setSelectedCity('');
    setCep(''); // Clear CEP when manually changing state
    onLocationChange(newUf, '');
  };

  const handleCityChange = (newCity: string) => {
    setActiveMethod('manual');
    setSuccess(true);
    setSelectedCity(newCity);
    onLocationChange(selectedUf, newCity);
  };

  const handleAddressSelect = (suggestion: AddressSuggestion) => {
    setActiveMethod('search');
    setSuccess(true);
    
    // Update all fields
    setSelectedUf(suggestion.uf);
    setSelectedCity(suggestion.city);
    if (suggestion.cep) {
      setCep(formatCep(suggestion.cep));
    }
    
    onLocationChange(
      suggestion.uf,
      suggestion.city,
      suggestion.neighborhood,
      suggestion.street,
      suggestion.cep
    );
  };

  const renderGpsError = () => {
    if (!error || activeMethod !== 'gps') return null;
    
    return (
      <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 space-y-2">
        <p className="text-sm text-destructive">{error}</p>
        {gpsErrorType && gpsErrorType !== 'not_supported' && (
          <Button
            type="button"
            variant="link"
            size="sm"
            onClick={() => setShowHelp(true)}
            className="h-auto p-0 text-destructive hover:text-destructive/80 gap-1"
          >
            <HelpCircle className="h-3 w-3" />
            Como habilitar a localização?
          </Button>
        )}
        {(showCep || showManual) && (
          <p className="text-xs text-muted-foreground">
            Você também pode usar CEP ou selecionar manualmente abaixo.
          </p>
        )}
      </div>
    );
  };

  const renderDivider = () => (
    <div className="flex items-center gap-4">
      <div className="flex-1 h-px bg-border" />
      <span className="text-sm text-muted-foreground">ou</span>
      <div className="flex-1 h-px bg-border" />
    </div>
  );

  if (compact) {
    return (
      <div className={cn("space-y-3", className)}>
        {/* Compact GPS Button */}
        {showGps && (
          <Button
            type="button"
            variant="outline"
            onClick={handleGpsClick}
            disabled={loading || gpsLoading}
            className="w-full justify-start gap-2 h-11"
          >
            {loading && activeMethod === 'gps' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Navigation className="h-4 w-4" />
            )}
            Usar minha localização
          </Button>
        )}

        {/* Compact CEP Input */}
        {showCep && (
          <div className="flex gap-2">
            <Input
              placeholder="Digite seu CEP"
              value={cep}
              onChange={(e) => handleCepChange(e.target.value)}
              maxLength={9}
              className="h-11"
            />
            <Button
              type="button"
              variant="outline"
              onClick={handleCepSearch}
              disabled={loading || cep.replace(/\D/g, '').length !== 8}
              className="h-11 px-3"
            >
              {loading && activeMethod === 'cep' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
            </Button>
          </div>
        )}

        {/* GPS Error with help */}
        {activeMethod === 'gps' && error && renderGpsError()}
        
        {/* CEP Error */}
        {activeMethod === 'cep' && error && (
          <p className="text-sm text-destructive">{error}</p>
        )}
        
        {isLocationSet && success && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-success/10 border border-success/20">
            <Check className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">
              {selectedCity}, {selectedUf}
            </span>
          </div>
        )}

        <LocationHelpDialog
          open={showHelp}
          onOpenChange={setShowHelp}
          errorType={gpsErrorType}
          onRetry={handleGpsClick}
        />
      </div>
    );
  }

  return (
    <div className={cn("space-y-6", className)}>
      {/* GPS Option */}
      {showGps && (
        <div className="space-y-2">
          <Button
            type="button"
            variant="outline"
            onClick={handleGpsClick}
            disabled={loading || gpsLoading}
            className="w-full justify-start gap-3 h-14 text-left"
          >
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              {loading && activeMethod === 'gps' ? (
                <Loader2 className="h-5 w-5 text-primary animate-spin" />
              ) : (
                <Navigation className="h-5 w-5 text-primary" />
              )}
            </div>
            <div>
              <p className="font-medium">Usar minha localização</p>
              <p className="text-xs text-muted-foreground">Detectar automaticamente pelo GPS</p>
            </div>
          </Button>
          
          {/* GPS Error Message */}
          {activeMethod === 'gps' && error && renderGpsError()}
        </div>
      )}

      {/* Divider */}
      {showGps && (showAddressSearch || showCep || showManual) && renderDivider()}

      {/* Address Search */}
      {showAddressSearch && (
        <AddressAutocomplete
          value={addressQuery}
          onChange={setAddressQuery}
          onSelect={handleAddressSelect}
          placeholder="Digite rua, bairro ou cidade..."
          label="Buscar endereço"
        />
      )}

      {/* Divider */}
      {showAddressSearch && (showCep || showManual) && renderDivider()}

      {/* CEP Option */}
      {showCep && (
        <div className="space-y-2">
          <Label>CEP</Label>
          <div className="flex gap-2">
            <Input
              placeholder="00000-000"
              value={cep}
              onChange={(e) => handleCepChange(e.target.value)}
              maxLength={9}
              className="h-12"
            />
            <Button
              type="button"
              variant="outline"
              onClick={handleCepSearch}
              disabled={loading || cep.replace(/\D/g, '').length !== 8}
              className="h-12 px-4"
            >
              {loading && activeMethod === 'cep' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
            </Button>
          </div>
          
          {/* CEP Error */}
          {activeMethod === 'cep' && error && (
            <p className="text-sm text-destructive">{error}</p>
          )}
        </div>
      )}

      {/* Divider */}
      {showCep && showManual && renderDivider()}

      {/* Manual Selection - Estado */}
      {showManual && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="uf">Estado</Label>
            <Select value={selectedUf} onValueChange={handleUfChange}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Selecione seu estado" />
              </SelectTrigger>
              <SelectContent>
                {states.map((state) => (
                  <SelectItem key={state.sigla} value={state.sigla}>
                    {state.nome} ({state.sigla})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Manual Selection - Cidade */}
          <div className="space-y-2">
            <Label htmlFor="city">Cidade</Label>
            <Select 
              value={selectedCity} 
              onValueChange={handleCityChange}
              disabled={!selectedUf || loadingCities}
            >
              <SelectTrigger className="h-12">
                <SelectValue placeholder={
                  loadingCities 
                    ? "Carregando cidades..." 
                    : selectedUf 
                      ? "Selecione sua cidade" 
                      : "Primeiro selecione o estado"
                } />
              </SelectTrigger>
              <SelectContent>
                {cities.map((cityItem) => (
                  <SelectItem key={cityItem.id} value={cityItem.nome}>
                    {cityItem.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {/* Success Indicator */}
      {isLocationSet && success && (
        <div className="p-4 rounded-xl bg-success/10 border border-success/20 text-center animate-fade-in">
          <div className="flex items-center justify-center gap-2">
            <MapPin className="h-5 w-5 text-success" />
            <p className="text-success font-medium">
              {selectedCity}, {selectedUf}
            </p>
          </div>
        </div>
      )}

      <LocationHelpDialog
        open={showHelp}
        onOpenChange={setShowHelp}
        errorType={gpsErrorType}
        onRetry={handleGpsClick}
      />
    </div>
  );
};
