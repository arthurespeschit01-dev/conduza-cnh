import { logger } from '@/lib/logger';

export interface NominatimResult {
  place_id: number;
  display_name: string;
  address: {
    road?: string;
    suburb?: string;
    city?: string;
    town?: string;
    village?: string;
    state?: string;
    postcode?: string;
    country?: string;
    country_code?: string;
  };
  lat: string;
  lon: string;
}

export interface AddressSuggestion {
  id: number;
  displayName: string;
  street?: string;
  neighborhood?: string;
  city: string;
  uf: string;
  cep?: string;
}

// Debounce helper
let searchTimeout: ReturnType<typeof setTimeout> | null = null;

export const searchAddresses = async (
  query: string,
  uf?: string,
  city?: string
): Promise<AddressSuggestion[]> => {
  if (query.length < 3) return [];

  // Cancel previous request
  if (searchTimeout) {
    clearTimeout(searchTimeout);
  }

  return new Promise((resolve) => {
    searchTimeout = setTimeout(async () => {
      try {
        // Build search query with location context
        let searchQuery = query;
        if (city) searchQuery += `, ${city}`;
        if (uf) searchQuery += `, ${uf}`;
        searchQuery += ', Brasil';

        const params = new URLSearchParams({
          q: searchQuery,
          format: 'json',
          addressdetails: '1',
          countrycodes: 'br',
          limit: '8',
          'accept-language': 'pt-BR',
        });

        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?${params}`,
          {
            headers: {
              'User-Agent': 'ConduzaApp/1.0',
            },
          }
        );

        if (!response.ok) {
          throw new Error('Nominatim API error');
        }

        const data: NominatimResult[] = await response.json();

        const suggestions: AddressSuggestion[] = data
          .filter((item) => item.address.country_code === 'br')
          .map((item) => ({
            id: item.place_id,
            displayName: formatDisplayName(item),
            street: item.address.road,
            neighborhood: item.address.suburb,
            city: item.address.city || item.address.town || item.address.village || '',
            uf: getUfFromState(item.address.state || ''),
            cep: item.address.postcode,
          }))
          .filter((item) => item.city && item.uf);

        resolve(suggestions);
      } catch (error) {
        logger.error('Error searching addresses:', error);
        resolve([]);
      }
    }, 300); // 300ms debounce
  });
};

const formatDisplayName = (item: NominatimResult): string => {
  const parts: string[] = [];
  
  if (item.address.road) {
    parts.push(item.address.road);
  }
  if (item.address.suburb) {
    parts.push(item.address.suburb);
  }
  
  const city = item.address.city || item.address.town || item.address.village;
  if (city) {
    parts.push(city);
  }
  
  if (item.address.state) {
    const uf = getUfFromState(item.address.state);
    if (uf) parts.push(uf);
  }
  
  return parts.join(', ');
};

// Map Brazilian state names to UF codes
const stateToUf: Record<string, string> = {
  'acre': 'AC',
  'alagoas': 'AL',
  'amapá': 'AP',
  'amazonas': 'AM',
  'bahia': 'BA',
  'ceará': 'CE',
  'distrito federal': 'DF',
  'espírito santo': 'ES',
  'goiás': 'GO',
  'maranhão': 'MA',
  'mato grosso': 'MT',
  'mato grosso do sul': 'MS',
  'minas gerais': 'MG',
  'pará': 'PA',
  'paraíba': 'PB',
  'paraná': 'PR',
  'pernambuco': 'PE',
  'piauí': 'PI',
  'rio de janeiro': 'RJ',
  'rio grande do norte': 'RN',
  'rio grande do sul': 'RS',
  'rondônia': 'RO',
  'roraima': 'RR',
  'santa catarina': 'SC',
  'são paulo': 'SP',
  'sergipe': 'SE',
  'tocantins': 'TO',
};

const getUfFromState = (stateName: string): string => {
  // If already a UF code
  if (stateName.length === 2) return stateName.toUpperCase();
  
  const normalized = stateName.toLowerCase().trim();
  return stateToUf[normalized] || '';
};
