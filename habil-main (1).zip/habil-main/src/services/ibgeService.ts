import { logger } from '@/lib/logger';

export interface IBGEState {
  id: number;
  sigla: string;
  nome: string;
}

export interface IBGECity {
  id: number;
  nome: string;
}

// Cache para evitar requisições repetidas
const statesCache: IBGEState[] = [];
const citiesCache: Record<string, IBGECity[]> = {};

export const fetchIBGEStates = async (): Promise<IBGEState[]> => {
  if (statesCache.length > 0) {
    return statesCache;
  }

  try {
    const response = await fetch(
      'https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome'
    );
    const data: IBGEState[] = await response.json();
    statesCache.push(...data);
    return data;
  } catch (error) {
    logger.error('Error fetching IBGE states:', error);
    return [];
  }
};

export const fetchIBGECities = async (uf: string): Promise<IBGECity[]> => {
  if (!uf) return [];
  
  const cacheKey = uf.toUpperCase();
  
  if (citiesCache[cacheKey]) {
    return citiesCache[cacheKey];
  }

  try {
    const response = await fetch(
      `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios?orderBy=nome`
    );
    const data: IBGECity[] = await response.json();
    citiesCache[cacheKey] = data;
    return data;
  } catch (error) {
    logger.error('Error fetching IBGE cities:', error);
    return [];
  }
};

// Função para pré-carregar estados
export const preloadStates = async (): Promise<void> => {
  await fetchIBGEStates();
};
