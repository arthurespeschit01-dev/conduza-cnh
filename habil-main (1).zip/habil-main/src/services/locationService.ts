import { logger } from '@/lib/logger';

export interface AddressData {
  city: string;
  uf: string;
  neighborhood?: string;
  street?: string;
}

export interface CepResponse {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  erro?: boolean;
}

export interface GeoResponse {
  city: string;
  principalSubdivisionCode: string;
  countryCode: string;
}

export const fetchAddressByCep = async (cep: string): Promise<AddressData | null> => {
  const cleanCep = cep.replace(/\D/g, '');
  
  if (cleanCep.length !== 8) {
    return null;
  }

  try {
    const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
    const data: CepResponse = await response.json();

    if (data.erro) {
      return null;
    }

    return {
      city: data.localidade,
      uf: data.uf,
      neighborhood: data.bairro,
      street: data.logradouro,
    };
  } catch (error) {
    logger.error('Error fetching address by CEP:', error);
    return null;
  }
};

export const fetchAddressByCoordinates = async (
  latitude: number,
  longitude: number
): Promise<AddressData | null> => {
  try {
    const response = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=pt`
    );
    const data: GeoResponse = await response.json();

    if (!data.city || data.countryCode !== 'BR') {
      return null;
    }

    // BigDataCloud returns state code as "BR-SP", we need just "SP"
    const uf = data.principalSubdivisionCode?.replace('BR-', '') || '';

    return {
      city: data.city,
      uf: uf,
    };
  } catch (error) {
    logger.error('Error fetching address by coordinates:', error);
    return null;
  }
};

export const formatCep = (value: string): string => {
  const numbers = value.replace(/\D/g, '');
  if (numbers.length <= 5) {
    return numbers;
  }
  return `${numbers.slice(0, 5)}-${numbers.slice(5, 8)}`;
};
