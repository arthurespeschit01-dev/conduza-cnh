import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Car, Shield, Award, ArrowRight, Search, MapPin, Calendar, FileText, Headphones, Clock, Star, UserPlus, CalendarCheck, ShieldCheck, Trophy, Navigation, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocation } from '@/contexts/LocationContext';
import { useGeolocation } from '@/hooks/useGeolocation';
import { fetchAddressByCep, fetchAddressByCoordinates, formatCep } from '@/services/locationService';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { Testimonials, type Testimonial } from '@/components/home/Testimonials';
import { ComparisonSection } from '@/components/home/ComparisonSection';
import { FAQSection } from '@/components/home/FAQSection';
import { SocialProofStats, TrustBadges } from '@/components/home/SocialProof';

// Fotos dos depoimentos
import lucasAvatar from '@/assets/testimonials/lucas.png';
import amandaAvatar from '@/assets/testimonials/amanda.png';
import rafaelAvatar from '@/assets/testimonials/rafael.png';

// Depoimentos com textos persuasivos
const testimonials: Testimonial[] = [{
  id: '1',
  name: 'Lucas M.',
  location: 'São Paulo, SP',
  text: 'Eu tinha medo de dirigir e já tinha reprovado uma vez. Encontrei um instrutor super paciente pela Conduza e em 3 semanas passei no exame. Melhor decisão que tomei!',
  avatar: lucasAvatar
}, {
  id: '2',
  name: 'Amanda R.',
  location: 'Belo Horizonte, MG',
  text: 'Perdi muito tempo indo de autoescola em autoescola procurando preço. Na Conduza comparei tudo em 5 minutos e ainda achei um instrutor com horários flexíveis que encaixou na minha rotina.',
  avatar: amandaAvatar
}, {
  id: '3',
  name: 'Rafael S.',
  location: 'Curitiba, PR',
  text: 'O instrutor que encontrei aqui tinha 98% de aprovação. Isso me deu muita confiança! Fiz 15 aulas e passei de primeira. Recomendo demais.',
  avatar: rafaelAvatar
}];
const Index = () => {
  const navigate = useNavigate();
  const {
    location,
    setLocationDirect
  } = useLocation();
  const {
    getCurrentPosition
  } = useGeolocation();
  const {
    toast
  } = useToast();
  const [category, setCategory] = useState('');
  const [locationOpen, setLocationOpen] = useState(false);
  const [cep, setCep] = useState('');
  const [loading, setLoading] = useState(false);
  const displayLocation = location.isValid ? `${location.city}, ${location.uf}` : '';
  const handleGpsClick = async () => {
    setLoading(true);
    const coords = await getCurrentPosition();
    if (!coords) {
      toast({
        title: 'Erro de localização',
        description: 'Não foi possível obter sua localização. Verifique as permissões.',
        variant: 'destructive'
      });
      setLoading(false);
      return;
    }
    const address = await fetchAddressByCoordinates(coords.latitude, coords.longitude);
    if (address) {
      setLocationDirect(address.uf, address.city, address.neighborhood, address.street);
      setLocationOpen(false);
      toast({
        title: 'Localização detectada',
        description: `${address.city}, ${address.uf}`
      });
    } else {
      toast({
        title: 'Erro',
        description: 'Não foi possível identificar sua cidade.',
        variant: 'destructive'
      });
    }
    setLoading(false);
  };
  const handleCepSearch = async () => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;
    setLoading(true);
    const address = await fetchAddressByCep(cleanCep);
    if (address) {
      setLocationDirect(address.uf, address.city, address.neighborhood, address.street, cleanCep);
      setLocationOpen(false);
      toast({
        title: 'Localização encontrada',
        description: `${address.city}, ${address.uf}`
      });
    } else {
      toast({
        title: 'CEP não encontrado',
        description: 'Verifique o número digitado.',
        variant: 'destructive'
      });
    }
    setLoading(false);
  };
  const handleCepChange = (value: string) => {
    setCep(formatCep(value));
    const cleanCep = value.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      handleCepSearch();
    }
  };
  const handleSearch = () => {
    if (location.isValid) {
      navigate('/student/instructors');
    } else {
      navigate('/onboarding/location');
    }
  };
  return <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-hero py-16 lg:py-20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6 animate-fade-in">
              <Shield className="h-4 w-4 text-primary-foreground" />
              <span className="text-sm font-medium text-primary-foreground">Instrutores verificados e certificados</span>
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-extrabold text-primary-foreground mb-4 animate-fade-in" style={{
            animationDelay: '0.1s'
          }}>
              Sua <span className="bg-gradient-to-r from-blue-200 to-sky-300 bg-clip-text text-transparent">CNH</span> começa aqui
            </h1>
            
            <p className="text-lg text-primary-foreground/80 mb-8 animate-fade-in" style={{
            animationDelay: '0.2s'
          }}>
              Encontre instrutores qualificados perto de você. Agende aulas práticas de direção para carro ou moto com segurança e praticidade.
            </p>
            
            {/* Search Bar */}
            <div className="bg-card rounded-2xl p-2 shadow-xl max-w-2xl mx-auto animate-fade-in" style={{
            animationDelay: '0.3s'
          }}>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex-1">
                  <Popover open={locationOpen} onOpenChange={setLocationOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" className="w-full h-12 justify-start text-left font-normal bg-muted/50 hover:bg-muted">
                        <MapPin className="h-5 w-5 mr-2 text-muted-foreground shrink-0" />
                        <span className={displayLocation ? 'text-foreground' : 'text-muted-foreground'}>
                          {displayLocation || 'Cidade ou região'}
                        </span>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80 p-4" align="start">
                      <div className="space-y-4">
                        <div className="text-sm font-medium">Como deseja informar sua localização?</div>
                        
                        {/* GPS Button */}
                        <Button variant="outline" onClick={handleGpsClick} disabled={loading} className="w-full justify-start gap-2 h-11">
                          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Navigation className="h-4 w-4" />}
                          Usar minha localização
                        </Button>
                        
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-px bg-border" />
                          <span className="text-xs text-muted-foreground">ou</span>
                          <div className="flex-1 h-px bg-border" />
                        </div>
                        
                        {/* CEP Input */}
                        <div className="flex gap-2">
                          <Input placeholder="Digite seu CEP" value={cep} onChange={e => handleCepChange(e.target.value)} maxLength={9} className="h-11" />
                          <Button variant="outline" onClick={handleCepSearch} disabled={loading || cep.replace(/\D/g, '').length !== 8} className="h-11 px-3">
                            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                          </Button>
                        </div>
                        
                        {location.isValid && <div className="p-2 rounded-lg bg-success/10 border border-success/20 text-center">
                            <span className="text-sm font-medium text-success">
                              ✓ {location.city}, {location.uf}
                            </span>
                          </div>}
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="w-full sm:w-44 h-12 border-0 bg-muted/50">
                    <Car className="h-4 w-4 mr-2 text-muted-foreground" />
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Categoria A</SelectItem>
                    <SelectItem value="B">Categoria B</SelectItem>
                    <SelectItem value="AB">Categoria AB</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="hero" size="lg" className="h-12 px-8" onClick={handleSearch}>
                  <Search className="h-5 w-5 mr-2" />
                  Buscar
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-10 mt-10 animate-fade-in" style={{
            animationDelay: '0.4s'
          }}>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-foreground">500+</div>
                <div className="text-sm text-primary-foreground/70">Instrutores Ativos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-foreground flex items-center justify-center gap-1">
                  4.9 <Star className="h-5 w-5 fill-accent text-accent" />
                </div>
                <div className="text-sm text-primary-foreground/70">Avaliação Média</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-foreground flex items-center justify-center gap-1">
                  <Clock className="h-5 w-5" /> 24h
                </div>
                <div className="text-sm text-primary-foreground/70">Agendamento Flexível</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Por que escolher a Conduza?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Uma plataforma completa pensada para facilitar sua primeira via à CNH
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div className="card-elevated p-6 group hover:scale-[1.02] transition-transform">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Instrutores Verificados</h3>
              <p className="text-sm text-muted-foreground">
                Todos os instrutores passam por verificação de documentos, antecedentes e certificações.
              </p>
            </div>
            
            <div className="card-elevated p-6 group hover:scale-[1.02] transition-transform">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Agendamento Flexível</h3>
              <p className="text-sm text-muted-foreground">
                Escolha horários que se encaixam na sua rotina. Flexibilidade total para suas aulas.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="card-elevated p-6 group hover:scale-[1.02] transition-transform">
              <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Star className="h-6 w-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Sistema de Avaliações</h3>
              <p className="text-sm text-muted-foreground">
                Veja avaliações reais de outros alunos antes de escolher seu instrutor.
              </p>
            </div>
            
            <div className="card-elevated p-6 group hover:scale-[1.02] transition-transform">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Documentação Digital</h3>
              <p className="text-sm text-muted-foreground">
                Controle todo o processo de habilitação em um só lugar. Histórico de aulas e comprovantes.
              </p>
            </div>
            
            <div className="card-elevated p-6 group hover:scale-[1.02] transition-transform">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Headphones className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Suporte Dedicado</h3>
              <p className="text-sm text-muted-foreground">
                Equipe de suporte disponível para ajudar em todas as etapas do processo.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="como-funciona" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-14">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Como funciona?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Quatro passos simples para conquistar sua habilitação
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="relative inline-block">
                <div className="h-20 w-20 rounded-full bg-card border-2 border-border flex items-center justify-center mb-4 shadow-md">
                  <Search className="h-8 w-8 text-primary" />
                </div>
                <div className="absolute -top-1 -right-1 h-7 w-7 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                  1
                </div>
              </div>
              <h3 className="text-base font-semibold text-primary mb-2">Encontre um Instrutor</h3>
              <p className="text-sm text-muted-foreground">
                Busque por localidade, categoria (A ou B), tipo de veículo e veja avaliações de outros alunos.
              </p>
            </div>
            
            <div className="text-center">
              <div className="relative inline-block">
                <div className="h-20 w-20 rounded-full bg-card border-2 border-border flex items-center justify-center mb-4 shadow-md">
                  <CalendarCheck className="h-8 w-8 text-primary" />
                </div>
                <div className="absolute -top-1 -right-1 h-7 w-7 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                  2
                </div>
              </div>
              <h3 className="text-base font-semibold text-primary mb-2">Agende suas Aulas</h3>
              <p className="text-sm text-muted-foreground">
                Escolha os melhores horários na agenda do instrutor. Flexibilidade total para suas aulas.
              </p>
            </div>
            
            <div className="text-center">
              <div className="relative inline-block">
                <div className="h-20 w-20 rounded-full bg-card border-2 border-border flex items-center justify-center mb-4 shadow-md">
                  <Car className="h-8 w-8 text-primary" />
                </div>
                <div className="absolute -top-1 -right-1 h-7 w-7 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                  3
                </div>
              </div>
              <h3 className="text-base font-semibold text-primary mb-2">Pratique com Segurança</h3>
              <p className="text-sm text-muted-foreground">
                Aulas práticas com veículos regularizados e instrutores certificados pelo DETRAN.
              </p>
            </div>
            
            <div className="text-center">
              <div className="relative inline-block">
                <div className="h-20 w-20 rounded-full bg-card border-2 border-border flex items-center justify-center mb-4 shadow-md">
                  <Trophy className="h-8 w-8 text-primary" />
                </div>
                <div className="absolute -top-1 -right-1 h-7 w-7 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                  4
                </div>
              </div>
              <h3 className="text-base font-semibold text-primary mb-2">Conquiste sua CNH!</h3>
              <p className="text-sm text-muted-foreground">
                Acompanhe seu progresso, gerencie exames e esteja pronto para a prova prática.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Conduza vs. Método Tradicional
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Veja como a Conduza simplifica o caminho para sua CNH
            </p>
          </div>
          
          <ComparisonSection />
          
          <p className="text-center text-sm text-muted-foreground mt-8">
            A Conduza simplifica o caminho, respeitando todas as etapas obrigatórias da CNH.
          </p>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Números que comprovam
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Baseado na experiência de alunos que encontraram instrutores pela Conduza
            </p>
          </div>
          
          <SocialProofStats />
          
          {/* Testimonials */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-foreground text-center mb-8">
              O que dizem nossos alunos
            </h3>
            <Testimonials testimonials={testimonials} />
          </div>
          
          {/* Trust Badges */}
          <div className="mt-16">
            <h3 className="text-lg font-semibold text-foreground text-center mb-6">
              Confiança & Segurança
            </h3>
            <TrustBadges />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Perguntas Frequentes
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tire suas dúvidas sobre a plataforma
            </p>
          </div>
          
          <FAQSection />
        </div>
      </section>

      {/* CTA Section - Student & Instructor Side by Side */}
      <section className="relative py-20 gradient-hero overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm rounded-full px-4 py-2 mb-4">
              <Car className="h-4 w-4 text-primary-foreground" />
              <span className="text-sm font-medium text-primary-foreground">Milhares de alunos já deram o primeiro passo</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
              Agora é a sua vez
            </h2>
            <p className="text-primary-foreground/80 max-w-2xl mx-auto">
              Comece sua CNH com mais clareza e praticidade
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Student CTA */}
            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-6">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <UserPlus className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">Sou Aluno</h3>
                  <p className="text-sm text-muted-foreground">Quero aprender a dirigir</p>
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Encontre instrutores verificados
                </li>
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Agende aulas no seu horário
                </li>
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Acompanhe seu progresso
                </li>
              </ul>
              <Link to="/register" className="block">
                <Button className="w-full h-12 text-base font-semibold gradient-primary text-primary-foreground hover:opacity-90">
                  Cadastrar como Aluno
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </Link>
            </div>

            {/* Instructor CTA */}
            <div className="bg-card rounded-2xl p-8 border border-accent/30 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-6">
                <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center">
                  <Award className="h-8 w-8 text-accent" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">Sou Instrutor</h3>
                  <p className="text-sm text-muted-foreground">Quero ensinar e ganhar</p>
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Aumente sua visibilidade
                </li>
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Gerencie sua agenda online
                </li>
                <li className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <svg className="h-3 w-3 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  Receba pagamentos seguros
                </li>
              </ul>
              <Link to="/register" className="block">
                <Button className="w-full h-12 text-base font-semibold gradient-accent text-accent-foreground hover:opacity-90">
                  Cadastrar como Instrutor
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>;
};
export default Index;