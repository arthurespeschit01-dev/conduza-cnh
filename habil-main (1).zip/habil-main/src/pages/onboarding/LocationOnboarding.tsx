import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { useLocation } from '@/contexts/LocationContext';
import { useToast } from '@/hooks/use-toast';
import { MapPin, ArrowRight } from 'lucide-react';
import { LocationInput } from '@/components/location/LocationInput';

const LocationOnboarding = () => {
  const { location, setLocationDirect, setCoordinates } = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLocationChange = (uf: string, city: string, neighborhood?: string, street?: string, cep?: string, coordinates?: { latitude: number; longitude: number }) => {
    setLocationDirect(uf, city, neighborhood, street, cep);
    if (coordinates) {
      setCoordinates(coordinates.latitude, coordinates.longitude);
    }
  };

  const handleContinue = () => {
    if (!location.isValid) {
      toast({
        title: 'Localização incompleta',
        description: 'Selecione seu estado e cidade',
        variant: 'destructive',
      });
      return;
    }

    navigate('/onboarding/profile');
  };

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-lg">
          <div className="text-center mb-8">
            <div className="inline-flex h-20 w-20 items-center justify-center rounded-2xl gradient-primary mb-6 animate-float">
              <MapPin className="h-10 w-10 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-3">Onde você está?</h1>
            <p className="text-muted-foreground">
              Selecione sua localização para encontrar os melhores instrutores na sua região
            </p>
          </div>

          <div className="card-elevated p-8">
            <LocationInput
              uf={location.uf}
              city={location.city}
              onLocationChange={handleLocationChange}
              showGps={true}
              showCep={true}
              showManual={true}
              showAddressSearch={true}
            />

            <div className="mt-8">
              <Button 
                variant="hero" 
                className="w-full h-12" 
                onClick={handleContinue}
                disabled={!location.isValid}
              >
                Continuar
                <ArrowRight className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default LocationOnboarding;
