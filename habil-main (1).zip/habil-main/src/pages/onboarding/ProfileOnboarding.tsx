import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { LoadingScreen } from '@/components/ui/loading-screen';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from '@/contexts/LocationContext';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';
import { CheckCircle, ArrowRight, GraduationCap, UserCog, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ProfileOnboarding = () => {
  const { user, isAuthenticated } = useAuth();
  const { location } = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [hasSaved, setHasSaved] = useState(false);

  useEffect(() => {
    if (!location.isValid) {
      navigate('/onboarding/location', { replace: true });
    }
  }, [location.isValid, navigate]);

  // Save location to user profile when authenticated
  useEffect(() => {
    const saveLocationToProfile = async () => {
      if (!isAuthenticated || !user || !location.isValid || hasSaved) return;
      
      setIsSaving(true);
      try {
        const { error } = await supabase
          .from('profiles')
          .update({
            city: location.city,
            uf: location.uf,
          })
          .eq('id', user.id);

        if (error) {
          console.error('Error saving location:', error);
          toast({
            title: 'Erro ao salvar localização',
            description: 'Tente novamente mais tarde',
            variant: 'destructive',
          });
        } else {
          setHasSaved(true);
        }
      } catch (error) {
        console.error('Error saving location:', error);
      } finally {
        setIsSaving(false);
      }
    };

    saveLocationToProfile();
  }, [isAuthenticated, user, location, hasSaved, toast]);

  const handleContinue = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    switch (user?.role) {
      case 'student':
        navigate('/student/dashboard');
        break;
      case 'instructor':
        navigate('/instructor/dashboard');
        break;
      case 'admin':
        // Admin route handled by AuthGuard
        navigate('/');
        break;
      default:
        navigate('/');
    }
  };

  if (!location.isValid || isSaving) {
    return <LoadingScreen message={isSaving ? "Salvando localização..." : "Verificando localização..."} />;
  }

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-lg text-center">
          <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-success/10 mb-6 animate-fade-in">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          
          <h1 className="text-3xl font-bold text-foreground mb-3 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Tudo pronto!
          </h1>
          
          <p className="text-muted-foreground mb-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Sua localização foi configurada: <strong className="text-foreground">{location.city}, {location.uf}</strong>
          </p>

          {isAuthenticated && user ? (
            <div className="card-elevated p-6 mb-8 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <div className="flex items-center gap-4">
                <div className={`h-14 w-14 rounded-xl flex items-center justify-center ${
                  user.role === 'student' ? 'gradient-primary' : 
                  user.role === 'instructor' ? 'gradient-accent' : 
                  'bg-muted'
                }`}>
                  {user.role === 'student' && <GraduationCap className="h-7 w-7 text-primary-foreground" />}
                  {user.role === 'instructor' && <UserCog className="h-7 w-7 text-accent-foreground" />}
                  {user.role === 'admin' && <Shield className="h-7 w-7 text-foreground" />}
                </div>
                <div className="text-left">
                  <p className="font-semibold text-foreground">{user.name}</p>
                  <p className="text-sm text-muted-foreground capitalize">
                    {user.role === 'student' ? 'Aluno' : user.role === 'instructor' ? 'Instrutor' : 'Administrador'}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="card-elevated p-6 mb-8 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <p className="text-muted-foreground mb-4">
                Para continuar, faça login ou crie sua conta
              </p>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => navigate('/login')}>
                  Entrar
                </Button>
                <Button variant="hero" className="flex-1" onClick={() => navigate('/register')}>
                  Cadastrar
                </Button>
              </div>
            </div>
          )}

          {isAuthenticated && (
            <Button 
              variant="hero" 
              size="lg" 
              onClick={handleContinue}
              className="animate-fade-in"
              style={{ animationDelay: '0.4s' }}
            >
              Acessar meu painel
              <ArrowRight className="h-5 w-5" />
            </Button>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default ProfileOnboarding;
