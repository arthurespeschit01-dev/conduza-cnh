import { useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Link, useNavigate } from 'react-router-dom';
import { 
  UserPlus, MapPin, Search, BarChart3, CheckCircle, 
  Award, Users, Shield, Eye, Target, ArrowRight,
  ClipboardCheck, Star, FileCheck, Building2
} from 'lucide-react';

const HowItWorks = () => {
  const navigate = useNavigate();

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-hero py-16 lg:py-24">
        <BackButton fallbackPath="/" className="absolute top-4 left-4 z-20 text-primary-foreground hover:text-primary-foreground/80" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-extrabold text-primary-foreground mb-6 animate-fade-in">
              Como funciona a <span className="bg-gradient-to-r from-blue-200 to-sky-300 bg-clip-text text-transparent">Conduza</span>
            </h1>
            <p className="text-lg lg:text-xl text-primary-foreground/80 animate-fade-in" style={{ animationDelay: '0.1s' }}>
              A plataforma que conecta alunos e instrutores de forma simples, transparente e orientada a resultado. 
              Tudo foi pensado para facilitar o processo de habilitação, do primeiro contato até a aprovação.
            </p>
          </div>
        </div>
      </section>

      {/* Para Alunos */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 bg-primary/10 rounded-full px-4 py-2 mb-4">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Para Alunos</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Para quem quer tirar a habilitação
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Conquiste sua CNH de forma organizada e acompanhe cada etapa do processo
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Step 1 */}
            <div className="relative">
              <div className="card-elevated p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <UserPlus className="h-6 w-6 text-primary" />
                  </div>
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                    1
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Crie sua conta</h3>
                <p className="text-sm text-muted-foreground">
                  Cadastre-se em poucos minutos informando seus dados básicos e o tipo de habilitação que deseja (A, B ou AB).
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="card-elevated p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                    2
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Escolha sua localização</h3>
                <p className="text-sm text-muted-foreground">
                  Selecione seu estado e cidade para visualizar apenas instrutores disponíveis na sua região.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="card-elevated p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Search className="h-6 w-6 text-primary" />
                  </div>
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                    3
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Encontre o instrutor ideal</h3>
                <p className="text-sm text-muted-foreground">
                  Compare instrutores com base em tipo de habilitação, experiência, taxa de aprovação, perfil e certificações.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="relative">
              <div className="card-elevated p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                    4
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Acompanhe seu progresso</h3>
                <p className="text-sm text-muted-foreground">
                  Registre aulas, acompanhe etapas e visualize seus resultados teóricos e práticos diretamente na plataforma.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="relative">
              <div className="card-elevated p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-xl bg-success/10 flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-success" />
                  </div>
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                    5
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Confirme seus exames</h3>
                <p className="text-sm text-muted-foreground">
                  Após cada exame, aluno e instrutor confirmam o resultado. Isso garante transparência e credibilidade no processo.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center mt-10">
            <Button variant="hero" size="lg" onClick={() => handleNavigate('/register/student')}>
              Começar agora
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Para Instrutores */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 bg-accent/10 rounded-full px-4 py-2 mb-4">
              <Award className="h-4 w-4 text-accent" />
              <span className="text-sm font-medium text-accent">Para Instrutores</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Para quem ensina a dirigir
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Expanda sua base de alunos e construa sua reputação de forma profissional
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Step 1 */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <FileCheck className="h-6 w-6 text-accent" />
                </div>
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">
                  1
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Cadastre seu perfil profissional</h3>
              <p className="text-sm text-muted-foreground">
                Informe suas certificações, categorias de habilitação que atua e região de atendimento.
              </p>
            </div>

            {/* Step 2 */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Eye className="h-6 w-6 text-accent" />
                </div>
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">
                  2
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Seja encontrado por alunos</h3>
              <p className="text-sm text-muted-foreground">
                Alunos próximos à sua localização encontram seu perfil de forma orgânica, sem intermediações desnecessárias.
              </p>
            </div>

            {/* Step 3 */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <ClipboardCheck className="h-6 w-6 text-accent" />
                </div>
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">
                  3
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Gerencie seus alunos</h3>
              <p className="text-sm text-muted-foreground">
                Acompanhe o progresso de cada aluno, registre exames e mantenha tudo organizado em um único painel.
              </p>
            </div>

            {/* Step 4 */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Star className="h-6 w-6 text-accent" />
                </div>
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">
                  4
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Construa sua reputação</h3>
              <p className="text-sm text-muted-foreground">
                Sua taxa de aprovação é calculada automaticamente com base nos resultados confirmados, fortalecendo sua autoridade e confiança no mercado.
              </p>
            </div>
          </div>

          <div className="text-center mt-10">
            <Button variant="outline" size="lg" onClick={() => handleNavigate('/register/instructor')}>
              Cadastrar como instrutor
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Transparência */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-14">
              <div className="inline-flex items-center gap-2 bg-success/10 rounded-full px-4 py-2 mb-4">
                <Shield className="h-4 w-4 text-success" />
                <span className="text-sm font-medium text-success">Nossos Valores</span>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                Transparência e confiança
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-6">
                <div className="h-14 w-14 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-7 w-7 text-success" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Resultados confirmados</h3>
                <p className="text-sm text-muted-foreground">
                  Por aluno e instrutor
                </p>
              </div>

              <div className="text-center p-6">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Dados claros</h3>
                <p className="text-sm text-muted-foreground">
                  E auditáveis
                </p>
              </div>

              <div className="text-center p-6">
                <div className="h-14 w-14 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-7 w-7 text-accent" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Perfis verificados</h3>
                <p className="text-sm text-muted-foreground">
                  Documentos validados
                </p>
              </div>

              <div className="text-center p-6">
                <div className="h-14 w-14 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
                  <Target className="h-7 w-7 text-success" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Foco em aprovação</h3>
                <p className="text-sm text-muted-foreground">
                  Real, não promessas vazias
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-primary/10 rounded-full px-4 py-2 mb-6">
              <Building2 className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Tudo em um só lugar</span>
            </div>
            
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
              Centralize todo o processo de habilitação
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8">
              A Conduza centraliza todo o processo de ensino, acompanhamento e validação da habilitação em uma única plataforma, 
              tornando a jornada mais simples para quem ensina e para quem aprende.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg" onClick={() => handleNavigate('/register/student')}>
                Sou aluno
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
              <Button variant="outline" size="lg" onClick={() => handleNavigate('/register/instructor')}>
                Sou instrutor
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default HowItWorks;