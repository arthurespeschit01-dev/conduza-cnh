import { useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import {
  EmbeddedCheckoutProvider,
  EmbeddedCheckout,
} from '@stripe/react-stripe-js';
import { MainLayout } from '@/components/layout/MainLayout';
import { BackButton } from '@/components/ui/back-button';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Shield, Lock, CreditCard } from 'lucide-react';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

const PLAN_NAMES: Record<string, string> = {
  basic: 'Básico',
  professional: 'Profissional',
  premium: 'Premium',
};

const PLAN_PRICES: Record<string, number> = {
  basic: 49,
  professional: 97,
  premium: 149,
};

const EmbeddedCheckoutPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const planId = searchParams.get('plan') || 'professional';
  const planName = PLAN_NAMES[planId] || 'Profissional';
  const planPrice = PLAN_PRICES[planId] || 97;

  const fetchClientSecret = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    const { data, error } = await supabase.functions.invoke('create-embedded-checkout', {
      body: { planId },
      headers: session?.access_token 
        ? { Authorization: `Bearer ${session.access_token}` }
        : undefined,
    });

    if (error) {
      console.error('Error creating checkout session:', error);
      throw error;
    }

    if (!data?.clientSecret) {
      throw new Error('Client secret not received');
    }

    return data.clientSecret;
  }, [planId]);

  if (!import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY) {
    return (
      <MainLayout showFooter={false}>
        <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
          <p className="text-destructive">Erro de configuração do Stripe</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <BackButton fallbackPath="/register/instructor" className="mb-6" />

          <div className="grid lg:grid-cols-5 gap-8">
            {/* Order Summary */}
            <div className="lg:col-span-2 order-2 lg:order-1">
              <div className="bg-card border border-border rounded-2xl p-6 sticky top-24">
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  Resumo do pedido
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Plano</span>
                    <span className="font-medium text-foreground">{planName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Cobrança</span>
                    <span className="text-foreground">Mensal</span>
                  </div>
                  <div className="border-t border-border pt-4">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-foreground">Total</span>
                      <span className="text-2xl font-bold text-foreground">
                        R$ {planPrice}<span className="text-sm font-normal text-muted-foreground">/mês</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Security badges */}
                <div className="space-y-3 pt-4 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary" />
                    <span>Pagamento 100% seguro</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-4 w-4 text-primary" />
                    <span>Dados criptografados</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CreditCard className="h-4 w-4 text-primary" />
                    <span>Cancele a qualquer momento</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Checkout Form */}
            <div className="lg:col-span-3 order-1 lg:order-2">
              <div className="bg-card border border-border rounded-2xl p-6">
                <h1 className="text-xl font-bold text-foreground mb-6">
                  Finalizar assinatura
                </h1>

                <EmbeddedCheckoutProvider
                  stripe={stripePromise}
                  options={{ fetchClientSecret }}
                >
                  <EmbeddedCheckout className="min-h-[400px]" />
                </EmbeddedCheckoutProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default EmbeddedCheckoutPage;
