import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle, ArrowRight, Star, Crown, Zap, User, FileText, Rocket } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';

const PLAN_NAMES: Record<string, string> = {
  'basic': 'Plano Básico',
  'professional': 'Plano Profissional',
  'premium': 'Plano Premium',
};

const PLAN_PRICES: Record<string, number> = {
  'basic': 49,
  'professional': 97,
  'premium': 149,
};

const PLAN_ICONS: Record<string, React.ReactNode> = {
  'basic': <Zap className="w-6 h-6 text-emerald-500" />,
  'professional': <Star className="w-6 h-6 text-primary" />,
  'premium': <Crown className="w-6 h-6 text-amber-500" />,
};

const PLAN_FEATURES: Record<string, string[]> = {
  'basic': [
    'Perfil público na Conduza',
    'Botão de contato (WhatsApp)',
    'Exibição básica no marketplace',
    'Cadastro de alunos manual',
    'Registro simples de aulas',
  ],
  'professional': [
    'Tudo do Básico',
    'Perfil verificado',
    'Destaque na busca da cidade',
    'Taxa de aprovação automática',
    'Selo "Instrutor com Alta Aprovação"',
    'Dashboard com métricas',
    'Suporte prioritário',
  ],
  'premium': [
    'Tudo do Profissional',
    'Topo do ranking da cidade',
    'Destaque visual premium',
    'Página personalizada (URL própria)',
    'Relatórios avançados',
    'WhatsApp Business integrado',
    'Exportação de dados',
    'Selo "Instrutor Premium"',
    'Suporte VIP 24/7',
  ],
};

const NEXT_STEPS = [
  {
    icon: User,
    title: 'Complete seu perfil',
    description: 'Adicione foto, experiência e especialidades',
  },
  {
    icon: FileText,
    title: 'Envie seus documentos',
    description: 'CNH, certificado de instrutor e comprovantes',
  },
  {
    icon: Rocket,
    title: 'Comece a receber alunos',
    description: 'Seu perfil ficará visível na plataforma',
  },
];

// Confetti animation component
const Confetti = () => {
  const colors = ['#3B82F6', '#F97316', '#10B981', '#8B5CF6', '#EC4899'];
  
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full"
          style={{
            backgroundColor: colors[i % colors.length],
            left: `${Math.random() * 100}%`,
          }}
          initial={{ 
            y: -20, 
            opacity: 1,
            scale: Math.random() * 0.5 + 0.5,
          }}
          animate={{ 
            y: '100vh',
            opacity: 0,
            rotate: Math.random() * 360,
          }}
          transition={{ 
            duration: Math.random() * 2 + 2,
            delay: Math.random() * 0.5,
            ease: 'easeOut',
          }}
        />
      ))}
    </div>
  );
};

export default function CheckoutSuccess() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const planFromUrl = searchParams.get('plan') as string | null;
  const sessionId = searchParams.get('session_id');
  
  const planName = planFromUrl ? PLAN_NAMES[planFromUrl] || 'Plano' : 'Plano';
  const planPrice = planFromUrl ? PLAN_PRICES[planFromUrl] || 0 : 0;
  const planIcon = planFromUrl ? PLAN_ICONS[planFromUrl] : null;
  const planFeatures = planFromUrl ? PLAN_FEATURES[planFromUrl] || [] : [];

  // Update subscription status after successful checkout
  useEffect(() => {
    const updateSubscription = async () => {
      const { data: session } = await supabase.auth.getSession();
      if (session.session) {
        await supabase.functions.invoke('check-subscription');
      }
    };

    if (sessionId) {
      updateSubscription();
    }
  }, [sessionId]);

  const handleContinue = () => {
    if (planFromUrl) {
      sessionStorage.setItem('selectedInstructorPlan', planFromUrl);
    }
    if (sessionId) {
      sessionStorage.setItem('stripeSessionId', sessionId);
    }
    navigate('/register/instructor/form');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/30 flex items-center justify-center p-4 relative">
      <Confetti />
      
      <div className="max-w-2xl w-full space-y-8">
        {/* Success Header */}
        <motion.div 
          className="text-center space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div 
            className="inline-flex items-center justify-center w-24 h-24 bg-primary/10 rounded-full mb-4 relative"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ 
              type: "spring",
              stiffness: 200,
              damping: 15,
              delay: 0.2 
            }}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5, type: "spring" }}
            >
              <CheckCircle className="w-14 h-14 text-primary" />
            </motion.div>
            
            {/* Pulse rings */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-primary/30"
              initial={{ scale: 1, opacity: 0.5 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{ 
                duration: 1.5, 
                repeat: Infinity,
                ease: "easeOut"
              }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-primary/20"
              initial={{ scale: 1, opacity: 0.3 }}
              animate={{ scale: 2, opacity: 0 }}
              transition={{ 
                duration: 1.5, 
                repeat: Infinity,
                ease: "easeOut",
                delay: 0.3
              }}
            />
          </motion.div>
          
          <motion.h1 
            className="text-3xl md:text-4xl font-bold text-foreground"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            Parabéns! 🎉
          </motion.h1>
          <motion.p 
            className="text-muted-foreground text-lg"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            Seu pagamento foi confirmado com sucesso!
          </motion.p>
        </motion.div>

        {/* Plan Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          <Card className="border-primary/20 bg-card/80 backdrop-blur overflow-hidden relative">
            {/* Gradient accent */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary" />
            
            <CardHeader className="text-center pb-4">
              <motion.div 
                className="flex justify-center mb-3"
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.8, type: "spring", stiffness: 200 }}
              >
                <div className="inline-flex items-center justify-center w-14 h-14 bg-primary/10 rounded-xl">
                  {planIcon}
                </div>
              </motion.div>
              <CardTitle className="text-2xl text-foreground">
                {planName}
              </CardTitle>
              <div className="flex items-baseline justify-center gap-1 mt-2">
                <span className="text-sm text-muted-foreground">R$</span>
                <span className="text-3xl font-bold text-primary">{planPrice}</span>
                <span className="text-muted-foreground">/mês</span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border-t border-border pt-4">
                <p className="text-sm font-medium text-muted-foreground mb-3 text-center">
                  Recursos incluídos:
                </p>
                <ul className="space-y-2">
                  {planFeatures.slice(0, 5).map((feature, index) => (
                    <motion.li 
                      key={index} 
                      className="flex items-center gap-2 text-sm"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.9 + index * 0.1 }}
                    >
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      <span className="text-foreground">{feature}</span>
                    </motion.li>
                  ))}
                  {planFeatures.length > 5 && (
                    <motion.li 
                      className="text-sm text-muted-foreground text-center pt-1"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.4 }}
                    >
                      +{planFeatures.length - 5} recursos adicionais
                    </motion.li>
                  )}
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Next Steps */}
        <motion.div
          className="space-y-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.5 }}
        >
          <h2 className="text-lg font-semibold text-center text-foreground">
            Próximos passos
          </h2>
          
          <div className="grid gap-3">
            {NEXT_STEPS.map((step, index) => (
              <motion.div
                key={index}
                className="flex items-center gap-4 p-4 rounded-xl bg-card/60 border border-border/50 backdrop-blur"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.3 + index * 0.15 }}
                whileHover={{ scale: 1.02, x: 5 }}
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-foreground">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                </div>
                <step.icon className="w-5 h-5 text-muted-foreground" />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Button */}
        <motion.div 
          className="flex justify-center pt-2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.7, duration: 0.5 }}
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button 
              size="lg" 
              onClick={handleContinue}
              className="gap-2 px-8 shadow-lg shadow-primary/25"
              variant="hero"
            >
              Continuar cadastro
              <ArrowRight className="w-4 h-4" />
            </Button>
          </motion.div>
        </motion.div>

        {/* Footer note */}
        <motion.p 
          className="text-center text-xs text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.9 }}
        >
          Sua assinatura está ativa. Você receberá um email de confirmação em instantes.
        </motion.p>
      </div>
    </div>
  );
}
