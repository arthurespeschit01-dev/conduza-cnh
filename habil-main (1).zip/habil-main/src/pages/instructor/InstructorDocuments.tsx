import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';
import { 
  FileText, 
  Upload, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DocumentType {
  id: string;
  name: string;
  description: string;
  fieldName: 'cnh_document_path' | 'rg_document_path' | 'proof_of_residence_path' | 'instructor_certificate_path';
}

const documentTypes: DocumentType[] = [
  {
    id: 'cnh',
    name: 'CNH',
    description: 'Carteira Nacional de Habilitação válida',
    fieldName: 'cnh_document_path'
  },
  {
    id: 'rg',
    name: 'RG',
    description: 'Documento de identidade (frente e verso)',
    fieldName: 'rg_document_path'
  },
  {
    id: 'residence',
    name: 'Comprovante de Residência',
    description: 'Conta de luz, água ou telefone (últimos 3 meses)',
    fieldName: 'proof_of_residence_path'
  },
  {
    id: 'certificate',
    name: 'Certificado de Instrutor',
    description: 'Certificado de formação como instrutor de trânsito',
    fieldName: 'instructor_certificate_path'
  }
];

interface DocumentStatus {
  [key: string]: {
    uploaded: boolean;
    url: string | null;
  };
}

const InstructorDocuments = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [documentStatus, setDocumentStatus] = useState<DocumentStatus>({});
  const [uploadingDoc, setUploadingDoc] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    if (user) {
      fetchDocumentStatus();
    }
  }, [user]);
  
  const fetchDocumentStatus = async () => {
    if (!user) return;
    
    try {
      // Fetch from user_sensitive_data (new location for sensitive documents)
      const { data, error } = await supabase
        .from('user_sensitive_data')
        .select('cnh_document_path, rg_document_path, proof_of_residence_path, instructor_certificate_path')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (error) throw error;
      
      const status: DocumentStatus = {};
      documentTypes.forEach(doc => {
        const url = data?.[doc.fieldName as keyof typeof data] as string | null;
        status[doc.id] = {
          uploaded: !!url,
          url: url
        };
      });
      
      setDocumentStatus(status);
    } catch (error) {
      console.error('Error fetching document status:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleFileUpload = async (docType: DocumentType, file: File) => {
    if (!user) return;
    
    setUploadingDoc(docType.id);
    
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${docType.id}.${fileExt}`;
      
      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('instructor-documents')
        .upload(fileName, file, { upsert: true });
      
      if (uploadError) throw uploadError;
      
      // Store file path in user_sensitive_data
      const fileUrl = fileName;
      
      // Update user_sensitive_data (upsert to handle first document)
      const updateData: Record<string, string> = {};
      updateData[docType.fieldName] = fileUrl;
      
      const { error: updateError } = await supabase
        .from('user_sensitive_data')
        .upsert({
          user_id: user.id,
          ...updateData
        }, { onConflict: 'user_id' });
      
      if (updateError) throw updateError;
      
      // Update local state with new document
      const newDocumentStatus = {
        ...documentStatus,
        [docType.id]: {
          uploaded: true,
          url: fileUrl
        }
      };
      setDocumentStatus(newDocumentStatus);
      
      // Check if all documents are now uploaded
      const allDocsUploaded = documentTypes.every(doc => 
        doc.id === docType.id ? true : newDocumentStatus[doc.id]?.uploaded
      );
      
      if (allDocsUploaded) {
        // Update registration status to approved
        await supabase
          .from('profiles')
          .update({ registration_status: 'approved' })
          .eq('id', user.id);
        
        toast({
          title: 'Cadastro Aprovado!',
          description: 'Todos os documentos foram enviados. Seu cadastro foi aprovado automaticamente.',
        });
      } else {
        toast({
          title: 'Documento enviado!',
          description: `${docType.name} foi enviado com sucesso.`,
        });
      }
    } catch (error) {
      console.error('Error uploading document:', error);
      toast({
        title: 'Erro no upload',
        description: 'Não foi possível enviar o documento. Tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setUploadingDoc(null);
    }
  };
  
  const handleInputChange = (docType: DocumentType) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: 'Formato inválido',
          description: 'Formatos aceitos: PDF, JPG, PNG',
          variant: 'destructive'
        });
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'Arquivo muito grande',
          description: 'O arquivo deve ter no máximo 5MB',
          variant: 'destructive'
        });
        return;
      }
      
      handleFileUpload(docType, file);
    }
  };
  
  const uploadedCount = Object.values(documentStatus).filter(s => s.uploaded).length;
  const totalDocs = documentTypes.length;
  const allDocsUploaded = uploadedCount === totalDocs;
  
  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-[60vh] flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <div className="container max-w-3xl py-8 px-4">
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">Meus Documentos</h1>
            <p className="text-muted-foreground mt-1">
              Envie os documentos necessários para ativar seu perfil
            </p>
          </div>
          
          {/* Progress Card */}
          <div className={cn(
            "card-elevated p-6",
            allDocsUploaded && "border-success/30 bg-success/5"
          )}>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">
                  {allDocsUploaded ? 'Cadastro Aprovado!' : 'Progresso da Verificação'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {allDocsUploaded 
                    ? 'Todos os documentos foram enviados e aprovados' 
                    : `${uploadedCount} de ${totalDocs} documentos enviados`}
                </p>
              </div>
              <div className={cn(
                "flex items-center gap-2",
                allDocsUploaded ? "text-success" : "text-amber-600"
              )}>
                {allDocsUploaded ? (
                  <>
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-medium">Aprovado</span>
                  </>
                ) : (
                  <>
                    <Clock className="h-5 w-5" />
                    <span className="font-medium">Pendente</span>
                  </>
                )}
              </div>
            </div>
          </div>
          
          {/* Documents List */}
          <div className="space-y-4">
            {documentTypes.map((docType) => {
              const status = documentStatus[docType.id];
              const isUploading = uploadingDoc === docType.id;
              const isUploaded = status?.uploaded;
              
              return (
                <div
                  key={docType.id}
                  className="card-elevated p-5 flex items-center gap-4"
                >
                  <div className={cn(
                    "h-12 w-12 rounded-lg flex items-center justify-center",
                    isUploaded ? "bg-success/10" : "bg-muted"
                  )}>
                    {isUploaded ? (
                      <CheckCircle2 className="h-6 w-6 text-success" />
                    ) : (
                      <FileText className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground">{docType.name}</h3>
                    <p className="text-sm text-muted-foreground truncate">{docType.description}</p>
                  </div>
                  
                  <div>
                    <input
                      type="file"
                      id={`file-${docType.id}`}
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleInputChange(docType)}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <label htmlFor={`file-${docType.id}`}>
                      <Button
                        variant={isUploaded ? "outline" : "default"}
                        size="sm"
                        className={cn(
                          "gap-2 cursor-pointer",
                          !isUploaded && "bg-amber-500 hover:bg-amber-600"
                        )}
                        disabled={isUploading}
                        asChild
                      >
                        <span>
                          {isUploading ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Enviando...
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4" />
                              {isUploaded ? 'Atualizar' : 'Enviar'}
                            </>
                          )}
                        </span>
                      </Button>
                    </label>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Important Information */}
          <div className="bg-muted/50 rounded-lg p-5 space-y-3">
            <h3 className="font-semibold text-foreground">Informações Importantes</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                Todos os documentos devem estar legíveis e atualizados
              </li>
              <li className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                A verificação pode levar até 48 horas úteis
              </li>
              <li className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                Você será notificado quando seus documentos forem analisados
              </li>
              <li className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                Formatos aceitos: PDF, JPG, PNG
              </li>
            </ul>
          </div>
          
          {/* Back Button */}
          <div className="pt-4">
            <Button
              variant="outline"
              onClick={() => navigate('/instructor/dashboard')}
            >
              Voltar ao Painel
            </Button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default InstructorDocuments;
