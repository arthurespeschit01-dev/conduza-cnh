import { useState, useEffect, useMemo } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useSchedules } from '@/hooks/useSchedules';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { format, isSameDay, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isWithinInterval } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { ptBR } from 'date-fns/locale';
import { 
  CalendarDays, 
  Clock, 
  Car, 
  Bike, 
  BookOpen, 
  Loader2, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle,
  XCircle,
  Ban,
  Plus,
  Trash2,
  LayoutGrid,
  List
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface BlockedSlot {
  id: string;
  blocked_date: string;
  blocked_time: string;
  reason: string | null;
}

const InstructorSchedule = () => {
  const { user } = useAuth();
  const { schedules, isLoading, updateScheduleStatus, rescheduleLesson, refetch } = useSchedules();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');
  const [actionDialogOpen, setActionDialogOpen] = useState(false);
  const [selectedLesson, setSelectedLesson] = useState<{ id: string; action: 'confirm' | 'cancel' | 'complete' } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Blocked slots state
  const [blockedSlots, setBlockedSlots] = useState<BlockedSlot[]>([]);
  const [blockedSlotsLoading, setBlockedSlotsLoading] = useState(true);
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [selectedTimeToBlock, setSelectedTimeToBlock] = useState<string>('');
  const [blockReason, setBlockReason] = useState<string>('');
  const [isBlocking, setIsBlocking] = useState(false);

  // Instructor availability
  const [instructorAvailability, setInstructorAvailability] = useState<{ start: string; end: string } | null>(null);

  // Drag and drop state
  const [draggedLesson, setDraggedLesson] = useState<string | null>(null);
  const [dropTargetDay, setDropTargetDay] = useState<string | null>(null);
  const [isRescheduling, setIsRescheduling] = useState(false);

  // Fetch blocked slots
  useEffect(() => {
    const fetchBlockedSlots = async () => {
      if (!user?.id) return;

      const { data, error } = await supabase
        .from('instructor_blocked_slots')
        .select('*')
        .eq('instructor_id', user.id)
        .order('blocked_date', { ascending: true })
        .order('blocked_time', { ascending: true });

      if (!error && data) {
        setBlockedSlots(data);
      }
      setBlockedSlotsLoading(false);
    };

    fetchBlockedSlots();
  }, [user?.id]);

  // Fetch instructor availability hours
  useEffect(() => {
    const fetchAvailability = async () => {
      if (!user?.id) return;

      const { data } = await supabase
        .from('profiles')
        .select('available_start_time, available_end_time')
        .eq('id', user.id)
        .single();

      if (data) {
        setInstructorAvailability({
          start: data.available_start_time || '08:00',
          end: data.available_end_time || '18:00',
        });
      }
    };

    fetchAvailability();
  }, [user?.id]);

  // Filter only instructor's schedules
  const instructorSchedules = schedules.filter(s => s.instructor_id === user?.id);

  // Filter schedules that are not cancelled (for calendar highlighting and stats)
  const activeSchedules = instructorSchedules.filter(s => s.status !== 'cancelled');

  // Get dates with scheduled lessons for calendar highlighting
  const scheduledDates = instructorSchedules.map(s => new Date(s.scheduled_date));
  
  // Get dates with blocked slots
  const blockedDates = blockedSlots.map(s => new Date(s.blocked_date));

  // Get ALL lessons for selected date (including cancelled)
  const selectedDateLessons = selectedDate
    ? instructorSchedules.filter(s => isSameDay(new Date(s.scheduled_date), selectedDate))
    : [];

  // Get blocked slots for selected date
  const selectedDateBlockedSlots = selectedDate
    ? blockedSlots.filter(s => isSameDay(new Date(s.blocked_date), selectedDate))
    : [];

  // Generate available time slots for blocking
  const availableTimeSlots = useMemo(() => {
    if (!instructorAvailability || !selectedDate) return [];

    const slots: string[] = [];
    const startHour = parseInt(instructorAvailability.start.split(':')[0], 10);
    const endHour = parseInt(instructorAvailability.end.split(':')[0], 10);
    const dateStr = format(selectedDate, 'yyyy-MM-dd');

    // Get already blocked times for this date
    const blockedTimes = selectedDateBlockedSlots.map(s => s.blocked_time.slice(0, 5));
    
    // Get scheduled times for this date
    const scheduledTimes = selectedDateLessons
      .filter(s => s.status !== 'cancelled')
      .map(s => s.scheduled_time.slice(0, 5));

    for (let hour = startHour; hour < endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00`;
      // Only show times that are not blocked and not scheduled
      if (!blockedTimes.includes(timeString) && !scheduledTimes.includes(timeString)) {
        slots.push(timeString);
      }
    }

    return slots;
  }, [instructorAvailability, selectedDate, selectedDateBlockedSlots, selectedDateLessons]);

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <Badge className="bg-success/10 text-success border-success/20">Confirmada</Badge>;
      case 'completed':
        return <Badge className="bg-primary/10 text-primary border-primary/20">Concluída</Badge>;
      case 'pending':
        return <Badge variant="outline">Pendente</Badge>;
      case 'cancelled':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Cancelada</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Get lesson type icon and label
  const getLessonInfo = (type: string) => {
    switch (type) {
      case 'practical_car':
        return { icon: <Car className="h-4 w-4" />, label: 'Prática Carro' };
      case 'practical_motorcycle':
        return { icon: <Bike className="h-4 w-4" />, label: 'Prática Moto' };
      case 'theoretical':
        return { icon: <BookOpen className="h-4 w-4" />, label: 'Teórica' };
      default:
        return { icon: <Car className="h-4 w-4" />, label: type };
    }
  };

  // Handle action click
  const handleActionClick = (lessonId: string, action: 'confirm' | 'cancel' | 'complete') => {
    setSelectedLesson({ id: lessonId, action });
    setActionDialogOpen(true);
  };

  const confirmAction = async () => {
    if (!selectedLesson) return;
    
    setIsProcessing(true);
    
    const statusMap = {
      confirm: 'confirmed',
      cancel: 'cancelled',
      complete: 'completed'
    } as const;
    
    const result = await updateScheduleStatus(selectedLesson.id, statusMap[selectedLesson.action]);
    setIsProcessing(false);
    setActionDialogOpen(false);
    setSelectedLesson(null);
    
    if (result.success) {
      const messages = {
        confirm: 'Aula confirmada com sucesso!',
        cancel: 'Aula cancelada.',
        complete: 'Aula marcada como concluída!'
      };
      toast({
        title: messages[selectedLesson.action],
      });
    } else {
      toast({
        title: 'Erro',
        description: 'Não foi possível realizar a ação. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  // Handle block time slot
  const handleBlockSlot = async () => {
    if (!user?.id || !selectedDate || !selectedTimeToBlock) return;

    setIsBlocking(true);

    const { data, error } = await supabase
      .from('instructor_blocked_slots')
      .insert({
        instructor_id: user.id,
        blocked_date: format(selectedDate, 'yyyy-MM-dd'),
        blocked_time: selectedTimeToBlock,
        reason: blockReason || null,
      })
      .select()
      .single();

    setIsBlocking(false);

    if (error) {
      toast({
        title: 'Erro ao bloquear horário',
        description: error.message,
        variant: 'destructive',
      });
      return;
    }

    if (data) {
      setBlockedSlots(prev => [...prev, data]);
      toast({
        title: 'Horário bloqueado!',
        description: `${selectedTimeToBlock} em ${format(selectedDate, "dd/MM/yyyy")} foi bloqueado.`,
      });
    }

    setBlockDialogOpen(false);
    setSelectedTimeToBlock('');
    setBlockReason('');
  };

  // Handle unblock time slot
  const handleUnblockSlot = async (slotId: string) => {
    const { error } = await supabase
      .from('instructor_blocked_slots')
      .delete()
      .eq('id', slotId);

    if (error) {
      toast({
        title: 'Erro ao desbloquear horário',
        description: error.message,
        variant: 'destructive',
      });
      return;
    }

    setBlockedSlots(prev => prev.filter(s => s.id !== slotId));
    toast({
      title: 'Horário desbloqueado!',
    });
  };

  const getActionDialogContent = () => {
    if (!selectedLesson) return { title: '', description: '' };
    
    switch (selectedLesson.action) {
      case 'confirm':
        return {
          title: 'Confirmar Aula',
          description: 'Tem certeza que deseja confirmar esta aula?'
        };
      case 'cancel':
        return {
          title: 'Cancelar Aula',
          description: 'Tem certeza que deseja cancelar esta aula? O aluno será notificado.'
        };
      case 'complete':
        return {
          title: 'Concluir Aula',
          description: 'Tem certeza que deseja marcar esta aula como concluída?'
        };
      default:
        return { title: '', description: '' };
    }
  };

  // Get upcoming lessons count per month
  const currentMonthLessons = activeSchedules.filter(s => {
    const date = new Date(s.scheduled_date);
    return date >= startOfMonth(currentMonth) && date <= endOfMonth(currentMonth);
  });

  // Get lessons for current week
  const currentWeekEnd = endOfWeek(currentWeekStart, { weekStartsOn: 1 });
  const currentWeekLessons = activeSchedules.filter(s => {
    const date = new Date(s.scheduled_date);
    return isWithinInterval(date, { start: currentWeekStart, end: currentWeekEnd });
  });

  // Generate week days array
  const weekDays = useMemo(() => {
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
      days.push(addDays(currentWeekStart, i));
    }
    return days;
  }, [currentWeekStart]);

  // Get lessons and blocked slots for a specific day (for weekly view)
  const getLessonsForDay = (day: Date) => {
    return instructorSchedules.filter(s => isSameDay(new Date(s.scheduled_date), day));
  };

  const getBlockedSlotsForDay = (day: Date) => {
    return blockedSlots.filter(s => isSameDay(new Date(s.blocked_date), day));
  };

  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent, lessonId: string) => {
    setDraggedLesson(lessonId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', lessonId);
  };

  const handleDragEnd = () => {
    setDraggedLesson(null);
    setDropTargetDay(null);
  };

  const handleDragOver = (e: React.DragEvent, day: Date) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDropTargetDay(format(day, 'yyyy-MM-dd'));
  };

  const handleDragLeave = () => {
    setDropTargetDay(null);
  };

  const handleDrop = async (e: React.DragEvent, day: Date) => {
    e.preventDefault();
    setDropTargetDay(null);

    const lessonId = e.dataTransfer.getData('text/plain');
    if (!lessonId || !user?.id) return;

    const lesson = instructorSchedules.find(s => s.id === lessonId);
    if (!lesson) return;

    // Don't do anything if dropped on the same day
    if (isSameDay(new Date(lesson.scheduled_date), day)) {
      setDraggedLesson(null);
      return;
    }

    // Check if status allows rescheduling
    if (lesson.status === 'completed' || lesson.status === 'cancelled') {
      toast({
        title: 'Não é possível reagendar',
        description: 'Aulas concluídas ou canceladas não podem ser reagendadas.',
        variant: 'destructive',
      });
      setDraggedLesson(null);
      return;
    }

    const newDate = format(day, 'yyyy-MM-dd');
    const newTime = lesson.scheduled_time;

    // Check if the time slot is blocked on the new date
    const blockedForDay = blockedSlots.filter(s => s.blocked_date === newDate);
    const isBlocked = blockedForDay.some(s => s.blocked_time.slice(0, 5) === newTime.slice(0, 5));
    
    if (isBlocked) {
      toast({
        title: 'Horário bloqueado',
        description: 'Este horário está bloqueado na data selecionada.',
        variant: 'destructive',
      });
      setDraggedLesson(null);
      return;
    }

    setIsRescheduling(true);

    const result = await rescheduleLesson(lessonId, newDate, newTime, user.id);

    setIsRescheduling(false);
    setDraggedLesson(null);

    if (result.success) {
      toast({
        title: 'Aula reagendada!',
        description: `Movida para ${format(day, "dd 'de' MMMM", { locale: ptBR })}.`,
      });
    } else {
      toast({
        title: 'Erro ao reagendar',
        description: result.error || 'Não foi possível reagendar a aula.',
        variant: 'destructive',
      });
    }
  };

  // Stats
  const pendingCount = instructorSchedules.filter(s => s.status === 'pending').length;
  const confirmedCount = instructorSchedules.filter(s => s.status === 'confirmed').length;
  const completedCount = instructorSchedules.filter(s => s.status === 'completed').length;

  if (isLoading || blockedSlotsLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  const dialogContent = getActionDialogContent();

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Minha Agenda</h1>
          <p className="text-muted-foreground">
            Gerencie suas aulas e bloqueie horários indisponíveis
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{pendingCount}</p>
                <p className="text-sm text-muted-foreground">Pendentes</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{confirmedCount}</p>
                <p className="text-sm text-muted-foreground">Confirmadas</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <CalendarDays className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{completedCount}</p>
                <p className="text-sm text-muted-foreground">Concluídas</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                <Ban className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{blockedSlots.length}</p>
                <p className="text-sm text-muted-foreground">Bloqueados</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar / Week View */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-primary" />
                    {viewMode === 'month' ? 'Calendário de Aulas' : 'Visualização Semanal'}
                  </CardTitle>
                  <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'month' | 'week')}>
                    <TabsList>
                      <TabsTrigger value="month" className="gap-2">
                        <LayoutGrid className="h-4 w-4" />
                        <span className="hidden sm:inline">Mensal</span>
                      </TabsTrigger>
                      <TabsTrigger value="week" className="gap-2">
                        <List className="h-4 w-4" />
                        <span className="hidden sm:inline">Semanal</span>
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        if (viewMode === 'month') {
                          setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)));
                        } else {
                          setCurrentWeekStart(addDays(currentWeekStart, -7));
                        }
                      }}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm font-medium min-w-[140px] text-center">
                      {viewMode === 'month' 
                        ? format(currentMonth, 'MMMM yyyy', { locale: ptBR })
                        : `${format(currentWeekStart, "dd MMM", { locale: ptBR })} - ${format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), "dd MMM", { locale: ptBR })}`
                      }
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        if (viewMode === 'month') {
                          setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)));
                        } else {
                          setCurrentWeekStart(addDays(currentWeekStart, 7));
                        }
                      }}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {viewMode === 'month' 
                      ? `${currentMonthLessons.length} aula${currentMonthLessons.length !== 1 ? 's' : ''} neste mês`
                      : `${currentWeekLessons.length} aula${currentWeekLessons.length !== 1 ? 's' : ''} nesta semana`
                    }
                  </p>
                </div>
              </CardHeader>
              <CardContent>
                {viewMode === 'month' ? (
                  <>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      month={currentMonth}
                      onMonthChange={setCurrentMonth}
                      locale={ptBR}
                      className="w-full pointer-events-auto"
                      modifiers={{
                        scheduled: scheduledDates,
                        blocked: blockedDates,
                      }}
                      modifiersStyles={{
                        scheduled: {
                          fontWeight: 'bold',
                          color: 'hsl(var(--primary))',
                        },
                        blocked: {
                          textDecoration: 'line-through',
                          opacity: 0.6,
                        },
                      }}
                      classNames={{
                        months: "w-full",
                        month: "w-full",
                        table: "w-full border-collapse",
                        head_row: "flex w-full",
                        head_cell: "text-muted-foreground rounded-md w-full font-normal text-sm",
                        row: "flex w-full mt-2",
                        cell: "relative p-0 text-center text-sm focus-within:relative focus-within:z-20 w-full h-12",
                        day: "h-12 w-full p-0 font-normal aria-selected:opacity-100 hover:bg-accent hover:text-accent-foreground rounded-lg transition-colors flex items-center justify-center text-foreground",
                        day_selected: "bg-primary !text-primary-foreground hover:bg-primary hover:!text-primary-foreground focus:bg-primary focus:!text-primary-foreground",
                        day_today: "bg-accent text-accent-foreground",
                        nav: "hidden",
                      }}
                    />

                    {/* Legend */}
                    <div className="flex items-center gap-4 mt-4 pt-4 border-t flex-wrap">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary" />
                        <span className="text-sm text-muted-foreground">Dia com aula</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-accent" />
                        <span className="text-sm text-muted-foreground">Hoje</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-destructive/50" />
                        <span className="text-sm text-muted-foreground">Com bloqueio</span>
                      </div>
                    </div>
                  </>
                ) : (
                  /* Weekly View */
                  <div className="space-y-3">
                    {isRescheduling && (
                      <div className="fixed inset-0 bg-background/50 z-50 flex items-center justify-center">
                        <div className="bg-card p-4 rounded-lg shadow-lg flex items-center gap-3">
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                          <span>Reagendando aula...</span>
                        </div>
                      </div>
                    )}
                    {weekDays.map((day) => {
                      const dayLessons = getLessonsForDay(day);
                      const dayBlockedSlots = getBlockedSlotsForDay(day);
                      const isToday = isSameDay(day, new Date());
                      const isSelected = selectedDate && isSameDay(day, selectedDate);
                      const hasContent = dayLessons.length > 0 || dayBlockedSlots.length > 0;
                      const isDragTarget = dropTargetDay === format(day, 'yyyy-MM-dd');

                      return (
                        <div
                          key={day.toISOString()}
                          className={`p-4 rounded-xl border transition-all cursor-pointer ${
                            isDragTarget
                              ? 'border-primary border-2 bg-primary/10 scale-[1.01]'
                              : isSelected 
                                ? 'border-primary bg-primary/5' 
                                : isToday 
                                  ? 'border-accent bg-accent/5' 
                                  : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setSelectedDate(day)}
                          onDragOver={(e) => handleDragOver(e, day)}
                          onDragLeave={handleDragLeave}
                          onDrop={(e) => handleDrop(e, day)}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <div className={`text-center min-w-[50px] ${isToday ? 'text-primary' : ''}`}>
                                <p className="text-xs uppercase text-muted-foreground">
                                  {format(day, 'EEE', { locale: ptBR })}
                                </p>
                                <p className={`text-2xl font-bold ${isToday ? 'text-primary' : ''}`}>
                                  {format(day, 'dd')}
                                </p>
                              </div>
                              {hasContent && (
                                <div className="flex items-center gap-2">
                                  {dayLessons.length > 0 && (
                                    <Badge variant="secondary" className="text-xs">
                                      {dayLessons.filter(l => l.status !== 'cancelled').length} aula{dayLessons.filter(l => l.status !== 'cancelled').length !== 1 ? 's' : ''}
                                    </Badge>
                                  )}
                                  {dayBlockedSlots.length > 0 && (
                                    <Badge variant="outline" className="text-xs text-destructive border-destructive/30">
                                      {dayBlockedSlots.length} bloqueio{dayBlockedSlots.length !== 1 ? 's' : ''}
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          {hasContent ? (
                            <div className="space-y-2 ml-[62px]">
                              {dayLessons
                                .sort((a, b) => a.scheduled_time.localeCompare(b.scheduled_time))
                                .slice(0, 3)
                                .map((lesson) => {
                                  const lessonInfo = getLessonInfo(lesson.lesson_type);
                                  const isDragging = draggedLesson === lesson.id;
                                  const canDrag = lesson.status !== 'completed' && lesson.status !== 'cancelled';
                                  
                                  return (
                                    <div
                                      key={lesson.id}
                                      draggable={canDrag}
                                      onDragStart={(e) => canDrag && handleDragStart(e, lesson.id)}
                                      onDragEnd={handleDragEnd}
                                      className={`flex items-center gap-2 text-sm rounded-md px-2 py-1 -mx-2 transition-all ${
                                        lesson.status === 'cancelled' 
                                          ? 'opacity-50 line-through' 
                                          : canDrag 
                                            ? 'cursor-grab active:cursor-grabbing hover:bg-muted' 
                                            : ''
                                      } ${isDragging ? 'opacity-50 scale-95' : ''}`}
                                      title={canDrag ? 'Arraste para reagendar' : undefined}
                                    >
                                      <Clock className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                                      <span className="font-medium">{lesson.scheduled_time.slice(0, 5)}</span>
                                      <span className="text-muted-foreground">-</span>
                                      {lessonInfo.icon}
                                      <span className="text-muted-foreground truncate">
                                        {'student' in lesson && lesson.student 
                                          ? lesson.student.full_name 
                                          : lessonInfo.label}
                                      </span>
                                      {getStatusBadge(lesson.status)}
                                    </div>
                                  );
                                })}
                              {dayLessons.length > 3 && (
                                <p className="text-xs text-muted-foreground">
                                  +{dayLessons.length - 3} mais...
                                </p>
                              )}
                              {dayBlockedSlots.slice(0, 2).map((slot) => (
                                <div key={slot.id} className="flex items-center gap-2 text-sm text-destructive">
                                  <Ban className="h-3 w-3" />
                                  <span>{slot.blocked_time.slice(0, 5)}</span>
                                  {slot.reason && (
                                    <span className="text-muted-foreground truncate">- {slot.reason}</span>
                                  )}
                                </div>
                              ))}
                              {dayBlockedSlots.length > 2 && (
                                <p className="text-xs text-muted-foreground">
                                  +{dayBlockedSlots.length - 2} bloqueios...
                                </p>
                              )}
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground ml-[62px]">Sem compromissos</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Selected Day Details */}
          <div className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">
                  {selectedDate 
                    ? format(selectedDate, "dd 'de' MMMM", { locale: ptBR })
                    : 'Selecione uma data'
                  }
                </CardTitle>
                {selectedDate && availableTimeSlots.length > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setBlockDialogOpen(true)}
                  >
                    <Ban className="h-4 w-4 mr-2" />
                    Bloquear
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {/* Blocked slots for this date */}
                {selectedDateBlockedSlots.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-muted-foreground mb-2">Horários Bloqueados</p>
                    <div className="space-y-2">
                      {selectedDateBlockedSlots.map((slot) => (
                        <div
                          key={slot.id}
                          className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <Ban className="h-4 w-4 text-destructive" />
                            <span className="font-medium">{slot.blocked_time.slice(0, 5)}</span>
                            {slot.reason && (
                              <span className="text-sm text-muted-foreground">- {slot.reason}</span>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleUnblockSlot(slot.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Lessons for this date */}
                {selectedDateLessons.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateLessons.map((lesson) => {
                      const lessonInfo = getLessonInfo(lesson.lesson_type);
                      const isPast = new Date(`${lesson.scheduled_date}T${lesson.scheduled_time}`) < new Date();
                      
                      return (
                        <div
                          key={lesson.id}
                          className="p-4 rounded-xl bg-muted/50 space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-primary">
                              {lessonInfo.icon}
                              <span className="font-medium">{lessonInfo.label}</span>
                            </div>
                            {getStatusBadge(lesson.status)}
                          </div>
                          
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>{lesson.scheduled_time.slice(0, 5)}</span>
                            <span className="text-muted-foreground/50">•</span>
                            <span>R$ {Number(lesson.price).toFixed(2)}</span>
                          </div>

                          {'student' in lesson && lesson.student && (
                            <div className="flex items-center gap-2 pt-2 border-t">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={lesson.student.avatar_url || undefined} />
                                <AvatarFallback className="bg-primary/10 text-primary text-sm">
                                  {lesson.student.full_name?.charAt(0) || 'A'}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{lesson.student.full_name}</p>
                                <p className="text-xs text-muted-foreground">Aluno</p>
                              </div>
                            </div>
                          )}

                          {/* Action buttons based on status */}
                          {lesson.status === 'pending' && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                variant="default"
                                size="sm"
                                className="flex-1"
                                onClick={() => handleActionClick(lesson.id, 'confirm')}
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Confirmar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1 text-destructive hover:text-destructive"
                                onClick={() => handleActionClick(lesson.id, 'cancel')}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Cancelar
                              </Button>
                            </div>
                          )}

                          {lesson.status === 'confirmed' && isPast && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                variant="default"
                                size="sm"
                                className="flex-1"
                                onClick={() => handleActionClick(lesson.id, 'complete')}
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Concluir
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1 text-destructive hover:text-destructive"
                                onClick={() => handleActionClick(lesson.id, 'cancel')}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Cancelar
                              </Button>
                            </div>
                          )}

                          {lesson.status === 'confirmed' && !isPast && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1 text-destructive hover:text-destructive"
                                onClick={() => handleActionClick(lesson.id, 'cancel')}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Cancelar
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : selectedDateBlockedSlots.length === 0 ? (
                  <div className="text-center py-8">
                    <CalendarDays className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">
                      {selectedDate ? 'Nenhuma aula neste dia' : 'Selecione uma data'}
                    </p>
                    {selectedDate && availableTimeSlots.length > 0 && (
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setBlockDialogOpen(true)}
                      >
                        <Ban className="h-4 w-4 mr-2" />
                        Bloquear horário
                      </Button>
                    )}
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Action Confirmation Dialog */}
      <AlertDialog open={actionDialogOpen} onOpenChange={setActionDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{dialogContent.title}</AlertDialogTitle>
            <AlertDialogDescription>
              {dialogContent.description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isProcessing}>Voltar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmAction} disabled={isProcessing}>
              {isProcessing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                'Confirmar'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Block Time Slot Dialog */}
      <Dialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bloquear Horário</DialogTitle>
            <DialogDescription>
              Selecione o horário que deseja bloquear para {selectedDate && format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Horário</Label>
              <Select value={selectedTimeToBlock} onValueChange={setSelectedTimeToBlock}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o horário" />
                </SelectTrigger>
                <SelectContent>
                  {availableTimeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Motivo (opcional)</Label>
              <Input
                placeholder="Ex: Consulta médica, Compromisso pessoal..."
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setBlockDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleBlockSlot} 
              disabled={!selectedTimeToBlock || isBlocking}
            >
              {isBlocking ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Ban className="h-4 w-4 mr-2" />
              )}
              Bloquear
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default InstructorSchedule;
