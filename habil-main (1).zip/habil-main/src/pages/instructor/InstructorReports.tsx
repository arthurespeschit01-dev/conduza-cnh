import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/ui/back-button';
import { FeatureGate, useFeatureAccess } from '@/components/instructor/FeatureGate';
import { useInstructorPlan } from '@/hooks/useInstructorPlan';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Calendar,
  Download,
  FileSpreadsheet,
  FileText,
  Crown,
  Lock,
  PieChart,
  Activity
} from 'lucide-react';

const InstructorReports = () => {
  const { hasFeature, effectivePlan, getPlanName } = useInstructorPlan();
  const { UpgradeDialog, openUpgradeDialog } = useFeatureAccess('advanced_reports');
  const { 
    UpgradeDialog: ExportDialog, 
    openUpgradeDialog: openExportDialog,
    isAvailable: canExport 
  } = useFeatureAccess('data_export');

  const hasAdvancedReports = hasFeature('advanced_reports');

  const handleExport = (format: 'pdf' | 'excel') => {
    if (!canExport) {
      openExportDialog();
      return;
    }
    // TODO: Implementar exportação real
    // Funcionalidade de exportação será implementada
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <BackButton fallbackPath="/instructor/dashboard" className="mb-6" />
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
              <Badge variant="outline" className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30">
                <Crown className="h-3 w-3 mr-1" />
                Premium
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Análises detalhadas do seu desempenho como instrutor
            </p>
          </div>

          {/* Export Buttons */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => handleExport('pdf')}
            >
              <FileText className="h-4 w-4" />
              Exportar PDF
              {!canExport && <Lock className="h-3 w-3 ml-1" />}
            </Button>
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => handleExport('excel')}
            >
              <FileSpreadsheet className="h-4 w-4" />
              Exportar Excel
              {!canExport && <Lock className="h-3 w-3 ml-1" />}
            </Button>
          </div>
        </div>

        <FeatureGate feature="advanced_reports" fallback="card">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Total de Aulas</span>
                <Calendar className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground">248</p>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" />
                +12% este mês
              </p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Alunos Ativos</span>
                <Users className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground">32</p>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" />
                +5 novos
              </p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Taxa de Aprovação</span>
                <Activity className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground">94%</p>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" />
                +2% vs. média
              </p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Receita Mensal</span>
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground">R$ 4.850</p>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" />
                +18% este mês
              </p>
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Performance Chart Placeholder */}
            <div className="card-elevated p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-foreground">Desempenho Mensal</h3>
                <Badge variant="outline">Últimos 6 meses</Badge>
              </div>
              <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">Gráfico de barras</p>
                  <p className="text-sm text-muted-foreground/70">Aulas por mês</p>
                </div>
              </div>
            </div>

            {/* Approval Rate Chart Placeholder */}
            <div className="card-elevated p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-foreground">Taxa de Aprovação</h3>
                <Badge variant="outline">Comparativo</Badge>
              </div>
              <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
                <div className="text-center">
                  <PieChart className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">Gráfico de pizza</p>
                  <p className="text-sm text-muted-foreground/70">Aprovados vs Reprovados</p>
                </div>
              </div>
            </div>
          </div>

          {/* Detailed Tables */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold text-foreground">Histórico Detalhado</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">Filtrar</Button>
                <Button variant="outline" size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Mês</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Aulas</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Alunos</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Aprovação</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Receita</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { mes: 'Janeiro 2026', aulas: 45, alunos: 12, aprovacao: '95%', receita: 'R$ 4.200' },
                    { mes: 'Dezembro 2025', aulas: 42, alunos: 10, aprovacao: '93%', receita: 'R$ 3.850' },
                    { mes: 'Novembro 2025', aulas: 38, alunos: 9, aprovacao: '94%', receita: 'R$ 3.500' },
                    { mes: 'Outubro 2025', aulas: 40, alunos: 11, aprovacao: '91%', receita: 'R$ 3.700' },
                  ].map((row, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-muted/30">
                      <td className="py-3 px-4 text-sm text-foreground">{row.mes}</td>
                      <td className="py-3 px-4 text-sm text-foreground">{row.aulas}</td>
                      <td className="py-3 px-4 text-sm text-foreground">{row.alunos}</td>
                      <td className="py-3 px-4 text-sm text-foreground">{row.aprovacao}</td>
                      <td className="py-3 px-4 text-sm text-foreground font-medium">{row.receita}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </FeatureGate>

        <ExportDialog />
      </div>
    </MainLayout>
  );
};

export default InstructorReports;
