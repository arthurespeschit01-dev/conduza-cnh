import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { BackButton } from '@/components/ui/back-button';
import { useAuth } from '@/contexts/AuthContext';
import { useInstructorPlan, PLAN_NAMES, PLAN_PRICES, SubscriptionPlan } from '@/hooks/useInstructorPlan';
import { useStripeSubscription } from '@/hooks/useStripeSubscription';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { 
  Crown, 
  CreditCard, 
  Calendar, 
  CheckCircle2, 
  XCircle,
  ArrowUpRight,
  Loader2,
  Receipt,
  Clock,
  AlertTriangle,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const PLAN_COLORS: Record<string, string> = {
  basic: 'bg-muted text-muted-foreground border-muted-foreground/30',
  professional: 'bg-primary/10 text-primary border-primary/30',
  premium: 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30'
};

const PLAN_ICONS: Record<string, string> = {
  basic: '🟢',
  professional: '⭐',
  premium: '👑'
};

interface SubscriptionDetails {
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  subscription_plan: string | null;
  payment_status: string;
  created_at: string;
  updated_at: string;
}

const InstructorSubscription = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { 
    currentPlan, 
    paymentStatus, 
    isPaymentActive,
    getPlanFeatures,
    isLoading: planLoading 
  } = useInstructorPlan();
  const { openCustomerPortal, createCheckoutSession, isLoading: stripeLoading } = useStripeSubscription();
  
  const [subscriptionDetails, setSubscriptionDetails] = useState<SubscriptionDetails | null>(null);
  const [detailsLoading, setDetailsLoading] = useState(true);

  useEffect(() => {
    const fetchSubscriptionDetails = async () => {
      if (!user?.id) return;
      
      // Fetch profile data
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('subscription_plan, payment_status, created_at, updated_at')
        .eq('id', user.id)
        .single();
      
      // Fetch sensitive data (Stripe IDs)
      const { data: sensitiveData } = await supabase
        .from('user_sensitive_data')
        .select('stripe_customer_id, stripe_subscription_id')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (!profileError && profileData) {
        setSubscriptionDetails({
          subscription_plan: profileData.subscription_plan,
          payment_status: profileData.payment_status,
          created_at: profileData.created_at,
          updated_at: profileData.updated_at,
          stripe_customer_id: sensitiveData?.stripe_customer_id || null,
          stripe_subscription_id: sensitiveData?.stripe_subscription_id || null,
        });
      }
      setDetailsLoading(false);
    };
    
    fetchSubscriptionDetails();
  }, [user?.id]);

  const handleUpgrade = async (targetPlan: SubscriptionPlan) => {
    if (stripeLoading) return;
    
    // If user already has a subscription, open portal
    if (subscriptionDetails?.stripe_subscription_id) {
      await openCustomerPortal();
    } else {
      // Create new checkout session
      await createCheckoutSession(targetPlan);
    }
  };

  const handleManageSubscription = async () => {
    if (stripeLoading) return;
    await openCustomerPortal();
  };

  const isLoading = planLoading || detailsLoading;

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  const planName = PLAN_NAMES[currentPlan] || 'Básico';
  const planPrice = PLAN_PRICES[currentPlan] || 49;
  const planColor = PLAN_COLORS[currentPlan] || PLAN_COLORS.basic;
  const planIcon = PLAN_ICONS[currentPlan] || '🟢';
  const features = getPlanFeatures(currentPlan);

  const allPlans: { id: SubscriptionPlan; name: string; price: number; features: string[] }[] = [
    {
      id: 'basic',
      name: 'Básico',
      price: 49,
      features: ['Perfil básico', 'Até 5 alunos ativos', 'Agendamento simples', 'Suporte por email']
    },
    {
      id: 'professional',
      name: 'Profissional',
      price: 97,
      features: ['Tudo do Básico', 'Alunos ilimitados', 'Métricas avançadas', 'Relatórios detalhados', 'Suporte prioritário']
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 149,
      features: ['Tudo do Profissional', 'URL personalizada', 'Destaque na busca', 'Consultoria mensal', 'Suporte 24/7']
    }
  ];

  return (
    <MainLayout>
      <div className="min-h-screen bg-gradient-to-b from-primary/10 to-background">
        <div className="container mx-auto px-4 py-6 max-w-5xl">
          <BackButton fallbackPath="/instructor/dashboard" />
          
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Minha Assinatura</h1>
            <p className="text-muted-foreground mt-1">
              Gerencie seu plano e histórico de pagamentos
            </p>
          </div>

          {/* Current Plan Card */}
          <Card className="mb-6 overflow-hidden">
            <div className={`h-2 ${currentPlan === 'premium' ? 'bg-gradient-to-r from-amber-500 to-orange-500' : currentPlan === 'professional' ? 'bg-primary' : 'bg-muted-foreground'}`} />
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-2xl">
                    {planIcon}
                  </div>
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      Plano {planName}
                      <Badge variant="outline" className={planColor}>
                        <Crown className="h-3 w-3 mr-1" />
                        Ativo
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      R$ {planPrice},00/mês
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isPaymentActive ? (
                    <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Pagamento Ativo
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30">
                      <XCircle className="h-3 w-3 mr-1" />
                      {paymentStatus === 'pending' ? 'Pendente' : 'Expirado'}
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-3">Detalhes da Assinatura</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-2 border-b border-border/50">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Membro desde
                      </span>
                      <span className="text-sm font-medium">
                        {subscriptionDetails?.created_at 
                          ? format(new Date(subscriptionDetails.created_at), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                          : '-'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-border/50">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Última atualização
                      </span>
                      <span className="text-sm font-medium">
                        {subscriptionDetails?.updated_at 
                          ? format(new Date(subscriptionDetails.updated_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })
                          : '-'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Receipt className="h-4 w-4" />
                        ID do Cliente
                      </span>
                      <span className="text-sm font-mono text-muted-foreground">
                        {subscriptionDetails?.stripe_customer_id 
                          ? `${subscriptionDetails.stripe_customer_id.slice(0, 14)}...`
                          : '-'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-3">Ações Rápidas</h4>
                  <div className="space-y-3">
                    {subscriptionDetails?.stripe_subscription_id && (
                      <Button 
                        variant="outline" 
                        className="w-full justify-between"
                        onClick={handleManageSubscription}
                        disabled={stripeLoading}
                      >
                        <span className="flex items-center gap-2">
                          <CreditCard className="h-4 w-4" />
                          Gerenciar Pagamentos
                        </span>
                        {stripeLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <ArrowUpRight className="h-4 w-4" />
                        )}
                      </Button>
                    )}
                    {currentPlan !== 'premium' && (
                      <Button 
                        className="w-full justify-between"
                        onClick={() => navigate('/register/instructor')}
                      >
                        <span className="flex items-center gap-2">
                          <Sparkles className="h-4 w-4" />
                          Fazer Upgrade
                        </span>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    )}
                    {!isPaymentActive && (
                      <Button 
                        variant="destructive"
                        className="w-full justify-between"
                        onClick={() => navigate('/register/instructor')}
                      >
                        <span className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4" />
                          Regularizar Pagamento
                        </span>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Plan Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Comparar Planos</CardTitle>
              <CardDescription>
                Escolha o plano ideal para o seu negócio
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {allPlans.map((plan) => {
                  const isCurrentPlan = plan.id === currentPlan;
                  const canUpgrade = !isCurrentPlan && 
                    (plan.id === 'professional' && currentPlan === 'basic') ||
                    (plan.id === 'premium' && (currentPlan === 'basic' || currentPlan === 'professional'));
                  
                  return (
                    <div 
                      key={plan.id}
                      className={`rounded-xl border-2 p-5 transition-all ${
                        isCurrentPlan 
                          ? 'border-primary bg-primary/5' 
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-foreground">{plan.name}</h3>
                          <p className="text-2xl font-bold text-foreground">
                            R$ {plan.price}
                            <span className="text-sm font-normal text-muted-foreground">/mês</span>
                          </p>
                        </div>
                        {isCurrentPlan && (
                          <Badge className="bg-primary text-primary-foreground">
                            Seu Plano
                          </Badge>
                        )}
                      </div>
                      
                      <Separator className="my-4" />
                      
                      <ul className="space-y-2 mb-4">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center gap-2 text-sm">
                            <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
                            <span className="text-muted-foreground">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      
                      {canUpgrade && (
                        <Button 
                          className="w-full"
                          variant={plan.id === 'premium' ? 'default' : 'outline'}
                          onClick={() => handleUpgrade(plan.id)}
                          disabled={stripeLoading}
                        >
                          {stripeLoading ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : null}
                          Fazer Upgrade
                        </Button>
                      )}
                      {isCurrentPlan && (
                        <Button className="w-full" variant="secondary" disabled>
                          Plano Atual
                        </Button>
                      )}
                      {!isCurrentPlan && !canUpgrade && (
                        <Button className="w-full" variant="ghost" disabled>
                          -
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Info Section */}
          <div className="mt-6 p-4 rounded-xl bg-muted/50 border border-border">
            <div className="flex items-start gap-3">
              <CreditCard className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Sobre pagamentos</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Todos os pagamentos são processados de forma segura pelo Stripe. 
                  Você pode cancelar ou alterar seu plano a qualquer momento através do portal de gerenciamento.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default InstructorSubscription;
