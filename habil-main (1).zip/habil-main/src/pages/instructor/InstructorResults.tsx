import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useExams } from '@/hooks/useExams';
import { FeatureGate } from '@/components/instructor/FeatureGate';
import { BookOpen, Car, CheckCircle, XCircle, Clock, AlertCircle, Loader2, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const InstructorResults = () => {
  const { exams, isLoading, instructorConfirmExam } = useExams();

  const handleConfirmExam = async (examId: string) => {
    await instructorConfirmExam(examId);
  };

  const getStatusBadge = (exam: typeof exams[0]) => {
    if (!exam.confirmed_by_student || !exam.confirmed_by_instructor) {
      return (
        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
          <Clock className="h-3 w-3 mr-1" />
          Aguardando confirmação
        </Badge>
      );
    }
    
    if (exam.status === 'approved') {
      return (
        <Badge className="bg-success text-success-foreground">
          <CheckCircle className="h-3 w-3 mr-1" />
          Aprovado
        </Badge>
      );
    }
    
    if (exam.status === 'failed') {
      return (
        <Badge variant="destructive">
          <XCircle className="h-3 w-3 mr-1" />
          Reprovado
        </Badge>
      );
    }

    return (
      <Badge variant="secondary">
        <Clock className="h-3 w-3 mr-1" />
        Pendente
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold text-foreground">Resultados de Exames</h1>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
              <Sparkles className="h-3 w-3 mr-1" />
              Profissional
            </Badge>
          </div>
          <p className="text-muted-foreground">
            Confirme os resultados dos exames dos seus alunos
          </p>
        </div>

        <FeatureGate feature="exam_management" fallback="card">
          {/* Info Card */}
          <div className="card-elevated p-4 mb-8 bg-primary/5 border-primary/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <p className="font-medium text-foreground">Confirmação dupla obrigatória</p>
                <p className="text-sm text-muted-foreground">
                  Os resultados só são validados após confirmação do aluno e do instrutor.
                  Isso garante a integridade dos dados e atualiza sua taxa de aprovação.
                </p>
              </div>
            </div>
          </div>

        {/* Exams List */}
        <div className="space-y-4">
          {exams.map((exam) => {
            return (
              <div key={exam.id} className="card-elevated p-6">
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  <div className={cn(
                    "h-14 w-14 rounded-xl flex items-center justify-center flex-shrink-0",
                    exam.exam_type === 'theoretical' ? "gradient-primary" : "gradient-accent"
                  )}>
                    {exam.exam_type === 'theoretical' ? (
                      <BookOpen className="h-7 w-7 text-primary-foreground" />
                    ) : (
                      <Car className="h-7 w-7 text-accent-foreground" />
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-lg font-semibold text-foreground">
                        Exame {exam.exam_type === 'theoretical' ? 'Teórico' : 'Prático'}
                      </h3>
                      <Badge variant="outline">Categoria {exam.category}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Aluno: <span className="font-medium text-foreground">{exam.student?.full_name || 'Aluno'}</span>
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Data: {format(new Date(exam.exam_date), "dd/MM/yyyy", { locale: ptBR })}
                    </p>
                  </div>

                  <div className="flex flex-col lg:items-end gap-3">
                    {getStatusBadge(exam)}
                    
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <span className={cn(
                          "h-2 w-2 rounded-full",
                          exam.confirmed_by_student ? "bg-success" : "bg-muted"
                        )} />
                        <span className="text-muted-foreground">Aluno</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className={cn(
                          "h-2 w-2 rounded-full",
                          exam.confirmed_by_instructor ? "bg-success" : "bg-muted"
                        )} />
                        <span className="text-muted-foreground">Instrutor</span>
                      </div>
                    </div>
                  </div>

                  {!exam.confirmed_by_instructor && exam.confirmed_by_student && (
                    <Button 
                      variant="hero" 
                      onClick={() => handleConfirmExam(exam.id)}
                    >
                      Confirmar resultado
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {exams.length === 0 && (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <BookOpen className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhum exame registrado</h3>
            <p className="text-muted-foreground">
              Os exames dos seus alunos aparecerão aqui quando forem registrados
            </p>
          </div>
        )}
        </FeatureGate>
      </div>
    </MainLayout>
  );
};

export default InstructorResults;
