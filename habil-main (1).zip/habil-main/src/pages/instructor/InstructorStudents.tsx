import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useSchedules } from '@/hooks/useSchedules';
import { useExams } from '@/hooks/useExams';
import { Search, User, BookOpen, Car, Loader2 } from 'lucide-react';
import { useState } from 'react';

const InstructorStudents = () => {
  const { schedules, isLoading: schedulesLoading } = useSchedules();
  const { exams, isLoading: examsLoading } = useExams();
  const [search, setSearch] = useState('');

  const isLoading = schedulesLoading || examsLoading;

  // Get unique students from schedules
  const studentsMap = new Map<string, any>();
  schedules.forEach(schedule => {
    const studentData = (schedule as any).student;
    if (studentData && !studentsMap.has(schedule.student_id)) {
      studentsMap.set(schedule.student_id, {
        id: schedule.student_id,
        name: studentData?.full_name || 'Aluno',
        avatar: studentData?.avatar_url,
      });
    }
  });

  const students = Array.from(studentsMap.values()).filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  // Get exams for each student
  const getStudentExams = (studentId: string) => {
    return exams.filter(e => e.student_id === studentId);
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Meus Alunos</h1>
          <p className="text-muted-foreground">
            Gerencie seus alunos e acompanhe o progresso
          </p>
        </div>

        {/* Search */}
        <div className="card-elevated p-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Buscar aluno por nome..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </div>

        {/* Students List */}
        {students.length > 0 ? (
          <div className="space-y-4">
            {students.map((student) => {
              const studentExams = getStudentExams(student.id);
              const approvedExams = studentExams.filter(e => 
                e.status === 'approved' && e.confirmed_by_student && e.confirmed_by_instructor
              );

              return (
                <div key={student.id} className="card-elevated p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-lg flex-shrink-0">
                      {student.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-lg font-semibold text-foreground">{student.name}</h3>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-foreground">{approvedExams.length}</p>
                        <p className="text-xs text-muted-foreground">Exames aprovados</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-foreground">{studentExams.length}</p>
                        <p className="text-xs text-muted-foreground">Total de exames</p>
                      </div>
                    </div>

                    <Button variant="outline">Ver detalhes</Button>
                  </div>

                  {/* Student Exams */}
                  {studentExams.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-border">
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">Exames</h4>
                      <div className="flex flex-wrap gap-2">
                        {studentExams.map((exam) => (
                          <div
                            key={exam.id}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${
                              exam.status === 'approved' && exam.confirmed_by_student && exam.confirmed_by_instructor
                                ? 'bg-success/10 text-success'
                                : exam.status === 'failed'
                                ? 'bg-destructive/10 text-destructive'
                                : 'bg-muted text-muted-foreground'
                            }`}
                          >
                            {exam.exam_type === 'theoretical' ? (
                              <BookOpen className="h-4 w-4" />
                            ) : (
                              <Car className="h-4 w-4" />
                            )}
                            <span>
                              {exam.exam_type === 'theoretical' ? 'Teórico' : 'Prático'} - Cat. {exam.category}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <User className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              {search ? 'Nenhum aluno encontrado' : 'Você ainda não tem alunos'}
            </h3>
            <p className="text-muted-foreground">
              {search 
                ? 'Tente buscar por outro nome' 
                : 'Seus alunos aparecerão aqui quando agendarem aulas com você'}
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default InstructorStudents;
