import { useState, useEffect, useRef } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useExams } from '@/hooks/useExams';
import { useSchedules } from '@/hooks/useSchedules';
import { logger } from '@/lib/logger';
import { Save, Award, Star, Users, Loader2, Camera, Upload, FileText, Clock, CheckCircle2, XCircle, Eye, EyeOff, ShieldCheck, ShieldX, MessageCircle, ExternalLink } from 'lucide-react';
import { MFASettings } from '@/components/auth/MFASettings';
import { cn } from '@/lib/utils';

const InstructorProfile = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { getInstructorApprovalRate } = useExams();
  const { schedules } = useSchedules();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    bio: '',
    pricePerHour: 0,
    category: 'B' as 'A' | 'B' | 'AB',
    yearsOfExperience: 0,
    whatsappLink: '',
  });
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [stats, setStats] = useState({
    approvalRate: 0,
    rating: 4.5,
    totalStudents: 0,
  });
  const [certifications, setCertifications] = useState<string[]>([]);
  const [profileStatus, setProfileStatus] = useState({
    documentsApproved: false,
    subscriptionActive: false,
    registrationStatus: 'pending',
    subscriptionPlan: 'basic',
  });

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchStats();
    }
  }, [user, schedules]);

  const fetchProfile = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();
    
    if (data && !error) {
      setFormData({
        name: data.full_name || '',
        bio: data.bio || '',
        pricePerHour: data.price_per_hour || 0,
        category: (data.cnh_category as 'A' | 'B' | 'AB') || 'B',
        yearsOfExperience: data.years_of_experience || 0,
        whatsappLink: data.whatsapp || '',
      });
      setAvatarUrl(data.avatar_url);
      setCertifications(data.certifications || []);
      
      // Check documents and subscription status
      const documentsApproved = data.registration_status === 'approved';
      // For now, we consider subscription active if plan is not 'basic' (free)
      // In a real scenario, this would check payment status
      const subscriptionActive = data.subscription_plan && data.subscription_plan !== 'basic';
      
      setProfileStatus({
        documentsApproved,
        subscriptionActive,
        registrationStatus: data.registration_status || 'pending',
        subscriptionPlan: data.subscription_plan || 'basic',
      });
    }
  };

  const fetchStats = async () => {
    if (!user) return;
    
    // Get approval rate from exams
    const rateData = getInstructorApprovalRate(user.id);
    
    // Count unique students from schedules (confirmed or completed)
    const instructorSchedules = schedules.filter(s => s.instructor_id === user.id);
    const uniqueStudents = new Set(instructorSchedules.map(s => s.student_id));
    
    // Fetch average rating from instructor_reviews
    const { data: reviewsData } = await supabase
      .from('instructor_reviews')
      .select('rating')
      .eq('instructor_id', user.id);
    
    let averageRating = 0;
    if (reviewsData && reviewsData.length > 0) {
      const totalRating = reviewsData.reduce((sum, r) => sum + r.rating, 0);
      averageRating = totalRating / reviewsData.length;
    }
    
    setStats({
      approvalRate: rateData.rate,
      rating: averageRating,
      totalStudents: uniqueStudents.size,
    });
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    
    setIsUploading(true);
    
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/avatar.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });
      
      if (uploadError) throw uploadError;
      
      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);
      
      const newAvatarUrl = `${urlData.publicUrl}?t=${Date.now()}`;
      
      // Update profile with avatar URL
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: newAvatarUrl })
        .eq('id', user.id);
      
      if (updateError) throw updateError;
      
      setAvatarUrl(newAvatarUrl);
      toast({
        title: 'Foto atualizada!',
        description: 'Sua foto de perfil foi alterada.',
      });
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({
        title: 'Erro ao enviar foto',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Validate WhatsApp link format
  const isValidWhatsAppLink = (link: string): boolean => {
    if (!link) return true; // Empty is valid (optional)
    const waPattern = /^https:\/\/(wa\.me|api\.whatsapp\.com\/send\?phone=)\d+/;
    return waPattern.test(link);
  };

  const handleSave = async () => {
    if (!user) return;
    
    // Validate WhatsApp link if provided
    if (formData.whatsappLink && !isValidWhatsAppLink(formData.whatsappLink)) {
      toast({
        title: 'Link inválido',
        description: 'O link do WhatsApp deve ser no formato: https://wa.me/5511999999999 ou https://api.whatsapp.com/send?phone=5511999999999',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: formData.name,
          bio: formData.bio,
          price_per_hour: formData.pricePerHour,
          cnh_category: formData.category,
          years_of_experience: formData.yearsOfExperience,
          whatsapp: formData.whatsappLink || null,
        })
        .eq('id', user.id);
      
      if (error) throw error;
      
      toast({
        title: 'Perfil atualizado!',
        description: formData.whatsappLink 
          ? 'Link do WhatsApp atualizado com sucesso.' 
          : 'Suas informações foram salvas com sucesso.',
      });
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: 'Erro ao salvar',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectCategory = (cat: 'A' | 'B' | 'AB') => {
    setFormData(prev => ({ ...prev, category: cat }));
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Meu Perfil</h1>
          <p className="text-muted-foreground">
            Gerencie suas informações profissionais
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Avatar Section */}
            <div className="card-elevated p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">Foto de Perfil</h2>
              
              <div className="flex items-center gap-6">
                <div className="relative">
                  <div className="h-24 w-24 rounded-2xl overflow-hidden bg-muted flex items-center justify-center">
                    {avatarUrl ? (
                      <img 
                        src={avatarUrl} 
                        alt="Avatar" 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span className="text-3xl font-bold text-muted-foreground">
                        {formData.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-primary-foreground hover:opacity-90 transition-opacity"
                  >
                    {isUploading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    className="hidden"
                  />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">
                    Clique no ícone da câmera para alterar sua foto.
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Formatos aceitos: JPG, PNG, WEBP
                  </p>
                </div>
              </div>
            </div>

            <div className="card-elevated p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">Informações Básicas</h2>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome completo</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Biografia</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    rows={4}
                    placeholder="Descreva sua experiência e metodologia..."
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Valor por hora (R$)</Label>
                    <Input
                      id="price"
                      type="number"
                      value={formData.pricePerHour}
                      onChange={(e) => setFormData({ ...formData, pricePerHour: Number(e.target.value) })}
                      className="h-12"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="experience" className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Tempo de atuação (anos)
                    </Label>
                    <Input
                      id="experience"
                      type="number"
                      value={formData.yearsOfExperience}
                      onChange={(e) => setFormData({ ...formData, yearsOfExperience: Number(e.target.value) })}
                      className="h-12"
                    />
                  </div>
                </div>

                {/* WhatsApp Link Section */}
                <div className="space-y-2 pt-4 border-t border-border">
                  <Label htmlFor="whatsapp" className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-green-500" />
                    Link do WhatsApp para contato com alunos
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="whatsapp"
                      value={formData.whatsappLink}
                      onChange={(e) => setFormData({ ...formData, whatsappLink: e.target.value })}
                      placeholder="https://wa.me/5511999999999"
                      className="h-12 flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="h-12 w-12 flex-shrink-0"
                      disabled={!formData.whatsappLink || !isValidWhatsAppLink(formData.whatsappLink)}
                      onClick={() => window.open(formData.whatsappLink, '_blank')}
                      title="Testar link"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Formatos aceitos: https://wa.me/5511999999999 ou https://api.whatsapp.com/send?phone=5511999999999
                  </p>
                  {formData.whatsappLink && !isValidWhatsAppLink(formData.whatsappLink) && (
                    <p className="text-xs text-destructive">
                      Link inválido. Use o formato correto.
                    </p>
                  )}
                </div>

                <div className="space-y-3">
                  <Label>Categoria que leciona</Label>
                  <div className="flex gap-3">
                    {(['A', 'B', 'AB'] as const).map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => selectCategory(cat)}
                        className={cn(
                          "px-6 py-3 rounded-xl font-medium transition-all",
                          formData.category === cat
                            ? "gradient-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        )}
                      >
                        Categoria {cat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {certifications.length > 0 && (
              <div className="card-elevated p-6">
                <h2 className="text-xl font-semibold text-foreground mb-6">Certificações</h2>
                
                <div className="space-y-3">
                  {certifications.map((cert, i) => (
                    <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
                      <Award className="h-5 w-5 text-accent" />
                      <span className="text-foreground">{cert}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button 
              variant="hero" 
              size="lg" 
              onClick={handleSave}
              disabled={isLoading}
              className="w-full lg:w-auto"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-5 w-5" />
                  Salvar alterações
                </>
              )}
            </Button>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Stats Card */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Estatísticas</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-success/10">
                  <div className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-success" />
                    <span className="text-foreground">Taxa de aprovação</span>
                  </div>
                  <span className="text-xl font-bold text-success">{stats.approvalRate}%</span>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl bg-accent/10">
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-accent" />
                    <span className="text-foreground">Avaliação</span>
                  </div>
                  <span className="text-xl font-bold text-accent">{stats.rating.toFixed(1)}</span>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl bg-primary/10">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    <span className="text-foreground">Total de alunos</span>
                  </div>
                  <span className="text-xl font-bold text-primary">{stats.totalStudents}</span>
                </div>
              </div>
            </div>

            {/* Status Card */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Status</h3>
              
              <div className="space-y-3">
                {/* Credenciamento: Ativo somente se documentos aprovados E pagamento em dia */}
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Credenciamento</span>
                  {profileStatus.documentsApproved && profileStatus.subscriptionActive ? (
                    <Badge className="bg-success text-success-foreground flex items-center gap-1">
                      <ShieldCheck className="h-3 w-3" />
                      Ativo
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-muted text-muted-foreground flex items-center gap-1">
                      <ShieldX className="h-3 w-3" />
                      Inativo
                    </Badge>
                  )}
                </div>
                
                {/* Perfil público: Visível somente se pagamento em dia */}
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Perfil público</span>
                  {profileStatus.subscriptionActive ? (
                    <Badge className="bg-primary text-primary-foreground flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      Visível
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-muted text-muted-foreground flex items-center gap-1">
                      <EyeOff className="h-3 w-3" />
                      Não visível
                    </Badge>
                  )}
                </div>
                
                {/* Verificação: Verificado somente se documentos aprovados */}
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Verificação</span>
                  {profileStatus.documentsApproved ? (
                    <Badge className="bg-success text-success-foreground flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      Verificado
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-amber-500/20 text-amber-600 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Pendente
                    </Badge>
                  )}
                </div>
              </div>
              
              {/* Help text */}
              {(!profileStatus.documentsApproved || !profileStatus.subscriptionActive) && (
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    {!profileStatus.documentsApproved && !profileStatus.subscriptionActive && (
                      "Envie seus documentos e ative um plano pago para ter o perfil visível e credenciamento ativo."
                    )}
                    {!profileStatus.documentsApproved && profileStatus.subscriptionActive && (
                      "Envie seus documentos para concluir a verificação e ativar o credenciamento."
                    )}
                    {profileStatus.documentsApproved && !profileStatus.subscriptionActive && (
                      "Ative um plano pago para tornar seu perfil visível e ativar o credenciamento."
                    )}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* 2FA Settings */}
          <MFASettings />
        </div>
      </div>
    </MainLayout>
  );
};

export default InstructorProfile;