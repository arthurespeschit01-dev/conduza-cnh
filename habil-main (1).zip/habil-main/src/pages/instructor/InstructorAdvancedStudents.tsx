import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/ui/back-button';
import { FeatureGate, useFeatureAccess } from '@/components/instructor/FeatureGate';
import { Input } from '@/components/ui/input';
import { 
  Users, 
  Search,
  Filter,
  Crown,
  GraduationCap,
  Clock,
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Download,
  History,
  Lock
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const InstructorAdvancedStudents = () => {
  const { 
    UpgradeDialog: ExportDialog, 
    openUpgradeDialog: openExportDialog,
    isAvailable: canExport 
  } = useFeatureAccess('data_export');

  const mockStudents = [
    { 
      id: '1', 
      name: 'Lucas Oliveira', 
      category: 'B', 
      totalLessons: 18, 
      completedLessons: 12,
      status: 'active',
      startDate: '10/11/2025',
      examStatus: 'pending'
    },
    { 
      id: '2', 
      name: 'Ana Paula Santos', 
      category: 'AB', 
      totalLessons: 25, 
      completedLessons: 25,
      status: 'completed',
      startDate: '01/09/2025',
      examStatus: 'approved'
    },
    { 
      id: '3', 
      name: 'Ricardo Mendes', 
      category: 'A', 
      totalLessons: 15, 
      completedLessons: 8,
      status: 'active',
      startDate: '15/12/2025',
      examStatus: null
    },
  ];

  const handleExport = () => {
    if (!canExport) {
      openExportDialog();
      return;
    }
    // TODO: Implementar exportação real
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <BackButton fallbackPath="/instructor/dashboard" className="mb-6" />
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-foreground">Gestão de Alunos</h1>
              <Badge variant="outline" className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30">
                <Crown className="h-3 w-3 mr-1" />
                Premium
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Gestão avançada com histórico completo de cada aluno
            </p>
          </div>

          <Button 
            variant="outline" 
            className="gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            Exportar Lista
            {!canExport && <Lock className="h-3 w-3 ml-1" />}
          </Button>
        </div>

        <FeatureGate feature="advanced_student_mgmt" fallback="card">
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Buscar aluno por nome..." 
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="card-elevated p-4">
              <div className="flex items-center gap-2 mb-1">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm text-muted-foreground">Total</span>
              </div>
              <p className="text-2xl font-bold">32</p>
            </div>
            <div className="card-elevated p-4">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-4 w-4 text-primary" />
                <span className="text-sm text-muted-foreground">Ativos</span>
              </div>
              <p className="text-2xl font-bold">18</p>
            </div>
            <div className="card-elevated p-4">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle className="h-4 w-4 text-success" />
                <span className="text-sm text-muted-foreground">Aprovados</span>
              </div>
              <p className="text-2xl font-bold">12</p>
            </div>
            <div className="card-elevated p-4">
              <div className="flex items-center gap-2 mb-1">
                <GraduationCap className="h-4 w-4 text-warning" />
                <span className="text-sm text-muted-foreground">Em prova</span>
              </div>
              <p className="text-2xl font-bold">2</p>
            </div>
          </div>

          {/* Students List */}
          <div className="card-elevated overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Aluno</th>
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Categoria</th>
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Progresso</th>
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Status</th>
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Início</th>
                    <th className="text-left py-4 px-4 text-sm font-medium text-muted-foreground">Exame</th>
                    <th className="text-right py-4 px-4 text-sm font-medium text-muted-foreground">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {mockStudents.map((student) => (
                    <tr key={student.id} className="border-b border-border/50 hover:bg-muted/20">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-sm font-medium text-primary">
                              {student.name.charAt(0)}
                            </span>
                          </div>
                          <span className="font-medium text-foreground">{student.name}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Badge variant="outline">Cat. {student.category}</Badge>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary rounded-full"
                              style={{ width: `${(student.completedLessons / student.totalLessons) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {student.completedLessons}/{student.totalLessons}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Badge 
                          variant="outline"
                          className={
                            student.status === 'active' 
                              ? 'bg-primary/10 text-primary border-primary/30'
                              : 'bg-success/10 text-success border-success/30'
                          }
                        >
                          {student.status === 'active' ? 'Ativo' : 'Concluído'}
                        </Badge>
                      </td>
                      <td className="py-4 px-4 text-sm text-muted-foreground">
                        {student.startDate}
                      </td>
                      <td className="py-4 px-4">
                        {student.examStatus === 'approved' && (
                          <Badge className="bg-success text-success-foreground">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Aprovado
                          </Badge>
                        )}
                        {student.examStatus === 'failed' && (
                          <Badge variant="destructive">
                            <XCircle className="h-3 w-3 mr-1" />
                            Reprovado
                          </Badge>
                        )}
                        {student.examStatus === 'pending' && (
                          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30">
                            <Clock className="h-3 w-3 mr-1" />
                            Pendente
                          </Badge>
                        )}
                        {!student.examStatus && (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <History className="h-4 w-4 mr-2" />
                              Ver histórico
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <GraduationCap className="h-4 w-4 mr-2" />
                              Registrar prova
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={handleExport}>
                              <Download className="h-4 w-4 mr-2" />
                              Exportar ficha
                              {!canExport && <Lock className="h-3 w-3 ml-auto" />}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </FeatureGate>

        <ExportDialog />
      </div>
    </MainLayout>
  );
};

export default InstructorAdvancedStudents;
