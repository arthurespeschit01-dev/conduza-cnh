import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useSchedules } from '@/hooks/useSchedules';
import { useExams } from '@/hooks/useExams';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  Calendar, 
  Loader2, 
  Clock,
  Bell,
  Settings,
  Car,
  Plus,
  FileText,
  DollarSign,
  CalendarDays,
  TrendingUp,
  Crown,
  ArrowUp,
  AlertTriangle,
  BarChart3,
  Sparkles,
  CreditCard,
  Users,
  Link,
  Lock,
  ChevronRight,
  XCircle,
  RefreshCw
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { VehiclesDialog } from '@/components/instructor/VehiclesDialog';
import { PackagesDialog } from '@/components/instructor/PackagesDialog';
import { DocumentsDialog } from '@/components/instructor/DocumentsDialog';
import { EarningsDialog } from '@/components/instructor/EarningsDialog';
import { RescheduleDialog } from '@/components/scheduling/RescheduleDialog';
import { useInstructorPlan } from '@/hooks/useInstructorPlan';
import { FeatureGate, useFeatureAccess } from '@/components/instructor/FeatureGate';
import { useStripeSubscription } from '@/hooks/useStripeSubscription';
import { toast } from 'sonner';
import { useToast } from '@/hooks/use-toast';

const PLAN_LABELS: Record<string, { name: string; color: string; icon: string }> = {
  basic: { name: 'Básico', color: 'bg-muted text-muted-foreground border-muted-foreground/30', icon: '🟢' },
  professional: { name: 'Profissional', color: 'bg-primary/10 text-primary border-primary/30', icon: '⭐' },
  premium: { name: 'Premium', color: 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30', icon: '👑' }
};

const PAYMENT_STATUS_LABELS: Record<string, { label: string; color: string }> = {
  active: { label: 'Ativo', color: 'bg-success/10 text-success border-success/30' },
  pending: { label: 'Pendente', color: 'bg-warning/10 text-warning border-warning/30' },
  expired: { label: 'Expirado', color: 'bg-destructive/10 text-destructive border-destructive/30' }
};

const InstructorDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { schedules, isLoading: schedulesLoading, rescheduleLesson } = useSchedules();
  const { exams, isLoading: examsLoading, getInstructorApprovalRate } = useExams();
  const { toast: toastHook } = useToast();
  const { 
    currentPlan: planType, 
    paymentStatus, 
    isPaymentActive, 
    effectivePlan,
    hasFeature,
    isLoading: planLoading,
    refetch: refetchPlan
  } = useInstructorPlan();
  const { openCustomerPortal, checkSubscription, isLoading: stripeLoading } = useStripeSubscription();
  
  const [registrationStatus, setRegistrationStatus] = useState<string | null>(null);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  
  // Dialog states
  const [vehiclesOpen, setVehiclesOpen] = useState(false);
  const [packagesOpen, setPackagesOpen] = useState(false);
  const [documentsOpen, setDocumentsOpen] = useState(false);
  const [earningsOpen, setEarningsOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);
  const [lessonToReschedule, setLessonToReschedule] = useState<{
    id: string;
    instructor_id: string;
    lesson_type: string;
    scheduled_date: string;
    scheduled_time: string;
  } | null>(null);

  // Handle checkout success
  useEffect(() => {
    const checkoutStatus = searchParams.get('checkout');
    if (checkoutStatus === 'success') {
      toast.success('Assinatura realizada com sucesso! 🎉');
      // Check subscription to update local state
      checkSubscription().then(() => {
        refetchPlan();
      });
      // Remove query params from URL
      navigate('/instructor/dashboard', { replace: true });
    }
  }, [searchParams, checkSubscription, refetchPlan, navigate]);

  const isLoading = schedulesLoading || examsLoading || profileLoading || planLoading;

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user?.id) return;
      
      const { data } = await supabase
        .from('profiles')
        .select('registration_status, avatar_url')
        .eq('id', user.id)
        .single();
      
      if (data) {
        setRegistrationStatus(data.registration_status);
        setAvatarUrl(data.avatar_url);
      }
      setProfileLoading(false);
    };
    
    fetchProfile();
  }, [user?.id]);

  // Calculate stats
  const approvalStats = user ? getInstructorApprovalRate(user.id) : { rate: 0, approved: 0, total: 0 };
  
  // Get unique students from schedules
  const upcomingClasses = schedules.filter(s => {
    const scheduleDate = new Date(`${s.scheduled_date}T${s.scheduled_time}`);
    return scheduleDate > new Date() && s.status !== 'cancelled';
  });

  // Calculate earnings (simplified)
  const completedClasses = schedules.filter(s => s.status === 'completed');
  const totalEarnings = completedClasses.reduce((sum, s) => sum + Number(s.price), 0);
  const pendingEarnings = schedules
    .filter(s => s.status === 'confirmed')
    .reduce((sum, s) => sum + Number(s.price), 0);

  const isPending = registrationStatus === 'pending';
  const currentPlan = PLAN_LABELS[planType] || PLAN_LABELS.basic;
  const canUpgrade = planType !== 'premium';
  const paymentInfo = PAYMENT_STATUS_LABELS[paymentStatus] || PAYMENT_STATUS_LABELS.pending;

  // Handle reschedule
  const handleRescheduleClick = (schedule: typeof schedules[0]) => {
    setLessonToReschedule({
      id: schedule.id,
      instructor_id: schedule.instructor_id,
      lesson_type: schedule.lesson_type,
      scheduled_date: schedule.scheduled_date,
      scheduled_time: schedule.scheduled_time,
    });
    setRescheduleOpen(true);
  };

  const handleReschedule = async (lessonId: string, newDate: string, newTime: string, instructorId: string) => {
    const result = await rescheduleLesson(lessonId, newDate, newTime, instructorId);
    if (result.success) {
      toastHook({
        title: 'Aula reagendada!',
        description: `A aula foi reagendada com sucesso.`,
      });
    } else {
      toastHook({
        title: 'Erro ao reagendar',
        description: result.error || 'Não foi possível reagendar a aula.',
        variant: 'destructive',
      });
    }
    return result;
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen bg-gradient-to-b from-primary/20 to-background">
        {/* Hero Header */}
        <div className="bg-primary/10 border-b border-border">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-4">
                {/* Profile Avatar */}
                <Avatar className="h-16 w-16 border-2 border-primary/30">
                  <AvatarImage src={avatarUrl || undefined} alt={user?.name} />
                  <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                    {user?.name?.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <div>
                  <div className="flex items-center gap-3 flex-wrap">
                    <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                      Olá, {user?.name?.split(' ')[0]}!
                    </h1>
                    {isPending && (
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30">
                        Pendente
                      </Badge>
                    )}
                  </div>
                  <p className="text-muted-foreground mt-1">
                    Gerencie sua agenda e acompanhe seus ganhos
                  </p>
                  
                  {/* Plan Badge */}
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <Badge variant="outline" className={currentPlan.color}>
                      <Crown className="h-3 w-3 mr-1" />
                      Plano {currentPlan.name}
                    </Badge>
                    <Badge variant="outline" className={paymentInfo.color}>
                      {paymentInfo.label}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-6 text-xs gap-1 text-muted-foreground hover:text-foreground"
                      onClick={() => navigate('/instructor/subscription')}
                    >
                      <CreditCard className="h-3 w-3" />
                      Gerenciar Assinatura
                    </Button>
                    {canUpgrade && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 text-xs gap-1 text-primary hover:text-primary"
                        onClick={() => navigate('/register/instructor')}
                      >
                        <ArrowUp className="h-3 w-3" />
                        Fazer Upgrade
                      </Button>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button variant="outline" className="gap-2" onClick={() => navigate('/instructor/schedule')}>
                  <CalendarDays className="h-4 w-4" />
                  Minha Agenda
                </Button>
                <Button variant="outline" className="gap-2" onClick={() => navigate('/instructor/profile')}>
                  <Settings className="h-4 w-4" />
                  Configurações
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-6 space-y-6">
          {/* Payment Warning Banner */}
          {!isPaymentActive && (
            <div className="rounded-xl bg-destructive/10 border border-destructive/20 p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-destructive/20 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                </div>
                <div>
                  <p className="font-medium text-foreground">
                    {paymentStatus === 'pending' ? 'Pagamento Pendente' : 'Pagamento Expirado'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {paymentStatus === 'pending' 
                      ? 'Complete seu pagamento para ativar todos os recursos do seu plano.'
                      : 'Seu pagamento expirou. Regularize para recuperar os recursos do seu plano.'}
                  </p>
                </div>
              </div>
              <Button variant="default" size="sm" onClick={() => navigate('/register/instructor')}>
                Regularizar Pagamento
              </Button>
            </div>
          )}

          {/* Pending Registration Banner */}
          {isPending && (
            <div className="rounded-xl bg-warning/10 border border-warning/20 p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-warning/20 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Cadastro em Análise</p>
                  <p className="text-sm text-muted-foreground">
                    Seus documentos estão sendo verificados pela equipe.
                  </p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => setDocumentsOpen(true)}>
                Ver Documentos
              </Button>
            </div>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Ganhos do Mês</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {totalEarnings.toFixed(2)}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-success" />
                </div>
              </div>
            </div>
            
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">A Receber</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {pendingEarnings.toFixed(2)}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
              </div>
            </div>
            
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Aulas este Mês</p>
                  <p className="text-2xl font-bold text-foreground">
                    {schedules.length}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <CalendarDays className="h-5 w-5 text-accent" />
                </div>
              </div>
            </div>
            
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avaliação Média</p>
                  <p className="text-2xl font-bold text-foreground">
                    {approvalStats.total > 0 ? `${(approvalStats.rate / 20).toFixed(1)}` : '0.0'}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-warning" />
                </div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Upcoming Classes */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-2 mb-6">
                <CalendarDays className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">Próximas Aulas</h2>
              </div>

              <div className="space-y-4">
                {upcomingClasses.slice(0, 3).map((schedule) => {
                  const scheduleDate = new Date(`${schedule.scheduled_date}T${schedule.scheduled_time}`);
                  const typeLabel = schedule.lesson_type === 'theoretical' 
                    ? 'Teórica' 
                    : schedule.lesson_type === 'practical_car' 
                      ? 'Prática Carro' 
                      : 'Prática Moto';

                  return (
                    <div key={schedule.id} className="flex items-center gap-4 p-4 rounded-xl bg-muted/50">
                      <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                        {format(scheduleDate, "dd")}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{typeLabel}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(scheduleDate, "dd/MM", { locale: ptBR })} às {format(scheduleDate, "HH:mm")}
                        </p>
                      </div>
                      <span className="text-sm text-muted-foreground">50 min</span>
                    </div>
                  );
                })}

                {upcomingClasses.length === 0 && (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">Nenhuma aula agendada</p>
                  </div>
                )}
              </div>
            </div>

            {/* Cancelled Classes */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-2 mb-6">
                <XCircle className="h-5 w-5 text-destructive" />
                <h2 className="text-lg font-semibold text-foreground">Aulas Canceladas</h2>
                <Badge variant="outline" className="ml-auto bg-destructive/10 text-destructive border-destructive/30">
                  {schedules.filter(s => s.status === 'cancelled').length}
                </Badge>
              </div>

              <div className="space-y-4 max-h-[280px] overflow-y-auto">
                {schedules
                  .filter(s => s.status === 'cancelled')
                  .slice(0, 5)
                  .map((schedule) => {
                    const scheduleDate = new Date(`${schedule.scheduled_date}T${schedule.scheduled_time}`);
                    const studentName = 'student' in schedule && schedule.student 
                      ? schedule.student.full_name 
                      : 'Aluno';
                    const typeLabel = schedule.lesson_type === 'theoretical' 
                      ? 'Teórica' 
                      : schedule.lesson_type === 'practical_car' 
                        ? 'Prática Carro' 
                        : 'Prática Moto';

                    return (
                      <div key={schedule.id} className="flex items-center gap-4 p-4 rounded-xl bg-destructive/5 border border-destructive/10">
                        <div className="h-12 w-12 rounded-xl bg-destructive/10 flex items-center justify-center text-destructive font-bold">
                          {format(scheduleDate, "dd")}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">{studentName}</p>
                          <p className="text-sm text-muted-foreground">
                            {typeLabel} • {format(scheduleDate, "dd/MM", { locale: ptBR })} às {format(scheduleDate, "HH:mm")}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-1"
                            onClick={() => handleRescheduleClick(schedule)}
                          >
                            <RefreshCw className="h-3 w-3" />
                            Reagendar
                          </Button>
                        </div>
                      </div>
                    );
                  })}

                {schedules.filter(s => s.status === 'cancelled').length === 0 && (
                  <div className="text-center py-8">
                    <XCircle className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">Nenhuma aula cancelada</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Advanced Metrics - Professional+ */}
            <FeatureGate feature="metrics_dashboard" fallback="card">
              <div className="card-elevated p-6">
                <div className="flex items-center gap-2 mb-6">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <h2 className="text-lg font-semibold text-foreground">Métricas Avançadas</h2>
                  <Badge variant="outline" className="ml-auto bg-primary/10 text-primary">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Profissional
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Taxa de Conversão</p>
                    <p className="text-xl font-bold text-foreground">78%</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Retenção de Alunos</p>
                    <p className="text-xl font-bold text-foreground">92%</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Visualizações</p>
                    <p className="text-xl font-bold text-foreground">1.2k</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Contatos</p>
                    <p className="text-xl font-bold text-foreground">45</p>
                  </div>
                </div>
              </div>
            </FeatureGate>

            {/* Quick Actions */}
            <div className="card-elevated p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Ações Rápidas</h2>
              
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => setVehiclesOpen(true)}
                >
                  <Car className="h-5 w-5" />
                  Meus Veículos
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => setPackagesOpen(true)}
                >
                  <Plus className="h-5 w-5" />
                  Gerenciar Pacotes
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => setDocumentsOpen(true)}
                >
                  <FileText className="h-5 w-5" />
                  Documentos
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => setEarningsOpen(true)}
                >
                  <DollarSign className="h-5 w-5" />
                  Meus Ganhos
                </Button>
              </div>
            </div>
          </div>

          {/* Premium Features Section */}
          <div className="mt-6">
            <div className="flex items-center gap-2 mb-4">
              <Crown className="h-5 w-5 text-amber-500" />
              <h2 className="text-lg font-semibold text-foreground">Recursos Premium</h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Advanced Reports */}
              <FeatureGate feature="advanced_reports" fallback="dialog">
                <button 
                  onClick={() => navigate('/instructor/reports')}
                  className="card-elevated p-4 text-left hover:border-primary/50 transition-all group w-full"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <BarChart3 className="h-5 w-5 text-primary" />
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <h3 className="font-medium text-foreground mb-1">Relatórios Avançados</h3>
                  <p className="text-sm text-muted-foreground">Análises detalhadas do seu desempenho</p>
                </button>
              </FeatureGate>

              {/* Advanced Student Management */}
              <FeatureGate feature="advanced_student_mgmt" fallback="dialog">
                <button 
                  onClick={() => navigate('/instructor/students/advanced')}
                  className="card-elevated p-4 text-left hover:border-primary/50 transition-all group w-full"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <h3 className="font-medium text-foreground mb-1">Gestão de Alunos</h3>
                  <p className="text-sm text-muted-foreground">Histórico completo e exportação</p>
                </button>
              </FeatureGate>

              {/* Custom Profile URL */}
              <FeatureGate feature="custom_profile_url" fallback="dialog">
                <button 
                  onClick={() => navigate('/instructor/custom-profile')}
                  className="card-elevated p-4 text-left hover:border-primary/50 transition-all group w-full"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Link className="h-5 w-5 text-primary" />
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <h3 className="font-medium text-foreground mb-1">Página Personalizada</h3>
                  <p className="text-sm text-muted-foreground">URL própria para seu perfil</p>
                </button>
              </FeatureGate>
            </div>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <VehiclesDialog open={vehiclesOpen} onOpenChange={setVehiclesOpen} />
      <PackagesDialog open={packagesOpen} onOpenChange={setPackagesOpen} />
      <DocumentsDialog open={documentsOpen} onOpenChange={setDocumentsOpen} />
      <EarningsDialog open={earningsOpen} onOpenChange={setEarningsOpen} />
      <RescheduleDialog 
        open={rescheduleOpen} 
        onOpenChange={setRescheduleOpen} 
        lesson={lessonToReschedule}
        onReschedule={handleReschedule}
      />
    </MainLayout>
  );
};

export default InstructorDashboard;
