import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/ui/back-button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FeatureGate } from '@/components/instructor/FeatureGate';
import { 
  Crown,
  Link as LinkIcon,
  Copy,
  Check,
  ExternalLink,
  Palette,
  Type,
  Image,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

const InstructorCustomProfile = () => {
  const [copied, setCopied] = useState(false);
  const customUrl = 'habil.com/carlos-silva';

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(`https://${customUrl}`);
    setCopied(true);
    toast.success('URL copiada!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <BackButton fallbackPath="/instructor/dashboard" className="mb-6" />
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-foreground">Página Personalizada</h1>
              <Badge variant="outline" className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600 border-amber-500/30">
                <Crown className="h-3 w-3 mr-1" />
                Premium
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Personalize sua página pública com URL própria
            </p>
          </div>
        </div>

        <FeatureGate feature="custom_profile_url" fallback="card">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Settings */}
            <div className="space-y-6">
              {/* Custom URL */}
              <div className="card-elevated p-6">
                <div className="flex items-center gap-2 mb-4">
                  <LinkIcon className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-foreground">Sua URL Personalizada</h3>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <div className="flex-1 flex items-center gap-2 p-3 rounded-lg bg-muted/50 border">
                    <span className="text-muted-foreground">https://</span>
                    <span className="font-medium text-foreground">{customUrl}</span>
                  </div>
                  <Button variant="outline" size="icon" onClick={handleCopyUrl}>
                    {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="icon">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-3">
                  <Label>Alterar URL</Label>
                  <div className="flex gap-2">
                    <div className="flex items-center px-3 bg-muted rounded-l-lg border border-r-0">
                      <span className="text-sm text-muted-foreground">habil.com/</span>
                    </div>
                    <Input 
                      className="rounded-l-none" 
                      placeholder="seu-nome"
                      defaultValue="carlos-silva"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Use apenas letras, números e hífens. Mínimo 3 caracteres.
                  </p>
                </div>
              </div>

              {/* Customization */}
              <div className="card-elevated p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Palette className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-foreground">Personalização</h3>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Título da página</Label>
                    <Input placeholder="Carlos Silva - Instrutor de Trânsito" />
                  </div>

                  <div className="space-y-2">
                    <Label>Descrição personalizada</Label>
                    <Textarea 
                      placeholder="Uma breve descrição sobre você e seus serviços..."
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Cor de destaque</Label>
                    <div className="flex gap-2">
                      {['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'].map((color) => (
                        <button
                          key={color}
                          className="h-8 w-8 rounded-full border-2 border-transparent hover:border-foreground/50 transition-all"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Cover Image */}
              <div className="card-elevated p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Image className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-foreground">Imagem de Capa</h3>
                </div>

                <div className="border-2 border-dashed border-muted-foreground/30 rounded-xl p-8 text-center">
                  <Image className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground mb-3">
                    Arraste uma imagem ou clique para enviar
                  </p>
                  <Button variant="outline" size="sm">
                    Escolher imagem
                  </Button>
                </div>
              </div>

              <Button className="w-full gap-2">
                <Sparkles className="h-4 w-4" />
                Salvar alterações
              </Button>
            </div>

            {/* Preview */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Type className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium text-muted-foreground">Prévia da página</span>
              </div>

              <div className="card-elevated overflow-hidden">
                {/* Cover */}
                <div className="h-32 bg-gradient-to-r from-primary to-primary/60" />
                
                {/* Profile */}
                <div className="p-6 -mt-12">
                  <div className="flex items-end gap-4 mb-4">
                    <div className="h-24 w-24 rounded-full bg-card border-4 border-card flex items-center justify-center">
                      <span className="text-3xl font-bold text-primary">CS</span>
                    </div>
                    <div className="pb-2">
                      <h3 className="text-xl font-bold text-foreground">Carlos Silva</h3>
                      <p className="text-sm text-muted-foreground">Instrutor de Trânsito</p>
                    </div>
                  </div>

                  <div className="flex gap-2 mb-4">
                    <Badge variant="outline" className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-600">
                      <Crown className="h-3 w-3 mr-1" />
                      Premium
                    </Badge>
                    <Badge variant="outline">Cat. B</Badge>
                    <Badge variant="outline">São Paulo, SP</Badge>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">
                    Instrutor com mais de 10 anos de experiência. 
                    Especialista em primeira habilitação e renovação de CNH.
                  </p>

                  <Button className="w-full">Entrar em contato</Button>
                </div>
              </div>
            </div>
          </div>
        </FeatureGate>
      </div>
    </MainLayout>
  );
};

export default InstructorCustomProfile;
