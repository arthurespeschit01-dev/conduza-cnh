import { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, Clock, Calendar, Eye, User, Share2,
  BookOpen, TrendingUp, Target, Users, Award, Lightbulb, CheckCircle
} from 'lucide-react';

interface ArticleContent {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: number;
  author: string;
  date: string;
  views: number;
  icon: React.ReactNode;
  content: string[];
}

const articlesData: ArticleContent[] = [
  {
    id: '1',
    title: 'Como aumentar sua taxa de aprovação em 30%',
    excerpt: 'Descubra técnicas comprovadas que os melhores instrutores usam para garantir que seus alunos passem no exame de primeira.',
    category: 'Técnicas de Ensino',
    readTime: 8,
    author: 'Equipe Conduza',
    date: '28 Dez 2025',
    views: 1240,
    icon: <TrendingUp className="h-6 w-6" />,
    content: [
      '## Introdução',
      'A taxa de aprovação é um dos indicadores mais importantes para um instrutor de trânsito. Ela não apenas reflete sua competência profissional, mas também impacta diretamente sua reputação e capacidade de atrair novos alunos.',
      'Neste artigo, vamos explorar técnicas comprovadas que podem aumentar significativamente sua taxa de aprovação.',
      '## 1. Avaliação Inicial Detalhada',
      'Antes de iniciar o treinamento, faça uma avaliação completa do aluno. Identifique pontos fortes e fracos, nível de ansiedade, experiência prévia (mesmo que informal) e expectativas.',
      'Use essa avaliação para criar um plano de ensino personalizado. Alunos que recebem instrução adaptada às suas necessidades específicas têm 40% mais chances de aprovação.',
      '## 2. Simulação de Exame',
      'Realize simulações completas do exame prático pelo menos 3 vezes antes da data real. Isso inclui:',
      '- Percorrer os trajetos comuns usados pelos examinadores',
      '- Cronometrar cada etapa',
      '- Usar o mesmo tom de voz e comandos que o examinador usaria',
      '- Dar feedback imediato sobre erros eliminatórios',
      '## 3. Foco em Pontos Críticos',
      'Estatisticamente, os pontos que mais reprovam são: baliza, conversão à esquerda, parada em aclive e observação de pedestres. Dedique 60% do tempo de prática a esses elementos.',
      '## 4. Preparação Psicológica',
      'A ansiedade é responsável por 35% das reprovações. Ensine técnicas de respiração, visualização positiva e mantenha um ambiente calmo durante as aulas.',
      '## 5. Comunicação Clara',
      'Use linguagem simples e consistente. Evite jargões técnicos e certifique-se de que o aluno entendeu cada instrução antes de prosseguir.',
      '## Conclusão',
      'Implementando essas técnicas de forma consistente, você pode esperar um aumento de 25-30% na sua taxa de aprovação em poucos meses. Lembre-se: cada aluno aprovado é um embaixador da sua competência.'
    ]
  },
  {
    id: '2',
    title: '5 erros que fazem alunos reprovarem na baliza',
    excerpt: 'A baliza é o terror de muitos alunos. Conheça os erros mais comuns e como orientar seus alunos a evitá-los.',
    category: 'Dicas Práticas',
    readTime: 5,
    author: 'Equipe Conduza',
    date: '25 Dez 2025',
    views: 890,
    icon: <Target className="h-6 w-6" />,
    content: [
      '## Por que a baliza reprova tanto?',
      'A baliza (estacionamento em vaga paralela) é uma das manobras que mais reprova candidatos no exame prático. Cerca de 40% das reprovações estão relacionadas a erros nessa etapa.',
      '## Erro 1: Posicionamento Inicial Incorreto',
      'Muitos alunos param muito longe ou muito perto do veículo da frente. O ideal é alinhar o retrovisor do seu carro com o retrovisor traseiro do veículo à frente, mantendo aproximadamente 50cm de distância lateral.',
      '**Como corrigir:** Pratique o posicionamento inicial até que o aluno consiga fazer sem pensar. Use referências visuais fixas.',
      '## Erro 2: Girar o Volante Parado',
      'Girar o volante com o carro parado (volante seco) é erro eliminatório em muitos estados. Além disso, danifica o sistema de direção.',
      '**Como corrigir:** Ensine o aluno a sempre ter o carro em movimento, mesmo que muito lento, ao girar o volante.',
      '## Erro 3: Não Usar os Espelhos',
      'Confiar apenas no vidro traseiro é um erro comum. Os espelhos laterais são essenciais para julgar distâncias.',
      '**Como corrigir:** Force o hábito de checar todos os espelhos antes e durante a manobra.',
      '## Erro 4: Velocidade Inadequada',
      'Entrar rápido demais na vaga causa perda de controle. Lento demais pode parecer insegurança.',
      '**Como corrigir:** Pratique com meia-embreagem para controle fino da velocidade.',
      '## Erro 5: Não Alinhar ao Final',
      'Terminar a manobra com o carro torto na vaga é erro comum e pode reprovar.',
      '**Como corrigir:** Ensine o aluno a sempre verificar o alinhamento final e corrigir se necessário.',
      '## Dica Bônus',
      'Grave vídeos das tentativas do aluno. Rever os erros visualmente acelera muito o aprendizado.'
    ]
  },
  {
    id: '3',
    title: 'Como lidar com alunos ansiosos',
    excerpt: 'A ansiedade é um dos maiores obstáculos para o aprendizado. Aprenda estratégias para ajudar seus alunos.',
    category: 'Psicologia',
    readTime: 6,
    author: 'Equipe Conduza',
    date: '22 Dez 2025',
    views: 756,
    icon: <Users className="h-6 w-6" />,
    content: [
      '## O Impacto da Ansiedade no Aprendizado',
      'A ansiedade ativa o sistema de "luta ou fuga" do cérebro, reduzindo a capacidade de processar novas informações e tomar decisões racionais. Para um aluno de direção, isso pode ser catastrófico.',
      '## Identificando Sinais de Ansiedade',
      'Fique atento a estes sinais:',
      '- Mãos suadas ou tremendo',
      '- Respiração acelerada ou superficial',
      '- Rigidez excessiva ao segurar o volante',
      '- Dificuldade em seguir instruções simples',
      '- Erros repetitivos em manobras já dominadas',
      '## Estratégia 1: Ambiente Seguro',
      'Comece as primeiras aulas em locais calmos, como estacionamentos vazios. Progrida gradualmente para ruas movimentadas.',
      '## Estratégia 2: Técnica de Respiração',
      'Ensine a respiração 4-7-8: inspire por 4 segundos, segure por 7, expire por 8. Pratique isso antes de cada aula.',
      '## Estratégia 3: Normalização do Erro',
      'Deixe claro que erros são parte do aprendizado. Compartilhe suas próprias experiências de quando estava aprendendo.',
      '## Estratégia 4: Fragmentação',
      'Divida manobras complexas em etapas menores. Celebre cada pequena conquista.',
      '## Estratégia 5: Visualização',
      'Peça ao aluno para visualizar mentalmente a manobra sendo executada com sucesso antes de tentar.',
      '## Quando Encaminhar',
      'Se a ansiedade for severa e persistente, sugira gentilmente que o aluno procure ajuda profissional. Isso não é fraqueza, é autocuidado.'
    ]
  },
  {
    id: '4',
    title: 'Guia completo: Documentação do instrutor autônomo',
    excerpt: 'Tudo que você precisa saber sobre documentação e requisitos legais para atuar como instrutor autônomo.',
    category: 'Legislação',
    readTime: 12,
    author: 'Equipe Conduza',
    date: '18 Dez 2025',
    views: 623,
    icon: <BookOpen className="h-6 w-6" />,
    content: [
      '## Requisitos Básicos',
      'Para atuar como instrutor de trânsito autônomo no Brasil, você precisa atender aos seguintes requisitos:',
      '- Idade mínima de 21 anos',
      '- Ensino médio completo',
      '- CNH há pelo menos 2 anos (categoria compatível)',
      '- Não ter cometido infração grave ou gravíssima nos últimos 12 meses',
      '- Curso de formação de instrutores (mínimo 180 horas)',
      '## Documentação Necessária',
      '**Para o credenciamento:**',
      '- RG e CPF',
      '- Comprovante de residência',
      '- Certidão negativa criminal',
      '- Certificado do curso de formação',
      '- CNH válida',
      '- Atestado de saúde física e mental',
      '## Registro no DETRAN',
      'Após reunir a documentação, você deve solicitar o credenciamento junto ao DETRAN do seu estado. O processo varia, mas geralmente inclui:',
      '1. Protocolo da documentação',
      '2. Pagamento de taxas',
      '3. Análise documental (15-30 dias)',
      '4. Emissão da credencial de instrutor',
      '## Renovação',
      'A credencial deve ser renovada periodicamente (geralmente a cada 5 anos). Fique atento aos prazos para evitar irregularidades.',
      '## Veículo',
      'Se você usar veículo próprio, ele deve estar:',
      '- Adaptado com duplo comando',
      '- Com seguro obrigatório em dia',
      '- Vistoriado e aprovado pelo DETRAN',
      '- Identificado conforme regulamentação local',
      '## Obrigações Fiscais',
      'Como autônomo, você deve:',
      '- Registrar-se como MEI ou profissional liberal',
      '- Emitir notas fiscais',
      '- Recolher impostos (ISS, INSS)',
      '- Manter contabilidade organizada',
      '## Dica Final',
      'Consulte sempre a legislação específica do seu estado, pois há variações regionais importantes.'
    ]
  },
  {
    id: '5',
    title: 'Precificação: Quanto cobrar por aula?',
    excerpt: 'Entenda como definir o valor da sua hora-aula considerando todos os fatores relevantes.',
    category: 'Negócios',
    readTime: 7,
    author: 'Equipe Conduza',
    date: '15 Dez 2025',
    views: 1102,
    icon: <Award className="h-6 w-6" />,
    content: [
      '## A Importância da Precificação Correta',
      'Cobrar muito pouco desvaloriza seu trabalho e pode gerar desconfiança. Cobrar demais afasta alunos. O equilíbrio é crucial.',
      '## Fatores a Considerar',
      '**Custos Fixos:**',
      '- Manutenção do veículo',
      '- Combustível',
      '- Seguro',
      '- Impostos',
      '- Depreciação do veículo',
      '**Custos Variáveis:**',
      '- Deslocamento até o aluno',
      '- Tempo de preparação',
      '- Material didático',
      '## Pesquisa de Mercado',
      'Pesquise quanto os concorrentes na sua região cobram. Em capitais, o valor médio varia de R$ 80 a R$ 150 por hora. Em cidades menores, de R$ 50 a R$ 100.',
      '## Calculando seu Preço',
      'Uma fórmula simples:',
      '**Preço = (Custos Mensais / Horas Trabalhadas) + Margem de Lucro**',
      'Exemplo: Se seus custos são R$ 3.000/mês e você trabalha 120 horas, seu custo por hora é R$ 25. Adicione uma margem de 200-300% para chegar ao preço final.',
      '## Diferenciação',
      'Você pode cobrar mais se oferecer:',
      '- Alta taxa de aprovação comprovada',
      '- Flexibilidade de horários',
      '- Veículo de qualidade superior',
      '- Material didático exclusivo',
      '- Acompanhamento pós-aula',
      '## Pacotes',
      'Ofereça pacotes com desconto para incentivar a contratação de múltiplas aulas:',
      '- 10 aulas: 10% de desconto',
      '- 20 aulas: 15% de desconto',
      '## Reajustes',
      'Reajuste seus preços anualmente, comunicando com antecedência aos alunos em andamento.',
      '## Conclusão',
      'Não tenha medo de cobrar o que você vale. Qualidade tem preço, e alunos sérios entendem isso.'
    ]
  },
  {
    id: '6',
    title: 'Técnicas de comunicação efetiva com alunos',
    excerpt: 'Aprenda a dar feedbacks construtivos e criar um ambiente de aprendizado positivo.',
    category: 'Técnicas de Ensino',
    readTime: 6,
    author: 'Equipe Conduza',
    date: '12 Dez 2025',
    views: 534,
    icon: <Lightbulb className="h-6 w-6" />,
    content: [
      '## Por que Comunicação Importa',
      'Um instrutor tecnicamente excelente pode falhar se não souber transmitir conhecimento. A comunicação é a ponte entre sua expertise e o aprendizado do aluno.',
      '## Princípio 1: Clareza',
      'Use linguagem simples e direta. Evite jargões técnicos. Em vez de "execute a conversão com raio reduzido", diga "vire fechado à esquerda".',
      '## Princípio 2: Consistência',
      'Use sempre os mesmos termos para as mesmas ações. Se você chama o pedal do meio de "freio" em uma aula, não o chame de "breque" na próxima.',
      '## Princípio 3: Timing',
      'Dê instruções com antecedência suficiente para o aluno processar. "Na próxima rua, vire à direita" é melhor que "vire aqui!"',
      '## Feedback Construtivo',
      'Use a técnica do sanduíche:',
      '1. Comece com algo positivo',
      '2. Aponte o que precisa melhorar',
      '3. Termine com encorajamento',
      'Exemplo: "Sua velocidade está ótima. Precisa prestar mais atenção aos retrovisores. Com prática, isso vai ficar natural."',
      '## Escuta Ativa',
      'Pergunte ao aluno como ele se sente, quais dúvidas tem. Muitas vezes, o aluno tem uma pergunta mas tem vergonha de fazer.',
      '## Linguagem Corporal',
      'Mantenha postura relaxada. Evite suspirar, revirar os olhos ou demonstrar impaciência. O aluno percebe tudo.',
      '## Adaptação',
      'Cada aluno é único. Alguns aprendem melhor com explicações detalhadas, outros preferem tentar e errar. Adapte seu estilo.',
      '## Conclusão',
      'Investir em suas habilidades de comunicação trará retornos enormes: alunos mais satisfeitos, mais indicações e menos estresse para você.'
    ]
  },
  {
    id: '7',
    title: 'Checklist: Preparação para o exame prático',
    excerpt: 'Um guia passo a passo para preparar seu aluno nos dias que antecedem o exame.',
    category: 'Dicas Práticas',
    readTime: 4,
    author: 'Equipe Conduza',
    date: '10 Dez 2025',
    views: 445,
    icon: <CheckCircle className="h-6 w-6" />,
    content: [
      '## Uma Semana Antes',
      '- [ ] Revisar todos os pontos do exame',
      '- [ ] Fazer simulação completa do percurso',
      '- [ ] Identificar e trabalhar pontos fracos',
      '- [ ] Verificar documentação necessária',
      '## Três Dias Antes',
      '- [ ] Aula focada apenas em pontos críticos',
      '- [ ] Praticar técnicas de relaxamento',
      '- [ ] Confirmar horário e local do exame',
      '- [ ] Revisar checklist de documentos',
      '## Um Dia Antes',
      '- [ ] Aula leve, apenas para manter a confiança',
      '- [ ] Evitar introduzir novos conceitos',
      '- [ ] Recomendar boa noite de sono',
      '- [ ] Lembrar sobre alimentação adequada',
      '## No Dia do Exame',
      '- [ ] Chegar com 30 minutos de antecedência',
      '- [ ] Verificar documentos: RG, CNH (se tiver), comprovante de aulas',
      '- [ ] Usar roupas e calçados confortáveis',
      '- [ ] Fazer exercícios de respiração',
      '## Documentos Obrigatórios',
      '- RG ou CNH',
      '- Comprovante de conclusão das aulas teóricas',
      '- Ladv (Licença de Aprendizagem)',
      '- Comprovante de aulas práticas',
      '## Dicas Extras',
      '- Evitar cafeína em excesso',
      '- Não estudar coisas novas',
      '- Manter pensamentos positivos',
      '- Lembrar que nervosismo é normal',
      '## Após o Exame',
      'Independente do resultado, faça um debriefing com o aluno. Se aprovado, celebre! Se reprovado, identifique os pontos a melhorar e reagende.'
    ]
  },
  {
    id: '8',
    title: 'Como construir sua reputação online',
    excerpt: 'Dicas para fortalecer sua presença digital e atrair mais alunos.',
    category: 'Marketing',
    readTime: 5,
    author: 'Equipe Conduza',
    date: '8 Dez 2025',
    views: 678,
    icon: <TrendingUp className="h-6 w-6" />,
    content: [
      '## A Era Digital',
      'Hoje, a maioria dos alunos pesquisa online antes de escolher um instrutor. Sua presença digital pode ser a diferença entre ter agenda cheia ou vazia.',
      '## Perfil na Conduza',
      'Seu perfil na plataforma Conduza é seu cartão de visitas:',
      '- Use foto profissional e amigável',
      '- Escreva uma bio clara e atraente',
      '- Destaque sua experiência e certificações',
      '- Mantenha informações atualizadas',
      '## Avaliações',
      'Avaliações são ouro. Para conseguir boas avaliações:',
      '- Sempre peça feedback ao final do processo',
      '- Responda a todas as avaliações, boas ou ruins',
      '- Use críticas construtivas para melhorar',
      '## Taxa de Aprovação',
      'Na Conduza, sua taxa de aprovação é calculada automaticamente. Quanto maior, mais destaque você terá. Foque em qualidade, não quantidade.',
      '## Redes Sociais',
      'Considere criar perfis profissionais em:',
      '- Instagram: dicas rápidas e bastidores',
      '- YouTube: tutoriais e explicações',
      '- TikTok: conteúdo viral sobre direção',
      '## Conteúdo de Valor',
      'Compartilhe conhecimento gratuitamente. Isso constrói autoridade e atrai alunos que valorizam qualidade.',
      '## Networking',
      'Conecte-se com outros profissionais:',
      '- Autoescolas (para indicações)',
      '- Despachantes',
      '- Outros instrutores (troca de experiências)',
      '## Consistência',
      'Reputação se constrói com tempo. Seja consistente na qualidade do seu trabalho e na sua presença online.',
      '## Conclusão',
      'Sua reputação online é um ativo valioso. Invista nela como investiria em seu veículo.'
    ]
  }
];

const ArticlePage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const article = articlesData.find(a => a.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!article) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Artigo não encontrado</h1>
          <Button onClick={() => navigate('/blog-instrutor')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar ao blog
          </Button>
        </div>
      </MainLayout>
    );
  }

  const relatedArticles = articlesData
    .filter(a => a.id !== article.id && a.category === article.category)
    .slice(0, 2);

  const renderContent = (content: string[]) => {
    return content.map((paragraph, index) => {
      if (paragraph.startsWith('## ')) {
        return (
          <h2 key={index} className="text-xl font-bold text-foreground mt-8 mb-4">
            {paragraph.replace('## ', '')}
          </h2>
        );
      }
      if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
        return (
          <p key={index} className="font-semibold text-foreground mb-2">
            {paragraph.replace(/\*\*/g, '')}
          </p>
        );
      }
      if (paragraph.startsWith('**')) {
        const parts = paragraph.split('**');
        return (
          <p key={index} className="text-muted-foreground mb-4">
            <strong className="text-foreground">{parts[1]}</strong>
            {parts[2]}
          </p>
        );
      }
      if (paragraph.startsWith('- ')) {
        return (
          <li key={index} className="text-muted-foreground ml-6 mb-2 list-disc">
            {paragraph.replace('- ', '').replace('[ ] ', '☐ ')}
          </li>
        );
      }
      if (paragraph.match(/^\d\./)) {
        return (
          <li key={index} className="text-muted-foreground ml-6 mb-2 list-decimal">
            {paragraph.replace(/^\d\.\s/, '')}
          </li>
        );
      }
      return (
        <p key={index} className="text-muted-foreground mb-4 leading-relaxed">
          {paragraph}
        </p>
      );
    });
  };

  return (
    <MainLayout>
      {/* Header */}
      <section className="relative overflow-hidden gradient-hero py-12 lg:py-16">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto">
            <Button 
              variant="ghost" 
              className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 mb-6"
              onClick={() => navigate('/blog-instrutor')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar ao blog
            </Button>
            
            <div className="flex items-center gap-2 mb-4">
              <Badge className="bg-primary-foreground/20 text-primary-foreground border-0">
                {article.category}
              </Badge>
            </div>
            
            <h1 className="text-3xl lg:text-4xl font-extrabold text-primary-foreground mb-6">
              {article.title}
            </h1>
            
            <div className="flex flex-wrap items-center gap-4 text-sm text-primary-foreground/70">
              <span className="flex items-center gap-1">
                <User className="h-4 w-4" />
                {article.author}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {article.date}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {article.readTime} min de leitura
              </span>
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {article.views} visualizações
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="card-elevated p-8 lg:p-12">
              <div className="prose prose-lg max-w-none">
                {renderContent(article.content)}
              </div>
              
              {/* Share */}
              <div className="mt-12 pt-8 border-t border-border">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    Gostou do artigo? Compartilhe com outros instrutores!
                  </p>
                  <Button variant="outline" size="sm">
                    <Share2 className="h-4 w-4 mr-2" />
                    Compartilhar
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-xl font-bold text-foreground mb-6">Artigos relacionados</h2>
              
              <div className="grid md:grid-cols-2 gap-4">
                {relatedArticles.map((related) => (
                  <Link 
                    key={related.id} 
                    to={`/blog-instrutor/${related.id}`}
                    className="card-elevated p-5 group hover:scale-[1.02] transition-all"
                  >
                    <Badge variant="secondary" className="text-xs mb-3">
                      {related.category}
                    </Badge>
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 mb-2">
                      {related.title}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {related.readTime} min
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-xl font-bold text-foreground mb-3">
              Pronto para crescer como instrutor?
            </h2>
            <p className="text-muted-foreground mb-6">
              Cadastre-se na Conduza e comece a receber alunos hoje mesmo.
            </p>
            <Button variant="hero" onClick={() => navigate('/register/instructor')}>
              Cadastrar como instrutor
            </Button>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default ArticlePage;