import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { useNotifications } from '@/hooks/useNotifications';
import { Bell, CheckCircle2, Trash2, CheckCheck, Loader2, Calendar, Users, Award, AlertCircle, Info } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

const Notifications = () => {
  const { 
    notifications, 
    unreadCount, 
    isLoading, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification 
  } = useNotifications();

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'lesson_completed':
        return <CheckCircle2 className="h-5 w-5 text-success" />;
      case 'new_schedule':
        return <Calendar className="h-5 w-5 text-primary" />;
      case 'schedule_confirmed':
        return <CheckCircle2 className="h-5 w-5 text-success" />;
      case 'approval':
        return <Award className="h-5 w-5 text-success" />;
      case 'rejection':
        return <AlertCircle className="h-5 w-5 text-destructive" />;
      case 'new_student':
        return <Users className="h-5 w-5 text-primary" />;
      default:
        return <Info className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'lesson_completed':
      case 'approval':
      case 'schedule_confirmed':
        return 'bg-success/10 border-success/20';
      case 'rejection':
        return 'bg-destructive/10 border-destructive/20';
      case 'new_schedule':
      case 'new_student':
        return 'bg-primary/10 border-primary/20';
      default:
        return 'bg-muted/50 border-border';
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <BackButton className="mb-6" />
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Notificações</h1>
            <p className="text-muted-foreground">
              {unreadCount > 0 
                ? `Você tem ${unreadCount} notificação${unreadCount > 1 ? 'ões' : ''} não lida${unreadCount > 1 ? 's' : ''}`
                : 'Todas as notificações foram lidas'}
            </p>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <CheckCheck className="h-4 w-4 mr-2" />
              Marcar todas como lidas
            </Button>
          )}
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="card-elevated p-12 text-center">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <Bell className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhuma notificação</h3>
            <p className="text-muted-foreground">
              Você não tem notificações no momento. Quando houver novidades, elas aparecerão aqui.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={cn(
                  "card-elevated p-5 transition-all cursor-pointer hover:shadow-lg border",
                  !notification.is_read && "ring-2 ring-primary/20",
                  getNotificationColor(notification.type)
                )}
                onClick={() => !notification.is_read && markAsRead(notification.id)}
              >
                <div className="flex gap-4">
                  <div className={cn(
                    "h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0",
                    notification.type === 'approval' || notification.type === 'lesson_completed' || notification.type === 'schedule_confirmed'
                      ? "bg-success/20"
                      : notification.type === 'rejection'
                        ? "bg-destructive/20"
                        : "bg-primary/20"
                  )}>
                    {getNotificationIcon(notification.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className={cn(
                          "font-semibold",
                          !notification.is_read ? "text-foreground" : "text-muted-foreground"
                        )}>
                          {notification.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {notification.message}
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {!notification.is_read && (
                          <span className="h-2 w-2 rounded-full bg-primary" />
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <span>
                        {formatDistanceToNow(new Date(notification.created_at), {
                          addSuffix: true,
                          locale: ptBR,
                        })}
                      </span>
                      <span>•</span>
                      <span>
                        {format(new Date(notification.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Notifications;
