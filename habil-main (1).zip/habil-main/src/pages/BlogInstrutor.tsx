import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  BookOpen, Clock, User, Search, TrendingUp, 
  Target, Users, Award, Lightbulb, CheckCircle,
  ArrowRight, Calendar, Eye
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: number;
  author: string;
  date: string;
  views: number;
  featured?: boolean;
  icon: React.ReactNode;
}

const articles: Article[] = [
  {
    id: '1',
    title: 'Como aumentar sua taxa de aprovação em 30%',
    excerpt: 'Descubra técnicas comprovadas que os melhores instrutores usam para garantir que seus alunos passem no exame de primeira. Desde a preparação mental até exercícios práticos específicos.',
    category: 'Técnicas de Ensino',
    readTime: 8,
    author: 'Equipe Conduza',
    date: '28 Dez 2025',
    views: 1240,
    featured: true,
    icon: <TrendingUp className="h-6 w-6" />
  },
  {
    id: '2',
    title: '5 erros que fazem alunos reprovarem na baliza',
    excerpt: 'A baliza é o terror de muitos alunos. Conheça os erros mais comuns e como orientar seus alunos a evitá-los durante o exame prático.',
    category: 'Dicas Práticas',
    readTime: 5,
    author: 'Equipe Conduza',
    date: '25 Dez 2025',
    views: 890,
    featured: true,
    icon: <Target className="h-6 w-6" />
  },
  {
    id: '3',
    title: 'Como lidar com alunos ansiosos',
    excerpt: 'A ansiedade é um dos maiores obstáculos para o aprendizado. Aprenda estratégias para ajudar seus alunos a manterem a calma durante as aulas e no dia do exame.',
    category: 'Psicologia',
    readTime: 6,
    author: 'Equipe Conduza',
    date: '22 Dez 2025',
    views: 756,
    icon: <Users className="h-6 w-6" />
  },
  {
    id: '4',
    title: 'Guia completo: Documentação do instrutor autônomo',
    excerpt: 'Tudo que você precisa saber sobre documentação, credenciamento e requisitos legais para atuar como instrutor de trânsito autônomo no Brasil.',
    category: 'Legislação',
    readTime: 12,
    author: 'Equipe Conduza',
    date: '18 Dez 2025',
    views: 623,
    icon: <BookOpen className="h-6 w-6" />
  },
  {
    id: '5',
    title: 'Precificação: Quanto cobrar por aula?',
    excerpt: 'Entenda como definir o valor da sua hora-aula considerando sua região, experiência, custos operacionais e o que o mercado pratica.',
    category: 'Negócios',
    readTime: 7,
    author: 'Equipe Conduza',
    date: '15 Dez 2025',
    views: 1102,
    icon: <Award className="h-6 w-6" />
  },
  {
    id: '6',
    title: 'Técnicas de comunicação efetiva com alunos',
    excerpt: 'Aprenda a dar feedbacks construtivos, explicar manobras de forma clara e criar um ambiente de aprendizado positivo.',
    category: 'Técnicas de Ensino',
    readTime: 6,
    author: 'Equipe Conduza',
    date: '12 Dez 2025',
    views: 534,
    icon: <Lightbulb className="h-6 w-6" />
  },
  {
    id: '7',
    title: 'Checklist: Preparação para o exame prático',
    excerpt: 'Um guia passo a passo para preparar seu aluno nos dias que antecedem o exame. Inclui exercícios, dicas de relaxamento e revisão de pontos críticos.',
    category: 'Dicas Práticas',
    readTime: 4,
    author: 'Equipe Conduza',
    date: '10 Dez 2025',
    views: 445,
    icon: <CheckCircle className="h-6 w-6" />
  },
  {
    id: '8',
    title: 'Como construir sua reputação online',
    excerpt: 'Dicas para fortalecer sua presença digital, conseguir boas avaliações e atrair mais alunos através da plataforma Conduza.',
    category: 'Marketing',
    readTime: 5,
    author: 'Equipe Conduza',
    date: '8 Dez 2025',
    views: 678,
    icon: <TrendingUp className="h-6 w-6" />
  }
];

const categories = [
  'Todos',
  'Técnicas de Ensino',
  'Dicas Práticas',
  'Psicologia',
  'Legislação',
  'Negócios',
  'Marketing'
];

const BlogInstrutor = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(search.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'Todos' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredArticles = articles.filter(a => a.featured);
  const regularArticles = filteredArticles.filter(a => !a.featured || selectedCategory !== 'Todos' || search);

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-hero py-16 lg:py-20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6 animate-fade-in">
              <BookOpen className="h-4 w-4 text-primary-foreground" />
              <span className="text-sm font-medium text-primary-foreground">Blog do Instrutor</span>
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-extrabold text-primary-foreground mb-4 animate-fade-in" style={{ animationDelay: '0.1s' }}>
              Dicas e estratégias para <span className="bg-gradient-to-r from-blue-200 to-sky-300 bg-clip-text text-transparent">instrutores</span>
            </h1>
            
            <p className="text-lg text-primary-foreground/80 mb-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Artigos, guias e insights para você se destacar como instrutor e aumentar sua taxa de aprovação.
            </p>

            {/* Search */}
            <div className="max-w-xl mx-auto animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Buscar artigos..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-12 h-14 text-base bg-card border-0 shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-6 bg-background border-b border-border sticky top-16 z-40">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="whitespace-nowrap"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      {selectedCategory === 'Todos' && !search && (
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold text-foreground mb-8">Destaques</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              {featuredArticles.map((article, index) => (
                <div 
                  key={article.id} 
                  className="card-elevated p-6 group hover:scale-[1.02] transition-all cursor-pointer animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                  onClick={() => navigate(`/blog-instrutor/${article.id}`)}
                >
                  <div className="flex items-start gap-4">
                    <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                      <div className="text-primary">{article.icon}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="text-xs">
                          {article.category}
                        </Badge>
                        <Badge variant="outline" className="text-xs bg-accent/10 text-accent border-accent/20">
                          Destaque
                        </Badge>
                      </div>
                      <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                        {article.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {article.excerpt}
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {article.readTime} min
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {article.date}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {article.views}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Articles */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-foreground">
              {selectedCategory === 'Todos' && !search ? 'Todos os artigos' : `${filteredArticles.length} artigo${filteredArticles.length !== 1 ? 's' : ''} encontrado${filteredArticles.length !== 1 ? 's' : ''}`}
            </h2>
          </div>

          {filteredArticles.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(selectedCategory !== 'Todos' || search ? filteredArticles : regularArticles).map((article, index) => (
                <div 
                  key={article.id} 
                  className="card-elevated p-5 group hover:scale-[1.02] transition-all cursor-pointer animate-fade-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                  onClick={() => navigate(`/blog-instrutor/${article.id}`)}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                      <div className="text-primary scale-75">{article.icon}</div>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {article.category}
                    </Badge>
                  </div>
                  
                  <h3 className="text-base font-semibold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                    {article.title}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                    {article.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {article.readTime} min
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {article.views}
                      </span>
                    </div>
                    <span>{article.date}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
                <BookOpen className="h-10 w-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Nenhum artigo encontrado</h3>
              <p className="text-muted-foreground mb-4">
                Tente buscar por outro termo ou selecione outra categoria
              </p>
              <Button variant="outline" onClick={() => { setSearch(''); setSelectedCategory('Todos'); }}>
                Limpar filtros
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Quer receber mais dicas?
            </h2>
            <p className="text-muted-foreground mb-6">
              Cadastre-se como instrutor na Conduza e tenha acesso a conteúdos exclusivos, 
              além de poder gerenciar seus alunos e construir sua reputação.
            </p>
            <Button variant="hero" size="lg" onClick={() => window.location.href = '/register/instructor'}>
              Cadastrar como instrutor
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default BlogInstrutor;