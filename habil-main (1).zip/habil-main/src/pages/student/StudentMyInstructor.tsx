import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useInstructorLink } from '@/hooks/useInstructorLink';
import { useInstructorContact } from '@/hooks/useInstructorContact';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { logger } from '@/lib/logger';
import { 
  User, MapPin, Star, Calendar, MessageCircle, Clock, 
  CheckCircle, Car, Loader2, Award
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface InstructorProfile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  city: string;
  neighborhood: string | null;
  price_per_hour: number | null;
  cnh_category: string | null;
  bio: string | null;
  years_of_experience: number | null;
  certifications: string[] | null;
  available_days: string[] | null;
  available_start_time: string | null;
  available_end_time: string | null;
}

interface Schedule {
  id: string;
  scheduled_date: string;
  scheduled_time: string;
  lesson_type: string;
  status: string;
  notes: string | null;
}

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer_name: string | null;
}

const StudentMyInstructor = () => {
  const navigate = useNavigate();
  const { session } = useAuth();
  const { linkedInstructor, unlinkInstructor, isLoading: unlinkLoading } = useInstructorLink();
  const { openWhatsApp, isLoading: isContactLoading } = useInstructorContact();
  
  const [instructor, setInstructor] = useState<InstructorProfile | null>(null);
  const [upcomingLessons, setUpcomingLessons] = useState<Schedule[]>([]);
  const [completedLessons, setCompletedLessons] = useState<Schedule[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [averageRating, setAverageRating] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!linkedInstructor?.instructorId || !session?.user?.id) {
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        // Fetch instructor profile (without whatsapp - fetched via secure edge function)
        const { data: profileData, error: profileError } = await supabase
          .from('public_instructor_profiles')
          .select('id, full_name, avatar_url, city, neighborhood, price_per_hour, cnh_category, bio, years_of_experience, certifications, available_days, available_start_time, available_end_time, latitude, longitude')
          .eq('id', linkedInstructor.instructorId)
          .single();

        if (profileError) {
          logger.error('Error fetching instructor profile:', profileError);
        } else if (profileData) {
          setInstructor(profileData);
        }

        // Fetch schedules with this instructor
        const { data: schedulesData } = await supabase
          .from('schedules')
          .select('id, scheduled_date, scheduled_time, lesson_type, status, notes')
          .eq('instructor_id', linkedInstructor.instructorId)
          .eq('student_id', session.user.id)
          .order('scheduled_date', { ascending: false });

        if (schedulesData) {
          const today = new Date().toISOString().split('T')[0];
          setUpcomingLessons(
            schedulesData.filter(s => 
              s.scheduled_date >= today && 
              ['pending', 'confirmed'].includes(s.status)
            ).reverse()
          );
          setCompletedLessons(
            schedulesData.filter(s => s.status === 'completed')
          );
        }

        // Fetch reviews for this instructor
        const { data: reviewsData } = await supabase
          .from('public_reviews')
          .select('id, rating, comment, created_at, reviewer_name')
          .eq('instructor_id', linkedInstructor.instructorId)
          .order('created_at', { ascending: false })
          .limit(10);

        if (reviewsData) {
          setReviews(reviewsData);
          if (reviewsData.length > 0) {
            const avg = reviewsData.reduce((sum, r) => sum + (r.rating || 0), 0) / reviewsData.length;
            setAverageRating(Math.round(avg * 10) / 10);
          }
        }
      } catch (err) {
        logger.error('Error fetching instructor data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [linkedInstructor?.instructorId, session?.user?.id]);

  const handleWhatsAppClick = () => {
    if (instructor?.id) {
      openWhatsApp(instructor.id);
    }
  };

  const getLessonTypeLabel = (type: string) => {
    switch (type) {
      case 'theoretical': return 'Teórica';
      case 'practical_car': return 'Prática Carro';
      case 'practical_motorcycle': return 'Prática Moto';
      default: return type;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="text-amber-600 border-amber-300">Pendente</Badge>;
      case 'confirmed':
        return <Badge className="bg-primary/10 text-primary border-primary/20">Confirmada</Badge>;
      case 'completed':
        return <Badge className="bg-success/10 text-success border-success/20">Concluída</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelada</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const dayLabels: Record<string, string> = {
    'monday': 'Seg',
    'tuesday': 'Ter',
    'wednesday': 'Qua',
    'thursday': 'Qui',
    'friday': 'Sex',
    'saturday': 'Sáb',
    'sunday': 'Dom',
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!linkedInstructor || !instructor) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <BackButton />
          <div className="text-center py-16">
            <User className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold text-foreground mb-2">Nenhum instrutor vinculado</h2>
            <p className="text-muted-foreground mb-6">
              Você ainda não está vinculado a um instrutor.
            </p>
            <Button onClick={() => navigate('/student/instructors')}>
              Buscar instrutores
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const linkedDate = linkedInstructor.linkedAt 
    ? format(new Date(linkedInstructor.linkedAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
    : null;

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <BackButton />
        
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground">Meu Instrutor</h1>
          <p className="text-muted-foreground">Detalhes do seu instrutor e histórico de aulas</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Instructor Profile Card */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-primary/20">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 border-4 border-primary/20 mb-4">
                    <AvatarImage src={instructor.avatar_url || undefined} alt={instructor.full_name} />
                    <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                      {instructor.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>

                  <h2 className="text-xl font-bold text-foreground">{instructor.full_name}</h2>
                  
                  <div className="flex items-center gap-2 mt-2">
                    {averageRating && (
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span className="font-semibold">{averageRating}</span>
                        <span className="text-muted-foreground text-sm">({reviews.length} avaliações)</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-muted-foreground mt-2">
                    <MapPin className="h-4 w-4" />
                    <span>{instructor.neighborhood ? `${instructor.neighborhood}, ` : ''}{instructor.city}</span>
                  </div>

                  {linkedDate && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Vinculado desde {linkedDate}
                    </p>
                  )}

                  <div className="flex flex-wrap justify-center gap-2 mt-4">
                    {instructor.cnh_category && (
                      <Badge variant="secondary">Cat. {instructor.cnh_category}</Badge>
                    )}
                    {instructor.years_of_experience && (
                      <Badge variant="outline">{instructor.years_of_experience} anos exp.</Badge>
                    )}
                  </div>

                  {instructor.bio && (
                    <p className="text-sm text-muted-foreground mt-4">{instructor.bio}</p>
                  )}
                </div>

                <div className="border-t mt-6 pt-6 space-y-4">
                  {instructor.price_per_hour && (
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Valor/hora</span>
                      <span className="font-semibold text-primary">
                        R$ {instructor.price_per_hour.toFixed(2)}
                      </span>
                    </div>
                  )}

                  {instructor.available_days && instructor.available_days.length > 0 && (
                    <div>
                      <span className="text-muted-foreground text-sm">Dias disponíveis</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {instructor.available_days.map(day => (
                          <Badge key={day} variant="outline" className="text-xs">
                            {dayLabels[day] || day}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {instructor.available_start_time && instructor.available_end_time && (
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Horário</span>
                      <span className="text-sm">
                        {instructor.available_start_time.slice(0, 5)} - {instructor.available_end_time.slice(0, 5)}
                      </span>
                    </div>
                  )}

                  {instructor.certifications && instructor.certifications.length > 0 && (
                    <div>
                      <span className="text-muted-foreground text-sm">Certificações</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {instructor.certifications.map((cert, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            <Award className="h-3 w-3 mr-1" />
                            {cert}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-6">
                  <Button 
                    className="flex-1" 
                    onClick={handleWhatsAppClick}
                    disabled={isContactLoading}
                  >
                    {isContactLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <MessageCircle className="h-4 w-4 mr-2" />
                        WhatsApp
                      </>
                    )}
                  </Button>
                </div>

                <Button 
                  variant="outline" 
                  className="w-full mt-2"
                  onClick={unlinkInstructor}
                  disabled={unlinkLoading}
                >
                  Trocar de instrutor
                </Button>
              </CardContent>
            </Card>

            {/* Stats Summary */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-primary">{completedLessons.length}</p>
                    <p className="text-xs text-muted-foreground">Aulas concluídas</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{upcomingLessons.length}</p>
                    <p className="text-xs text-muted-foreground">Aulas agendadas</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="upcoming" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="upcoming">Próximas Aulas</TabsTrigger>
                <TabsTrigger value="history">Histórico</TabsTrigger>
                <TabsTrigger value="reviews">Avaliações</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-primary" />
                      Próximas Aulas Agendadas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {upcomingLessons.length === 0 ? (
                      <div className="text-center py-8">
                        <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                        <p className="text-muted-foreground">Nenhuma aula agendada</p>
                        <Button 
                          variant="outline" 
                          className="mt-4"
                          onClick={() => navigate('/student/instructors')}
                        >
                          Agendar aula
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {upcomingLessons.map(lesson => {
                          const lessonDate = new Date(`${lesson.scheduled_date}T${lesson.scheduled_time}`);
                          return (
                            <div 
                              key={lesson.id} 
                              className="flex items-center gap-4 p-4 rounded-lg bg-muted/50"
                            >
                              <div className="h-12 w-12 rounded-lg gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                                {format(lessonDate, 'dd')}
                              </div>
                              <div className="flex-1">
                                <p className="font-medium">{getLessonTypeLabel(lesson.lesson_type)}</p>
                                <p className="text-sm text-muted-foreground">
                                  {format(lessonDate, "EEEE, dd 'de' MMMM", { locale: ptBR })} às {format(lessonDate, 'HH:mm')}
                                </p>
                              </div>
                              {getStatusBadge(lesson.status)}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="history" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-success" />
                      Histórico de Aulas Concluídas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {completedLessons.length === 0 ? (
                      <div className="text-center py-8">
                        <Car className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                        <p className="text-muted-foreground">Nenhuma aula concluída ainda</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {completedLessons.map(lesson => {
                          const lessonDate = new Date(`${lesson.scheduled_date}T${lesson.scheduled_time}`);
                          return (
                            <div 
                              key={lesson.id} 
                              className="flex items-center gap-4 p-4 rounded-lg bg-success/5 border border-success/10"
                            >
                              <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                                <CheckCircle className="h-5 w-5 text-success" />
                              </div>
                              <div className="flex-1">
                                <p className="font-medium">{getLessonTypeLabel(lesson.lesson_type)}</p>
                                <p className="text-sm text-muted-foreground">
                                  {format(lessonDate, "dd/MM/yyyy", { locale: ptBR })} às {format(lessonDate, 'HH:mm')}
                                </p>
                              </div>
                              <span className="text-success text-sm font-medium">Concluída</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="h-5 w-5 text-amber-400" />
                      Avaliações de Outros Alunos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {reviews.length === 0 ? (
                      <div className="text-center py-8">
                        <Star className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                        <p className="text-muted-foreground">Nenhuma avaliação ainda</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {reviews.map(review => (
                          <div key={review.id} className="p-4 rounded-lg bg-muted/50">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{review.reviewer_name || 'Aluno'}</span>
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`h-4 w-4 ${
                                      i < (review.rating || 0) 
                                        ? 'fill-amber-400 text-amber-400' 
                                        : 'text-muted-foreground'
                                    }`} 
                                  />
                                ))}
                              </div>
                            </div>
                            {review.comment && (
                              <p className="text-sm text-muted-foreground">{review.comment}</p>
                            )}
                            <p className="text-xs text-muted-foreground mt-2">
                              {format(new Date(review.created_at), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default StudentMyInstructor;
