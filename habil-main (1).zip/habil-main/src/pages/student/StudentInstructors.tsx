import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { InstructorCard } from '@/components/cards/InstructorCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useLocation } from '@/contexts/LocationContext';
import { useInstructors } from '@/hooks/useInstructors';
import { Search, MapPin, Loader2, Users, Edit2, Navigation, Crown, Sparkles, BadgeCheck, Shield } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SchedulingDialog } from '@/components/scheduling/SchedulingDialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { SimpleLocationSelector } from '@/components/location/SimpleLocationSelector';
import { motion } from 'framer-motion';

const StudentInstructors = () => {
  const { location, setLocationDirect, setCoordinates } = useLocation();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [planFilter, setPlanFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('none');
  const [selectedInstructor, setSelectedInstructor] = useState<any>(null);
  const [isSchedulingOpen, setIsSchedulingOpen] = useState(false);
  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false);

  const hasCoordinates = Boolean(location.coordinates?.latitude && location.coordinates?.longitude);
  const sortByProximity = sortBy === 'proximity' && hasCoordinates;

  // Fetch instructors - always filter by user's location (UF + City)
  // SECURITY: showAll is false - only show approved instructors
  const { instructors, isLoading } = useInstructors(
    location.uf,
    location.city,
    { 
      showAll: false,
      userLat: location.coordinates?.latitude,
      userLng: location.coordinates?.longitude,
      sortByProximity,
    }
  );

  // Filter instructors by search, category, and plan
  let filteredInstructors = instructors.filter((instructor) => {
    const matchesSearch = instructor.full_name.toLowerCase().includes(search.toLowerCase()) ||
                         (instructor.bio || '').toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || 
                           instructor.categories.includes(categoryFilter as 'A' | 'B' | 'AB');
    
    let matchesPlan = true;
    if (planFilter === 'premium') {
      matchesPlan = instructor.subscription_plan === 'premium';
    } else if (planFilter === 'verified') {
      matchesPlan = instructor.subscription_plan === 'professional' || instructor.subscription_plan === 'premium';
    }
    
    return matchesSearch && matchesCategory && matchesPlan;
  });

  // Sort instructors (only if a sort option is selected, proximity is handled by hook)
  if (sortBy !== 'none' && sortBy !== 'proximity') {
    filteredInstructors = [...filteredInstructors].sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'approval':
          return b.approvalRate - a.approvalRate;
        case 'price':
          return (a.price_per_hour || 0) - (b.price_per_hour || 0);
        default:
          return 0;
      }
    });
  }

  // Separate premium instructors for featured section
  const premiumInstructors = filteredInstructors.filter(i => i.subscription_plan === 'premium');
  const otherInstructors = filteredInstructors.filter(i => i.subscription_plan !== 'premium');

  // Format distance for display
  const formatDistance = (km: number | null) => {
    if (km === null) return null;
    if (km < 1) return `${Math.round(km * 1000)}m`;
    return `${km.toFixed(1)}km`;
  };

  const handleSelectInstructor = (instructor: any) => {
    // Convert to format expected by SchedulingDialog
    // NOTE: Only public data is passed - no sensitive info like email, cpf, cnh
    const formattedInstructor = {
      id: instructor.id,
      name: instructor.full_name,
      categories: instructor.categories,
      certifications: instructor.certifications || [],
      approved: true,
      approvalRate: instructor.approvalRate,
      totalStudents: instructor.totalStudents,
      approvedStudents: instructor.approvedStudents,
      bio: instructor.bio || '',
      pricePerHour: instructor.price_per_hour || 80,
      rating: instructor.rating,
      reviewCount: instructor.reviewCount,
      uf: instructor.uf,
      city: instructor.city,
      // WhatsApp is fetched via secure edge function when needed
    };
    setSelectedInstructor(formattedInstructor);
    setIsSchedulingOpen(true);
  };

  const handleLocationChange = (uf: string, city: string) => {
    setLocationDirect(uf, city);
    if (uf && city) {
      setIsLocationDialogOpen(false);
    }
  };

  const renderInstructorCard = (instructor: any, index: number) => {
    const cardInstructor = {
      id: instructor.id,
      full_name: instructor.full_name,
      bio: instructor.bio,
      price_per_hour: instructor.price_per_hour,
      uf: instructor.uf,
      city: instructor.city,
      avatar_url: instructor.avatar_url,
      years_of_experience: instructor.years_of_experience,
      approvalRate: instructor.approvalRate,
      totalStudents: instructor.totalStudents,
      rating: instructor.rating,
      reviewCount: instructor.reviewCount,
      categories: instructor.categories,
      distance_km: instructor.distance_km,
      subscription_plan: instructor.subscription_plan,
    };
    
    return (
      <div key={instructor.id} style={{ animationDelay: `${index * 0.1}s` }}>
        <InstructorCard 
          instructor={cardInstructor} 
          onSelect={handleSelectInstructor}
          showDistance={sortByProximity}
          formatDistance={formatDistance}
        />
      </div>
    );
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Encontre seu Instrutor</h1>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>Mostrando instrutores em {location.city}, {location.uf}</span>
            <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 px-2 text-primary">
                  <Edit2 className="h-3 w-3 mr-1" />
                  Alterar
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Alterar localização</DialogTitle>
                </DialogHeader>
                <SimpleLocationSelector
                  currentUf={location.uf}
                  currentCity={location.city}
                  onConfirm={(uf, city) => {
                    handleLocationChange(uf, city);
                  }}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Filters */}
        <div className="card-elevated p-4 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou especialidade..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-12"
              />
            </div>
            
            <div className="flex flex-wrap gap-3">

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[140px] h-12">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="A">Categoria A</SelectItem>
                  <SelectItem value="B">Categoria B</SelectItem>
                  <SelectItem value="AB">Categoria AB</SelectItem>
                </SelectContent>
              </Select>

              <Select value={planFilter} onValueChange={setPlanFilter}>
                <SelectTrigger className="w-[180px] h-12">
                  <SelectValue placeholder="Tipo de instrutor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    <span className="flex items-center gap-2">
                      <Users className="h-3 w-3" />
                      Todos
                    </span>
                  </SelectItem>
                  <SelectItem value="verified">
                    <span className="flex items-center gap-2">
                      <BadgeCheck className="h-3 w-3 text-primary" />
                      Verificados
                    </span>
                  </SelectItem>
                  <SelectItem value="premium">
                    <span className="flex items-center gap-2">
                      <Crown className="h-3 w-3 text-amber-500" />
                      Premium
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px] h-12">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem filtro</SelectItem>
                  <SelectItem value="proximity" disabled={!hasCoordinates}>
                    <span className="flex items-center gap-2">
                      <Navigation className="h-3 w-3" />
                      Mais próximos
                      {!hasCoordinates && <span className="text-xs text-muted-foreground">(GPS)</span>}
                    </span>
                  </SelectItem>
                  <SelectItem value="rating">Melhor avaliação</SelectItem>
                  <SelectItem value="approval">Maior aprovação</SelectItem>
                  <SelectItem value="price">Menor preço</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Results */}
        {filteredInstructors.length > 0 ? (
          <>
            <div className="flex items-center justify-between mb-6">
              <p className="text-muted-foreground">
                {filteredInstructors.length} instrutor{filteredInstructors.length !== 1 ? 'es' : ''} encontrado{filteredInstructors.length !== 1 ? 's' : ''}
              </p>
            </div>

            {/* Premium Instructors Featured Section */}
            {premiumInstructors.length > 0 && (
              <motion.div 
                className="mb-10 relative"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              >
                {/* Shimmer effect background */}
                <div className="absolute inset-0 -m-2 rounded-2xl bg-gradient-to-r from-transparent via-amber-400/10 to-transparent overflow-hidden pointer-events-none">
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12"
                    animate={{ x: ["-200%", "200%"] }}
                    transition={{ 
                      duration: 3, 
                      repeat: Infinity, 
                      repeatDelay: 2,
                      ease: "easeInOut" 
                    }}
                  />
                </div>

                <motion.div 
                  className="flex items-center gap-3 mb-4"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.2 }}
                >
                  <motion.div 
                    className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-yellow-400 text-white px-4 py-2 rounded-full shadow-lg shadow-amber-500/30"
                    whileHover={{ scale: 1.02 }}
                    animate={{ 
                      boxShadow: [
                        "0 10px 15px -3px rgba(245, 158, 11, 0.3)",
                        "0 10px 25px -3px rgba(245, 158, 11, 0.5)",
                        "0 10px 15px -3px rgba(245, 158, 11, 0.3)"
                      ]
                    }}
                    transition={{ 
                      boxShadow: { duration: 2, repeat: Infinity, ease: "easeInOut" }
                    }}
                  >
                    <motion.div
                      animate={{ rotate: [0, -10, 10, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 3 }}
                    >
                      <Crown className="h-5 w-5" />
                    </motion.div>
                    <span className="font-bold">Instrutores Premium</span>
                    <motion.div
                      animate={{ scale: [1, 1.2, 1], opacity: [1, 0.8, 1] }}
                      transition={{ duration: 1, repeat: Infinity, repeatDelay: 1 }}
                    >
                      <Sparkles className="h-4 w-4" />
                    </motion.div>
                  </motion.div>
                  <motion.div 
                    className="flex-1 h-px bg-gradient-to-r from-amber-400/50 to-transparent"
                    initial={{ scaleX: 0, originX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 0.6, delay: 0.4 }}
                  />
                </motion.div>

                <motion.p 
                  className="text-sm text-muted-foreground mb-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4, delay: 0.3 }}
                >
                  Os melhores instrutores com recursos exclusivos e alta taxa de aprovação
                </motion.p>

                <div className="grid md:grid-cols-2 gap-6">
                  {premiumInstructors.map((instructor, index) => (
                    <motion.div
                      key={instructor.id}
                      initial={{ opacity: 0, y: 20, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ 
                        duration: 0.4, 
                        delay: 0.4 + index * 0.1,
                        ease: "easeOut"
                      }}
                    >
                      {renderInstructorCard(instructor, index)}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Other Instructors */}
            {otherInstructors.length > 0 && (
              <div className="mb-12">
                {premiumInstructors.length > 0 && (
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="text-lg font-semibold text-foreground">Todos os Instrutores</h2>
                    <div className="flex-1 h-px bg-border" />
                  </div>
                )}
                <div className="grid md:grid-cols-2 gap-6">
                  {otherInstructors.map((instructor, index) => renderInstructorCard(instructor, index))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <Users className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhum instrutor disponível</h3>
            <p className="text-muted-foreground mb-4">
              Ainda não há instrutores cadastrados em {location.city}, {location.uf}
            </p>
            <Button variant="outline" onClick={() => { 
              setSearch(''); 
              setCategoryFilter('all');
              setPlanFilter('all'); 
              setSortBy('none'); 
            }}>
              Limpar filtros
            </Button>
          </div>
        )}

        {/* Scheduling Dialog */}
        <SchedulingDialog
          instructor={selectedInstructor}
          open={isSchedulingOpen}
          onOpenChange={setIsSchedulingOpen}
        />
      </div>
    </MainLayout>
  );
};

export default StudentInstructors;
