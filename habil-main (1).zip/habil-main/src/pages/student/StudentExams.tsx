import { useState, useRef, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useExams } from '@/hooks/useExams';
import { useSchedules } from '@/hooks/useSchedules';
import { BookOpen, Car, CheckCircle, XCircle, Clock, AlertCircle, Plus, Loader2, Upload, FileText, Brain, HeartPulse, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { SecureDocumentLink } from '@/components/ui/secure-document-link';
import { Checkbox } from '@/components/ui/checkbox';
import type { Database } from '@/integrations/supabase/types';

type ExamType = Database['public']['Enums']['exam_type'];
type CnhCategory = Database['public']['Enums']['cnh_category'];

interface MedicalExams {
  psychological: boolean;
  aptitude: boolean;
  physicalMental: boolean;
}

const MEDICAL_EXAMS_KEY = 'conduza_medical_exams';

const StudentExams = () => {
  const { exams, isLoading, confirmExamResult, createExam } = useExams();
  const { schedules } = useSchedules();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Medical exams state (stored in localStorage)
  const [medicalExams, setMedicalExams] = useState<MedicalExams>(() => {
    const stored = localStorage.getItem(MEDICAL_EXAMS_KEY);
    return stored ? JSON.parse(stored) : { psychological: false, aptitude: false, physicalMental: false };
  });

  useEffect(() => {
    localStorage.setItem(MEDICAL_EXAMS_KEY, JSON.stringify(medicalExams));
  }, [medicalExams]);

  const handleMedicalExamToggle = (exam: keyof MedicalExams) => {
    setMedicalExams(prev => ({ ...prev, [exam]: !prev[exam] }));
    toast({
      title: medicalExams[exam] ? 'Exame desmarcado' : 'Exame concluído!',
      description: medicalExams[exam] ? 'O exame foi desmarcado' : 'Parabéns pelo progresso!',
    });
  };
  
  // Get unique instructor IDs from schedules
  const instructorIds = [...new Set(schedules.map(s => s.instructor_id))];
  const hasInstructor = instructorIds.length > 0;
  
  // Form state for new exam
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [examType, setExamType] = useState<ExamType>('theoretical');
  const [category, setCategory] = useState<CnhCategory>('B');
  const [examDate, setExamDate] = useState<Date>();
  const [passed, setPassed] = useState<boolean | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [documentFile, setDocumentFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type (PDF, images)
      const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        toast({
          title: 'Tipo de arquivo inválido',
          description: 'Por favor, envie um PDF ou imagem (JPG, PNG, WebP)',
          variant: 'destructive',
        });
        return;
      }
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'Arquivo muito grande',
          description: 'O tamanho máximo permitido é 5MB',
          variant: 'destructive',
        });
        return;
      }
      setDocumentFile(file);
    }
  };

  const handleCreateExam = async () => {
    if (!examDate || passed === null || !hasInstructor) return;

    // Document is required for theoretical exams
    if (examType === 'theoretical' && !documentFile) {
      toast({
        title: 'Documento obrigatório',
        description: 'Por favor, anexe o comprovante do exame teórico',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    
    await createExam({
      instructor_id: instructorIds[0],
      exam_type: examType,
      category: category,
      exam_date: format(examDate, 'yyyy-MM-dd'),
      status: passed ? 'approved' : 'failed',
      confirmed_by_student: true,
      student_passed: passed,
    }, documentFile || undefined);

    setIsSubmitting(false);
    setIsDialogOpen(false);
    setExamDate(undefined);
    setPassed(null);
    setDocumentFile(null);
  };

  const handleConfirmResult = async (examId: string, didPass: boolean) => {
    await confirmExamResult(examId, didPass);
  };

  const getStatusBadge = (exam: typeof exams[0]) => {
    if (!exam.confirmed_by_student || !exam.confirmed_by_instructor) {
      return (
        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
          <Clock className="h-3 w-3 mr-1" />
          Aguardando confirmação
        </Badge>
      );
    }
    
    if (exam.status === 'approved') {
      return (
        <Badge className="bg-success text-success-foreground">
          <CheckCircle className="h-3 w-3 mr-1" />
          Aprovado
        </Badge>
      );
    }
    
    if (exam.status === 'failed') {
      return (
        <Badge variant="destructive">
          <XCircle className="h-3 w-3 mr-1" />
          Reprovado
        </Badge>
      );
    }

    return (
      <Badge variant="secondary">
        <Clock className="h-3 w-3 mr-1" />
        Pendente
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Meus Exames</h1>
            <p className="text-muted-foreground">
              Registre e acompanhe os resultados dos seus exames
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="hero" disabled={!hasInstructor}>
                <Plus className="h-4 w-4 mr-2" />
                Registrar Exame
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Registrar Resultado de Exame</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Tipo de Exame</Label>
                  <Select value={examType} onValueChange={(v) => setExamType(v as ExamType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="theoretical">Teórico</SelectItem>
                      <SelectItem value="practical">Prático</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Categoria</Label>
                  <Select value={category} onValueChange={(v) => setCategory(v as CnhCategory)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Categoria A (Moto)</SelectItem>
                      <SelectItem value="B">Categoria B (Carro)</SelectItem>
                      <SelectItem value="AB">Categoria AB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Data do Exame</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !examDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {examDate ? format(examDate, "dd/MM/yyyy", { locale: ptBR }) : "Selecione a data"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={examDate}
                        onSelect={setExamDate}
                        disabled={(date) => date > new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Resultado</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={passed === true ? "default" : "outline"}
                      className={cn(
                        passed === true && "bg-success hover:bg-success/90"
                      )}
                      onClick={() => setPassed(true)}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Aprovado
                    </Button>
                    <Button
                      type="button"
                      variant={passed === false ? "destructive" : "outline"}
                      onClick={() => setPassed(false)}
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Reprovado
                    </Button>
                  </div>
                </div>

                {/* Document upload - required for theoretical exams */}
                {examType === 'theoretical' && (
                  <div className="space-y-2">
                    <Label>
                      Comprovante do Exame <span className="text-destructive">*</span>
                    </Label>
                    <div 
                      className={cn(
                        "border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors",
                        documentFile 
                          ? "border-success bg-success/5" 
                          : "border-muted-foreground/25 hover:border-primary/50 hover:bg-primary/5"
                      )}
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png,.webp"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      {documentFile ? (
                        <div className="flex items-center justify-center gap-2 text-success">
                          <FileText className="h-5 w-5" />
                          <span className="text-sm font-medium">{documentFile.name}</span>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            Clique para enviar o comprovante
                          </p>
                          <p className="text-xs text-muted-foreground">
                            PDF ou imagem (máx. 5MB)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <Button 
                  className="w-full" 
                  variant="hero"
                  disabled={!examDate || passed === null || isSubmitting || (examType === 'theoretical' && !documentFile)}
                  onClick={handleCreateExam}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Registrando...
                    </>
                  ) : (
                    'Registrar Exame'
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {!hasInstructor && (
          <div className="card-elevated p-4 mb-8 bg-warning/10 border-warning/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
              <div>
                <p className="font-medium text-foreground">Agende uma aula primeiro</p>
                <p className="text-sm text-muted-foreground">
                  Para registrar exames, você precisa ter agendado pelo menos uma aula com um instrutor.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Medical Exams Section */}
        <div className="card-elevated p-6 mb-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">Exames Médicos e Avaliações</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Marque como concluído os exames obrigatórios para o processo de habilitação.
          </p>
          <div className="grid sm:grid-cols-3 gap-4">
            {/* Avaliação Psicológica */}
            <div 
              className={cn(
                "p-4 rounded-xl border-2 cursor-pointer transition-all",
                medicalExams.psychological 
                  ? "border-success bg-success/5" 
                  : "border-border hover:border-primary/50"
              )}
              onClick={() => handleMedicalExamToggle('psychological')}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center shrink-0",
                  medicalExams.psychological ? "bg-success/20" : "bg-muted"
                )}>
                  <Brain className={cn("h-5 w-5", medicalExams.psychological ? "text-success" : "text-muted-foreground")} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-medium text-foreground text-sm">Avaliação Psicológica</h3>
                    <Checkbox checked={medicalExams.psychological} className="shrink-0" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Avaliação de aptidão psicológica para dirigir</p>
                </div>
              </div>
            </div>

            {/* Exame de Aptidão */}
            <div 
              className={cn(
                "p-4 rounded-xl border-2 cursor-pointer transition-all",
                medicalExams.aptitude 
                  ? "border-success bg-success/5" 
                  : "border-border hover:border-primary/50"
              )}
              onClick={() => handleMedicalExamToggle('aptitude')}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center shrink-0",
                  medicalExams.aptitude ? "bg-success/20" : "bg-muted"
                )}>
                  <Activity className={cn("h-5 w-5", medicalExams.aptitude ? "text-success" : "text-muted-foreground")} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-medium text-foreground text-sm">Exame de Aptidão</h3>
                    <Checkbox checked={medicalExams.aptitude} className="shrink-0" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Avaliação de habilidades e reflexos</p>
                </div>
              </div>
            </div>

            {/* Física e Mental */}
            <div 
              className={cn(
                "p-4 rounded-xl border-2 cursor-pointer transition-all",
                medicalExams.physicalMental 
                  ? "border-success bg-success/5" 
                  : "border-border hover:border-primary/50"
              )}
              onClick={() => handleMedicalExamToggle('physicalMental')}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center shrink-0",
                  medicalExams.physicalMental ? "bg-success/20" : "bg-muted"
                )}>
                  <HeartPulse className={cn("h-5 w-5", medicalExams.physicalMental ? "text-success" : "text-muted-foreground")} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-medium text-foreground text-sm">Física e Mental</h3>
                    <Checkbox checked={medicalExams.physicalMental} className="shrink-0" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Exame médico de sanidade física e mental</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Info Card */}
        <div className="card-elevated p-4 mb-8 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <p className="font-medium text-foreground">Confirmação dupla</p>
              <p className="text-sm text-muted-foreground">
                Os resultados só são validados após confirmação do aluno e do instrutor. 
                A taxa de aprovação do instrutor é calculada apenas com exames confirmados por ambos.
              </p>
            </div>
          </div>
        </div>

        {/* Exams List */}
        <div className="space-y-4">
          {exams.map((exam) => (
            <div key={exam.id} className="card-elevated p-6">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                <div className={cn(
                  "h-14 w-14 rounded-xl flex items-center justify-center",
                  exam.exam_type === 'theoretical' ? "gradient-primary" : "gradient-accent"
                )}>
                  {exam.exam_type === 'theoretical' ? (
                    <BookOpen className="h-7 w-7 text-primary-foreground" />
                  ) : (
                    <Car className="h-7 w-7 text-accent-foreground" />
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-semibold text-foreground">
                      Exame {exam.exam_type === 'theoretical' ? 'Teórico' : 'Prático'}
                    </h3>
                    <Badge variant="outline">Categoria {exam.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Data: {format(new Date(exam.exam_date), "dd/MM/yyyy", { locale: ptBR })}
                  </p>
                  {exam.document_url && (
                    <SecureDocumentLink 
                      documentUrl={exam.document_url}
                      bucket="exam-documents"
                      label="Ver comprovante"
                      className="text-primary text-sm flex items-center gap-1 hover:underline cursor-pointer mt-1"
                    />
                  )}
                </div>

                <div className="flex flex-col lg:items-end gap-3">
                  {getStatusBadge(exam)}
                  
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <span className={cn(
                        "h-2 w-2 rounded-full",
                        exam.confirmed_by_student ? "bg-success" : "bg-muted"
                      )} />
                      <span className="text-muted-foreground">Aluno</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={cn(
                        "h-2 w-2 rounded-full",
                        exam.confirmed_by_instructor ? "bg-success" : "bg-muted"
                      )} />
                      <span className="text-muted-foreground">Instrutor</span>
                    </div>
                  </div>
                </div>

                {!exam.confirmed_by_student && exam.status === 'pending' && (
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      className="border-success text-success hover:bg-success/10"
                      onClick={() => handleConfirmResult(exam.id, true)}
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Aprovei
                    </Button>
                    <Button 
                      variant="outline"
                      className="border-destructive text-destructive hover:bg-destructive/10"
                      onClick={() => handleConfirmResult(exam.id, false)}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Reprovei
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {exams.length === 0 && (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <BookOpen className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhum exame registrado</h3>
            <p className="text-muted-foreground mb-4">
              Registre seus exames para acompanhar seu progresso
            </p>
            {hasInstructor && (
              <Button variant="hero" onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Registrar primeiro exame
              </Button>
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default StudentExams;
