import { useState, useEffect, useMemo } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useSchedules } from '@/hooks/useSchedules';
import { useToast } from '@/hooks/use-toast';
import { format, isSameDay, startOfMonth, endOfMonth, addHours, isBefore } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { ptBR } from 'date-fns/locale';
import { CalendarDays, Clock, Car, Bike, BookOpen, Loader2, ChevronLeft, ChevronRight, X, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface LessonToReschedule {
  id: string;
  instructor_id: string;
  lesson_type: string;
  scheduled_date: string;
  scheduled_time: string;
}

const StudentSchedule = () => {
  const { schedules, isLoading, updateScheduleStatus, rescheduleLesson } = useSchedules();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [lessonToCancel, setLessonToCancel] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  
  // Reschedule state
  const [rescheduleDialogOpen, setRescheduleDialogOpen] = useState(false);
  const [lessonToReschedule, setLessonToReschedule] = useState<LessonToReschedule | null>(null);
  const [newDate, setNewDate] = useState<Date | undefined>(undefined);
  const [newTime, setNewTime] = useState<string>('');
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [instructorBusyTimes, setInstructorBusyTimes] = useState<string[]>([]);
  const [instructorAvailability, setInstructorAvailability] = useState<{ start: string; end: string } | null>(null);
  const [instructorAvailableDays, setInstructorAvailableDays] = useState<string[]>([]);
  const [isLoadingAvailability, setIsLoadingAvailability] = useState(false);

  // Filter schedules that are not cancelled (for calendar highlighting and stats)
  const activeSchedules = schedules.filter(s => s.status !== 'cancelled');

  // Get dates with scheduled lessons for calendar highlighting (include cancelled for visibility)
  const scheduledDates = schedules.map(s => new Date(s.scheduled_date));

  // Get ALL lessons for selected date (including cancelled)
  const selectedDateLessons = selectedDate
    ? schedules.filter(s => isSameDay(new Date(s.scheduled_date), selectedDate))
    : [];

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <Badge className="bg-success/10 text-success border-success/20">Confirmada</Badge>;
      case 'completed':
        return <Badge className="bg-primary/10 text-primary border-primary/20">Concluída</Badge>;
      case 'pending':
        return <Badge variant="outline">Pendente</Badge>;
      case 'cancelled':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Cancelada</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Get lesson type icon and label
  const getLessonInfo = (type: string) => {
    switch (type) {
      case 'practical_car':
        return { icon: <Car className="h-4 w-4" />, label: 'Prática Carro' };
      case 'practical_motorcycle':
        return { icon: <Bike className="h-4 w-4" />, label: 'Prática Moto' };
      case 'theoretical':
        return { icon: <BookOpen className="h-4 w-4" />, label: 'Teórica' };
      default:
        return { icon: <Car className="h-4 w-4" />, label: type };
    }
  };

  // Handle cancel lesson
  const handleCancelClick = (lessonId: string) => {
    setLessonToCancel(lessonId);
    setCancelDialogOpen(true);
  };

  const confirmCancelLesson = async () => {
    if (!lessonToCancel) return;
    
    setIsCancelling(true);
    const result = await updateScheduleStatus(lessonToCancel, 'cancelled');
    setIsCancelling(false);
    setCancelDialogOpen(false);
    setLessonToCancel(null);
    
    if (result.success) {
      toast({
        title: 'Aula cancelada',
        description: 'Sua aula foi cancelada com sucesso.',
      });
    } else {
      toast({
        title: 'Erro ao cancelar',
        description: 'Não foi possível cancelar a aula. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  // Handle reschedule lesson
  const handleRescheduleClick = async (lesson: LessonToReschedule) => {
    setLessonToReschedule(lesson);
    setNewDate(undefined);
    setNewTime('');
    setInstructorBusyTimes([]);
    setInstructorAvailability(null);
    setInstructorAvailableDays([]);
    setRescheduleDialogOpen(true);

    // Fetch instructor's available days immediately
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('available_days, available_start_time, available_end_time')
        .eq('id', lesson.instructor_id)
        .single();

      if (profile) {
        setInstructorAvailableDays(profile.available_days || []);
        setInstructorAvailability({
          start: profile.available_start_time || '08:00',
          end: profile.available_end_time || '18:00',
        });
      }
    } catch (error) {
      console.error('Error fetching instructor profile:', error);
    }
  };

  // Reset time when date changes
  const handleNewDateChange = (date: Date | undefined) => {
    setNewDate(date);
    setNewTime(''); // Reset time when date changes
  };

  const confirmRescheduleLesson = async () => {
    if (!lessonToReschedule || !newDate || !newTime) return;
    
    setIsRescheduling(true);
    const result = await rescheduleLesson(lessonToReschedule.id, format(newDate, 'yyyy-MM-dd'), newTime, lessonToReschedule.instructor_id);
    setIsRescheduling(false);
    
    if (result.success) {
      setRescheduleDialogOpen(false);
      setLessonToReschedule(null);
      setNewDate(undefined);
      setNewTime('');
      toast({
        title: 'Aula reagendada!',
        description: `Sua aula foi reagendada para ${format(newDate, "dd 'de' MMMM", { locale: ptBR })} às ${newTime}.`,
      });
    } else {
      toast({
        title: 'Erro ao reagendar',
        description: result.error || 'Não foi possível reagendar a aula. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  // Map day names to day of week numbers (0 = Sunday, 1 = Monday, etc.)
  const dayNameToNumber: Record<string, number> = {
    'domingo': 0,
    'segunda': 1,
    'terça': 2,
    'quarta': 3,
    'quinta': 4,
    'sexta': 5,
    'sábado': 6,
  };

  // Check if a date is on an available day for the instructor
  const isDateAvailable = (date: Date) => {
    if (instructorAvailableDays.length === 0) return true; // If no days set, allow all
    const dayOfWeek = date.getDay();
    return instructorAvailableDays.some(day => dayNameToNumber[day.toLowerCase()] === dayOfWeek);
  };

  // Fetch busy times when date changes
  useEffect(() => {
    const fetchBusyTimes = async () => {
      if (!lessonToReschedule || !newDate) {
        setInstructorBusyTimes([]);
        return;
      }

      setIsLoadingAvailability(true);
      
      try {
        // Fetch instructor's busy times for the selected date
        const { data: busySchedules } = await supabase
          .from('schedules')
          .select('scheduled_time')
          .eq('instructor_id', lessonToReschedule.instructor_id)
          .eq('scheduled_date', format(newDate, 'yyyy-MM-dd'))
          .neq('id', lessonToReschedule.id) // Exclude the current lesson
          .neq('status', 'cancelled');

        if (busySchedules) {
          setInstructorBusyTimes(busySchedules.map(s => s.scheduled_time));
        }
      } catch (error) {
        console.error('Error fetching busy times:', error);
      } finally {
        setIsLoadingAvailability(false);
      }
    };

    fetchBusyTimes();
  }, [lessonToReschedule, newDate]);

  // Generate available time slots based on instructor's availability
  const availableTimeSlots = useMemo(() => {
    if (!instructorAvailability) return [];

    const slots: string[] = [];
    const startHour = parseInt(instructorAvailability.start.split(':')[0], 10);
    const endHour = parseInt(instructorAvailability.end.split(':')[0], 10);

    for (let hour = startHour; hour < endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00`;
      // Filter out busy times
      if (!instructorBusyTimes.includes(timeString)) {
        slots.push(timeString);
      }
    }

    return slots;
  }, [instructorAvailability, instructorBusyTimes]);

  // Get upcoming lessons count per month
  const currentMonthLessons = activeSchedules.filter(s => {
    const date = new Date(s.scheduled_date);
    return date >= startOfMonth(currentMonth) && date <= endOfMonth(currentMonth);
  });

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Minha Agenda</h1>
          <p className="text-muted-foreground">
            Visualize e acompanhe suas aulas agendadas
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-primary" />
                    Calendário de Aulas
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)))}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm font-medium min-w-[120px] text-center">
                      {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)))}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  {currentMonthLessons.length} aula{currentMonthLessons.length !== 1 ? 's' : ''} neste mês
                </p>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  month={currentMonth}
                  onMonthChange={setCurrentMonth}
                  locale={ptBR}
                  className="w-full"
                  modifiers={{
                    scheduled: scheduledDates,
                  }}
                  modifiersStyles={{
                    scheduled: {
                      fontWeight: 'bold',
                      color: 'hsl(var(--primary))',
                    },
                  }}
                  classNames={{
                    months: "w-full",
                    month: "w-full",
                    table: "w-full border-collapse",
                    head_row: "flex w-full",
                    head_cell: "text-muted-foreground rounded-md w-full font-normal text-sm",
                    row: "flex w-full mt-2",
                    cell: "relative p-0 text-center text-sm focus-within:relative focus-within:z-20 w-full h-12",
                    day: "h-12 w-full p-0 font-normal aria-selected:opacity-100 hover:bg-accent hover:text-accent-foreground rounded-lg transition-colors flex items-center justify-center text-foreground",
                    day_selected: "bg-primary !text-primary-foreground hover:bg-primary hover:!text-primary-foreground focus:bg-primary focus:!text-primary-foreground",
                    day_today: "bg-accent text-accent-foreground",
                    nav: "hidden",
                  }}
                />

                {/* Legend */}
                <div className="flex items-center gap-4 mt-4 pt-4 border-t">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-primary" />
                    <span className="text-sm text-muted-foreground">Dia com aula</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-accent" />
                    <span className="text-sm text-muted-foreground">Hoje</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Selected Day Details */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {selectedDate 
                    ? format(selectedDate, "dd 'de' MMMM", { locale: ptBR })
                    : 'Selecione uma data'
                  }
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDateLessons.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateLessons.map((lesson) => {
                      const lessonInfo = getLessonInfo(lesson.lesson_type);
                      return (
                        <div
                          key={lesson.id}
                          className="p-4 rounded-xl bg-muted/50 space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-primary">
                              {lessonInfo.icon}
                              <span className="font-medium">{lessonInfo.label}</span>
                            </div>
                            {getStatusBadge(lesson.status)}
                          </div>
                          
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>{lesson.scheduled_time.slice(0, 5)}</span>
                            <span className="text-muted-foreground/50">•</span>
                            <span>50 min</span>
                          </div>

                          {'instructor' in lesson && lesson.instructor && (
                            <div className="flex items-center gap-2 pt-2 border-t">
                              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-medium">
                                {lesson.instructor.full_name?.charAt(0) || 'I'}
                              </div>
                              <div>
                                <p className="text-sm font-medium">{lesson.instructor.full_name}</p>
                                <p className="text-xs text-muted-foreground">Instrutor</p>
                              </div>
                            </div>
                          )}

                          {/* Action buttons for pending/confirmed lessons */}
                          {(lesson.status === 'pending' || lesson.status === 'confirmed') && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1"
                                onClick={() => handleRescheduleClick({
                                  id: lesson.id,
                                  instructor_id: lesson.instructor_id,
                                  lesson_type: lesson.lesson_type,
                                  scheduled_date: lesson.scheduled_date,
                                  scheduled_time: lesson.scheduled_time,
                                })}
                              >
                                <RefreshCw className="h-4 w-4 mr-2" />
                                Reagendar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1 text-destructive border-destructive/30 hover:bg-destructive/10"
                                onClick={() => handleCancelClick(lesson.id)}
                              >
                                <X className="h-4 w-4 mr-2" />
                                Cancelar
                              </Button>
                            </div>
                          )}

                          {/* Reschedule button for cancelled lessons */}
                          {lesson.status === 'cancelled' && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full mt-2"
                              onClick={() => handleRescheduleClick({
                                id: lesson.id,
                                instructor_id: lesson.instructor_id,
                                lesson_type: lesson.lesson_type,
                                scheduled_date: lesson.scheduled_date,
                                scheduled_time: lesson.scheduled_time,
                              })}
                            >
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Reagendar aula
                            </Button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CalendarDays className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">
                      {selectedDate 
                        ? 'Nenhuma aula neste dia'
                        : 'Selecione uma data no calendário'
                      }
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Resumo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total de aulas</span>
                  <span className="font-medium">{schedules.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Concluídas</span>
                  <span className="font-medium text-success">
                    {schedules.filter(s => s.status === 'completed').length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Pendentes</span>
                  <span className="font-medium text-warning">
                    {schedules.filter(s => s.status === 'pending').length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Confirmadas</span>
                  <span className="font-medium text-primary">
                    {schedules.filter(s => s.status === 'confirmed').length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Canceladas</span>
                  <span className="font-medium text-destructive">
                    {schedules.filter(s => s.status === 'cancelled').length}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Action Button */}
            <Link to="/student/instructors">
              <Button variant="hero" className="w-full">
                Agendar nova aula
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancelar aula?</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja cancelar esta aula? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isCancelling}>Voltar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmCancelLesson}
              disabled={isCancelling}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isCancelling ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Cancelando...
                </>
              ) : (
                'Sim, cancelar'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reschedule Dialog */}
      <Dialog open={rescheduleDialogOpen} onOpenChange={setRescheduleDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reagendar aula</DialogTitle>
            <DialogDescription>
              Escolha uma nova data e horário para sua aula.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Nova data</Label>
              <p className="text-xs text-muted-foreground">
                Agendamentos devem ser feitos com no mínimo 24h de antecedência.
                {instructorAvailableDays.length > 0 && (
                  <> Dias disponíveis: {instructorAvailableDays.join(', ')}.</>
                )}
              </p>
              <Calendar
                mode="single"
                selected={newDate}
                onSelect={handleNewDateChange}
                locale={ptBR}
                disabled={(date) => {
                  const minDate = addHours(new Date(), 24);
                  return isBefore(date, minDate) || !isDateAvailable(date);
                }}
                className="rounded-md border pointer-events-auto"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Novo horário</Label>
              {isLoadingAvailability ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-sm text-muted-foreground">Carregando horários...</span>
                </div>
              ) : availableTimeSlots.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">
                  Nenhum horário disponível nesta data. Escolha outra data.
                </p>
              ) : (
                <Select value={newTime} onValueChange={setNewTime}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um horário" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTimeSlots.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setRescheduleDialogOpen(false)}
              disabled={isRescheduling}
            >
              Cancelar
            </Button>
            <Button
              onClick={confirmRescheduleLesson}
              disabled={isRescheduling || !newDate || !newTime}
            >
              {isRescheduling ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Reagendando...
                </>
              ) : (
                'Confirmar reagendamento'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default StudentSchedule;
