import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/cards/StatCard';
import { useAuth } from '@/contexts/AuthContext';
import { useSchedules } from '@/hooks/useSchedules';
import { useExams } from '@/hooks/useExams';
import { supabase } from '@/integrations/supabase/client';
import { PracticalLessonsCard } from '@/components/student/PracticalLessonsCard';
import { PracticalExamCard } from '@/components/student/PracticalExamCard';
import { BookOpen, Car, Trophy, CheckCircle, Clock, Target, Loader2 } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Milestone {
  id: number;
  title: string;
  completed: boolean;
  date: string | null;
}

const StudentProgress = () => {
  const { user } = useAuth();
  const { schedules, isLoading: schedulesLoading, refetch: refetchSchedules } = useSchedules();
  const { exams, isLoading: examsLoading, refetch: refetchExams } = useExams();
  const [profileCreatedAt, setProfileCreatedAt] = useState<string | null>(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);

  useEffect(() => {
    if (user) {
      fetchProfileData();
    }
  }, [user]);

  const fetchProfileData = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('profiles')
      .select('created_at')
      .eq('id', user.id)
      .single();
    
    if (data) {
      setProfileCreatedAt(data.created_at);
    }
    setIsLoadingProfile(false);
  };

  const handleDataRefresh = () => {
    refetchSchedules();
    refetchExams();
  };

  // Calculate real data from schedules and exams
  const mySchedules = schedules.filter(s => s.student_id === user?.id);
  const myExams = exams.filter(e => e.student_id === user?.id);

  // Completed practical lessons
  const completedPracticalLessons = mySchedules.filter(
    s => s.status === 'completed' && s.lesson_type !== 'theoretical'
  );
  
  // Completed theoretical lessons
  const completedTheoreticalLessons = mySchedules.filter(
    s => s.status === 'completed' && s.lesson_type === 'theoretical'
  );

  // Theoretical exam status
  const theoreticalExams = myExams.filter(e => e.exam_type === 'theoretical');
  const approvedTheoreticalExam = theoreticalExams.find(
    e => e.status === 'approved' && e.confirmed_by_student && e.confirmed_by_instructor
  );

  // Practical exam status
  const practicalExams = myExams.filter(e => e.exam_type === 'practical');
  const approvedPracticalExam = practicalExams.find(
    e => e.status === 'approved' && e.confirmed_by_student && e.confirmed_by_instructor
  );

  // Calculate percentages
  const practicalLessonsCount = completedPracticalLessons.length;
  const practicalLessonsPercent = Math.min(Math.round((practicalLessonsCount / 20) * 100), 100);
  
  const hasCompletedTheoretical = approvedTheoreticalExam !== undefined;

  // Days in process
  const daysInProcess = profileCreatedAt 
    ? differenceInDays(new Date(), new Date(profileCreatedAt))
    : 0;
  const startDate = profileCreatedAt 
    ? format(new Date(profileCreatedAt), 'dd/MM/yyyy', { locale: ptBR })
    : '-';

  // Build milestones based on real data
  const milestones: Milestone[] = [
    { 
      id: 1, 
      title: 'Cadastro completo', 
      completed: true, 
      date: profileCreatedAt ? format(new Date(profileCreatedAt), 'dd/MM/yyyy', { locale: ptBR }) : null
    },
    { 
      id: 2, 
      title: 'Exame teórico aprovado', 
      completed: !!approvedTheoreticalExam, 
      date: approvedTheoreticalExam 
        ? format(new Date(approvedTheoreticalExam.exam_date), 'dd/MM/yyyy', { locale: ptBR }) 
        : null 
    },
    { 
      id: 3, 
      title: '10 aulas práticas', 
      completed: practicalLessonsCount >= 10, 
      date: practicalLessonsCount >= 10 && completedPracticalLessons[9]
        ? format(new Date(completedPracticalLessons[9].scheduled_date), 'dd/MM/yyyy', { locale: ptBR })
        : null
    },
    { 
      id: 4, 
      title: '20 aulas práticas', 
      completed: practicalLessonsCount >= 20, 
      date: practicalLessonsCount >= 20 && completedPracticalLessons[19]
        ? format(new Date(completedPracticalLessons[19].scheduled_date), 'dd/MM/yyyy', { locale: ptBR })
        : null
    },
    { 
      id: 5, 
      title: 'Exame prático aprovado', 
      completed: !!approvedPracticalExam, 
      date: approvedPracticalExam 
        ? format(new Date(approvedPracticalExam.exam_date), 'dd/MM/yyyy', { locale: ptBR }) 
        : null 
    },
    { 
      id: 6, 
      title: 'CNH emitida', 
      completed: !!approvedPracticalExam,
      date: approvedPracticalExam 
        ? format(new Date(approvedPracticalExam.exam_date), 'dd/MM/yyyy', { locale: ptBR }) 
        : null 
    },
  ];

  const completedMilestones = milestones.filter(m => m.completed).length;
  const progressPercent = (completedMilestones / milestones.length) * 100;

  // Total lessons (all types)
  const totalCompletedLessons = mySchedules.filter(s => s.status === 'completed').length;

  // Pending lessons
  const pendingLessons = mySchedules.filter(
    s => s.status === 'pending' || s.status === 'confirmed'
  ).length;

  const isLoading = schedulesLoading || examsLoading || isLoadingProfile;

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  // Prepare schedules with instructor info for the card
  const schedulesWithInstructor = mySchedules.map(s => ({
    ...s,
    instructor: (s as any).instructor,
  }));

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Meu Progresso</h1>
          <p className="text-muted-foreground">
            Acompanhe sua jornada até a CNH
          </p>
        </div>

        {/* Overall Progress */}
        <div className="card-elevated p-8 mb-8">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="relative">
              <div className="h-40 w-40 rounded-full border-8 border-muted flex items-center justify-center">
                <div className="text-center">
                  <span className="text-4xl font-bold text-foreground">{Math.round(progressPercent)}%</span>
                  <p className="text-sm text-muted-foreground">Completo</p>
                </div>
              </div>
              <svg className="absolute inset-0 h-40 w-40 -rotate-90">
                <circle
                  cx="80"
                  cy="80"
                  r="72"
                  fill="none"
                  stroke="hsl(var(--primary))"
                  strokeWidth="8"
                  strokeDasharray={`${progressPercent * 4.52} 452`}
                  strokeLinecap="round"
                />
              </svg>
            </div>
            
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-foreground mb-2">
                {progressPercent === 100 
                  ? `Parabéns, ${user?.name?.split(' ')[0]}! 🎉`
                  : progressPercent >= 50 
                    ? `Você está quase lá, ${user?.name?.split(' ')[0]}!`
                    : `Continue assim, ${user?.name?.split(' ')[0]}!`
                }
              </h2>
              <p className="text-muted-foreground mb-4">
                {progressPercent === 100 
                  ? 'Você completou todas as etapas!'
                  : `Complete mais ${milestones.length - completedMilestones} etapa${milestones.length - completedMilestones !== 1 ? 's' : ''} para conquistar sua CNH`
                }
              </p>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-xl bg-success/10">
                  <p className="text-2xl font-bold text-success">{completedMilestones}</p>
                  <p className="text-xs text-muted-foreground">Concluídas</p>
                </div>
                <div className="text-center p-3 rounded-xl bg-accent/10">
                  <p className="text-2xl font-bold text-accent">{milestones.length - completedMilestones}</p>
                  <p className="text-xs text-muted-foreground">Pendentes</p>
                </div>
                <div className="text-center p-3 rounded-xl bg-primary/10">
                  <p className="text-2xl font-bold text-primary">{totalCompletedLessons}</p>
                  <p className="text-xs text-muted-foreground">Aulas feitas</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Exame Teórico"
            value={hasCompletedTheoretical ? 'Aprovado' : 'Pendente'}
            description={hasCompletedTheoretical ? 'Parabéns!' : 'Próxima etapa'}
            icon={<BookOpen className="h-6 w-6" />}
          />
          <StatCard
            title="Aulas Práticas"
            value={`${practicalLessonsPercent}%`}
            description={`${practicalLessonsCount} de 20 aulas`}
            icon={<Car className="h-6 w-6" />}
          />
          <StatCard
            title="Aulas Agendadas"
            value={pendingLessons.toString()}
            description={pendingLessons === 1 ? 'Aula pendente' : 'Aulas pendentes'}
            icon={<Target className="h-6 w-6" />}
          />
          <StatCard
            title="Tempo no Processo"
            value={`${daysInProcess} dias`}
            description={`Início: ${startDate}`}
            icon={<Clock className="h-6 w-6" />}
          />
        </div>

        {/* Interactive Progress Cards */}
        <div className="card-elevated p-6 mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-6">Aulas e Exames</h2>
          <div className="space-y-4">
            {/* Practical Lessons Card */}
            <PracticalLessonsCard 
              schedules={schedulesWithInstructor}
              onLessonCompleted={handleDataRefresh}
            />

            {/* Practical Exam Card */}
            <PracticalExamCard 
              practicalLessonsCompleted={practicalLessonsCount}
              practicalExams={practicalExams}
              onExamUpdated={handleDataRefresh}
            />
          </div>
        </div>

        {/* Milestones */}
        <div className="card-elevated p-6">
          <h2 className="text-xl font-semibold text-foreground mb-6">Etapas do Processo</h2>
          
          <div className="space-y-4">
            {milestones.map((milestone, index) => (
              <div key={milestone.id} className="flex items-center gap-4">
                <div className="relative">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                    milestone.completed 
                      ? 'bg-success text-success-foreground' 
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {milestone.completed ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <span className="font-semibold">{index + 1}</span>
                    )}
                  </div>
                  {index < milestones.length - 1 && (
                    <div className={`absolute left-1/2 top-10 h-8 w-0.5 -translate-x-1/2 ${
                      milestone.completed ? 'bg-success' : 'bg-muted'
                    }`} />
                  )}
                </div>
                
                <div className="flex-1 py-2">
                  <p className={`font-medium ${
                    milestone.completed ? 'text-foreground' : 'text-muted-foreground'
                  }`}>
                    {milestone.title}
                  </p>
                  {milestone.date && (
                    <p className="text-sm text-muted-foreground">
                      Concluído em {milestone.date}
                    </p>
                  )}
                </div>
                
                {milestone.completed && (
                  <span className="text-success text-sm font-medium">✓</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default StudentProgress;
