import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/cards/StatCard';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from '@/contexts/LocationContext';
import { useSchedules } from '@/hooks/useSchedules';
import { useExams } from '@/hooks/useExams';
import { CompletedLessonsCard } from '@/components/student/CompletedLessonsCard';
import { CompletionForecastCard } from '@/components/student/CompletionForecastCard';
import { RegisterExamResultDialog } from '@/components/student/RegisterExamResultDialog';
import { GamificationWidget } from '@/components/student/GamificationWidget';
import { ExamPreparationCenter } from '@/components/student/ExamPreparationCenter';
import { PendingLinkBanner } from '@/components/student/PendingLinkBanner';
import { LinkedInstructorCard } from '@/components/student/LinkedInstructorCard';
import { AvatarUpload } from '@/components/student/AvatarUpload';
import { Link } from 'react-router-dom';
import { BookOpen, Car, Calendar, Trophy, ArrowRight, Clock, CheckCircle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const StudentDashboard = () => {
  const { user } = useAuth();
  const { location } = useLocation();
  const { schedules, isLoading: schedulesLoading, getNextSchedule } = useSchedules();
  const { exams, isLoading: examsLoading, refetch: refetchExams } = useExams();
  const [isExamDialogOpen, setIsExamDialogOpen] = useState(false);

  const nextSchedule = getNextSchedule();
  
  // Calculate progress from real data
  const theoreticalExams = exams.filter(e => e.exam_type === 'theoretical');
  const approvedTheoretical = theoreticalExams.filter(
    e => e.status === 'approved' && e.confirmed_by_student && e.confirmed_by_instructor
  );
  
  const practicalClasses = schedules.filter(
    s => s.lesson_type !== 'theoretical' && s.status === 'completed'
  );

  // Get the instructor from the most recent completed practical class
  const lastPracticalClass = schedules.find(
    s => s.lesson_type !== 'theoretical' && s.status === 'completed'
  );
  const practicalInstructorId = lastPracticalClass?.instructor_id || '';

  // Check practical exam status
  const practicalExams = exams.filter(e => e.exam_type === 'practical');
  const approvedPracticalExam = practicalExams.find(
    e => e.status === 'approved' && e.confirmed_by_student
  );
  const pendingPracticalExam = practicalExams.find(
    e => e.status === 'pending' && !e.confirmed_by_student
  );

  const REQUIRED_LESSONS = 2;
  const isPracticalExamUnlocked = practicalClasses.length >= REQUIRED_LESSONS;

  const isLoading = schedulesLoading || examsLoading;

  // Format next class info
  const getNextClassInfo = () => {
    if (!nextSchedule) return { value: 'Nenhuma', description: 'Agende uma aula' };
    
    const scheduleDate = new Date(`${nextSchedule.scheduled_date}T${nextSchedule.scheduled_time}`);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const isToday = scheduleDate.toDateString() === today.toDateString();
    const isTomorrow = scheduleDate.toDateString() === tomorrow.toDateString();

    const dateStr = isToday 
      ? 'Hoje' 
      : isTomorrow 
        ? 'Amanhã' 
        : format(scheduleDate, "dd/MM", { locale: ptBR });
    
    const timeStr = format(scheduleDate, "HH:mm");
    const typeStr = nextSchedule.lesson_type === 'theoretical' 
      ? 'Teórica' 
      : nextSchedule.lesson_type === 'practical_car' 
        ? 'Prática Carro' 
        : 'Prática Moto';

    return { value: dateStr, description: `${timeStr} - ${typeStr}` };
  };

  const nextClassInfo = getNextClassInfo();

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Pending Link Banner */}
        <PendingLinkBanner />

        {/* Header with Avatar */}
        <div className="flex items-center gap-6 mb-6">
          <AvatarUpload 
            currentAvatarUrl={user?.avatar} 
            userName={user?.name || 'Aluno'} 
          />
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Olá, {user?.name?.split(' ')[0]}! 👋
            </h1>
            <p className="text-muted-foreground">
              Acompanhe seu progresso para conquistar sua CNH
            </p>
          </div>
        </div>

        {/* Gamification Widget */}
        <div className="mb-8">
          <GamificationWidget />
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Aulas Práticas"
            value={practicalClasses.length.toString()}
            description="de 10 recomendadas"
            icon={<Car className="h-6 w-6" />}
          />
          <StatCard
            title="Exame Teórico"
            value={approvedTheoretical.length > 0 ? "Aprovado" : "Pendente"}
            description={approvedTheoretical.length > 0 ? "Parabéns!" : "Próxima etapa"}
            icon={<BookOpen className="h-6 w-6" />}
          />
          <StatCard
            title="Próxima Aula"
            value={nextClassInfo.value}
            description={nextClassInfo.description}
            icon={<Calendar className="h-6 w-6" />}
          />
          <StatCard
            title="Progresso Geral"
            value={`${Math.min(Math.round((practicalClasses.length / 10) * 100), 100)}%`}
            description="Aulas práticas"
            icon={<Trophy className="h-6 w-6" />}
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Card */}
            <div className="card-elevated p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">Meu Progresso</h2>
              
              <div className="space-y-6">
                {/* Theoretical Exam */}
                <div className="flex items-center gap-4">
                  <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${
                    approvedTheoretical.length > 0 ? 'bg-success/10' : 'bg-muted'
                  }`}>
                    {approvedTheoretical.length > 0 ? (
                      <CheckCircle className="h-6 w-6 text-success" />
                    ) : (
                      <Clock className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Exame Teórico</p>
                    <p className="text-sm text-muted-foreground">
                      {approvedTheoretical.length > 0 
                        ? `Aprovado em ${format(new Date(approvedTheoretical[0].exam_date), "dd/MM/yyyy", { locale: ptBR })}`
                        : 'Aguardando realização'}
                    </p>
                  </div>
                  {approvedTheoretical.length > 0 && (
                    <span className="text-success font-medium">✓ Concluído</span>
                  )}
                </div>

                {/* Practical Classes */}
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Car className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Aulas Práticas</p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full gradient-primary rounded-full transition-all" 
                          style={{ width: `${Math.min((practicalClasses.length / 10) * 100, 100)}%` }} 
                        />
                      </div>
                      <span className="text-sm text-muted-foreground">{practicalClasses.length}/10</span>
                    </div>
                  </div>
                </div>

                {/* Practical Exam */}
                <div className="flex items-center gap-4">
                  <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${
                    approvedPracticalExam ? 'bg-success/10' : isPracticalExamUnlocked ? 'bg-primary/10' : 'bg-muted'
                  }`}>
                    {approvedPracticalExam ? (
                      <CheckCircle className="h-6 w-6 text-success" />
                    ) : (
                      <Trophy className={`h-6 w-6 ${
                        isPracticalExamUnlocked ? 'text-primary' : 'text-muted-foreground'
                      }`} />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Exame Prático</p>
                    <p className="text-sm text-muted-foreground">
                      {approvedPracticalExam
                        ? `Aprovado em ${format(new Date(approvedPracticalExam.exam_date), "dd/MM/yyyy", { locale: ptBR })}`
                        : isPracticalExamUnlocked 
                          ? 'Disponível para agendamento'
                          : `Disponível após ${REQUIRED_LESSONS} aulas práticas (${practicalClasses.length}/${REQUIRED_LESSONS})`}
                    </p>
                  </div>
                  {approvedPracticalExam ? (
                    <span className="text-success font-medium">✓ Concluído</span>
                  ) : isPracticalExamUnlocked ? (
                    <Button
                      size="sm"
                      onClick={() => setIsExamDialogOpen(true)}
                    >
                      Registrar resultado
                    </Button>
                  ) : (
                    <span className="text-muted-foreground text-sm">Bloqueado</span>
                  )}
                </div>
              </div>
            </div>

            {/* Upcoming Classes */}
            <div className="card-elevated p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-foreground">Próximas Aulas</h2>
                <Link to="/student/schedule">
                  <Button variant="ghost" size="sm">
                    Ver todas
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>

              <div className="space-y-4">
                {schedules.filter(s => s.status !== 'cancelled' && s.status !== 'completed').slice(0, 3).map((schedule) => {
                  const scheduleDate = new Date(`${schedule.scheduled_date}T${schedule.scheduled_time}`);
                  const typeLabel = schedule.lesson_type === 'theoretical' 
                    ? 'Teórica' 
                    : schedule.lesson_type === 'practical_car' 
                      ? 'Prática Carro' 
                      : 'Prática Moto';

                  return (
                    <div key={schedule.id} className="flex items-center gap-4 p-4 rounded-xl bg-muted/50">
                      <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                        {format(scheduleDate, "dd")}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{typeLabel}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(scheduleDate, "dd/MM", { locale: ptBR })} às {format(scheduleDate, "HH:mm")}
                        </p>
                      </div>
                      <span className="text-sm text-muted-foreground">50 min</span>
                    </div>
                  );
                })}

                {schedules.filter(s => s.status !== 'cancelled' && s.status !== 'completed').length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">Nenhuma aula agendada</p>
                    <Link to="/student/instructors">
                      <Button variant="hero">Agendar primeira aula</Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>

            {/* Exam Preparation Center */}
            <ExamPreparationCenter />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Linked Instructor */}
            <LinkedInstructorCard />
            {/* Completion Forecast */}
            <CompletionForecastCard 
              aulasConcluidas={practicalClasses.length}
            />

            {/* Review Instructors */}
            <CompletedLessonsCard />

            {/* Quick Actions */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Ações Rápidas</h3>
              <div className="space-y-3">
                <Link to="/student/schedule" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Minha agenda
                  </Button>
                </Link>
                <Link to="/student/instructors" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Car className="h-4 w-4 mr-2" />
                    Buscar instrutores
                  </Button>
                </Link>
                <Link to="/student/exams" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Meus exames
                  </Button>
                </Link>
                <Link to="/student/progress" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Trophy className="h-4 w-4 mr-2" />
                    Ver progresso
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Register Exam Result Dialog */}
        <RegisterExamResultDialog
          open={isExamDialogOpen}
          onOpenChange={setIsExamDialogOpen}
          instructorId={practicalInstructorId}
          onExamRegistered={() => {
            refetchExams();
          }}
        />
      </div>
    </MainLayout>
  );
};

export default StudentDashboard;
