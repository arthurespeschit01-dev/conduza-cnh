import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { BackButton } from '@/components/ui/back-button';
import { Shield } from 'lucide-react';

const PrivacyPolicy = () => {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <BackButton className="mb-6" />
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-3 rounded-full bg-primary/10">
                <Shield className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Política de Privacidade</h1>
            <p className="text-muted-foreground">Última atualização: Janeiro de 2026</p>
          </div>

          <Card>
            <CardContent className="prose prose-sm max-w-none p-6 space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">1. Informações Coletadas</h2>
                <p className="text-muted-foreground">
                  Coletamos informações que você nos fornece diretamente, como nome, e-mail, telefone, CPF e documentos necessários para o cadastro de instrutores.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">2. Uso das Informações</h2>
                <p className="text-muted-foreground">
                  Utilizamos suas informações para: fornecer nossos serviços, processar agendamentos, comunicar atualizações importantes e melhorar a experiência do usuário.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">3. Compartilhamento de Dados</h2>
                <p className="text-muted-foreground">
                  Compartilhamos informações limitadas entre alunos e instrutores para facilitar o contato e agendamento de aulas. Não vendemos seus dados a terceiros.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">4. Segurança</h2>
                <p className="text-muted-foreground">
                  Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações pessoais contra acesso não autorizado, alteração ou destruição.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">5. Seus Direitos</h2>
                <p className="text-muted-foreground">
                  Você tem direito a acessar, corrigir ou excluir seus dados pessoais. Para exercer esses direitos, entre em contato conosco através do e-mail contato@conduza.com.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">6. Cookies</h2>
                <p className="text-muted-foreground">
                  Utilizamos cookies para melhorar sua experiência de navegação e analisar o uso da plataforma. Você pode configurar seu navegador para recusar cookies.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">7. Contato</h2>
                <p className="text-muted-foreground">
                  Para dúvidas sobre esta política, entre em contato pelo e-mail contato@conduza.com ou telefone (11) 9999-9999.
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default PrivacyPolicy;
