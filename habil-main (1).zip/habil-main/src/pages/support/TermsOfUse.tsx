import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BackButton } from '@/components/ui/back-button';
import { FileText } from 'lucide-react';

const TermsOfUse = () => {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <BackButton className="mb-6" />
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-3 rounded-full bg-primary/10">
                <FileText className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Termos de Uso</h1>
            <p className="text-muted-foreground">Última atualização: Janeiro de 2026</p>
          </div>

          <Card>
            <CardContent className="prose prose-sm max-w-none p-6 space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">1. Aceitação dos Termos</h2>
                <p className="text-muted-foreground">
                  Ao acessar e usar a plataforma Conduza, você concorda em cumprir e estar vinculado a estes Termos de Uso. Se você não concordar com qualquer parte destes termos, não poderá acessar o serviço.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">2. Descrição do Serviço</h2>
                <p className="text-muted-foreground">
                  A Conduza é uma plataforma que conecta alunos a instrutores de direção qualificados. Facilitamos o agendamento de aulas práticas e o acompanhamento do progresso dos alunos.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">3. Cadastro e Conta</h2>
                <p className="text-muted-foreground">
                  Para utilizar nossos serviços, você deve criar uma conta fornecendo informações verdadeiras e atualizadas. Você é responsável por manter a confidencialidade de sua senha e conta.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">4. Responsabilidades do Usuário</h2>
                <p className="text-muted-foreground">
                  Os usuários comprometem-se a utilizar a plataforma de forma ética e legal, respeitando outros usuários e as leis de trânsito vigentes.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">5. Instrutores</h2>
                <p className="text-muted-foreground">
                  Os instrutores cadastrados são profissionais independentes. A Conduza não se responsabiliza diretamente pela qualidade das aulas, mas trabalha para manter apenas profissionais qualificados na plataforma.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">6. Cancelamentos</h2>
                <p className="text-muted-foreground">
                  Aulas podem ser canceladas conforme as políticas de cada instrutor. Recomendamos comunicar cancelamentos com antecedência mínima de 24 horas.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-foreground mb-3">7. Alterações nos Termos</h2>
                <p className="text-muted-foreground">
                  Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor imediatamente após sua publicação na plataforma.
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default TermsOfUse;
