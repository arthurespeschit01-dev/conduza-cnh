import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { BackButton } from '@/components/ui/back-button';
import { HelpCircle, Mail, Phone } from 'lucide-react';

const HelpCenter = () => {
  const faqs = [
    {
      question: 'Como encontro um instrutor na minha região?',
      answer: 'Após se cadastrar como aluno, você pode buscar instrutores disponíveis na sua cidade. Basta acessar a área de "Instrutores" no seu painel.'
    },
    {
      question: 'Como funciona o agendamento de aulas?',
      answer: 'Você pode agendar aulas diretamente com o instrutor escolhido através do sistema. Selecione o dia e horário disponível e confirme o agendamento.'
    },
    {
      question: 'Como me torno um instrutor na plataforma?',
      answer: 'Clique em "Seja Instrutor" e preencha o cadastro com seus dados e documentos. Após análise, você será aprovado para atender alunos.'
    },
    {
      question: 'Posso cancelar uma aula agendada?',
      answer: 'Sim, você pode cancelar aulas através do seu painel. Recomendamos avisar com antecedência para melhor organização.'
    },
    {
      question: 'Como entro em contato com o instrutor?',
      answer: 'Após selecionar um instrutor, você pode entrar em contato através do WhatsApp cadastrado por ele na plataforma.'
    }
  ];

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <BackButton className="mb-6" />
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="p-3 rounded-full bg-primary/10">
                <HelpCircle className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Central de Ajuda</h1>
            <p className="text-muted-foreground">Encontre respostas para suas dúvidas</p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Perguntas Frequentes</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent>{faq.answer}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Ainda precisa de ajuda?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">contato@conduza.com</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">(11) 9999-9999</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default HelpCenter;
