import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Check, X, Star, Zap, Crown } from 'lucide-react';
import { Link } from 'react-router-dom';

const Pricing = () => {
  const instructorPlans = [
    {
      name: 'Básico',
      icon: Zap,
      price: '49',
      description: 'Para instrutor iniciante ou que só quer presença digital',
      included: [
        'Perfil público na Conduza',
        'Botão de contato direto (WhatsApp)',
        'Exibição básica no marketplace',
        'Cadastro de alunos manual',
        'Registro simples de aulas'
      ],
      notIncluded: [
        'Destaque na busca',
        'Métricas avançadas',
        'Selo de aprovação'
      ],
      cta: 'Selecionar',
      href: '/register/instructor',
      popular: false
    },
    {
      name: 'Profissional',
      icon: Star,
      price: '97',
      description: 'Para instrutores ativos que querem mais alunos e autoridade',
      included: [
        'Tudo do Básico',
        'Perfil verificado (documentos + certificação)',
        'Destaque na busca da cidade/região',
        'Filtro por taxa de aprovação',
        'Registro completo de aulas por aluno',
        'Marcação de provas e resultados',
        'Cálculo automático de taxa de aprovação',
        'Selo "Instrutor com Alta Aprovação"',
        'Dashboard com métricas',
        'Prioridade no suporte'
      ],
      notIncluded: [],
      cta: 'Selecionar',
      href: '/register/instructor',
      popular: true
    },
    {
      name: 'Premium',
      icon: Crown,
      price: '149',
      description: 'Para instrutores top ou mini autoescolas independentes',
      included: [
        'Tudo do Profissional',
        'Topo do ranking da cidade',
        'Destaque visual premium no marketplace',
        'Página personalizada (URL própria)',
        'Relatórios avançados',
        'Gestão avançada de alunos',
        'Integração com WhatsApp Business',
        'Exportação de dados (PDF / Excel)',
        'Selo "Instrutor Premium"',
        'Acesso antecipado a novas features'
      ],
      notIncluded: [],
      cta: 'Selecionar',
      href: '/register/instructor',
      popular: false
    }
  ];

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <BackButton className="mb-6" />
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-foreground mb-2">Escolha seu plano</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Selecione o plano ideal para impulsionar sua carreira como instrutor
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {instructorPlans.map((plan) => {
            const IconComponent = plan.icon;
            return (
              <Card 
                key={plan.name} 
                className={`relative flex flex-col ${plan.popular ? 'border-primary shadow-lg ring-2 ring-primary' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                      MAIS POPULAR
                    </span>
                  </div>
                )}
                <CardHeader className="text-center pb-2">
                  <div className="flex justify-center mb-3">
                    <div className={`p-3 rounded-xl ${plan.popular ? 'bg-primary/10' : 'bg-muted'}`}>
                      <IconComponent className={`h-6 w-6 ${plan.popular ? 'text-primary' : 'text-muted-foreground'}`} />
                    </div>
                  </div>
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <CardDescription className="min-h-[40px]">{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-sm text-muted-foreground">R$ </span>
                    <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground">/mês</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-2 flex-1">
                    {plan.included.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <Check className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                    {plan.notIncluded.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-muted-foreground/50">
                        <X className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    asChild 
                    className="w-full mt-6" 
                    variant={plan.popular ? 'default' : 'outline'}
                  >
                    <Link to={plan.href}>{plan.cta}</Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Aluno info */}
        <div className="mt-16 text-center">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">Você é aluno?</h3>
              <p className="text-muted-foreground mb-4">
                O cadastro e uso da plataforma é totalmente gratuito para alunos.
              </p>
              <Button asChild variant="outline">
                <Link to="/register/student">Cadastrar como Aluno</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default Pricing;
