import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Car, GraduationCap, UserCog, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const Register = () => {
  const navigate = useNavigate();

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md">
          <BackButton fallbackPath="/" className="mb-6" />
          <div className="text-center mb-8">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl gradient-primary mb-4">
              <Car className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Criar conta na Conduza</h1>
            <p className="text-muted-foreground mt-2">
              Escolha como deseja se cadastrar
            </p>
          </div>

          <div className="card-elevated p-8">
            <div className="space-y-4">
              {/* Student Option */}
              <button
                onClick={() => navigate('/register/student')}
                className={cn(
                  "w-full flex items-center gap-4 p-5 rounded-xl border-2 transition-all text-left",
                  "border-border hover:border-primary hover:bg-primary/5 group"
                )}
              >
                <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center shrink-0">
                  <GraduationCap className="h-7 w-7 text-primary-foreground" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    Sou Aluno
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Quero aprender a dirigir e tirar minha CNH
                  </p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </button>

              {/* Instructor Option */}
              <button
                onClick={() => navigate('/register/instructor')}
                className={cn(
                  "w-full flex items-center gap-4 p-5 rounded-xl border-2 transition-all text-left",
                  "border-border hover:border-accent hover:bg-accent/5 group"
                )}
              >
                <div className="h-14 w-14 rounded-xl gradient-accent flex items-center justify-center shrink-0">
                  <UserCog className="h-7 w-7 text-accent-foreground" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-foreground group-hover:text-accent transition-colors">
                    Sou Instrutor
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Quero oferecer aulas e crescer minha carreira
                  </p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-accent transition-colors" />
              </button>
            </div>

            <div className="mt-8 text-center">
              <p className="text-muted-foreground">
                Já tem uma conta?{' '}
                <Link to="/login" className="text-primary font-semibold hover:underline">
                  Entrar
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Register;
