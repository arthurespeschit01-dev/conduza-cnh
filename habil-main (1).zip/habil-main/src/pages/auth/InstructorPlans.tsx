import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Check, X, Star, Zap, Crown, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { useInstructorPlan } from '@/hooks/useInstructorPlan';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

type PlanId = 'basic' | 'professional' | 'premium';

interface Plan {
  id: PlanId;
  name: string;
  price: number;
  icon: React.ReactNode;
  tagline: string;
  highlight?: boolean;
  features: { text: string; included: boolean }[];
}

const plans: Plan[] = [
  {
    id: 'basic',
    name: 'Básico',
    price: 49,
    icon: <Zap className="h-6 w-6" />,
    tagline: 'Para instrutor iniciante ou que só quer presença digital',
    features: [
      { text: 'Perfil público na Conduza', included: true },
      { text: 'Botão de contato direto (WhatsApp)', included: true },
      { text: 'Exibição básica no marketplace', included: true },
      { text: 'Cadastro de alunos manual', included: true },
      { text: 'Registro simples de aulas', included: true },
      { text: 'Destaque na busca', included: false },
      { text: 'Métricas avançadas', included: false },
      { text: 'Selo de aprovação', included: false },
    ],
  },
  {
    id: 'professional',
    name: 'Profissional',
    price: 97,
    icon: <Star className="h-6 w-6" />,
    tagline: 'Para instrutores ativos que querem mais alunos e autoridade',
    highlight: true,
    features: [
      { text: 'Tudo do Básico', included: true },
      { text: 'Perfil verificado (documentos + certificação)', included: true },
      { text: 'Destaque na busca da cidade/região', included: true },
      { text: 'Filtro por taxa de aprovação', included: true },
      { text: 'Registro completo de aulas por aluno', included: true },
      { text: 'Marcação de provas e resultados', included: true },
      { text: 'Cálculo automático de taxa de aprovação', included: true },
      { text: 'Selo "Instrutor com Alta Aprovação"', included: true },
      { text: 'Dashboard com métricas', included: true },
      { text: 'Prioridade no suporte', included: true },
    ],
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 149,
    icon: <Crown className="h-6 w-6" />,
    tagline: 'Para instrutores top ou mini autoescolas independentes',
    features: [
      { text: 'Tudo do Profissional', included: true },
      { text: 'Topo do ranking da cidade', included: true },
      { text: 'Destaque visual premium no marketplace', included: true },
      { text: 'Página personalizada (URL própria)', included: true },
      { text: 'Relatórios avançados', included: true },
      { text: 'Gestão avançada de alunos', included: true },
      { text: 'Integração com WhatsApp Business', included: true },
      { text: 'Exportação de dados (PDF / Excel)', included: true },
      { text: 'Selo "Instrutor Premium"', included: true },
      { text: 'Acesso antecipado a novas features', included: true },
    ],
  },
];

// Comparison table features
const comparisonFeatures = [
  { name: 'Perfil público na Conduza', basic: true, professional: true, premium: true },
  { name: 'Botão de contato (WhatsApp)', basic: true, professional: true, premium: true },
  { name: 'Exibição no marketplace', basic: 'Básica', professional: 'Destacada', premium: 'Topo do ranking' },
  { name: 'Cadastro de alunos', basic: 'Manual', professional: 'Completo', premium: 'Avançado com histórico' },
  { name: 'Registro de aulas', basic: 'Simples', professional: 'Por aluno', premium: 'Detalhado' },
  { name: 'Perfil verificado', basic: false, professional: true, premium: true },
  { name: 'Destaque na busca', basic: false, professional: true, premium: 'Prioridade máxima' },
  { name: 'Taxa de aprovação automática', basic: false, professional: true, premium: true },
  { name: 'Selo de instrutor', basic: false, professional: 'Alta Aprovação', premium: 'Premium' },
  { name: 'Dashboard com métricas', basic: false, professional: 'Simples', premium: 'Avançado' },
  { name: 'Relatórios', basic: false, professional: false, premium: 'Avançados' },
  { name: 'Página personalizada (URL)', basic: false, professional: false, premium: true },
  { name: 'WhatsApp Business', basic: false, professional: false, premium: true },
  { name: 'Exportação de dados', basic: false, professional: false, premium: 'PDF / Excel' },
  { name: 'Suporte prioritário', basic: false, professional: true, premium: 'VIP' },
  { name: 'Acesso antecipado a features', basic: false, professional: false, premium: true },
];

// FAQ items
const faqItems = [
  {
    question: 'O que é o perfil público na Conduza?',
    answer: 'Seu perfil aparece para todos os alunos que buscam instrutores na plataforma. Inclui seu nome, cidade, estado e tipo de habilitação (A, B ou AB). É sua vitrine digital para atrair novos alunos.',
  },
  {
    question: 'Como funciona o destaque na busca?',
    answer: 'Instrutores com planos Profissional e Premium aparecem primeiro nos resultados de busca da sua cidade/região. O plano Premium garante posição no topo do ranking, maximizando sua visibilidade.',
  },
  {
    question: 'O que é a taxa de aprovação automática?',
    answer: 'O sistema calcula automaticamente sua taxa de aprovação com base nos resultados das provas dos seus alunos. Isso gera credibilidade e ajuda alunos a escolherem instrutores com melhor desempenho.',
  },
  {
    question: 'Como funciona o selo de instrutor?',
    answer: 'O selo "Instrutor com Alta Aprovação" é concedido automaticamente quando sua taxa de aprovação atinge um nível excelente. O selo "Instrutor Premium" é exclusivo para assinantes do plano Premium e demonstra seu compromisso com qualidade.',
  },
  {
    question: 'O que são os relatórios avançados?',
    answer: 'Relatórios avançados incluem: taxa de aprovação por mês, comparativo com a média da cidade, análise de tendências e insights para melhorar seu desempenho. Disponível apenas no plano Premium.',
  },
  {
    question: 'O que é a página personalizada?',
    answer: 'Com o plano Premium, você recebe uma URL única (ex: Conduza.com/seu-nome) que pode compartilhar nas redes sociais, cartões de visita e materiais de divulgação.',
  },
  {
    question: 'Como funciona a integração com WhatsApp Business?',
    answer: 'O plano Premium permite configurar links avançados para WhatsApp Business, com mensagens pré-formatadas e rastreamento de conversões para medir quantos alunos entraram em contato.',
  },
  {
    question: 'Posso mudar de plano depois?',
    answer: 'Sim! Você pode fazer upgrade ou downgrade do seu plano a qualquer momento. O valor é ajustado proporcionalmente ao período restante.',
  },
  {
    question: 'Existe período de teste gratuito?',
    answer: 'Oferecemos garantia de 7 dias. Se não estiver satisfeito, devolvemos seu dinheiro integralmente, sem perguntas.',
  },
  {
    question: 'Como funciona o suporte prioritário?',
    answer: 'Instrutores Profissionais têm atendimento prioritário por chat. Instrutores Premium contam com suporte VIP com resposta em até 2 horas em horário comercial.',
  },
];

const InstructorPlans = () => {
  const [selectedPlan, setSelectedPlan] = useState<PlanId>('professional');
  const [searchParams] = useSearchParams();
  const [isLoading, setIsLoading] = useState(false);
  const { effectivePlan, isPaymentActive } = useInstructorPlan();

  // Handle checkout result from URL params
  useEffect(() => {
    const checkoutStatus = searchParams.get('checkout');
    if (checkoutStatus === 'canceled') {
      toast.info('Checkout cancelado. Você pode tentar novamente quando quiser.');
    }
  }, [searchParams]);

  const handleSubscribe = async () => {
    setIsLoading(true);
    try {
      // Salva o plano selecionado para uso após o pagamento
      sessionStorage.setItem('selectedInstructorPlan', selectedPlan);
      
      // Chama a edge function para criar checkout como guest
      const { data, error } = await supabase.functions.invoke('create-guest-checkout', {
        body: { planId: selectedPlan },
      });

      if (error) throw error;
      if (!data?.url) throw new Error('URL de checkout não retornada');

      // Abre o Stripe Checkout em uma nova aba (evita problema de iframe)
      window.open(data.url, '_blank');
      setIsLoading(false);
      toast.success('Checkout aberto em nova aba. Complete o pagamento para continuar.');
    } catch (error) {
      console.error('Erro ao criar checkout:', error);
      toast.error('Erro ao iniciar pagamento. Tente novamente.');
      setIsLoading(false);
    }
  };

  const isCurrentPlan = (planId: PlanId): boolean => {
    return isPaymentActive && effectivePlan === planId;
  };

  const renderComparisonValue = (value: boolean | string) => {
    if (value === true) {
      return <Check className="h-5 w-5 text-primary mx-auto" />;
    }
    if (value === false) {
      return <X className="h-5 w-5 text-muted-foreground/40 mx-auto" />;
    }
    return <span className="text-sm font-medium text-foreground">{value}</span>;
  };

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <BackButton fallbackPath="/register" className="mb-6" />
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Escolha seu plano
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Selecione o plano ideal para impulsionar sua carreira como instrutor
            </p>
          </div>

          {/* Plans Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {plans.map((plan) => (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className={cn(
                  'relative rounded-2xl border-2 p-6 cursor-pointer transition-all duration-300',
                  plan.highlight && 'md:-mt-4 md:mb-4',
                  selectedPlan === plan.id
                    ? 'border-primary bg-primary/5 shadow-lg shadow-primary/20'
                    : 'border-border bg-card hover:border-primary/50'
                )}
              >
                {plan.highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="bg-primary text-primary-foreground text-xs font-bold px-4 py-1 rounded-full">
                      MAIS POPULAR
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div
                    className={cn(
                      'inline-flex h-14 w-14 items-center justify-center rounded-xl mb-4',
                      plan.id === 'basic' && 'bg-emerald-500/10 text-emerald-500',
                      plan.id === 'professional' && 'bg-primary/10 text-primary',
                      plan.id === 'premium' && 'bg-amber-500/10 text-amber-500'
                    )}
                  >
                    {plan.icon}
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-1">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{plan.tagline}</p>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-sm text-muted-foreground">R$</span>
                    <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground">/mês</span>
                  </div>
                </div>

                <div className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      {feature.included ? (
                        <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      ) : (
                        <X className="h-5 w-5 text-muted-foreground/50 shrink-0 mt-0.5" />
                      )}
                      <span
                        className={cn(
                          'text-sm',
                          feature.included ? 'text-foreground' : 'text-muted-foreground/50'
                        )}
                      >
                        {feature.text}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-6">
                  {isCurrentPlan(plan.id) ? (
                    <div className="w-full h-12 rounded-xl border-2 border-primary/50 bg-primary/10 flex items-center justify-center font-medium text-primary">
                      Seu Plano Atual
                    </div>
                  ) : (
                    <div
                      className={cn(
                        'w-full h-12 rounded-xl border-2 flex items-center justify-center font-medium transition-all',
                        selectedPlan === plan.id
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border text-muted-foreground'
                      )}
                    >
                      {selectedPlan === plan.id ? 'Selecionado' : 'Selecionar'}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Subscribe Button */}
          <div className="text-center mb-16">
            <Button
              onClick={handleSubscribe}
              variant="hero"
              size="lg"
              className="px-12"
              disabled={isCurrentPlan(selectedPlan) || isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : isCurrentPlan(selectedPlan) ? (
                'Plano Atual'
              ) : (
                `Assinar ${plans.find((p) => p.id === selectedPlan)?.name}`
              )}
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              Pagamento seguro via Stripe • Cancele quando quiser
            </p>
          </div>

          {/* Comparison Table */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground text-center mb-8">
              Comparação detalhada
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-4 px-4 font-medium text-muted-foreground">
                      Funcionalidade
                    </th>
                    <th className="text-center py-4 px-4 min-w-[120px]">
                      <div className="flex flex-col items-center gap-1">
                        <Zap className="h-5 w-5 text-emerald-500" />
                        <span className="font-bold text-foreground">Básico</span>
                        <span className="text-sm text-muted-foreground">R$ 49</span>
                      </div>
                    </th>
                    <th className="text-center py-4 px-4 min-w-[120px] bg-primary/5">
                      <div className="flex flex-col items-center gap-1">
                        <Star className="h-5 w-5 text-primary" />
                        <span className="font-bold text-foreground">Profissional</span>
                        <span className="text-sm text-muted-foreground">R$ 97</span>
                      </div>
                    </th>
                    <th className="text-center py-4 px-4 min-w-[120px]">
                      <div className="flex flex-col items-center gap-1">
                        <Crown className="h-5 w-5 text-amber-500" />
                        <span className="font-bold text-foreground">Premium</span>
                        <span className="text-sm text-muted-foreground">R$ 149</span>
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFeatures.map((feature, index) => (
                    <tr
                      key={index}
                      className={cn(
                        'border-b border-border/50',
                        index % 2 === 0 && 'bg-muted/30'
                      )}
                    >
                      <td className="py-3 px-4 text-sm text-foreground">{feature.name}</td>
                      <td className="py-3 px-4 text-center">
                        {renderComparisonValue(feature.basic)}
                      </td>
                      <td className="py-3 px-4 text-center bg-primary/5">
                        {renderComparisonValue(feature.professional)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {renderComparisonValue(feature.premium)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-foreground text-center mb-8">
              Perguntas frequentes
            </h2>
            <Accordion type="single" collapsible className="space-y-3">
              {faqItems.map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-border rounded-xl px-6 bg-card"
                >
                  <AccordionTrigger className="text-left font-medium text-foreground hover:no-underline py-4">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-4">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>

          {/* Final CTA */}
          <div className="text-center mt-16 pb-8">
            <h3 className="text-xl font-bold text-foreground mb-4">
              Pronto para começar?
            </h3>
            <Button
              onClick={handleSubscribe}
              variant="hero"
              size="lg"
              className="px-12"
              disabled={isCurrentPlan(selectedPlan)}
            >
              {isCurrentPlan(selectedPlan)
                ? 'Plano Atual'
                : `Assinar ${plans.find((p) => p.id === selectedPlan)?.name}`
              }
            </Button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default InstructorPlans;
