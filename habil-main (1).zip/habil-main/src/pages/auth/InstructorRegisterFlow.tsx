import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { LocationInput } from '@/components/location/LocationInput';
import { cn } from '@/lib/utils';
import { logger } from '@/lib/logger';
import { useStripeSubscription } from '@/hooks/useStripeSubscription';
import { SubscriptionPlan } from '@/hooks/useInstructorPlan';
import { 
  ArrowLeft, 
  ArrowRight, 
  User, 
  Building2, 
  MapPin, 
  Car,
  Upload,
  Check,
  Loader2,
  Bike,
  Eye,
  EyeOff,
  Clock
} from 'lucide-react';
import { PasswordStrengthIndicator } from '@/components/auth/PasswordStrengthIndicator';
import { strongPasswordSchema } from '@/lib/validations';

// Step types
type StepId = 'personal' | 'info' | 'location' | 'availability' | 'success';

interface Step {
  id: StepId;
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}

const steps: Step[] = [
  { id: 'personal', icon: <User className="h-5 w-5" />, title: 'Dados Pessoais', subtitle: 'Informe seus dados' },
  { id: 'info', icon: <Building2 className="h-5 w-5" />, title: 'Informações', subtitle: 'Detalhes sobre sua atuação' },
  { id: 'location', icon: <MapPin className="h-5 w-5" />, title: 'Localização', subtitle: 'Onde você atua?' },
  { id: 'availability', icon: <Car className="h-5 w-5" />, title: 'Disponibilidade', subtitle: 'Quando você está disponível?' },
];

const weekDays = [
  { id: 'monday', label: 'Segunda' },
  { id: 'tuesday', label: 'Terça' },
  { id: 'wednesday', label: 'Quarta' },
  { id: 'thursday', label: 'Quinta' },
  { id: 'friday', label: 'Sexta' },
  { id: 'saturday', label: 'Sábado' },
  { id: 'sunday', label: 'Domingo' },
];

const InstructorRegisterFlow = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, register } = useAuth();
  const { toast } = useToast();
  const { createCheckoutSession, isLoading: isCheckoutLoading } = useStripeSubscription();
  
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<StepId>('personal');
  const [isLoading, setIsLoading] = useState(false);
  const [isCreatingAccount, setIsCreatingAccount] = useState(!isAuthenticated);
  
  // Account creation fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Step 1 - Personal Data
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [fullName, setFullName] = useState('');
  const [cpf, setCpf] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [bio, setBio] = useState('');
  
  // Step 2 - Information
  const [cnhCategory, setCnhCategory] = useState<'A' | 'B' | 'AB' | null>(null);
  const [yearsOfExperience, setYearsOfExperience] = useState('0');
  const [pricePerHour, setPricePerHour] = useState('0');
  const [isIndependent, setIsIndependent] = useState(true);
  const [autoescolaName, setAutoescolaName] = useState('');
  
  // Step 3 - Location
  const [city, setCity] = useState('');
  const [uf, setUf] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [address, setAddress] = useState('');
  
  // Step 4 - Availability
  const [availableDays, setAvailableDays] = useState<string[]>([]);
  const [startTime, setStartTime] = useState('08:00');
  const [endTime, setEndTime] = useState('18:00');
  
  const stepIndex = steps.findIndex(s => s.id === currentStep);
  
  // Load selected plan from sessionStorage
  useEffect(() => {
    const plan = sessionStorage.getItem('selectedInstructorPlan');
    if (!plan) {
      navigate('/register/instructor');
      return;
    }
    setSelectedPlan(plan);
  }, [navigate]);

  // Update isCreatingAccount when auth state changes
  useEffect(() => {
    if (isAuthenticated && user) {
      setIsCreatingAccount(false);
      if (user.name) {
        setFullName(user.name);
      }
    }
  }, [isAuthenticated, user]);
  
  const formatCpf = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
    if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
    return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
  };
  
  const formatPhone = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 2) return `(${digits}`;
    if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
  };
  
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const toggleDay = (dayId: string) => {
    setAvailableDays(prev => 
      prev.includes(dayId) 
        ? prev.filter(d => d !== dayId)
        : [...prev, dayId]
    );
  };

  const handleCreateAccount = async () => {
    if (!fullName.trim()) {
      toast({ title: 'Nome obrigatório', description: 'Informe seu nome completo', variant: 'destructive' });
      return false;
    }
    if (!email.trim()) {
      toast({ title: 'Email obrigatório', description: 'Informe seu email', variant: 'destructive' });
      return false;
    }
    // Validate password strength
    const passwordResult = strongPasswordSchema.safeParse(password);
    if (!passwordResult.success) {
      toast({ 
        title: 'Senha fraca', 
        description: 'A senha deve ter pelo menos 8 caracteres, incluindo maiúscula, minúscula e número', 
        variant: 'destructive' 
      });
      return false;
    }
    if (password !== confirmPassword) {
      toast({ title: 'Senhas não conferem', description: 'A senha e a confirmação devem ser iguais', variant: 'destructive' });
      return false;
    }

    setIsLoading(true);
    const result = await register(fullName, email, password, 'instructor');
    
    if (result.success) {
      setIsCreatingAccount(false);
      toast({ title: 'Conta criada!', description: 'Continue seu cadastro' });
      setIsLoading(false);
      return true;
    } else {
      toast({ title: 'Erro no cadastro', description: result.error, variant: 'destructive' });
      setIsLoading(false);
      return false;
    }
  };
  
  const validateStep = (step: StepId): boolean => {
    switch (step) {
      case 'personal':
        if (!fullName.trim()) {
          toast({ title: 'Nome obrigatório', description: 'Informe seu nome completo', variant: 'destructive' });
          return false;
        }
        if (cpf.replace(/\D/g, '').length !== 11) {
          toast({ title: 'CPF inválido', description: 'Informe um CPF válido', variant: 'destructive' });
          return false;
        }
        return true;
        
      case 'info':
        if (!cnhCategory) {
          toast({ title: 'Categoria obrigatória', description: 'Selecione a categoria que você ministra', variant: 'destructive' });
          return false;
        }
        return true;
        
      case 'location':
        if (!city.trim() || !uf) {
          toast({ title: 'Localização obrigatória', description: 'Informe sua cidade e estado', variant: 'destructive' });
          return false;
        }
        return true;
        
      case 'availability':
        if (availableDays.length === 0) {
          toast({ title: 'Dias obrigatórios', description: 'Selecione pelo menos um dia disponível', variant: 'destructive' });
          return false;
        }
        return true;
        
      default:
        return true;
    }
  };
  
  const handleNext = async () => {
    // If creating account, validate and create first
    if (isCreatingAccount && currentStep === 'personal') {
      const success = await handleCreateAccount();
      if (!success) return;
    }

    if (!validateStep(currentStep)) return;
    
    const nextIndex = stepIndex + 1;
    if (nextIndex < steps.length) {
      setCurrentStep(steps[nextIndex].id);
    } else {
      handleSubmit();
    }
  };
  
  const handleBack = () => {
    const prevIndex = stepIndex - 1;
    if (prevIndex >= 0) {
      setCurrentStep(steps[prevIndex].id);
    } else {
      navigate('/register/instructor');
    }
  };
  
  const handleSubmit = async () => {
    if (!user) {
      toast({ title: 'Erro', description: 'Você precisa estar logado', variant: 'destructive' });
      return;
    }
    
    setIsLoading(true);
    
    try {
      let avatarUrl = null;
      
      // Upload avatar if exists
      if (avatarFile) {
        const fileExt = avatarFile.name.split('.').pop();
        const fileName = `${user.id}/avatar.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('avatars')
          .upload(fileName, avatarFile, { upsert: true });
        
        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from('avatars')
            .getPublicUrl(fileName);
          avatarUrl = urlData.publicUrl;
        }
      }
      
      // Update profile
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: fullName,
          cpf: cpf.replace(/\D/g, ''),
          phone: phone.replace(/\D/g, ''),
          whatsapp: whatsapp.replace(/\D/g, ''),
          bio,
          cnh_category: cnhCategory,
          years_of_experience: parseInt(yearsOfExperience) || 0,
          price_per_hour: parseFloat(pricePerHour) || 0,
          is_independent: isIndependent,
          city,
          uf,
          neighborhood,
          address,
          available_days: availableDays,
          available_start_time: startTime,
          available_end_time: endTime,
          registration_status: 'pending',
          avatar_url: avatarUrl || undefined,
        })
        .eq('id', user.id);
      
      if (error) throw error;
      
      // Get the selected plan and redirect to checkout
      const plan = selectedPlan as SubscriptionPlan;
      
      // Clear session storage
      sessionStorage.removeItem('selectedInstructorPlan');
      sessionStorage.removeItem('redirectToCheckout');
      
      // Redirect to Stripe checkout
      toast({ title: 'Cadastro salvo!', description: 'Redirecionando para pagamento...' });
      await createCheckoutSession(plan);
      
    } catch (error) {
      logger.error('Error saving profile:', error);
      toast({ title: 'Erro', description: 'Não foi possível salvar seu cadastro', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const renderStepIndicator = () => (
    <div className="flex items-center justify-center gap-0 mb-8">
      {steps.map((step, index) => {
        const isActive = stepIndex >= index;
        const isCurrent = step.id === currentStep;
        
        return (
          <div key={step.id} className="flex items-center">
            <div
              className={cn(
                "h-12 w-12 rounded-full flex items-center justify-center transition-all",
                isActive ? "bg-success text-success-foreground" : "bg-muted text-muted-foreground"
              )}
            >
              {step.icon}
            </div>
            {index < steps.length - 1 && (
              <div
                className={cn(
                  "w-12 h-0.5 transition-all",
                  stepIndex > index ? "bg-success" : "bg-muted"
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
  
  const renderPersonalStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-semibold text-foreground">Dados Pessoais</h2>
        <p className="text-muted-foreground text-sm">Informe seus dados</p>
      </div>
      
      {/* Avatar Upload */}
      <div className="flex flex-col items-center gap-2">
        <label htmlFor="avatar" className="cursor-pointer">
          <div className={cn(
            "h-24 w-24 rounded-full border-2 border-dashed flex items-center justify-center transition-all overflow-hidden",
            avatarPreview ? "border-success" : "border-muted-foreground/30 hover:border-primary/50"
          )}>
            {avatarPreview ? (
              <img src={avatarPreview} alt="Avatar" className="h-full w-full object-cover" />
            ) : (
              <Upload className="h-8 w-8 text-muted-foreground" />
            )}
          </div>
        </label>
        <input
          id="avatar"
          type="file"
          accept="image/*"
          onChange={handleAvatarChange}
          className="hidden"
        />
        <span className="text-sm text-muted-foreground">Foto de perfil</span>
      </div>
      
      {/* Full Name */}
      <div className="space-y-2">
        <Label htmlFor="fullName">Nome Completo</Label>
        <Input
          id="fullName"
          placeholder="Seu nome completo"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="h-12"
        />
      </div>

      {/* Account creation fields - only show if not authenticated */}
      {isCreatingAccount && (
        <>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12"
            />
          </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Crie uma senha forte"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              <PasswordStrengthIndicator password={password} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Repita a senha"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-12"
              />
            </div>
        </>
      )}
      
      {/* CPF and Phone */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="cpf">CPF</Label>
          <Input
            id="cpf"
            placeholder="000.000.000-00"
            value={cpf}
            onChange={(e) => setCpf(formatCpf(e.target.value))}
            maxLength={14}
            className="h-12"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Telefone</Label>
          <Input
            id="phone"
            placeholder="(00) 00000-0000"
            value={phone}
            onChange={(e) => setPhone(formatPhone(e.target.value))}
            maxLength={15}
            className="h-12"
          />
        </div>
      </div>

      {/* WhatsApp */}
      <div className="space-y-2">
        <Label htmlFor="whatsapp">WhatsApp para contato de alunos</Label>
        <Input
          id="whatsapp"
          placeholder="(00) 00000-0000"
          value={whatsapp}
          onChange={(e) => setWhatsapp(formatPhone(e.target.value))}
          maxLength={15}
          className="h-12"
        />
        <p className="text-xs text-muted-foreground">
          Este número será usado para alunos entrarem em contato diretamente
        </p>
      </div>
      
      {/* Bio */}
      <div className="space-y-2">
        <Label htmlFor="bio">Sobre você</Label>
        <Textarea
          id="bio"
          placeholder="Fale um pouco sobre sua experiência..."
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          rows={4}
          className="resize-none"
        />
      </div>
    </div>
  );
  
  const renderInfoStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-semibold text-foreground">Informações</h2>
        <p className="text-muted-foreground text-sm">Detalhes sobre sua atuação</p>
      </div>
      
      {/* CNH Categories */}
      <div className="space-y-3">
        <Label>Categorias que ministra</Label>
        <div className="grid grid-cols-3 gap-3">
          {[
            { value: 'A', label: 'Cat. A', icon: <Bike className="h-6 w-6" /> },
            { value: 'B', label: 'Categoria B', icon: <Car className="h-6 w-6" /> },
            { value: 'AB', label: 'Cat. AB', icon: <Car className="h-6 w-6" /> },
          ].map((cat) => (
            <button
              key={cat.value}
              type="button"
              onClick={() => setCnhCategory(cat.value as 'A' | 'B' | 'AB')}
              className={cn(
                "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all",
                cnhCategory === cat.value
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50"
              )}
            >
              <span className={cn(
                "transition-colors",
                cnhCategory === cat.value ? "text-primary" : "text-muted-foreground"
              )}>
                {cat.icon}
              </span>
              <span className={cn(
                "text-sm font-medium",
                cnhCategory === cat.value ? "text-primary" : "text-foreground"
              )}>
                {cat.label}
              </span>
            </button>
          ))}
        </div>
      </div>
      
      {/* Experience and Price */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="experience">Anos de experiência</Label>
          <Input
            id="experience"
            type="number"
            min="0"
            placeholder="0"
            value={yearsOfExperience}
            onChange={(e) => setYearsOfExperience(e.target.value)}
            className="h-12"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="price">Valor por Hora (R$)</Label>
          <Input
            id="price"
            type="number"
            min="0"
            placeholder="0"
            value={pricePerHour}
            onChange={(e) => setPricePerHour(e.target.value)}
            className="h-12"
          />
        </div>
      </div>
      
      {/* Independent Instructor */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-muted/50">
        <div>
          <p className="font-medium text-foreground">Sou instrutor independente</p>
          <p className="text-sm text-muted-foreground">Não estou relacionado à autoescola</p>
        </div>
        <Switch
          checked={isIndependent}
          onCheckedChange={setIsIndependent}
        />
      </div>

      {/* Driving School Name - only show if not independent */}
      {!isIndependent && (
        <div className="space-y-2">
          <Label htmlFor="autoescola">Nome da Autoescola</Label>
          <Input
            id="autoescola"
            placeholder="Nome da autoescola"
            value={autoescolaName}
            onChange={(e) => setAutoescolaName(e.target.value)}
            className="h-12"
          />
        </div>
      )}
    </div>
  );
  
  const handleLocationChange = (newUf: string, newCity: string, newNeighborhood?: string, newStreet?: string) => {
    setUf(newUf);
    setCity(newCity);
    if (newNeighborhood) setNeighborhood(newNeighborhood);
    if (newStreet) setAddress(newStreet);
  };

  const renderLocationStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-semibold text-foreground">Localização</h2>
        <p className="text-muted-foreground text-sm">Onde você atua? Use GPS ou CEP para maior precisão</p>
      </div>
      
      {/* Location Input with GPS, CEP and Address Search */}
      <LocationInput
        uf={uf}
        city={city}
        onLocationChange={handleLocationChange}
        showGps={true}
        showCep={true}
        showManual={true}
        showAddressSearch={true}
      />
      
      {/* Neighborhood */}
      <div className="space-y-2">
        <Label htmlFor="neighborhood">Bairro</Label>
        <Input
          id="neighborhood"
          placeholder="Seu bairro"
          value={neighborhood}
          onChange={(e) => setNeighborhood(e.target.value)}
          className="h-12"
        />
      </div>
      
      {/* Address */}
      <div className="space-y-2">
        <Label htmlFor="address">Endereço</Label>
        <Input
          id="address"
          placeholder="Rua, número, complemento"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className="h-12"
        />
      </div>
    </div>
  );
  
  const renderAvailabilityStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-semibold text-foreground">Disponibilidade</h2>
        <p className="text-muted-foreground text-sm">Quando você está disponível?</p>
      </div>
      
      {/* Available Days */}
      <div className="space-y-3">
        <Label>Dias disponíveis</Label>
        <div className="flex flex-wrap gap-2">
          {weekDays.map((day) => (
            <button
              key={day.id}
              type="button"
              onClick={() => toggleDay(day.id)}
              className={cn(
                "px-4 py-2 rounded-lg border-2 text-sm font-medium transition-all",
                availableDays.includes(day.id)
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-background hover:border-primary/50"
              )}
            >
              {day.label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Time Range */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startTime">Horário Início</Label>
          <div className="relative">
            <Input
              id="startTime"
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="h-12"
            />
            <Clock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="endTime">Horário Fim</Label>
          <div className="relative">
            <Input
              id="endTime"
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="h-12"
            />
            <Clock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderSuccessStep = () => (
    <div className="text-center space-y-6 py-8">
      <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-success/10">
        <Check className="h-10 w-10 text-success" />
      </div>
      
      <div>
        <h2 className="text-2xl font-bold text-foreground">Cadastro Enviado!</h2>
        <p className="text-muted-foreground mt-2">
          Seu cadastro foi enviado para análise. Você será notificado quando seus documentos forem verificados.
        </p>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
        <Button
          variant="default"
          size="lg"
          onClick={() => navigate('/instructor/dashboard')}
          className="bg-success hover:bg-success/90"
        >
          Ir para Meu Painel
        </Button>
        <Button
          variant="outline"
          size="lg"
          onClick={() => navigate('/instructor/documents')}
        >
          Enviar Documentos
        </Button>
      </div>
    </div>
  );
  
  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'personal':
        return renderPersonalStep();
      case 'info':
        return renderInfoStep();
      case 'location':
        return renderLocationStep();
      case 'availability':
        return renderAvailabilityStep();
      case 'success':
        return renderSuccessStep();
      default:
        return null;
    }
  };

  if (!selectedPlan) {
    return null; // Will redirect in useEffect
  }
  
  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-b from-primary/20 to-background py-8 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          {currentStep !== 'success' && (
            <div className="text-center mb-6">
              <button
                onClick={handleBack}
                className="inline-flex items-center gap-1 text-primary-foreground/80 hover:text-primary-foreground mb-4"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <h1 className="text-3xl font-bold text-primary-foreground">Cadastro de Instrutor</h1>
              <p className="text-primary-foreground/80 mt-1">Junte-se à nossa plataforma</p>
            </div>
          )}
          
          {/* Step Indicator */}
          {currentStep !== 'success' && renderStepIndicator()}
          
          {/* Form Card */}
          <div className="card-elevated p-6 sm:p-8">
            {renderCurrentStep()}
            
            {/* Navigation Buttons */}
            {currentStep !== 'success' && (
              <div className="flex justify-between mt-8 pt-6 border-t border-border">
                <Button
                  variant="outline"
                  onClick={handleBack}
                  className="gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Voltar
                </Button>
                
                <Button
                  onClick={handleNext}
                  disabled={isLoading || isCheckoutLoading}
                  className={cn(
                    "gap-2",
                    currentStep === 'availability' ? "bg-success hover:bg-success/90" : ""
                  )}
                >
                  {isLoading || isCheckoutLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {isCreatingAccount && currentStep === 'personal' ? 'Criando conta...' : 
                       currentStep === 'availability' ? 'Processando...' : 'Salvando...'}
                    </>
                  ) : currentStep === 'availability' ? (
                    'Finalizar e Pagar'
                  ) : (
                    <>
                      Próximo
                      <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>

          {/* Login link for personal step */}
          {currentStep === 'personal' && isCreatingAccount && (
            <div className="mt-6 text-center">
              <p className="text-primary-foreground/80">
                Já tem uma conta?{' '}
                <Link to="/login" className="text-white font-semibold hover:underline">
                  Entrar
                </Link>
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default InstructorRegisterFlow;
