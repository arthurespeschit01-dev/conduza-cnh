import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Car, Loader2, ArrowLeft, CheckCircle } from 'lucide-react';
import { forgotPasswordSchema } from '@/lib/validations';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { forgotPassword } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate with Zod
    const validation = forgotPasswordSchema.safeParse({ email });
    if (!validation.success) {
      const firstError = validation.error.errors[0];
      toast({
        title: 'Dados inválidos',
        description: firstError.message,
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await forgotPassword(validation.data.email);
    setIsLoading(false);

    if (result.success) {
      setIsSubmitted(true);
    } else {
      toast({
        title: 'Erro',
        description: result.error,
        variant: 'destructive',
      });
    }
  };

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl gradient-primary mb-4">
              <Car className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Recuperar senha</h1>
            <p className="text-muted-foreground mt-2">
              {isSubmitted 
                ? 'Verifique seu email' 
                : 'Digite seu email para receber as instruções'}
            </p>
          </div>

          <div className="card-elevated p-8">
            {isSubmitted ? (
              <div className="text-center py-6">
                <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-success/10 mb-4">
                  <CheckCircle className="h-8 w-8 text-success" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Email enviado!</h3>
                <p className="text-muted-foreground mb-6">
                  Se existe uma conta com o email informado, você receberá as instruções para redefinir sua senha.
                </p>
                <Link to="/login">
                  <Button variant="hero" className="w-full">
                    Voltar para login
                  </Button>
                </Link>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="h-12"
                    required
                    autoComplete="email"
                  />
                </div>

                <Button type="submit" variant="hero" className="w-full h-12" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    'Enviar instruções'
                  )}
                </Button>
              </form>
            )}

            {!isSubmitted && (
              <div className="mt-6 text-center">
                <Link to="/login" className="inline-flex items-center gap-2 text-primary hover:underline">
                  <ArrowLeft className="h-4 w-4" />
                  Voltar para login
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ForgotPassword;
