import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BackButton } from '@/components/ui/back-button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useMFA } from '@/hooks/useMFA';
import { Car, Loader2, Eye, EyeOff } from 'lucide-react';
import { loginSchema } from '@/lib/validations';
import { MFAVerifyDialog } from '@/components/auth/MFAVerifyDialog';
import { ADMIN_ROUTES } from '@/components/guards/AuthGuard';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showMFADialog, setShowMFADialog] = useState(false);
  const { login, user, isAuthenticated, logout } = useAuth();
  const { requiresMFAVerification } = useMFA();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Redirect based on role when user is authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      // Check if MFA verification is required
      const checkMFAAndRedirect = async () => {
        try {
          const needsMFA = await requiresMFAVerification();
          
          if (needsMFA) {
            setShowMFADialog(true);
          } else {
            redirectToDashboard(user.role);
          }
        } catch (error) {
          // If MFA check fails, proceed without MFA
          redirectToDashboard(user.role);
        }
      };
      
      checkMFAAndRedirect();
    }
  }, [isAuthenticated, user, navigate, requiresMFAVerification]);

  const redirectToDashboard = (role: string) => {
    if (role === 'admin') {
      navigate(ADMIN_ROUTES.dashboard, { replace: true });
    } else if (role === 'instructor') {
      navigate('/instructor/dashboard', { replace: true });
    } else if (role === 'student') {
      navigate('/student/dashboard', { replace: true });
    } else {
      navigate('/onboarding/location', { replace: true });
    }
  };

  const handleMFASuccess = () => {
    setShowMFADialog(false);
    toast({
      title: 'Verificação concluída!',
      description: 'Login realizado com sucesso.',
    });
    if (user) {
      redirectToDashboard(user.role);
    }
  };

  const handleMFACancel = async () => {
    // If user cancels MFA, log them out
    await logout();
    setShowMFADialog(false);
    toast({
      title: 'Login cancelado',
      description: 'Verificação de dois fatores é necessária para continuar.',
      variant: 'destructive',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate with Zod
    const validation = loginSchema.safeParse({ email, password });
    if (!validation.success) {
      const firstError = validation.error.errors[0];
      toast({
        title: 'Dados inválidos',
        description: firstError.message,
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await login(validation.data.email, validation.data.password);
    setIsLoading(false);

    if (result.success) {
      // MFA check and redirection handled by useEffect
      toast({
        title: 'Login realizado!',
        description: 'Bem-vindo de volta',
      });
    } else {
      toast({
        title: 'Erro no login',
        description: result.error,
        variant: 'destructive',
      });
    }
  };

  return (
    <MainLayout showFooter={false}>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md">
          <BackButton fallbackPath="/" className="mb-6" />
          <div className="text-center mb-8">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl gradient-primary mb-4">
              <Car className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Entrar na Conduza</h1>
            <p className="text-muted-foreground mt-2">
              Acesse sua conta para continuar
            </p>
          </div>

          <div className="card-elevated p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12"
                  required
                  autoComplete="email"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Senha</Label>
                  <Link to="/forgot-password" className="text-sm text-primary hover:underline">
                    Esqueceu a senha?
                  </Link>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-12 pr-10"
                    required
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <Button type="submit" variant="hero" className="w-full h-12" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  'Entrar'
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-muted-foreground">
                Não tem uma conta?{' '}
                <Link to="/register" className="text-primary font-semibold hover:underline">
                  Cadastre-se
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>

      <MFAVerifyDialog
        open={showMFADialog}
        onOpenChange={setShowMFADialog}
        onSuccess={handleMFASuccess}
        onCancel={handleMFACancel}
      />
    </MainLayout>
  );
};

export default Login;
