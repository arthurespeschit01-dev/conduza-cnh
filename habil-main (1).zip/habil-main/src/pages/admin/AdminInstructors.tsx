import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useAdminData } from '@/hooks/useAdminData';
import { 
  Search, 
  UserCog, 
  Users, 
  Award, 
  CheckCircle, 
  XCircle, 
  Clock, 
  FileText, 
  Loader2, 
  Pause,
  Play,
  FileWarning,
  Ban
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { SecureDocumentLink } from '@/components/ui/secure-document-link';

type FilterType = 'all' | 'approved' | 'pending' | 'rejected' | 'paused' | 'no_docs';

const AdminInstructors = () => {
  const { 
    instructors, 
    isLoading, 
    approveInstructor, 
    rejectInstructor,
    pauseInstructor,
    unpauseInstructor 
  } = useAdminData();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [selectedInstructor, setSelectedInstructor] = useState<typeof instructors[0] | null>(null);

  const filteredInstructors = instructors.filter(instructor => {
    const matchesSearch = instructor.full_name.toLowerCase().includes(search.toLowerCase()) ||
                         instructor.city.toLowerCase().includes(search.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'approved') return matchesSearch && instructor.registration_status === 'approved';
    if (filter === 'pending') return matchesSearch && instructor.registration_status === 'pending';
    if (filter === 'rejected') return matchesSearch && instructor.registration_status === 'rejected';
    if (filter === 'paused') return matchesSearch && instructor.registration_status === 'paused';
    if (filter === 'no_docs') return matchesSearch && !instructor.hasAllDocuments;
    return matchesSearch;
  });

  // Count for badges
  const counts = {
    all: instructors.length,
    approved: instructors.filter(i => i.registration_status === 'approved').length,
    pending: instructors.filter(i => i.registration_status === 'pending').length,
    rejected: instructors.filter(i => i.registration_status === 'rejected').length,
    paused: instructors.filter(i => i.registration_status === 'paused').length,
    no_docs: instructors.filter(i => !i.hasAllDocuments).length,
  };

  const handleApprove = async (instructorId: string) => {
    await approveInstructor(instructorId);
    setFilter('approved'); // Redirect to approved tab
  };

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case 'approved':
        return (
          <Badge className="bg-success text-success-foreground">
            <CheckCircle className="h-3 w-3 mr-1" />
            Aprovado
          </Badge>
        );
      case 'rejected':
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            Rejeitado
          </Badge>
        );
      case 'paused':
        return (
          <Badge className="bg-warning text-warning-foreground">
            <Pause className="h-3 w-3 mr-1" />
            Pausado
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        );
    }
  };

  const getPlanBadge = (plan: string | null) => {
    switch (plan) {
      case 'premium':
        return <Badge className="bg-primary">Premium</Badge>;
      case 'enterprise':
        return <Badge className="bg-accent">Enterprise</Badge>;
      default:
        return <Badge variant="secondary">Básico</Badge>;
    }
  };

  const renderActions = (instructor: typeof instructors[0]) => {
    const status = instructor.registration_status;

    if (status === 'pending') {
      return (
        <div className="flex gap-2">
          <Button 
            size="sm"
            className="bg-success hover:bg-success/90"
            onClick={() => handleApprove(instructor.id)}
          >
            <CheckCircle className="h-4 w-4" />
          </Button>
          <Button 
            size="sm"
            variant="destructive"
            onClick={() => rejectInstructor(instructor.id)}
          >
            <XCircle className="h-4 w-4" />
          </Button>
        </div>
      );
    }

    if (status === 'approved') {
      return (
        <Button 
          size="sm"
          variant="outline"
          className="text-warning border-warning hover:bg-warning/10"
          onClick={() => pauseInstructor(instructor.id)}
        >
          <Pause className="h-4 w-4 mr-1" />
          Pausar
        </Button>
      );
    }

    if (status === 'paused') {
      return (
        <Button 
          size="sm"
          className="bg-success hover:bg-success/90"
          onClick={() => unpauseInstructor(instructor.id)}
        >
          <Play className="h-4 w-4 mr-1" />
          Reativar
        </Button>
      );
    }

    if (status === 'rejected') {
      return (
        <Button 
          size="sm"
          variant="outline"
          onClick={() => handleApprove(instructor.id)}
        >
          <CheckCircle className="h-4 w-4 mr-1" />
          Reaprovar
        </Button>
      );
    }

    return null;
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Gerenciar Instrutores</h1>
          <p className="text-muted-foreground">
            Visualize e gerencie todos os instrutores da plataforma
          </p>
        </div>

        {/* Filters */}
        <div className="card-elevated p-4 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou cidade..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-12"
              />
            </div>
            
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={filter === 'all' ? 'default' : 'outline'}
                onClick={() => setFilter('all')}
                className="gap-2"
              >
                Todos
                <Badge variant="secondary" className="ml-1">{counts.all}</Badge>
              </Button>
              <Button
                variant={filter === 'approved' ? 'default' : 'outline'}
                onClick={() => setFilter('approved')}
                className="gap-2"
              >
                <CheckCircle className="h-4 w-4" />
                Aprovados
                <Badge variant="secondary" className="ml-1">{counts.approved}</Badge>
              </Button>
              <Button
                variant={filter === 'pending' ? 'default' : 'outline'}
                onClick={() => setFilter('pending')}
                className="gap-2"
              >
                <Clock className="h-4 w-4" />
                Pendentes
                <Badge variant="secondary" className="ml-1">{counts.pending}</Badge>
              </Button>
              <Button
                variant={filter === 'paused' ? 'default' : 'outline'}
                onClick={() => setFilter('paused')}
                className="gap-2"
              >
                <Pause className="h-4 w-4" />
                Pausados
                <Badge variant="secondary" className="ml-1">{counts.paused}</Badge>
              </Button>
              <Button
                variant={filter === 'no_docs' ? 'default' : 'outline'}
                onClick={() => setFilter('no_docs')}
                className="gap-2"
              >
                <FileWarning className="h-4 w-4" />
                Sem Docs
                <Badge variant="secondary" className="ml-1">{counts.no_docs}</Badge>
              </Button>
              <Button
                variant={filter === 'rejected' ? 'default' : 'outline'}
                onClick={() => setFilter('rejected')}
                className="gap-2"
              >
                <Ban className="h-4 w-4" />
                Rejeitados
                <Badge variant="secondary" className="ml-1">{counts.rejected}</Badge>
              </Button>
            </div>
          </div>
        </div>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-muted-foreground">
            {filteredInstructors.length} instrutor{filteredInstructors.length !== 1 ? 'es' : ''} encontrado{filteredInstructors.length !== 1 ? 's' : ''}
          </p>
        </div>

        {/* Instructors List */}
        <div className="space-y-4">
          {filteredInstructors.map((instructor) => (
            <div key={instructor.id} className="card-elevated p-6">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-lg flex-shrink-0">
                  {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1 flex-wrap">
                    <h3 className="text-lg font-semibold text-foreground">{instructor.full_name}</h3>
                    {getStatusBadge(instructor.registration_status)}
                    {getPlanBadge(instructor.subscription_plan)}
                  </div>
                  <p className="text-sm text-muted-foreground">{instructor.email}</p>
                  <p className="text-sm text-muted-foreground">{instructor.city}, {instructor.uf}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Cadastrado em {format(new Date(instructor.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                  </p>
                </div>

                {/* Document Status */}
                <div className="flex gap-2 flex-wrap">
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center",
                      instructor.cnh_document_path ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
                    )}>
                      <FileText className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-muted-foreground mt-1">CNH</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center",
                      instructor.rg_document_path ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
                    )}>
                      <FileText className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-muted-foreground mt-1">RG</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center",
                      instructor.proof_of_residence_path ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
                    )}>
                      <FileText className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-muted-foreground mt-1">Resid.</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center",
                      instructor.instructor_certificate_path ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
                    )}>
                      <FileText className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-muted-foreground mt-1">Cert.</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="flex items-center justify-center gap-1 text-success">
                      <Award className="h-4 w-4" />
                      <span className="font-bold">{instructor.approvalRate}%</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Aprovação</p>
                  </div>
                  <div>
                    <div className="flex items-center justify-center gap-1 text-primary">
                      <Users className="h-4 w-4" />
                      <span className="font-bold">{instructor.totalStudents}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Alunos</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedInstructor(instructor)}>
                        Ver detalhes
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Detalhes do Instrutor</DialogTitle>
                      </DialogHeader>
                      
                      {selectedInstructor && (
                        <div className="space-y-4">
                          <div className="flex items-center gap-4">
                            <div className="h-16 w-16 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
                              {selectedInstructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                            </div>
                            <div>
                              <h3 className="text-lg font-semibold">{selectedInstructor.full_name}</h3>
                              <p className="text-sm text-muted-foreground">{selectedInstructor.email}</p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Telefone:</span>
                              <p className="font-medium">{selectedInstructor.phone || 'Não informado'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">CPF:</span>
                              <p className="font-medium">{selectedInstructor.cpf || 'Não informado'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">CNH:</span>
                              <p className="font-medium">{selectedInstructor.cnh || 'Não informado'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Categoria:</span>
                              <p className="font-medium">{selectedInstructor.cnh_category || 'Não informado'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Plano:</span>
                              <p className="font-medium capitalize">{selectedInstructor.subscription_plan || 'Básico'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Preço/hora:</span>
                              <p className="font-medium">
                                {selectedInstructor.price_per_hour 
                                  ? `R$ ${selectedInstructor.price_per_hour.toFixed(2)}` 
                                  : 'Não definido'}
                              </p>
                            </div>
                          </div>

                          {/* Documents */}
                          <div className="border-t pt-4">
                            <h4 className="font-medium mb-3">Documentos</h4>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">CNH</span>
                                </div>
                                {selectedInstructor.cnh_document_path ? (
                                  <SecureDocumentLink documentUrl={selectedInstructor.cnh_document_path} />
                                ) : (
                                  <span className="text-sm text-destructive">Não enviado</span>
                                )}
                              </div>
                              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">RG</span>
                                </div>
                                {selectedInstructor.rg_document_path ? (
                                  <SecureDocumentLink documentUrl={selectedInstructor.rg_document_path} />
                                ) : (
                                  <span className="text-sm text-destructive">Não enviado</span>
                                )}
                              </div>
                              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">Comprovante de Residência</span>
                                </div>
                                {selectedInstructor.proof_of_residence_path ? (
                                  <SecureDocumentLink documentUrl={selectedInstructor.proof_of_residence_path} />
                                ) : (
                                  <span className="text-sm text-destructive">Não enviado</span>
                                )}
                              </div>
                              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">Certificado de Instrutor</span>
                                </div>
                                {selectedInstructor.instructor_certificate_path ? (
                                  <SecureDocumentLink documentUrl={selectedInstructor.instructor_certificate_path} />
                                ) : (
                                  <span className="text-sm text-destructive">Não enviado</span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="flex gap-3 pt-4 border-t">
                            {selectedInstructor.registration_status === 'pending' && (
                              <>
                                <Button 
                                  className="flex-1 bg-success hover:bg-success/90"
                                  onClick={() => {
                                    handleApprove(selectedInstructor.id);
                                    setSelectedInstructor(null);
                                  }}
                                >
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Aprovar
                                </Button>
                                <Button 
                                  variant="destructive"
                                  className="flex-1"
                                  onClick={() => {
                                    rejectInstructor(selectedInstructor.id);
                                    setSelectedInstructor(null);
                                  }}
                                >
                                  <XCircle className="h-4 w-4 mr-2" />
                                  Rejeitar
                                </Button>
                              </>
                            )}
                            {selectedInstructor.registration_status === 'approved' && (
                              <Button 
                                variant="outline"
                                className="flex-1 text-warning border-warning hover:bg-warning/10"
                                onClick={() => {
                                  pauseInstructor(selectedInstructor.id);
                                  setSelectedInstructor(null);
                                }}
                              >
                                <Pause className="h-4 w-4 mr-2" />
                                Pausar Instrutor
                              </Button>
                            )}
                            {selectedInstructor.registration_status === 'paused' && (
                              <Button 
                                className="flex-1 bg-success hover:bg-success/90"
                                onClick={() => {
                                  unpauseInstructor(selectedInstructor.id);
                                  setSelectedInstructor(null);
                                }}
                              >
                                <Play className="h-4 w-4 mr-2" />
                                Reativar Instrutor
                              </Button>
                            )}
                            {selectedInstructor.registration_status === 'rejected' && (
                              <Button 
                                className="flex-1"
                                onClick={() => {
                                  handleApprove(selectedInstructor.id);
                                  setSelectedInstructor(null);
                                }}
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Reaprovar
                              </Button>
                            )}
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  {renderActions(instructor)}
                </div>
              </div>

              {/* Categories and Certifications */}
              {(instructor.cnh_category || instructor.certifications?.length) && (
                <div className="mt-4 pt-4 border-t border-border flex flex-wrap gap-2">
                  {instructor.cnh_category && (
                    <span className="px-3 py-1 text-xs font-medium rounded-full bg-primary/10 text-primary">
                      Categoria {instructor.cnh_category}
                    </span>
                  )}
                  {instructor.certifications?.slice(0, 2).map((cert, i) => (
                    <span key={i} className="px-3 py-1 text-xs font-medium rounded-full bg-muted text-muted-foreground">
                      {cert}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredInstructors.length === 0 && (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-4">
              <UserCog className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Nenhum instrutor encontrado</h3>
            <p className="text-muted-foreground">
              {search ? 'Tente ajustar os filtros de busca' : 'Nenhum instrutor nesta categoria'}
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default AdminInstructors;