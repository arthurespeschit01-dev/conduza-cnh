import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAdminData } from '@/hooks/useAdminData';
import { CheckCircle, XCircle, Clock, FileText, Loader2, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { SecureDocumentLink } from '@/components/ui/secure-document-link';

const AdminApprovals = () => {
  const { instructors, isLoading, approveInstructor, rejectInstructor } = useAdminData();
  const [selectedInstructor, setSelectedInstructor] = useState<typeof instructors[0] | null>(null);

  // Filter pending instructors
  const pendingInstructors = instructors.filter(i => i.registration_status === 'pending');

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Aprovações Pendentes</h1>
          <p className="text-muted-foreground">
            Revise e aprove os novos cadastros de instrutores
          </p>
        </div>

        {/* Summary */}
        <div className="card-elevated p-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-xl bg-warning/10 flex items-center justify-center">
              <Clock className="h-7 w-7 text-warning" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{pendingInstructors.length}</p>
              <p className="text-muted-foreground">
                instrutor{pendingInstructors.length !== 1 ? 'es' : ''} aguardando aprovação
              </p>
            </div>
          </div>
        </div>

        {/* Info Card */}
        <div className="card-elevated p-4 mb-8 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <p className="font-medium text-foreground">Verificação de documentos</p>
              <p className="text-sm text-muted-foreground">
                Antes de aprovar, verifique se o instrutor enviou todos os documentos obrigatórios 
                (CNH, RG, Comprovante de Residência e Certificado de Instrutor) e se estão válidos.
              </p>
            </div>
          </div>
        </div>

        {/* Pending List */}
        {pendingInstructors.length > 0 ? (
          <div className="space-y-4">
            {pendingInstructors.map((instructor) => (
              <div key={instructor.id} className="card-elevated p-6">
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-lg flex-shrink-0">
                    {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1 flex-wrap">
                      <h3 className="text-lg font-semibold text-foreground">{instructor.full_name}</h3>
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                        <Clock className="h-3 w-3 mr-1" />
                        Pendente
                      </Badge>
                      <Badge variant="secondary" className="capitalize">
                        {instructor.subscription_plan || 'Básico'}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{instructor.email}</p>
                    <p className="text-sm text-muted-foreground">{instructor.city}, {instructor.uf}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Cadastrado em {format(new Date(instructor.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>

                  {/* Document Status */}
                  <div className="flex gap-2 flex-wrap">
                    <div className="text-center">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center mx-auto ${
                        instructor.cnh_document_path ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                      }`}>
                        <FileText className="h-4 w-4" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">CNH</p>
                    </div>
                    <div className="text-center">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center mx-auto ${
                        instructor.rg_document_path ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                      }`}>
                        <FileText className="h-4 w-4" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">RG</p>
                    </div>
                    <div className="text-center">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center mx-auto ${
                        instructor.proof_of_residence_path ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                      }`}>
                        <FileText className="h-4 w-4" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Residência</p>
                    </div>
                    <div className="text-center">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center mx-auto ${
                        instructor.instructor_certificate_path ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                      }`}>
                        <FileText className="h-4 w-4" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Certificado</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setSelectedInstructor(instructor)}>
                          Ver detalhes
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-lg">
                        <DialogHeader>
                          <DialogTitle>Revisar Instrutor</DialogTitle>
                        </DialogHeader>
                        
                        {selectedInstructor && (
                          <div className="space-y-4">
                            <div className="flex items-center gap-4">
                              <div className="h-16 w-16 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
                                {selectedInstructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                              </div>
                              <div>
                                <h3 className="text-lg font-semibold">{selectedInstructor.full_name}</h3>
                                <p className="text-sm text-muted-foreground">{selectedInstructor.email}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Telefone:</span>
                                <p className="font-medium">{selectedInstructor.phone || 'Não informado'}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">CPF:</span>
                                <p className="font-medium">{selectedInstructor.cpf || 'Não informado'}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">CNH:</span>
                                <p className="font-medium">{selectedInstructor.cnh || 'Não informado'}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Categoria:</span>
                                <p className="font-medium">{selectedInstructor.cnh_category || 'Não informado'}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Plano:</span>
                                <p className="font-medium capitalize">{selectedInstructor.subscription_plan || 'Básico'}</p>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Localização:</span>
                                <p className="font-medium">{selectedInstructor.city}, {selectedInstructor.uf}</p>
                              </div>
                            </div>

                            {/* Documents */}
                            <div className="border-t pt-4">
                              <h4 className="font-medium mb-3">Documentos</h4>
                              <div className="space-y-2">
                                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                  <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">CNH</span>
                                  </div>
                                  {selectedInstructor.cnh_document_path ? (
                                    <SecureDocumentLink documentUrl={selectedInstructor.cnh_document_path} />
                                  ) : (
                                    <Badge variant="destructive" className="text-xs">
                                      Não enviado
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                  <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">RG</span>
                                  </div>
                                  {selectedInstructor.rg_document_path ? (
                                    <SecureDocumentLink documentUrl={selectedInstructor.rg_document_path} />
                                  ) : (
                                    <Badge variant="destructive" className="text-xs">
                                      Não enviado
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                  <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">Comprovante de Residência</span>
                                  </div>
                                  {selectedInstructor.proof_of_residence_path ? (
                                    <SecureDocumentLink documentUrl={selectedInstructor.proof_of_residence_path} />
                                  ) : (
                                    <Badge variant="destructive" className="text-xs">
                                      Não enviado
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                                  <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">Certificado de Instrutor</span>
                                  </div>
                                  {selectedInstructor.instructor_certificate_path ? (
                                    <SecureDocumentLink documentUrl={selectedInstructor.instructor_certificate_path} />
                                  ) : (
                                    <Badge variant="destructive" className="text-xs">
                                      Não enviado
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="flex gap-3 pt-4 border-t">
                              <Button 
                                className="flex-1 bg-success hover:bg-success/90"
                                onClick={() => approveInstructor(selectedInstructor.id)}
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Aprovar
                              </Button>
                              <Button 
                                variant="destructive"
                                className="flex-1"
                                onClick={() => rejectInstructor(selectedInstructor.id)}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Rejeitar
                              </Button>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                    
                    <Button 
                      size="sm"
                      className="bg-success hover:bg-success/90"
                      onClick={() => approveInstructor(instructor.id)}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm"
                      variant="destructive"
                      onClick={() => rejectInstructor(instructor.id)}
                    >
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="h-20 w-20 mx-auto rounded-2xl bg-success/10 flex items-center justify-center mb-4">
              <CheckCircle className="h-10 w-10 text-success" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Tudo em dia!</h3>
            <p className="text-muted-foreground">
              Não há instrutores aguardando aprovação no momento
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default AdminApprovals;
