import { useState, useMemo, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/cards/StatCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useAdminData } from '@/hooks/useAdminData';
import { useAppSettings } from '@/hooks/useAppSettings';
import { useOperationalMetrics } from '@/hooks/useOperationalMetrics';
import { useStripeMRR, type MRRData } from '@/hooks/useStripeMRR';
import { OperationalMetricsCards } from '@/components/admin/OperationalMetricsCards';
import { MetricsEvolutionChart } from '@/components/admin/MetricsEvolutionChart';
import { PeriodComparisonCard } from '@/components/admin/PeriodComparisonCard';
import { SystemInsights } from '@/components/admin/SystemInsights';
import { ExportReportDialog, type ReportPeriodDates } from '@/components/admin/ExportReportDialog';
import { DashboardPeriodFilter, getDefaultPeriod, type DashboardPeriod } from '@/components/admin/DashboardPeriodFilter';
import { Link } from 'react-router-dom';
import { 
  Users, 
  UserCog, 
  Shield, 
  TrendingUp,
  TrendingDown,
  ArrowRight, 
  CheckCircle, 
  XCircle,
  Clock, 
  Loader2, 
  FileText,
  DollarSign,
  BarChart3,
  Package,
  Settings,
  Save,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  RefreshCw,
  CreditCard,
  AlertCircle,
  Repeat,
  Percent,
  UserCheck
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell, Legend } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { generateOperationalReport } from '@/lib/generateOperationalReport';

const AdminDashboard = () => {
  const { user } = useAuth();
  const { settings, updateLtvRetentionMonths } = useAppSettings();
  const { stats, instructors, isLoading, approveInstructor, rejectInstructor } = useAdminData(settings.ltvRetentionMonths);
  const [dashboardPeriod, setDashboardPeriod] = useState<DashboardPeriod>(getDefaultPeriod());
  const { metrics, insights, evolutionData, periodComparison, isLoading: metricsLoading } = useOperationalMetrics({
    startDate: dashboardPeriod.startDate,
    endDate: dashboardPeriod.endDate,
  });
  const { mrrData, isLoading: mrrLoading, fetchMRRData } = useStripeMRR();
  const [editingLtv, setEditingLtv] = useState(false);
  const [ltvValue, setLtvValue] = useState(settings.ltvRetentionMonths.toString());
  const [exportDialogOpen, setExportDialogOpen] = useState(false);

  // Fetch MRR data on mount
  useEffect(() => {
    fetchMRRData();
  }, [fetchMRRData]);

  // Get pending instructors (first 3)
  const pendingInstructors = instructors.filter(i => i.registration_status === 'pending').slice(0, 3);
  // Get approved instructors (first 4)
  const recentApproved = instructors.filter(i => i.registration_status === 'approved').slice(0, 4);

  const handleApprove = async (instructorId: string) => {
    await approveInstructor(instructorId);
  };

  const handleReject = async (instructorId: string) => {
    await rejectInstructor(instructorId);
  };

  const handleSaveLtv = async () => {
    const months = parseInt(ltvValue, 10);
    if (months > 0 && months <= 120) {
      await updateLtvRetentionMonths(months);
      setEditingLtv(false);
    }
  };

  const handleExportReport = (period: ReportPeriodDates) => {
    generateOperationalReport({ stats, metrics, insights, period });
  };

  // Generate revenue projection data for the next 12 months
  const revenueProjection = useMemo(() => {
    const monthlyRevenue = stats.totalRevenue;
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const currentMonth = new Date().getMonth();
    
    return Array.from({ length: 12 }, (_, i) => {
      const monthIndex = (currentMonth + i) % 12;
      // Simulate growth: 5% monthly growth rate
      const growthFactor = Math.pow(1.05, i);
      const projectedRevenue = monthlyRevenue * growthFactor;
      const accumulated = monthlyRevenue * ((Math.pow(1.05, i + 1) - 1) / 0.05);
      
      return {
        month: months[monthIndex],
        receita: Math.round(projectedRevenue * 100) / 100,
        acumulado: Math.round(accumulated * 100) / 100,
      };
    });
  }, [stats.totalRevenue]);

  // Revenue distribution by plan
  const revenueByPlan = useMemo(() => {
    const planPrices = { basic: 49, professional: 97, premium: 149 };
    const basicRevenue = stats.planStats.basic * planPrices.basic;
    const professionalRevenue = stats.planStats.professional * planPrices.professional;
    const premiumRevenue = stats.planStats.premium * planPrices.premium;
    
    return [
      { name: 'Básico', value: basicRevenue, color: 'hsl(var(--muted-foreground))' },
      { name: 'Profissional', value: professionalRevenue, color: 'hsl(var(--primary))' },
      { name: 'Premium', value: premiumRevenue, color: 'hsl(var(--accent))' },
    ].filter(item => item.value > 0);
  }, [stats.planStats]);

  const COLORS = ['hsl(var(--muted-foreground))', 'hsl(var(--primary))', 'hsl(var(--accent))'];

  const chartConfig = {
    receita: {
      label: "Receita Mensal",
      color: "hsl(var(--primary))",
    },
    acumulado: {
      label: "Acumulado",
      color: "hsl(var(--accent))",
    },
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Painel Administrativo
            </h1>
            <p className="text-muted-foreground">
              Gerencie a plataforma Conduza
            </p>
          </div>
          <Button 
            onClick={() => setExportDialogOpen(true)} 
            disabled={isLoading || metricsLoading}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Exportar Relatório PDF
          </Button>
        </div>

        <ExportReportDialog
          open={exportDialogOpen}
          onOpenChange={setExportDialogOpen}
          onExport={handleExportReport}
          isLoading={isLoading || metricsLoading}
        />

        {/* Period Filter */}
        <div className="mb-6 p-4 card-elevated">
          <DashboardPeriodFilter 
            period={dashboardPeriod} 
            onPeriodChange={setDashboardPeriod} 
          />
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total de Alunos"
            value={stats.totalStudents}
            description="Cadastrados na plataforma"
            icon={<Users className="h-6 w-6" />}
          />
          <StatCard
            title="Instrutores Ativos"
            value={stats.approvedInstructors}
            description="Credenciados e ativos"
            icon={<UserCog className="h-6 w-6" />}
          />
          <StatCard
            title="Aprovações Pendentes"
            value={stats.pendingApprovals}
            description="Aguardando revisão"
            icon={<Clock className="h-6 w-6" />}
          />
          <StatCard
            title="Docs Pendentes"
            value={stats.pendingDocuments}
            description="Documentação incompleta"
            icon={<FileText className="h-6 w-6" />}
          />
        </div>

        {/* Financial Stats Section Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
            <DollarSign className="h-5 w-5 text-success" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Financeiro</h2>
            <p className="text-sm text-muted-foreground">Métricas financeiras do Stripe (últimos 30 dias)</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => fetchMRRData()}
            disabled={mrrLoading}
            className="ml-auto gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${mrrLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        {/* Financial Metrics Row 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
          {/* Pagamentos Concluídos */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pagamentos Concluídos</p>
                <p className="text-xl font-bold text-foreground">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (mrrData?.payments.completed ?? 0)}
                </p>
                <p className="text-xs text-success">
                  R$ {(mrrData?.payments.completedAmount ?? 0).toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          {/* Pagamentos Falhados */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pagamentos Falhados</p>
                <p className="text-xl font-bold text-foreground">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (mrrData?.payments.failed ?? 0)}
                </p>
              </div>
            </div>
          </div>

          {/* Assinaturas Ativas */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <CreditCard className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Assinaturas Ativas</p>
                <p className="text-xl font-bold text-foreground">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (mrrData?.subscriptions.active ?? 0)}
                </p>
              </div>
            </div>
          </div>

          {/* Assinaturas Canceladas */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
                <XCircle className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Assinaturas Canceladas</p>
                <p className="text-xl font-bold text-foreground">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (mrrData?.subscriptions.canceled ?? 0)}
                </p>
                {mrrData?.subscriptions.canceledRecent ? (
                  <p className="text-xs text-destructive">
                    {mrrData.subscriptions.canceledRecent} recente{mrrData.subscriptions.canceledRecent !== 1 ? 's' : ''}
                  </p>
                ) : null}
              </div>
            </div>
          </div>

          {/* Upgrades / Downgrades */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-chart-4/10 flex items-center justify-center">
                <Repeat className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Upgrades / Downgrades</p>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-success flex items-center gap-0.5">
                    <ArrowUpRight className="h-3 w-3" />
                    {mrrLoading ? '-' : (mrrData?.subscriptions.upgrades ?? 0)}
                  </span>
                  <span className="text-muted-foreground">/</span>
                  <span className="text-sm font-medium text-destructive flex items-center gap-0.5">
                    <ArrowDownRight className="h-3 w-3" />
                    {mrrLoading ? '-' : (mrrData?.subscriptions.downgrades ?? 0)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Rates Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          {/* Taxa de Conversão */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Percent className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Taxa de Conversão</p>
                <p className="text-xl font-bold text-foreground">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : `${mrrData?.rates.conversion ?? 0}%`}
                </p>
                <p className="text-xs text-muted-foreground">
                  Pagamentos bem-sucedidos
                </p>
              </div>
            </div>
          </div>

          {/* Taxa de Retenção */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
                <UserCheck className="h-5 w-5 text-success" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Taxa de Retenção</p>
                <p className="text-xl font-bold text-success">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : `${mrrData?.rates.retention ?? 0}%`}
                </p>
                <p className="text-xs text-muted-foreground">
                  Clientes ativos mantidos
                </p>
              </div>
            </div>
          </div>

          {/* Taxa de Churn */}
          <div className="card-elevated p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                <TrendingDown className="h-5 w-5 text-destructive" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Taxa de Churn</p>
                <p className="text-xl font-bold text-destructive">
                  {mrrLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : `${mrrData?.rates.churn ?? 0}%`}
                </p>
                <p className="text-xs text-muted-foreground">
                  Cancelamentos no período
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* MRR by Plan Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="card-elevated p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">MRR por Plano</h3>
            {mrrLoading ? (
              <div className="h-64 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="h-64">
                <ChartContainer config={{
                  basic: { label: "Básico", color: "hsl(var(--muted-foreground))" },
                  professional: { label: "Profissional", color: "hsl(var(--primary))" },
                  premium: { label: "Premium", color: "hsl(var(--accent))" },
                }} className="h-full w-full">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Básico', value: mrrData?.planBreakdown.basic.mrr ?? 0, fill: 'hsl(var(--muted-foreground))' },
                        { name: 'Profissional', value: mrrData?.planBreakdown.professional.mrr ?? 0, fill: 'hsl(var(--primary))' },
                        { name: 'Premium', value: mrrData?.planBreakdown.premium.mrr ?? 0, fill: 'hsl(var(--accent))' },
                      ].filter(item => item.value > 0)}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                    </Pie>
                    <ChartTooltip 
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-popover border border-border rounded-lg p-2 shadow-lg">
                              <p className="font-medium">{payload[0].name}</p>
                              <p className="text-sm text-muted-foreground">
                                R$ {(payload[0].value as number).toFixed(2)}
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ChartContainer>
              </div>
            )}
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Detalhes por Plano</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-muted-foreground" />
                  <div>
                    <p className="font-medium text-foreground">Básico</p>
                    <p className="text-sm text-muted-foreground">
                      {mrrLoading ? '-' : (mrrData?.planBreakdown.basic.count ?? 0)} assinante{(mrrData?.planBreakdown.basic.count ?? 0) !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                <p className="text-lg font-bold text-foreground">
                  R$ {mrrLoading ? '-' : (mrrData?.planBreakdown.basic.mrr ?? 0).toFixed(2)}
                </p>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5">
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-primary" />
                  <div>
                    <p className="font-medium text-foreground">Profissional</p>
                    <p className="text-sm text-muted-foreground">
                      {mrrLoading ? '-' : (mrrData?.planBreakdown.professional.count ?? 0)} assinante{(mrrData?.planBreakdown.professional.count ?? 0) !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                <p className="text-lg font-bold text-foreground">
                  R$ {mrrLoading ? '-' : (mrrData?.planBreakdown.professional.mrr ?? 0).toFixed(2)}
                </p>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-accent/10">
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-accent" />
                  <div>
                    <p className="font-medium text-foreground">Premium</p>
                    <p className="text-sm text-muted-foreground">
                      {mrrLoading ? '-' : (mrrData?.planBreakdown.premium.count ?? 0)} assinante{(mrrData?.planBreakdown.premium.count ?? 0) !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                <p className="text-lg font-bold text-foreground">
                  R$ {mrrLoading ? '-' : (mrrData?.planBreakdown.premium.mrr ?? 0).toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Financial Stats Row 2 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card-elevated p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-success/10 flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Ticket Médio</p>
                <p className="text-2xl font-bold text-foreground">
                  R$ {stats.averageTicket.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">LTV</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {stats.ltv.toFixed(2)}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setLtvValue(settings.ltvRetentionMonths.toString());
                  setEditingLtv(!editingLtv);
                }}
                className="h-8 w-8"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
            {editingLtv && (
              <div className="mt-4 pt-4 border-t border-border">
                <label className="text-sm text-muted-foreground mb-2 block">
                  Meses de retenção
                </label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min="1"
                    max="120"
                    value={ltvValue}
                    onChange={(e) => setLtvValue(e.target.value)}
                    className="w-24"
                  />
                  <Button size="sm" onClick={handleSaveLtv}>
                    <Save className="h-4 w-4 mr-1" />
                    Salvar
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  LTV = Ticket Médio × {ltvValue} meses
                </p>
              </div>
            )}
          </div>
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-xl bg-chart-4/10 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-chart-4" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">MRR (Stripe)</p>
                  <p className="text-2xl font-bold text-foreground">
                    {mrrLoading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      `R$ ${(mrrData?.totalMRR ?? 0).toFixed(2)}`
                    )}
                  </p>
                  {mrrData && (
                    <p className="text-xs text-muted-foreground">
                      {mrrData.activeSubscribers} assinante{mrrData.activeSubscribers !== 1 ? 's' : ''} ativo{mrrData.activeSubscribers !== 1 ? 's' : ''}
                    </p>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => fetchMRRData()}
                disabled={mrrLoading}
                className="h-8 w-8"
              >
                <RefreshCw className={`h-4 w-4 ${mrrLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
            <div className="space-y-2 pt-3 border-t border-border">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <Plus className="h-3.5 w-3.5 text-success" />
                  New MRR
                  {mrrData?.breakdown.newCount ? (
                    <span className="text-xs">({mrrData.breakdown.newCount})</span>
                  ) : null}
                </span>
                <span className="font-medium text-success">
                  +R$ {(mrrData?.breakdown.newMRR ?? 0).toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <ArrowUpRight className="h-3.5 w-3.5 text-primary" />
                  Expansion
                </span>
                <span className="font-medium text-primary">
                  +R$ {(mrrData?.breakdown.expansion ?? 0).toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <Minus className="h-3.5 w-3.5 text-destructive" />
                  Churn
                  {mrrData?.breakdown.churnCount ? (
                    <span className="text-xs">({mrrData.breakdown.churnCount})</span>
                  ) : null}
                </span>
                <span className="font-medium text-destructive">
                  -R$ {(mrrData?.breakdown.churn ?? 0).toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm pt-2 border-t border-border">
                <span className="font-medium text-muted-foreground">Net MRR</span>
                <span className={`font-bold ${(mrrData?.breakdown.netMRR ?? 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  R$ {(mrrData?.breakdown.netMRR ?? 0).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
          <div className="card-elevated p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Receita Total</p>
                <p className="text-2xl font-bold text-foreground">
                  R$ {stats.totalRevenue.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Plan Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="card-elevated p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Distribuição de Planos</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 rounded-xl bg-muted/50">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Package className="h-5 w-5 text-muted-foreground" />
                  <Badge variant="secondary">Básico</Badge>
                </div>
                <p className="text-3xl font-bold text-foreground">{stats.planStats.basic}</p>
                <p className="text-sm text-muted-foreground">R$ 49/mês</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-primary/5">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Package className="h-5 w-5 text-primary" />
                  <Badge className="bg-primary">Profissional</Badge>
                </div>
                <p className="text-3xl font-bold text-primary">{stats.planStats.professional}</p>
                <p className="text-sm text-muted-foreground">R$ 97/mês</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-accent/5">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Package className="h-5 w-5 text-accent" />
                  <Badge className="bg-accent">Premium</Badge>
                </div>
                <p className="text-3xl font-bold text-accent">{stats.planStats.premium}</p>
                <p className="text-sm text-muted-foreground">R$ 149/mês</p>
              </div>
            </div>
          </div>

          {/* Revenue by Plan Pie Chart */}
          <div className="card-elevated p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Receita por Plano</h2>
            {revenueByPlan.length > 0 ? (
              <ChartContainer config={chartConfig} className="h-[200px] w-full">
                <PieChart>
                  <Pie
                    data={revenueByPlan}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {revenueByPlan.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <ChartTooltip 
                    content={<ChartTooltipContent />}
                    formatter={(value: number) => [`R$ ${value.toFixed(2)}`, '']}
                  />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    formatter={(value, entry: any) => (
                      <span className="text-sm text-muted-foreground">{value}</span>
                    )}
                  />
                </PieChart>
              </ChartContainer>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                Nenhum instrutor ativo
              </div>
            )}
          </div>
        </div>

        {/* Revenue Projection Chart */}
        <div className="card-elevated p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Projeção de Receita</h2>
              <p className="text-sm text-muted-foreground">Próximos 12 meses com crescimento de 5% ao mês</p>
            </div>
            <div className="flex gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-primary" />
                <span className="text-muted-foreground">Receita Mensal</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-accent" />
                <span className="text-muted-foreground">Acumulado</span>
              </div>
            </div>
          </div>
          <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <AreaChart data={revenueProjection} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorAcumulado" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="month" 
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                className="text-xs fill-muted-foreground"
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `R$${value}`}
              />
              <ChartTooltip 
                content={<ChartTooltipContent />}
                formatter={(value: number) => [`R$ ${value.toFixed(2)}`, '']}
              />
              <Area 
                type="monotone" 
                dataKey="receita" 
                stroke="hsl(var(--primary))" 
                fillOpacity={1} 
                fill="url(#colorReceita)" 
                strokeWidth={2}
              />
              <Area 
                type="monotone" 
                dataKey="acumulado" 
                stroke="hsl(var(--accent))" 
                fillOpacity={1} 
                fill="url(#colorAcumulado)" 
                strokeWidth={2}
              />
          </AreaChart>
        </ChartContainer>
      </div>

      {/* Metrics Evolution Chart */}
      {!metricsLoading && (
        <div className="card-elevated p-6 mb-8">
          <div className="mb-4">
            <h2 className="text-xl font-semibold text-foreground">Evolução das Métricas</h2>
            <p className="text-sm text-muted-foreground">Acompanhe a evolução operacional no período selecionado</p>
          </div>
          <MetricsEvolutionChart 
            data={evolutionData} 
            startDate={dashboardPeriod.startDate} 
            endDate={dashboardPeriod.endDate} 
          />
        </div>
      )}

      {/* Period Comparison + Operational Metrics */}
      {!metricsLoading && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <PeriodComparisonCard
            currentPeriodLabel={dashboardPeriod.label}
            previousPeriodLabel="Período anterior"
            metrics={[
              { label: 'Aprovações', currentValue: periodComparison.approvals.current, previousValue: periodComparison.approvals.previous },
              { label: 'Rejeições', currentValue: periodComparison.rejections.current, previousValue: periodComparison.rejections.previous, invertTrend: true },
              { label: 'Novos Instrutores', currentValue: periodComparison.newInstructors.current, previousValue: periodComparison.newInstructors.previous },
              { label: 'Agendamentos', currentValue: periodComparison.schedules.current, previousValue: periodComparison.schedules.previous },
              { label: 'Tempo Médio Aprovação', currentValue: periodComparison.avgApprovalDays.current, previousValue: periodComparison.avgApprovalDays.previous, format: 'days', invertTrend: true },
              { label: 'Taxa de Rejeição', currentValue: periodComparison.rejectionRate.current, previousValue: periodComparison.rejectionRate.previous, format: 'percentage', invertTrend: true },
            ]}
          />
          <div className="space-y-4">
            <OperationalMetricsCards metrics={metrics} />
          </div>
        </div>
      )}

      {/* Insights Section */}
      {!metricsLoading && (
        <div className="mb-8">
          <SystemInsights insights={insights} />
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Pending Approvals */}
            {pendingInstructors.length > 0 && (
              <div className="card-elevated p-6 border-warning/20 bg-warning/5">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-warning" />
                    <h2 className="text-xl font-semibold text-foreground">Aprovações Pendentes</h2>
                  </div>
                  <Link to="/sys/q5w4j6">
                    <Button variant="ghost" size="sm">
                      Ver todos
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>

                <div className="space-y-4">
                  {pendingInstructors.map((instructor) => (
                    <div key={instructor.id} className="flex items-center gap-4 p-4 rounded-xl bg-background">
                      <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                        {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{instructor.full_name}</p>
                        <p className="text-sm text-muted-foreground">{instructor.city}, {instructor.uf}</p>
                      </div>
                      <Badge variant="secondary" className="capitalize">
                        {instructor.subscription_plan || 'Básico'}
                      </Badge>
                      <div className="flex gap-1">
                        <div className={`h-2 w-2 rounded-full ${instructor.cnh_document_path ? 'bg-success' : 'bg-muted'}`} title="CNH" />
                        <div className={`h-2 w-2 rounded-full ${instructor.rg_document_path ? 'bg-success' : 'bg-muted'}`} title="RG" />
                        <div className={`h-2 w-2 rounded-full ${instructor.proof_of_residence_path ? 'bg-success' : 'bg-muted'}`} title="Residência" />
                        <div className={`h-2 w-2 rounded-full ${instructor.instructor_certificate_path ? 'bg-success' : 'bg-muted'}`} title="Certificado" />
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          className="bg-success hover:bg-success/90 h-8 w-8 p-0"
                          onClick={() => handleApprove(instructor.id)}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          className="h-8 w-8 p-0"
                          onClick={() => handleReject(instructor.id)}
                        >
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Instructors */}
            <div className="card-elevated p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-foreground">Instrutores Ativos</h2>
                <Link to="/sys/p3v8n1">
                  <Button variant="ghost" size="sm">
                    Ver todos
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>

              <div className="space-y-4">
                {recentApproved.length > 0 ? (
                  recentApproved.map((instructor) => (
                    <div key={instructor.id} className="flex items-center gap-4 p-4 rounded-xl bg-muted/50">
                      <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                        {instructor.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{instructor.full_name}</p>
                        <p className="text-sm text-muted-foreground">{instructor.city}, {instructor.uf}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-success">{instructor.approvalRate}%</p>
                        <p className="text-xs text-muted-foreground">Aprovação</p>
                      </div>
                      <CheckCircle className="h-5 w-5 text-success" />
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Nenhum instrutor aprovado ainda
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Admin Info */}
            <div className="card-elevated p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="h-14 w-14 rounded-xl bg-muted flex items-center justify-center">
                  <Shield className="h-7 w-7 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{user?.name}</p>
                  <p className="text-sm text-muted-foreground">Administrador</p>
                </div>
              </div>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Último acesso</span>
                  <span className="text-foreground">Agora</span>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Resumo Rápido</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Total Instrutores</span>
                  <span className="font-semibold text-foreground">{stats.totalInstructors}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Ativos</span>
                  <span className="font-semibold text-success">{stats.approvedInstructors}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Pendentes</span>
                  <span className="font-semibold text-warning">{stats.pendingApprovals}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Pausados</span>
                  <span className="font-semibold text-muted-foreground">{stats.pausedInstructors}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Rejeitados</span>
                  <span className="font-semibold text-destructive">{stats.rejectedInstructors}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Taxa Aprovação</span>
                  <span className="font-semibold text-foreground">
                    {stats.totalInstructors > 0 
                      ? Math.round((stats.approvedInstructors / stats.totalInstructors) * 100) 
                      : 0}%
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Ações Rápidas</h3>
              <div className="space-y-3">
                <Link to="/sys/p3v8n1" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <UserCog className="h-4 w-4 mr-2" />
                    Gerenciar instrutores
                  </Button>
                </Link>
                <Link to="/sys/q5w4j6" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Ver aprovações
                    {stats.pendingApprovals > 0 && (
                      <Badge className="ml-auto bg-warning text-warning-foreground">
                        {stats.pendingApprovals}
                      </Badge>
                    )}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default AdminDashboard;
