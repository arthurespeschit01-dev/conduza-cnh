import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { fetchAddressByCep, fetchAddressByCoordinates } from '@/services/locationService';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface Location {
  uf: string;
  city: string;
  neighborhood?: string;
  street?: string;
  cep?: string;
  coordinates?: Coordinates;
  isValid: boolean;
}

interface LocationContextType {
  location: Location;
  loading: boolean;
  setUf: (uf: string) => void;
  setCity: (city: string) => void;
  setLocationDirect: (uf: string, city: string, neighborhood?: string, street?: string, cep?: string) => void;
  setLocationFromCep: (cep: string) => Promise<boolean>;
  setLocationFromCoordinates: (lat: number, lng: number) => Promise<boolean>;
  setCoordinates: (lat: number, lng: number) => void;
  resetLocation: () => void;
}

const defaultLocation: Location = {
  uf: '',
  city: '',
  neighborhood: '',
  street: '',
  cep: '',
  coordinates: undefined,
  isValid: false,
};

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export const LocationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [location, setLocation] = useState<Location>(() => {
    const saved = localStorage.getItem('cnh_location');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          uf: parsed.uf || '',
          city: parsed.city || '',
          neighborhood: parsed.neighborhood || '',
          street: parsed.street || '',
          cep: parsed.cep || '',
          coordinates: parsed.coordinates || undefined,
          isValid: Boolean(parsed.uf && parsed.city),
        };
      } catch {
        return defaultLocation;
      }
    }
    return defaultLocation;
  });
  
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    localStorage.setItem('cnh_location', JSON.stringify(location));
  }, [location]);

  const setUf = (uf: string) => {
    setLocation({
      uf,
      city: '',
      neighborhood: '',
      street: '',
      cep: '',
      isValid: false,
    });
  };

  const setCity = (city: string) => {
    setLocation((prev) => ({
      ...prev,
      city,
      isValid: Boolean(prev.uf && city),
    }));
  };

  const setLocationDirect = (uf: string, city: string, neighborhood?: string, street?: string, cep?: string) => {
    setLocation({
      uf,
      city,
      neighborhood: neighborhood || '',
      street: street || '',
      cep: cep || '',
      isValid: Boolean(uf && city),
    });
  };

  const setLocationFromCep = async (cep: string): Promise<boolean> => {
    setLoading(true);
    try {
      const address = await fetchAddressByCep(cep);
      if (address) {
        setLocation({
          uf: address.uf,
          city: address.city,
          neighborhood: address.neighborhood || '',
          street: address.street || '',
          cep: cep.replace(/\D/g, ''),
          isValid: true,
        });
        return true;
      }
      return false;
    } finally {
      setLoading(false);
    }
  };

  const setLocationFromCoordinates = async (lat: number, lng: number): Promise<boolean> => {
    setLoading(true);
    try {
      const address = await fetchAddressByCoordinates(lat, lng);
      if (address) {
        setLocation({
          uf: address.uf,
          city: address.city,
          neighborhood: '',
          street: '',
          cep: '',
          coordinates: { latitude: lat, longitude: lng },
          isValid: true,
        });
        return true;
      }
      return false;
    } finally {
      setLoading(false);
    }
  };

  const setCoordinates = (lat: number, lng: number) => {
    setLocation((prev) => ({
      ...prev,
      coordinates: { latitude: lat, longitude: lng },
    }));
  };

  const resetLocation = () => {
    setLocation(defaultLocation);
    localStorage.removeItem('cnh_location');
  };

  return (
    <LocationContext.Provider value={{ 
      location, 
      loading,
      setUf, 
      setCity, 
      setLocationDirect,
      setLocationFromCep,
      setLocationFromCoordinates,
      setCoordinates,
      resetLocation 
    }}>
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = (): LocationContextType => {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
};
