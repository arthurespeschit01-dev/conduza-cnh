import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { LocationProvider } from "@/contexts/LocationContext";
import { LocationGuard } from "@/components/guards/LocationGuard";
import { AuthGuard } from "@/components/guards/AuthGuard";

// Public Pages
import Index from "./pages/Index";
import HowItWorks from "./pages/HowItWorks";
import BlogInstrutor from "./pages/BlogInstrutor";
import ArticlePage from "./pages/ArticlePage";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import StudentRegister from "./pages/auth/StudentRegister";
import InstructorPlans from "./pages/auth/InstructorPlans";
import InstructorRegisterFlow from "./pages/auth/InstructorRegisterFlow";
import ForgotPassword from "./pages/auth/ForgotPassword";
import CheckoutSuccess from "./pages/checkout/CheckoutSuccess";
import EmbeddedCheckoutPage from "./pages/checkout/EmbeddedCheckout";

// Support Pages
import HelpCenter from "./pages/support/HelpCenter";
import TermsOfUse from "./pages/support/TermsOfUse";
import PrivacyPolicy from "./pages/support/PrivacyPolicy";
import Contact from "./pages/support/Contact";
import Pricing from "./pages/support/Pricing";

// Onboarding Pages
import LocationOnboarding from "./pages/onboarding/LocationOnboarding";
import ProfileOnboarding from "./pages/onboarding/ProfileOnboarding";

// Student Pages
import StudentDashboard from "./pages/student/StudentDashboard";
import StudentInstructors from "./pages/student/StudentInstructors";
import StudentProgress from "./pages/student/StudentProgress";
import StudentExams from "./pages/student/StudentExams";
import StudentSchedule from "./pages/student/StudentSchedule";
import StudentMyInstructor from "./pages/student/StudentMyInstructor";

// Instructor Pages
import InstructorDashboard from "./pages/instructor/InstructorDashboard";
import InstructorProfile from "./pages/instructor/InstructorProfile";
import InstructorStudents from "./pages/instructor/InstructorStudents";
import InstructorResults from "./pages/instructor/InstructorResults";
import InstructorDocuments from "./pages/instructor/InstructorDocuments";
import InstructorReports from "./pages/instructor/InstructorReports";
import InstructorAdvancedStudents from "./pages/instructor/InstructorAdvancedStudents";
import InstructorCustomProfile from "./pages/instructor/InstructorCustomProfile";
import InstructorSubscription from "./pages/instructor/InstructorSubscription";
import InstructorSchedule from "./pages/instructor/InstructorSchedule";
import Notifications from "./pages/Notifications";

// Internal Management Pages (obfuscated routes)
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminInstructors from "./pages/admin/AdminInstructors";
import AdminApprovals from "./pages/admin/AdminApprovals";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <LocationProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
            <LocationGuard>
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Index />} />
                <Route path="/como-funciona" element={<HowItWorks />} />
                <Route path="/blog-instrutor" element={<BlogInstrutor />} />
                <Route path="/blog-instrutor/:id" element={<ArticlePage />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/register/student" element={<StudentRegister />} />
                <Route path="/register/instructor" element={<InstructorPlans />} />
                <Route path="/register/instructor/form" element={<InstructorRegisterFlow />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/checkout/success" element={<CheckoutSuccess />} />
                <Route path="/checkout/embedded" element={<EmbeddedCheckoutPage />} />

                {/* Support Routes */}
                <Route path="/ajuda" element={<HelpCenter />} />
                <Route path="/termos" element={<TermsOfUse />} />
                <Route path="/privacidade" element={<PrivacyPolicy />} />
                <Route path="/contato" element={<Contact />} />
                <Route path="/precos" element={<Pricing />} />

                {/* Onboarding Routes */}
                <Route path="/onboarding/location" element={<LocationOnboarding />} />
                <Route path="/onboarding/profile" element={<ProfileOnboarding />} />

                {/* Student Routes */}
                <Route
                  path="/student/dashboard"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentDashboard />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/student/instructors"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentInstructors />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/student/progress"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentProgress />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/student/exams"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentExams />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/student/schedule"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentSchedule />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/student/my-instructor"
                  element={
                    <AuthGuard allowedRoles={['student']}>
                      <StudentMyInstructor />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/notifications"
                  element={
                    <AuthGuard allowedRoles={['student', 'instructor', 'admin']}>
                      <Notifications />
                    </AuthGuard>
                  }
                />

                {/* Instructor Routes */}
                <Route
                  path="/instructor/dashboard"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorDashboard />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/profile"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorProfile />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/students"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorStudents />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/results"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorResults />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/documents"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorDocuments />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/reports"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorReports />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/students/advanced"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorAdvancedStudents />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/custom-profile"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorCustomProfile />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/subscription"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorSubscription />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/instructor/schedule"
                  element={
                    <AuthGuard allowedRoles={['instructor']}>
                      <InstructorSchedule />
                    </AuthGuard>
                  }
                />

                {/* Internal Management Routes - Obfuscated paths */}
                <Route
                  path="/sys/m7x9k2"
                  element={
                    <AuthGuard allowedRoles={['admin']}>
                      <AdminDashboard />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/sys/p3v8n1"
                  element={
                    <AuthGuard allowedRoles={['admin']}>
                      <AdminInstructors />
                    </AuthGuard>
                  }
                />
                <Route
                  path="/sys/q5w4j6"
                  element={
                    <AuthGuard allowedRoles={['admin']}>
                      <AdminApprovals />
                    </AuthGuard>
                  }
                />

                {/* Catch All */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </LocationGuard>
          </BrowserRouter>
        </LocationProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
