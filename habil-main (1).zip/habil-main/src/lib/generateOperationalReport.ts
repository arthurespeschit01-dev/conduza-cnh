import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface AdminStats {
  totalStudents: number;
  totalInstructors: number;
  pendingApprovals: number;
  approvedInstructors: number;
  pausedInstructors: number;
  pendingDocuments: number;
  rejectedInstructors: number;
  averageTicket: number;
  totalRevenue: number;
  ltv: number;
  planStats: {
    basic: number;
    professional: number;
    premium: number;
  };
}

interface OperationalMetrics {
  avgApprovalTime: {
    days: number;
    hours: number;
    previousPeriodDays: number;
    trend: 'up' | 'down' | 'stable';
  };
  rejectionRate: {
    percentage: number;
    total: number;
    rejected: number;
  };
  documentResubmissions: number;
  inactiveInstructors: {
    count: number;
    instructors: Array<{
      id: string;
      full_name: string;
      lastActivity: Date | null;
      daysSinceActivity: number;
    }>;
  };
  instructorsByRegion: Array<{
    region: string;
    count: number;
    type: 'city' | 'state';
  }>;
}

interface Insight {
  id: string;
  type: 'info' | 'warning' | 'critical';
  title: string;
  description: string;
  category: string;
  createdAt: Date;
}

export type ReportPeriodType = 'today' | 'yesterday' | 'this_week' | 'last_week' | 'this_month' | 'last_month' | 'last_quarter' | 'last_year' | 'custom';

export interface ReportPeriodDates {
  type: ReportPeriodType;
  startDate: Date;
  endDate: Date;
}

interface ReportData {
  stats: AdminStats;
  metrics: OperationalMetrics;
  insights: Insight[];
  period?: ReportPeriodDates;
}

const getPeriodLabel = (period: ReportPeriodDates): string => {
  const labels: Record<ReportPeriodType, string> = {
    today: 'Hoje',
    yesterday: 'Ontem',
    this_week: 'Esta Semana',
    last_week: 'Semana Passada',
    this_month: 'Este Mês',
    last_month: 'Mês Passado',
    last_quarter: 'Último Trimestre',
    last_year: 'Último Ano',
    custom: 'Personalizado',
  };
  return labels[period.type];
};

export const generateOperationalReport = (data: ReportData) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPosition = 20;
  
  // Default period if not provided
  const period: ReportPeriodDates = data.period || {
    type: 'last_month',
    startDate: new Date(new Date().setDate(new Date().getDate() - 30)),
    endDate: new Date(),
  };

  // Helper function to add new page if needed
  const checkNewPage = (requiredSpace: number) => {
    if (yPosition + requiredSpace > 280) {
      doc.addPage();
      yPosition = 20;
    }
  };

  const now = new Date();

  // Header
  doc.setFillColor(37, 99, 235); // Primary blue
  doc.rect(0, 0, pageWidth, 45, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('Relatório Operacional', 14, 22);
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Período: ${getPeriodLabel(period)}`, 14, 32);
  
  doc.setFontSize(10);
  doc.text(
    `${format(period.startDate, 'dd/MM/yyyy', { locale: ptBR })} a ${format(period.endDate, 'dd/MM/yyyy', { locale: ptBR })} | Gerado em: ${format(now, 'dd/MM/yyyy', { locale: ptBR })} às ${format(now, 'HH:mm:ss', { locale: ptBR })}`,
    14,
    40
  );

  yPosition = 60;
  doc.setTextColor(0, 0, 0);

  // Section: Platform Overview
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Visão Geral da Plataforma', 14, yPosition);
  yPosition += 10;

  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');

  autoTable(doc, {
    startY: yPosition,
    head: [['Métrica', 'Valor']],
    body: [
      ['Total de Alunos', data.stats.totalStudents.toString()],
      ['Total de Instrutores', data.stats.totalInstructors.toString()],
      ['Instrutores Aprovados', data.stats.approvedInstructors.toString()],
      ['Aprovações Pendentes', data.stats.pendingApprovals.toString()],
      ['Instrutores Pausados', data.stats.pausedInstructors.toString()],
      ['Instrutores Rejeitados', data.stats.rejectedInstructors.toString()],
      ['Documentos Pendentes', data.stats.pendingDocuments.toString()],
    ],
    theme: 'striped',
    headStyles: { fillColor: [37, 99, 235] },
    styles: { fontSize: 9 },
    margin: { left: 14, right: 14 },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Section: Financial Data
  checkNewPage(60);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Dados Financeiros', 14, yPosition);
  yPosition += 10;

  autoTable(doc, {
    startY: yPosition,
    head: [['Métrica', 'Valor']],
    body: [
      ['Ticket Médio', `R$ ${data.stats.averageTicket.toFixed(2)}`],
      ['LTV', `R$ ${data.stats.ltv.toFixed(2)}`],
      ['Receita Total', `R$ ${data.stats.totalRevenue.toFixed(2)}`],
    ],
    theme: 'striped',
    headStyles: { fillColor: [34, 197, 94] },
    styles: { fontSize: 9 },
    margin: { left: 14, right: 14 },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Section: Plan Distribution
  checkNewPage(60);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Distribuição de Planos', 14, yPosition);
  yPosition += 10;

  autoTable(doc, {
    startY: yPosition,
    head: [['Plano', 'Quantidade', 'Receita Mensal']],
    body: [
      ['Básico', data.stats.planStats.basic.toString(), `R$ ${(data.stats.planStats.basic * 49).toFixed(2)}`],
      ['Profissional', data.stats.planStats.professional.toString(), `R$ ${(data.stats.planStats.professional * 97).toFixed(2)}`],
      ['Premium', data.stats.planStats.premium.toString(), `R$ ${(data.stats.planStats.premium * 149).toFixed(2)}`],
    ],
    theme: 'striped',
    headStyles: { fillColor: [139, 92, 246] },
    styles: { fontSize: 9 },
    margin: { left: 14, right: 14 },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Section: Operational Metrics
  checkNewPage(80);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Métricas Operacionais', 14, yPosition);
  yPosition += 10;

  const trendText = data.metrics.avgApprovalTime.trend === 'up' ? '↑ Aumentando' : 
                    data.metrics.avgApprovalTime.trend === 'down' ? '↓ Diminuindo' : '→ Estável';

  autoTable(doc, {
    startY: yPosition,
    head: [['Métrica', 'Valor', 'Observação']],
    body: [
      [
        'Tempo Médio de Aprovação', 
        `${data.metrics.avgApprovalTime.days}d ${data.metrics.avgApprovalTime.hours}h`,
        `${trendText} (anterior: ${data.metrics.avgApprovalTime.previousPeriodDays}d)`
      ],
      [
        'Taxa de Reprovação', 
        `${data.metrics.rejectionRate.percentage.toFixed(1)}%`,
        `${data.metrics.rejectionRate.rejected} de ${data.metrics.rejectionRate.total} analisados`
      ],
      [
        'Reenvio de Documentos', 
        data.metrics.documentResubmissions.toString(),
        'Documentos atualizados'
      ],
      [
        'Instrutores Inativos', 
        data.metrics.inactiveInstructors.count.toString(),
        'Sem atividade há 30+ dias'
      ],
    ],
    theme: 'striped',
    headStyles: { fillColor: [245, 158, 11] },
    styles: { fontSize: 9 },
    margin: { left: 14, right: 14 },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Section: Instructors by Region
  checkNewPage(80);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Instrutores por Região', 14, yPosition);
  yPosition += 10;

  const stateRegions = data.metrics.instructorsByRegion.filter(r => r.type === 'state');
  const cityRegions = data.metrics.instructorsByRegion.filter(r => r.type === 'city').slice(0, 10);

  if (stateRegions.length > 0) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 100, 100);
    doc.text('Por Estado', 14, yPosition);
    yPosition += 5;

    autoTable(doc, {
      startY: yPosition,
      head: [['Estado', 'Instrutores']],
      body: stateRegions.map(r => [r.region, r.count.toString()]),
      theme: 'striped',
      headStyles: { fillColor: [59, 130, 246] },
      styles: { fontSize: 9 },
      margin: { left: 14, right: 14 },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 10;
  }

  if (cityRegions.length > 0) {
    checkNewPage(60);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 100, 100);
    doc.text('Top Cidades', 14, yPosition);
    yPosition += 5;

    autoTable(doc, {
      startY: yPosition,
      head: [['Cidade', 'Instrutores']],
      body: cityRegions.map(r => [r.region, r.count.toString()]),
      theme: 'striped',
      headStyles: { fillColor: [139, 92, 246] },
      styles: { fontSize: 9 },
      margin: { left: 14, right: 14 },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 15;
  }

  // Section: System Insights
  if (data.insights.length > 0) {
    checkNewPage(80);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text('Insights do Sistema', 14, yPosition);
    yPosition += 10;

    const priorityLabels = { critical: 'CRÍTICO', warning: 'ATENÇÃO', info: 'INFO' };
    const insightRows = data.insights.map(insight => [
      priorityLabels[insight.type],
      insight.category,
      insight.title,
      insight.description,
    ]);

    autoTable(doc, {
      startY: yPosition,
      head: [['Prioridade', 'Categoria', 'Título', 'Descrição']],
      body: insightRows,
      theme: 'striped',
      headStyles: { fillColor: [220, 38, 38] },
      styles: { fontSize: 8, cellWidth: 'wrap' },
      columnStyles: {
        0: { cellWidth: 25 },
        1: { cellWidth: 25 },
        2: { cellWidth: 40 },
        3: { cellWidth: 'auto' },
      },
      margin: { left: 14, right: 14 },
      didParseCell: (hookData) => {
        if (hookData.section === 'body' && hookData.column.index === 0) {
          const priority = hookData.cell.raw as string;
          if (priority === 'CRÍTICO') {
            hookData.cell.styles.textColor = [220, 38, 38];
            hookData.cell.styles.fontStyle = 'bold';
          } else if (priority === 'ATENÇÃO') {
            hookData.cell.styles.textColor = [245, 158, 11];
            hookData.cell.styles.fontStyle = 'bold';
          } else {
            hookData.cell.styles.textColor = [59, 130, 246];
          }
        }
      },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 15;
  }

  // Section: Inactive Instructors (if any)
  if (data.metrics.inactiveInstructors.instructors.length > 0) {
    checkNewPage(80);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text('Instrutores Inativos (Detalhado)', 14, yPosition);
    yPosition += 10;

    const inactiveRows = data.metrics.inactiveInstructors.instructors.slice(0, 15).map(i => [
      i.full_name,
      i.lastActivity ? i.lastActivity.toLocaleDateString('pt-BR') : 'Nunca',
      `${i.daysSinceActivity} dias`,
    ]);

    autoTable(doc, {
      startY: yPosition,
      head: [['Nome', 'Última Atividade', 'Dias Inativo']],
      body: inactiveRows,
      theme: 'striped',
      headStyles: { fillColor: [107, 114, 128] },
      styles: { fontSize: 9 },
      margin: { left: 14, right: 14 },
    });
  }

  // Footer on last page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
  doc.text(
      `Página ${i} de ${pageCount} | Conduza - Relatório Operacional`,
      pageWidth / 2,
      290,
      { align: 'center' }
    );
  }

  // Save the PDF
  const periodSuffix = `-${period.type.replace('_', '-')}`;
  const fileName = `relatorio-operacional${periodSuffix}-${now.toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);
};
