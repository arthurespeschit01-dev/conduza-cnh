import { supabase } from '@/integrations/supabase/client';

/**
 * Extrai o path do arquivo a partir de uma URL completa do Supabase Storage
 * @param url URL completa do documento
 * @param bucket Nome do bucket
 * @returns Path relativo do arquivo
 */
export const extractPathFromUrl = (url: string, bucket: string): string | null => {
  if (!url) return null;
  
  // Padrão: https://xxx.supabase.co/storage/v1/object/public/bucket-name/path/to/file.ext
  const regex = new RegExp(`/storage/v1/object/(?:public|sign)/${bucket}/(.+?)(?:\\?|$)`);
  const match = url.match(regex);
  
  if (match) {
    return decodeURIComponent(match[1]);
  }
  
  // Fallback: tentar extrair o path depois do nome do bucket
  const parts = url.split(`/${bucket}/`);
  if (parts.length > 1) {
    const path = parts[1].split('?')[0];
    return decodeURIComponent(path);
  }
  
  return null;
};

/**
 * Gera uma URL assinada para acessar um arquivo privado
 * @param bucket Nome do bucket
 * @param path Caminho do arquivo ou URL completa
 * @param expiresIn Tempo de expiração em segundos (padrão: 1 hora)
 * @returns URL assinada ou null em caso de erro
 */
export const getSignedUrl = async (
  bucket: string,
  pathOrUrl: string,
  expiresIn: number = 3600
): Promise<string | null> => {
  if (!pathOrUrl) return null;
  
  // Se for uma URL completa, extrair o path
  const path = pathOrUrl.includes('http') 
    ? extractPathFromUrl(pathOrUrl, bucket) 
    : pathOrUrl;
  
  if (!path) return null;
  
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn);
    
    if (error) {
      console.error('Error creating signed URL:', error);
      return null;
    }
    
    return data?.signedUrl || null;
  } catch (error) {
    console.error('Error in getSignedUrl:', error);
    return null;
  }
};

/**
 * Gera uma URL assinada para documentos de instrutor
 * @param documentUrl URL do documento armazenada no banco
 * @returns URL assinada ou null
 */
export const getInstructorDocumentUrl = async (documentUrl: string | null): Promise<string | null> => {
  if (!documentUrl) return null;
  return getSignedUrl('instructor-documents', documentUrl);
};

/**
 * Gera uma URL assinada para documentos de exame
 * @param documentUrl URL do documento armazenada no banco
 * @returns URL assinada ou null
 */
export const getExamDocumentUrl = async (documentUrl: string | null): Promise<string | null> => {
  if (!documentUrl) return null;
  return getSignedUrl('exam-documents', documentUrl);
};

export type DocumentBucket = 'instructor-documents' | 'exam-documents';

/**
 * Abre um documento em uma nova aba usando URL assinada
 * @param documentUrl URL do documento
 * @param bucket Nome do bucket (padrão: instructor-documents)
 * @param onError Callback de erro opcional
 */
export const openSecureDocument = async (
  documentUrl: string | null,
  bucket: DocumentBucket = 'instructor-documents',
  onError?: () => void
): Promise<void> => {
  if (!documentUrl) {
    onError?.();
    return;
  }
  
  const signedUrl = await getSignedUrl(bucket, documentUrl);
  
  if (signedUrl) {
    window.open(signedUrl, '_blank', 'noopener,noreferrer');
  } else {
    onError?.();
  }
};
