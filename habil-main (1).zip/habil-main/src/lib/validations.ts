import { z } from 'zod';

/**
 * Validation schemas for authentication forms
 * These ensure proper input validation and prevent injection attacks
 */

// Email validation
export const emailSchema = z
  .string()
  .trim()
  .min(1, 'Email é obrigatório')
  .email('Email inválido')
  .max(255, 'Email muito longo');

// Password validation
export const passwordSchema = z
  .string()
  .min(6, 'Senha deve ter pelo menos 6 caracteres')
  .max(128, 'Senha muito longa');

// Strong password validation (optional - for enhanced security)
export const strongPasswordSchema = z
  .string()
  .min(8, 'Senha deve ter pelo menos 8 caracteres')
  .max(128, 'Senha muito longa')
  .regex(/[a-z]/, 'Senha deve conter pelo menos uma letra minúscula')
  .regex(/[A-Z]/, 'Senha deve conter pelo menos uma letra maiúscula')
  .regex(/[0-9]/, 'Senha deve conter pelo menos um número');

// Name validation
export const nameSchema = z
  .string()
  .trim()
  .min(2, 'Nome deve ter pelo menos 2 caracteres')
  .max(100, 'Nome muito longo')
  .regex(/^[a-zA-ZÀ-ÿ\s'-]+$/, 'Nome contém caracteres inválidos');

// CPF validation (Brazilian tax ID)
export const cpfSchema = z
  .string()
  .transform(val => val.replace(/\D/g, ''))
  .refine(val => val.length === 11, 'CPF deve ter 11 dígitos')
  .refine(val => {
    // CPF validation algorithm
    if (/^(\d)\1+$/.test(val)) return false;
    
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(val[i]) * (10 - i);
    }
    let remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(val[9])) return false;
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(val[i]) * (11 - i);
    }
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    return remainder === parseInt(val[10]);
  }, 'CPF inválido');

// Phone validation (Brazilian format)
export const phoneSchema = z
  .string()
  .transform(val => val.replace(/\D/g, ''))
  .refine(val => val.length >= 10 && val.length <= 11, 'Telefone inválido');

// Login form schema
export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Senha é obrigatória'),
});

// Student registration schema (uses strong password validation)
export const studentRegisterSchema = z.object({
  name: nameSchema,
  email: emailSchema,
  password: strongPasswordSchema,
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: 'Senhas não conferem',
  path: ['confirmPassword'],
});

// Forgot password schema
export const forgotPasswordSchema = z.object({
  email: emailSchema,
});

// Instructor registration schema (partial - for personal step)
export const instructorPersonalSchema = z.object({
  fullName: nameSchema,
  email: emailSchema.optional(),
  password: passwordSchema.optional(),
  confirmPassword: z.string().optional(),
  cpf: cpfSchema,
  phone: phoneSchema.optional(),
  bio: z.string().max(500, 'Biografia muito longa').optional(),
}).refine(data => {
  if (data.password && data.confirmPassword) {
    return data.password === data.confirmPassword;
  }
  return true;
}, {
  message: 'Senhas não conferem',
  path: ['confirmPassword'],
});

// Review comment schema
export const reviewCommentSchema = z
  .string()
  .max(1000, 'Comentário muito longo (máximo 1000 caracteres)')
  .optional();

// Schedule notes schema
export const scheduleNotesSchema = z
  .string()
  .max(500, 'Observações muito longas (máximo 500 caracteres)')
  .optional();

// Generic text input schema (for sanitization)
export const sanitizedTextSchema = z
  .string()
  .trim()
  .transform(val => val.replace(/<[^>]*>/g, '')); // Remove HTML tags

export type LoginFormData = z.infer<typeof loginSchema>;
export type StudentRegisterFormData = z.infer<typeof studentRegisterSchema>;
export type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;
export type InstructorPersonalFormData = z.infer<typeof instructorPersonalSchema>;
