import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/lib/logger';
import type { Database } from '@/integrations/supabase/types';

type Exam = Database['public']['Tables']['exams']['Row'];
type ExamInsert = Database['public']['Tables']['exams']['Insert'];

interface ExamWithProfiles extends Exam {
  instructor?: {
    id: string;
    full_name: string;
  };
  student?: {
    id: string;
    full_name: string;
  };
}

export const useExams = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [exams, setExams] = useState<ExamWithProfiles[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchExams = async () => {
    if (!user) return;

    setIsLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('exams')
        .select('*')
        .order('exam_date', { ascending: false });

      if (fetchError) throw fetchError;

      // Fetch related profiles
      if (data && data.length > 0) {
        const instructorIds = [...new Set(data.map(e => e.instructor_id))];
        const studentIds = [...new Set(data.map(e => e.student_id))];
        const allIds = [...new Set([...instructorIds, ...studentIds])];

        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', allIds);

        const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

        const enrichedData = data.map(exam => ({
          ...exam,
          instructor: profileMap.get(exam.instructor_id),
          student: profileMap.get(exam.student_id),
        }));

        setExams(enrichedData);
      } else {
        setExams([]);
      }
    } catch (err) {
      logger.error('Error fetching exams:', err);
      setError('Erro ao carregar exames');
    } finally {
      setIsLoading(false);
    }
  };

  const uploadExamDocument = async (file: File): Promise<string | null> => {
    if (!user) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('exam-documents')
      .upload(fileName, file);

    if (uploadError) {
      logger.error('Error uploading document:', uploadError);
      return null;
    }

    // Return the file path instead of public URL - signed URLs should be generated when viewing
    return fileName;
  };

  const getExamDocumentSignedUrl = async (documentPath: string): Promise<string | null> => {
    const { data, error } = await supabase.storage
      .from('exam-documents')
      .createSignedUrl(documentPath, 3600); // 1 hour expiration

    if (error) {
      logger.error('Error creating signed URL:', error);
      return null;
    }

    return data.signedUrl;
  };

  const createExam = async (examData: Omit<ExamInsert, 'student_id'>, documentFile?: File) => {
    if (!user) return { success: false, error: 'Usuário não autenticado' };

    try {
      let documentUrl: string | undefined;

      // Upload document if provided
      if (documentFile) {
        const uploadedUrl = await uploadExamDocument(documentFile);
        if (!uploadedUrl) {
          return { success: false, error: 'Erro ao enviar documento' };
        }
        documentUrl = uploadedUrl;
      }

      const { error: insertError } = await supabase
        .from('exams')
        .insert({
          ...examData,
          student_id: user.id,
          document_url: documentUrl,
        });

      if (insertError) throw insertError;

      toast({
        title: 'Exame registrado!',
        description: 'O exame foi registrado com sucesso.',
      });

      await fetchExams();
      return { success: true };
    } catch (err) {
      logger.error('Error creating exam:', err);
      return { success: false, error: 'Erro ao registrar exame' };
    }
  };

  const confirmExamResult = async (examId: string, passed: boolean) => {
    if (!user) return { success: false, error: 'Usuário não autenticado' };

    try {
      const updateData: Partial<Exam> = {
        confirmed_by_student: true,
        student_passed: passed,
        status: passed ? 'approved' : 'failed',
      };

      const { error: updateError } = await supabase
        .from('exams')
        .update(updateData)
        .eq('id', examId);

      if (updateError) throw updateError;

      toast({
        title: 'Resultado confirmado!',
        description: passed ? 'Parabéns pela aprovação!' : 'Continue praticando!',
      });

      await fetchExams();
      return { success: true };
    } catch (err) {
      logger.error('Error confirming exam:', err);
      return { success: false, error: 'Erro ao confirmar resultado' };
    }
  };

  const instructorConfirmExam = async (examId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('exams')
        .update({ confirmed_by_instructor: true })
        .eq('id', examId);

      if (updateError) throw updateError;

      toast({
        title: 'Resultado confirmado!',
        description: 'O resultado foi confirmado pelo instrutor.',
      });

      await fetchExams();
      return { success: true };
    } catch (err) {
      logger.error('Error confirming exam:', err);
      return { success: false, error: 'Erro ao confirmar resultado' };
    }
  };

  // Calculate instructor approval rate from confirmed exams
  const getInstructorApprovalRate = (instructorId: string) => {
    const confirmedExams = exams.filter(
      e => e.instructor_id === instructorId && 
           e.confirmed_by_student && 
           e.confirmed_by_instructor
    );
    
    if (confirmedExams.length === 0) return { rate: 0, approved: 0, total: 0 };

    const approved = confirmedExams.filter(e => e.status === 'approved').length;
    const rate = Math.round((approved / confirmedExams.length) * 100);

    return { rate, approved, total: confirmedExams.length };
  };

  useEffect(() => {
    if (user) {
      fetchExams();
    }
  }, [user]);

  return {
    exams,
    isLoading,
    error,
    createExam,
    confirmExamResult,
    instructorConfirmExam,
    getInstructorApprovalRate,
    getExamDocumentSignedUrl,
    refetch: fetchExams,
  };
};
