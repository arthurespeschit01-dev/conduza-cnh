import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface PendingLink {
  instructorId: string;
  instructorName: string;
  contactAt: string;
}

interface LinkedInstructor {
  instructorId: string;
  linkedAt: string;
}

export const useInstructorLink = () => {
  const { session, user } = useAuth();
  const { toast } = useToast();
  const [pendingLink, setPendingLink] = useState<PendingLink | null>(null);
  const [linkedInstructor, setLinkedInstructor] = useState<LinkedInstructor | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch current link status
  const fetchLinkStatus = useCallback(async () => {
    if (!session?.user?.id) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('pending_instructor_id, pending_instructor_name, pending_contact_at, linked_instructor_id, linked_at')
        .eq('id', session.user.id)
        .single();

      if (error) throw error;

      if (data?.pending_instructor_id && data?.pending_instructor_name) {
        setPendingLink({
          instructorId: data.pending_instructor_id,
          instructorName: data.pending_instructor_name,
          contactAt: data.pending_contact_at || '',
        });
      } else {
        setPendingLink(null);
      }

      if (data?.linked_instructor_id) {
        setLinkedInstructor({
          instructorId: data.linked_instructor_id,
          linkedAt: data.linked_at || '',
        });
      } else {
        setLinkedInstructor(null);
      }
    } catch (err) {
      console.error('Error fetching link status:', err);
    }
  }, [session?.user?.id]);

  useEffect(() => {
    fetchLinkStatus();
  }, [fetchLinkStatus]);

  // Register pending contact (called when student clicks WhatsApp)
  const registerPendingContact = async (instructorId: string, instructorName: string) => {
    if (!session?.user?.id) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          pending_instructor_id: instructorId,
          pending_instructor_name: instructorName,
          pending_contact_at: new Date().toISOString(),
        })
        .eq('id', session.user.id);

      if (error) throw error;

      setPendingLink({
        instructorId,
        instructorName,
        contactAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Error registering pending contact:', err);
    }
  };

  // Confirm link with instructor
  const confirmLink = async () => {
    if (!session?.user?.id || !pendingLink) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          linked_instructor_id: pendingLink.instructorId,
          linked_at: new Date().toISOString(),
          pending_instructor_id: null,
          pending_instructor_name: null,
          pending_contact_at: null,
        })
        .eq('id', session.user.id);

      if (error) throw error;

      setLinkedInstructor({
        instructorId: pendingLink.instructorId,
        linkedAt: new Date().toISOString(),
      });
      setPendingLink(null);

      toast({
        title: 'Instrutor vinculado!',
        description: 'Seu painel agora está 100% funcional. Bons estudos!',
      });
    } catch (err) {
      console.error('Error confirming link:', err);
      toast({
        title: 'Erro ao vincular',
        description: 'Não foi possível confirmar o vínculo. Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Cancel pending link (continue looking for instructors)
  const cancelPendingLink = async () => {
    if (!session?.user?.id) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          pending_instructor_id: null,
          pending_instructor_name: null,
          pending_contact_at: null,
        })
        .eq('id', session.user.id);

      if (error) throw error;

      setPendingLink(null);

      toast({
        title: 'Contato limpo',
        description: 'Você pode buscar outro instrutor agora.',
      });
    } catch (err) {
      console.error('Error canceling pending link:', err);
      toast({
        title: 'Erro',
        description: 'Não foi possível limpar o contato pendente.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Unlink from current instructor
  const unlinkInstructor = async () => {
    if (!session?.user?.id) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          linked_instructor_id: null,
          linked_at: null,
        })
        .eq('id', session.user.id);

      if (error) throw error;

      setLinkedInstructor(null);

      toast({
        title: 'Vínculo removido',
        description: 'Você pode buscar outro instrutor agora.',
      });
    } catch (err) {
      console.error('Error unlinking instructor:', err);
      toast({
        title: 'Erro',
        description: 'Não foi possível remover o vínculo.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    pendingLink,
    linkedInstructor,
    isLoading,
    registerPendingContact,
    confirmLink,
    cancelPendingLink,
    unlinkInstructor,
    refetch: fetchLinkStatus,
  };
};
