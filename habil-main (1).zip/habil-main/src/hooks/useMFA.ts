import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AuthMFAVerifyResponse } from '@supabase/supabase-js';

interface MFAFactor {
  id: string;
  factor_type: 'totp';
  friendly_name?: string;
  created_at: string;
  updated_at: string;
  status: 'verified' | 'unverified';
}

interface MFAState {
  isEnrolled: boolean;
  factors: MFAFactor[];
  currentLevel: 'aal1' | 'aal2';
  nextLevel: 'aal1' | 'aal2' | null;
}

interface EnrollData {
  id: string;
  qr_code: string;
  secret: string;
}

export const useMFA = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get current MFA status
  const getMFAStatus = useCallback(async (): Promise<MFAState | null> => {
    try {
      setIsLoading(true);
      setError(null);

      // Get current assurance level
      const { data: aalData, error: aalError } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (aalError) throw aalError;

      // List enrolled factors
      const { data: factorsData, error: factorsError } = await supabase.auth.mfa.listFactors();
      if (factorsError) throw factorsError;

      const verifiedFactors = factorsData.totp.filter(f => f.status === 'verified');

      return {
        isEnrolled: verifiedFactors.length > 0,
        factors: factorsData.totp as unknown as MFAFactor[],
        currentLevel: aalData.currentLevel || 'aal1',
        nextLevel: aalData.nextLevel,
      };
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Enroll in TOTP MFA - returns QR code
  const enrollTOTP = useCallback(async (friendlyName?: string): Promise<EnrollData | null> => {
    try {
      setIsLoading(true);
      setError(null);

      const { data, error } = await supabase.auth.mfa.enroll({
        factorType: 'totp',
        friendlyName: friendlyName || 'Autenticador',
      });

      if (error) throw error;

      // Type guard to ensure we have TOTP data
      if (data.type === 'totp') {
        return {
          id: data.id,
          qr_code: data.totp.qr_code,
          secret: data.totp.secret,
        };
      }

      return null;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Verify TOTP code during enrollment
  const verifyEnrollment = useCallback(async (factorId: string, code: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      setError(null);

      // Create a challenge
      const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({
        factorId,
      });

      if (challengeError) throw challengeError;

      // Verify the code
      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId,
        challengeId: challengeData.id,
        code,
      });

      if (verifyError) throw verifyError;

      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Verify TOTP code during login
  const verifyLogin = useCallback(async (code: string): Promise<AuthMFAVerifyResponse['data'] | null> => {
    try {
      setIsLoading(true);
      setError(null);

      // Get factors
      const { data: factorsData, error: factorsError } = await supabase.auth.mfa.listFactors();
      if (factorsError) throw factorsError;

      const totpFactor = factorsData.totp.find(f => f.status === 'verified');
      if (!totpFactor) {
        throw new Error('Nenhum fator TOTP encontrado');
      }

      // Create challenge
      const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({
        factorId: totpFactor.id,
      });

      if (challengeError) throw challengeError;

      // Verify
      const { data, error: verifyError } = await supabase.auth.mfa.verify({
        factorId: totpFactor.id,
        challengeId: challengeData.id,
        code,
      });

      if (verifyError) throw verifyError;

      return data;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Unenroll a factor
  const unenroll = useCallback(async (factorId: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      setError(null);

      const { error } = await supabase.auth.mfa.unenroll({
        factorId,
      });

      if (error) throw error;

      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Check if MFA verification is required after login
  const requiresMFAVerification = useCallback(async (): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (error) return false;

      // If user has enrolled factors but current level is aal1, they need to verify
      return data.currentLevel === 'aal1' && data.nextLevel === 'aal2';
    } catch {
      return false;
    }
  }, []);

  return {
    isLoading,
    error,
    getMFAStatus,
    enrollTOTP,
    verifyEnrollment,
    verifyLogin,
    unenroll,
    requiresMFAVerification,
    clearError: () => setError(null),
  };
};
