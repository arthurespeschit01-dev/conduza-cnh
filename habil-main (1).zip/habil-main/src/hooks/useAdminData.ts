import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/lib/logger';
interface MRRBreakdown {
  newMRR: number;
  expansion: number;
  churn: number;
  netMRR: number;
}

interface AdminStats {
  totalStudents: number;
  totalInstructors: number;
  pendingApprovals: number;
  approvedInstructors: number;
  pausedInstructors: number;
  pendingDocuments: number;
  rejectedInstructors: number;
  averageTicket: number;
  totalRevenue: number;
  ltv: number;
  mrrBreakdown: MRRBreakdown;
  planStats: {
    basic: number;
    professional: number;
    premium: number;
  };
}

interface InstructorData {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  city: string;
  uf: string;
  cpf: string | null;
  cnh: string | null;
  cnh_document_path: string | null;
  rg_document_path: string | null;
  proof_of_residence_path: string | null;
  instructor_certificate_path: string | null;
  bio: string | null;
  certifications: string[] | null;
  cnh_category: string | null;
  registration_status: string | null;
  subscription_plan: string | null;
  price_per_hour: number | null;
  approvalRate: number;
  totalStudents: number;
  created_at: string;
  hasAllDocuments: boolean;
}

export const useAdminData = (ltvRetentionMonths: number = 18) => {
  const { toast } = useToast();
  const [stats, setStats] = useState<AdminStats>({
    totalStudents: 0,
    totalInstructors: 0,
    pendingApprovals: 0,
    approvedInstructors: 0,
    pausedInstructors: 0,
    pendingDocuments: 0,
    rejectedInstructors: 0,
    averageTicket: 0,
    totalRevenue: 0,
    ltv: 0,
    mrrBreakdown: { newMRR: 0, expansion: 0, churn: 0, netMRR: 0 },
    planStats: {
      basic: 0,
      professional: 0,
      premium: 0,
    },
  });
  const [instructors, setInstructors] = useState<InstructorData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAdminData = useCallback(async () => {
    setIsLoading(true);
    try {
      // Fetch all user roles
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role');

      if (rolesError) throw rolesError;

      const studentCount = roles?.filter(r => r.role === 'student').length || 0;
      const instructorIds = roles?.filter(r => r.role === 'instructor').map(r => r.user_id) || [];

      // Fetch instructor profiles
      if (instructorIds.length > 0) {
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select('*')
          .in('id', instructorIds)
          .order('created_at', { ascending: false });

        if (profilesError) throw profilesError;

        // Fetch sensitive data for documents
        const { data: sensitiveData } = await supabase
          .from('user_sensitive_data')
          .select('user_id, cpf_masked, cnh, cnh_document_path, rg_document_path, proof_of_residence_path, instructor_certificate_path')
          .in('user_id', instructorIds);

        const sensitiveDataMap = new Map((sensitiveData || []).map(s => [s.user_id, s]));

        // Fetch exam stats
        const { data: exams } = await supabase
          .from('exams')
          .select('instructor_id, status, confirmed_by_student, confirmed_by_instructor')
          .in('instructor_id', instructorIds)
          .eq('confirmed_by_student', true)
          .eq('confirmed_by_instructor', true);

        // Fetch schedules for revenue calculation
        const { data: schedules } = await supabase
          .from('schedules')
          .select('instructor_id, price, status')
          .in('instructor_id', instructorIds);

        // Plan prices
        const planPrices: Record<string, number> = {
          basic: 49,
          professional: 97,
          premium: 149,
        };

        // Calculate revenue based on instructor plans
        const approvedProfiles = (profiles || []).filter(p => p.registration_status === 'approved');
        const totalPlanRevenue = approvedProfiles.reduce((acc, profile) => {
          const plan = profile.subscription_plan || 'basic';
          return acc + (planPrices[plan] || 49);
        }, 0);

        // Average ticket is the average plan value
        const averageTicket = approvedProfiles.length > 0 
          ? totalPlanRevenue / approvedProfiles.length 
          : 0;

        const enrichedInstructors: InstructorData[] = (profiles || []).map(profile => {
          const instructorExams = exams?.filter(e => e.instructor_id === profile.id) || [];
          const approved = instructorExams.filter(e => e.status === 'approved').length;
          const total = instructorExams.length;
          const rate = total > 0 ? Math.round((approved / total) * 100) : 0;

          // Count unique students from schedules
          const instructorSchedules = schedules?.filter(s => s.instructor_id === profile.id) || [];
          const uniqueStudents = new Set(instructorSchedules.map(s => (s as any).student_id)).size;

          // Get sensitive data for documents
          const sensitive = sensitiveDataMap.get(profile.id);

          // Check if has all documents (4 required) - from user_sensitive_data
          const hasAllDocuments = Boolean(
            sensitive?.cnh_document_path && 
            sensitive?.rg_document_path && 
            sensitive?.proof_of_residence_path && 
            sensitive?.instructor_certificate_path
          );

          return {
            id: profile.id,
            full_name: profile.full_name,
            email: profile.email,
            phone: profile.phone,
            city: profile.city,
            uf: profile.uf,
            cpf: sensitive?.cpf_masked || null,
            cnh: sensitive?.cnh || null,
            cnh_document_path: sensitive?.cnh_document_path || null,
            rg_document_path: sensitive?.rg_document_path || null,
            proof_of_residence_path: sensitive?.proof_of_residence_path || null,
            instructor_certificate_path: sensitive?.instructor_certificate_path || null,
            bio: profile.bio,
            certifications: profile.certifications,
            cnh_category: profile.cnh_category,
            registration_status: profile.registration_status || 'pending',
            subscription_plan: profile.subscription_plan || 'basic',
            price_per_hour: profile.price_per_hour,
            approvalRate: rate,
            totalStudents: uniqueStudents,
            created_at: profile.created_at,
            hasAllDocuments,
          };
        });

        setInstructors(enrichedInstructors);

        // Calculate stats
        const pendingApprovals = enrichedInstructors.filter(i => i.registration_status === 'pending').length;
        const approvedInstructors = enrichedInstructors.filter(i => i.registration_status === 'approved').length;
        const pausedInstructors = enrichedInstructors.filter(i => i.registration_status === 'paused').length;
        const rejectedInstructors = enrichedInstructors.filter(i => i.registration_status === 'rejected').length;
        const pendingDocuments = enrichedInstructors.filter(i => !i.hasAllDocuments).length;

        // Plan stats
        const planStats = {
          basic: enrichedInstructors.filter(i => i.subscription_plan === 'basic').length,
          professional: enrichedInstructors.filter(i => i.subscription_plan === 'professional').length,
          premium: enrichedInstructors.filter(i => i.subscription_plan === 'premium').length,
        };

        // Calculate LTV: average ticket * retention months
        const ltv = averageTicket * ltvRetentionMonths;

        // Calculate MRR breakdown based on last 30 days
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        // New MRR: instructors approved in last 30 days
        const newInstructors = approvedProfiles.filter(p => 
          new Date(p.created_at) >= thirtyDaysAgo
        );
        const newMRR = newInstructors.reduce((acc, profile) => {
          const plan = profile.subscription_plan || 'basic';
          return acc + (planPrices[plan] || 49);
        }, 0);

        // Expansion: Simulated as upgrades (instructors with professional/premium plans created before 30 days)
        const existingUpgrades = approvedProfiles.filter(p => 
          new Date(p.created_at) < thirtyDaysAgo && 
          (p.subscription_plan === 'professional' || p.subscription_plan === 'premium')
        );
        const expansion = existingUpgrades.length * 20; // Estimated upgrade value

        // Churn: instructors that were rejected or paused recently
        const churnedInstructors = (profiles || []).filter(p => 
          (p.registration_status === 'rejected' || p.registration_status === 'paused') &&
          new Date(p.updated_at) >= thirtyDaysAgo
        );
        const churn = churnedInstructors.reduce((acc, profile) => {
          const plan = profile.subscription_plan || 'basic';
          return acc + (planPrices[plan] || 49);
        }, 0);

        const netMRR = newMRR + expansion - churn;

        const mrrBreakdown: MRRBreakdown = { newMRR, expansion, churn, netMRR };

        setStats({
          totalStudents: studentCount,
          totalInstructors: instructorIds.length,
          pendingApprovals,
          approvedInstructors,
          pausedInstructors,
          pendingDocuments,
          rejectedInstructors,
          averageTicket,
          totalRevenue: totalPlanRevenue,
          ltv,
          mrrBreakdown,
          planStats,
        });
      } else {
        setStats({
          totalStudents: studentCount,
          totalInstructors: 0,
          pendingApprovals: 0,
          approvedInstructors: 0,
          pausedInstructors: 0,
          pendingDocuments: 0,
          rejectedInstructors: 0,
          averageTicket: 0,
          totalRevenue: 0,
          ltv: 0,
          mrrBreakdown: { newMRR: 0, expansion: 0, churn: 0, netMRR: 0 },
          planStats: { basic: 0, professional: 0, premium: 0 },
        });
        setInstructors([]);
      }
    } catch (error) {
      logger.error('Error fetching admin data:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os dados',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast, ltvRetentionMonths]);

  const approveInstructor = async (instructorId: string) => {
    // Optimistic update - immediately update local state
    setInstructors(prev => prev.map(i => 
      i.id === instructorId ? { ...i, registration_status: 'approved' } : i
    ));
    
    // Update stats optimistically
    setStats(prev => ({
      ...prev,
      pendingApprovals: Math.max(0, prev.pendingApprovals - 1),
      approvedInstructors: prev.approvedInstructors + 1,
    }));

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ registration_status: 'approved' })
        .eq('id', instructorId);

      if (error) throw error;

      toast({
        title: 'Instrutor aprovado!',
        description: 'O instrutor foi aprovado com sucesso.',
      });

      return { success: true };
    } catch (error) {
      logger.error('Error approving instructor:', error);
      // Revert on error
      fetchAdminData();
      return { success: false, error: 'Erro ao aprovar instrutor' };
    }
  };

  const rejectInstructor = async (instructorId: string) => {
    // Optimistic update
    setInstructors(prev => prev.map(i => 
      i.id === instructorId ? { ...i, registration_status: 'rejected' } : i
    ));
    
    setStats(prev => ({
      ...prev,
      pendingApprovals: Math.max(0, prev.pendingApprovals - 1),
      rejectedInstructors: prev.rejectedInstructors + 1,
    }));

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ registration_status: 'rejected' })
        .eq('id', instructorId);

      if (error) throw error;

      toast({
        title: 'Instrutor rejeitado',
        description: 'O cadastro foi rejeitado.',
      });

      return { success: true };
    } catch (error) {
      logger.error('Error rejecting instructor:', error);
      fetchAdminData();
      return { success: false, error: 'Erro ao rejeitar instrutor' };
    }
  };

  const pauseInstructor = async (instructorId: string) => {
    // Optimistic update
    setInstructors(prev => prev.map(i => 
      i.id === instructorId ? { ...i, registration_status: 'paused' } : i
    ));
    
    setStats(prev => ({
      ...prev,
      approvedInstructors: Math.max(0, prev.approvedInstructors - 1),
      pausedInstructors: prev.pausedInstructors + 1,
    }));

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ registration_status: 'paused' })
        .eq('id', instructorId);

      if (error) throw error;

      toast({
        title: 'Instrutor pausado',
        description: 'O instrutor foi pausado e não aparecerá para os alunos.',
      });

      return { success: true };
    } catch (error) {
      logger.error('Error pausing instructor:', error);
      fetchAdminData();
      return { success: false, error: 'Erro ao pausar instrutor' };
    }
  };

  const unpauseInstructor = async (instructorId: string) => {
    // Optimistic update
    setInstructors(prev => prev.map(i => 
      i.id === instructorId ? { ...i, registration_status: 'approved' } : i
    ));
    
    setStats(prev => ({
      ...prev,
      pausedInstructors: Math.max(0, prev.pausedInstructors - 1),
      approvedInstructors: prev.approvedInstructors + 1,
    }));

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ registration_status: 'approved' })
        .eq('id', instructorId);

      if (error) throw error;

      toast({
        title: 'Instrutor reativado',
        description: 'O instrutor foi reativado e agora aparecerá para os alunos.',
      });

      return { success: true };
    } catch (error) {
      logger.error('Error unpausing instructor:', error);
      fetchAdminData();
      return { success: false, error: 'Erro ao reativar instrutor' };
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [fetchAdminData]);

  // Subscribe to realtime changes on profiles table
  useEffect(() => {
    const channel = supabase
      .channel('admin-profiles-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
        },
        () => {
          // Refetch all data when any profile changes
          fetchAdminData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchAdminData]);

  return {
    stats,
    instructors,
    isLoading,
    approveInstructor,
    rejectInstructor,
    pauseInstructor,
    unpauseInstructor,
    refetch: fetchAdminData,
  };
};