import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { logger } from '@/lib/logger';

interface GamificationStats {
  points: number;
  currentStreak: number;
  longestStreak: number;
  lastAccessDate: string | null;
}

interface Achievement {
  id: string;
  code: string;
  title: string;
  description: string | null;
  icon: string;
  pointsRequired: number;
  lessonsRequired: number;
  streakRequired: number;
  unlocked: boolean;
  unlockedAt: string | null;
}

const POINTS_PER_LESSON = 10;

export const useGamification = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<GamificationStats>({
    points: 0,
    currentStreak: 0,
    longestStreak: 0,
    lastAccessDate: null,
  });
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [completedLessons, setCompletedLessons] = useState(0);

  const fetchStats = useCallback(async () => {
    if (!user) return;

    try {
      // First, try to get existing stats
      const { data: existingStats, error: statsError } = await supabase
        .from('gamification_stats')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (statsError) {
        logger.error('Error fetching gamification stats:', statsError);
        return;
      }

      // If no stats exist, create initial record
      if (!existingStats) {
        const { data: newStats, error: insertError } = await supabase
          .from('gamification_stats')
          .insert({
            user_id: user.id,
            points: 0,
            current_streak: 1,
            longest_streak: 1,
            last_access_date: new Date().toISOString().split('T')[0],
          })
          .select()
          .single();

        if (insertError) {
          logger.error('Error creating gamification stats:', insertError);
          return;
        }

        setStats({
          points: newStats.points,
          currentStreak: newStats.current_streak,
          longestStreak: newStats.longest_streak,
          lastAccessDate: newStats.last_access_date,
        });
      } else {
        // Update last access date to trigger streak calculation
        const today = new Date().toISOString().split('T')[0];
        if (existingStats.last_access_date !== today) {
          const { data: updatedStats, error: updateError } = await supabase
            .from('gamification_stats')
            .update({ last_access_date: today })
            .eq('user_id', user.id)
            .select()
            .single();

          if (!updateError && updatedStats) {
            setStats({
              points: updatedStats.points,
              currentStreak: updatedStats.current_streak,
              longestStreak: updatedStats.longest_streak,
              lastAccessDate: updatedStats.last_access_date,
            });
          }
        } else {
          setStats({
            points: existingStats.points,
            currentStreak: existingStats.current_streak,
            longestStreak: existingStats.longest_streak,
            lastAccessDate: existingStats.last_access_date,
          });
        }
      }

      // Fetch completed lessons count for points calculation (practical_car + practical_motorcycle)
      const { count: lessonsCount } = await supabase
        .from('schedules')
        .select('*', { count: 'exact', head: true })
        .eq('student_id', user.id)
        .eq('status', 'completed')
        .in('lesson_type', ['practical_car', 'practical_motorcycle']);

      const lessons = lessonsCount || 0;
      setCompletedLessons(lessons);

      // Calculate points based on completed lessons
      const calculatedPoints = lessons * POINTS_PER_LESSON;
      
      // Update points if they don't match
      if (existingStats && existingStats.points !== calculatedPoints) {
        await supabase
          .from('gamification_stats')
          .update({ points: calculatedPoints })
          .eq('user_id', user.id);
        
        setStats(prev => ({ ...prev, points: calculatedPoints }));
      } else if (!existingStats) {
        setStats(prev => ({ ...prev, points: calculatedPoints }));
      }

    } catch (error) {
      logger.error('Error in fetchStats:', error);
    }
  }, [user]);

  const fetchAchievements = useCallback(async () => {
    if (!user) return;

    try {
      // Fetch all achievements
      const { data: allAchievements, error: achievementsError } = await supabase
        .from('achievements')
        .select('*')
        .order('created_at', { ascending: true });

      if (achievementsError) {
        logger.error('Error fetching achievements:', achievementsError);
        return;
      }

      // Fetch user's unlocked achievements
      const { data: userAchievements, error: userAchievementsError } = await supabase
        .from('user_achievements')
        .select('achievement_id, unlocked_at')
        .eq('user_id', user.id);

      if (userAchievementsError) {
        logger.error('Error fetching user achievements:', userAchievementsError);
        return;
      }

      const unlockedMap = new Map(
        userAchievements?.map(ua => [ua.achievement_id, ua.unlocked_at]) || []
      );

      const mappedAchievements: Achievement[] = (allAchievements || []).map(a => ({
        id: a.id,
        code: a.code,
        title: a.title,
        description: a.description,
        icon: a.icon,
        pointsRequired: a.points_required || 0,
        lessonsRequired: a.lessons_required || 0,
        streakRequired: a.streak_required || 0,
        unlocked: unlockedMap.has(a.id),
        unlockedAt: unlockedMap.get(a.id) || null,
      }));

      setAchievements(mappedAchievements);
    } catch (error) {
      logger.error('Error in fetchAchievements:', error);
    }
  }, [user]);

  const checkAndUnlockAchievements = useCallback(async () => {
    if (!user || achievements.length === 0) return;

    const toUnlock: string[] = [];

    for (const achievement of achievements) {
      if (achievement.unlocked) continue;

      let shouldUnlock = false;

      // Check lessons-based achievements
      if (achievement.lessonsRequired > 0 && completedLessons >= achievement.lessonsRequired) {
        shouldUnlock = true;
      }

      // Check streak-based achievements
      if (achievement.streakRequired > 0 && stats.currentStreak >= achievement.streakRequired) {
        shouldUnlock = true;
      }

      // Check points-based achievements
      if (achievement.pointsRequired > 0 && stats.points >= achievement.pointsRequired) {
        shouldUnlock = true;
      }

      if (shouldUnlock) {
        toUnlock.push(achievement.id);
      }
    }

    // Unlock achievements
    for (const achievementId of toUnlock) {
      const { error } = await supabase
        .from('user_achievements')
        .insert({ user_id: user.id, achievement_id: achievementId });

      if (!error) {
        setAchievements(prev =>
          prev.map(a =>
            a.id === achievementId
              ? { ...a, unlocked: true, unlockedAt: new Date().toISOString() }
              : a
          )
        );
      }
    }
  }, [user, achievements, completedLessons, stats]);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchStats();
      await fetchAchievements();
      setIsLoading(false);
    };

    if (user) {
      loadData();
    }
  }, [user, fetchStats, fetchAchievements]);

  // Check achievements after data is loaded
  useEffect(() => {
    if (!isLoading && achievements.length > 0) {
      checkAndUnlockAchievements();
    }
  }, [isLoading, stats, completedLessons, checkAndUnlockAchievements]);

  return {
    stats,
    achievements,
    isLoading,
    completedLessons,
    refetch: async () => {
      await fetchStats();
      await fetchAchievements();
    },
  };
};
