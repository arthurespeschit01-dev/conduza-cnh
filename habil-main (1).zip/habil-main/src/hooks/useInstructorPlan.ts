import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type SubscriptionPlan = 'basic' | 'professional' | 'premium';
export type PaymentStatus = 'active' | 'pending' | 'expired';

/**
 * Complete feature mapping based on pricing structure:
 * 
 * BASIC (R$ 49/mês):
 * - Perfil público na Conduza
 * - Botão de contato direto (WhatsApp)
 * - Exibição básica no marketplace
 * - Cadastro de alunos manual
 * - Registro simples de aulas
 *
 * PROFESSIONAL (R$ 97/mês) - Inclui Básico +:
 * - Perfil verificado (documentos + certificação)
 * - Destaque na busca da cidade/região
 * - Filtro por taxa de aprovação
 * - Registro completo de aulas por aluno
 * - Marcação de provas e resultados
 * - Cálculo automático de taxa de aprovação
 * - Selo "Instrutor com Alta Aprovação"
 * - Dashboard com métricas
 * - Prioridade no suporte
 * 
 * PREMIUM (R$ 149/mês) - Inclui Profissional +:
 * - Topo do ranking da cidade
 * - Destaque visual premium no marketplace
 * - Página personalizada (URL própria)
 * - Relatórios avançados
 * - Gestão avançada de alunos
 * - Integração com WhatsApp Business
 * - Exportação de dados (PDF / Excel)
 * - Selo "Instrutor Premium"
 * - Acesso antecipado a novas features
 */

export type PlanFeature = 
  // Basic features (R$ 49/mês)
  | 'public_profile'           // Perfil público na Conduza
  | 'whatsapp_contact'         // Botão de contato direto (WhatsApp)
  | 'basic_marketplace'        // Exibição básica no marketplace
  | 'manual_student_register'  // Cadastro de alunos manual
  | 'simple_lesson_register'   // Registro simples de aulas
  | 'vehicle_management'       // Gerenciamento de veículos
  | 'package_management'       // Gerenciamento de pacotes
  | 'basic_notifications'      // Notificações básicas
  
  // Professional features (R$ 97/mês)
  | 'verified_profile'         // Perfil verificado (documentos + certificação)
  | 'search_highlight'         // Destaque na busca da cidade/região
  | 'approval_rate_filter'     // Filtro por taxa de aprovação
  | 'complete_lesson_register' // Registro completo de aulas por aluno
  | 'exam_management'          // Marcação de provas e resultados
  | 'auto_approval_rate'       // Cálculo automático de taxa de aprovação
  | 'high_approval_seal'       // Selo "Instrutor com Alta Aprovação"
  | 'metrics_dashboard'        // Dashboard com métricas
  | 'priority_support'         // Prioridade no suporte
  
  // Premium features (R$ 149/mês)
  | 'city_ranking_top'         // Topo do ranking da cidade
  | 'premium_marketplace'      // Destaque visual premium no marketplace
  | 'custom_profile_url'       // Página personalizada (URL própria)
  | 'advanced_reports'         // Relatórios avançados
  | 'advanced_student_mgmt'    // Gestão avançada de alunos
  | 'whatsapp_business'        // Integração com WhatsApp Business
  | 'data_export'              // Exportação de dados (PDF / Excel)
  | 'premium_seal'             // Selo "Instrutor Premium"
  | 'early_access';            // Acesso antecipado a novas features

const PLAN_FEATURES: Record<SubscriptionPlan, PlanFeature[]> = {
  basic: [
    'public_profile',
    'whatsapp_contact',
    'basic_marketplace',
    'manual_student_register',
    'simple_lesson_register',
    'vehicle_management',
    'package_management',
    'basic_notifications',
  ],
  professional: [
    // Basic features
    'public_profile',
    'whatsapp_contact',
    'basic_marketplace',
    'manual_student_register',
    'simple_lesson_register',
    'vehicle_management',
    'package_management',
    'basic_notifications',
    // Professional features
    'verified_profile',
    'search_highlight',
    'approval_rate_filter',
    'complete_lesson_register',
    'exam_management',
    'auto_approval_rate',
    'high_approval_seal',
    'metrics_dashboard',
    'priority_support',
  ],
  premium: [
    // Basic features
    'public_profile',
    'whatsapp_contact',
    'basic_marketplace',
    'manual_student_register',
    'simple_lesson_register',
    'vehicle_management',
    'package_management',
    'basic_notifications',
    // Professional features
    'verified_profile',
    'search_highlight',
    'approval_rate_filter',
    'complete_lesson_register',
    'exam_management',
    'auto_approval_rate',
    'high_approval_seal',
    'metrics_dashboard',
    'priority_support',
    // Premium features
    'city_ranking_top',
    'premium_marketplace',
    'custom_profile_url',
    'advanced_reports',
    'advanced_student_mgmt',
    'whatsapp_business',
    'data_export',
    'premium_seal',
    'early_access',
  ],
};

const FEATURE_NAMES: Record<PlanFeature, string> = {
  // Basic
  public_profile: 'Perfil Público',
  whatsapp_contact: 'Contato WhatsApp',
  basic_marketplace: 'Exibição no Marketplace',
  manual_student_register: 'Cadastro de Alunos',
  simple_lesson_register: 'Registro de Aulas',
  vehicle_management: 'Gerenciamento de Veículos',
  package_management: 'Gerenciamento de Pacotes',
  basic_notifications: 'Notificações',
  // Professional
  verified_profile: 'Perfil Verificado',
  search_highlight: 'Destaque na Busca',
  approval_rate_filter: 'Filtro por Taxa de Aprovação',
  complete_lesson_register: 'Registro Completo de Aulas',
  exam_management: 'Marcação de Provas',
  auto_approval_rate: 'Taxa de Aprovação Automática',
  high_approval_seal: 'Selo Alta Aprovação',
  metrics_dashboard: 'Dashboard de Métricas',
  priority_support: 'Suporte Prioritário',
  // Premium
  city_ranking_top: 'Topo do Ranking',
  premium_marketplace: 'Destaque Premium',
  custom_profile_url: 'URL Personalizada',
  advanced_reports: 'Relatórios Avançados',
  advanced_student_mgmt: 'Gestão Avançada de Alunos',
  whatsapp_business: 'WhatsApp Business',
  data_export: 'Exportação de Dados',
  premium_seal: 'Selo Premium',
  early_access: 'Acesso Antecipado',
};

const FEATURE_DESCRIPTIONS: Record<PlanFeature, string> = {
  // Basic
  public_profile: 'Seu perfil aparece para todos os alunos que buscam instrutores',
  whatsapp_contact: 'Botão de contato direto via WhatsApp',
  basic_marketplace: 'Exibição básica no marketplace de instrutores',
  manual_student_register: 'Cadastre seus alunos manualmente',
  simple_lesson_register: 'Registre suas aulas de forma simples',
  vehicle_management: 'Gerencie os veículos utilizados nas aulas',
  package_management: 'Crie e gerencie pacotes de aulas',
  basic_notifications: 'Receba notificações sobre agendamentos',
  // Professional
  verified_profile: 'Selo de perfil verificado com documentos e certificações',
  search_highlight: 'Apareça em destaque na busca da sua cidade/região',
  approval_rate_filter: 'Alunos podem filtrar por taxa de aprovação',
  complete_lesson_register: 'Registro detalhado de cada aula por aluno',
  exam_management: 'Registre provas e seus resultados',
  auto_approval_rate: 'Cálculo automático da sua taxa de aprovação',
  high_approval_seal: 'Selo "Instrutor com Alta Aprovação" no seu perfil',
  metrics_dashboard: 'Dashboard com métricas de desempenho',
  priority_support: 'Atendimento prioritário pelo suporte',
  // Premium
  city_ranking_top: 'Apareça no topo do ranking da sua cidade',
  premium_marketplace: 'Destaque visual premium no marketplace',
  custom_profile_url: 'URL personalizada para seu perfil (conduza.com/seu-nome)',
  advanced_reports: 'Relatórios avançados com análises detalhadas',
  advanced_student_mgmt: 'Gestão avançada com histórico completo de alunos',
  whatsapp_business: 'Integração com WhatsApp Business para atendimento profissional',
  data_export: 'Exporte seus dados em PDF e Excel',
  premium_seal: 'Selo "Instrutor Premium" no seu perfil',
  early_access: 'Acesso antecipado a novas funcionalidades',
};

const REQUIRED_PLAN_FOR_FEATURE: Record<PlanFeature, SubscriptionPlan> = {
  // Basic
  public_profile: 'basic',
  whatsapp_contact: 'basic',
  basic_marketplace: 'basic',
  manual_student_register: 'basic',
  simple_lesson_register: 'basic',
  vehicle_management: 'basic',
  package_management: 'basic',
  basic_notifications: 'basic',
  // Professional
  verified_profile: 'professional',
  search_highlight: 'professional',
  approval_rate_filter: 'professional',
  complete_lesson_register: 'professional',
  exam_management: 'professional',
  auto_approval_rate: 'professional',
  high_approval_seal: 'professional',
  metrics_dashboard: 'professional',
  priority_support: 'professional',
  // Premium
  city_ranking_top: 'premium',
  premium_marketplace: 'premium',
  custom_profile_url: 'premium',
  advanced_reports: 'premium',
  advanced_student_mgmt: 'premium',
  whatsapp_business: 'premium',
  data_export: 'premium',
  premium_seal: 'premium',
  early_access: 'premium',
};

export const PLAN_NAMES: Record<SubscriptionPlan, string> = {
  basic: 'Básico',
  professional: 'Profissional',
  premium: 'Premium',
};

export const PLAN_PRICES: Record<SubscriptionPlan, number> = {
  basic: 49,
  professional: 97,
  premium: 149,
};

const PLAN_HIERARCHY: Record<SubscriptionPlan, number> = {
  basic: 1,
  professional: 2,
  premium: 3,
};

interface InstructorPlanState {
  currentPlan: SubscriptionPlan;
  paymentStatus: PaymentStatus;
  isLoading: boolean;
  error: string | null;
}

export const useInstructorPlan = () => {
  const { user } = useAuth();
  const [state, setState] = useState<InstructorPlanState>({
    currentPlan: 'basic',
    paymentStatus: 'pending',
    isLoading: true,
    error: null,
  });

  const fetchPlanData = useCallback(async () => {
    if (!user?.id) {
      setState(prev => ({ ...prev, isLoading: false }));
      return;
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('subscription_plan, payment_status')
        .eq('id', user.id)
        .single();

      if (error) throw error;

      setState({
        currentPlan: (data?.subscription_plan as SubscriptionPlan) || 'basic',
        paymentStatus: (data?.payment_status as PaymentStatus) || 'pending',
        isLoading: false,
        error: null,
      });
    } catch (err) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Erro ao carregar informações do plano',
      }));
    }
  }, [user?.id]);

  useEffect(() => {
    fetchPlanData();
  }, [fetchPlanData]);

  // Check if payment is active (required for any paid feature)
  const isPaymentActive = state.paymentStatus === 'active';

  // Get effective plan (basic if payment not active)
  const effectivePlan: SubscriptionPlan = isPaymentActive ? state.currentPlan : 'basic';

  // Check if a specific feature is available
  const hasFeature = (feature: PlanFeature): boolean => {
    return PLAN_FEATURES[effectivePlan].includes(feature);
  };

  // Check if feature requires upgrade
  const requiresUpgrade = (feature: PlanFeature): boolean => {
    return !hasFeature(feature);
  };

  // Get the required plan for a feature
  const getRequiredPlan = (feature: PlanFeature): SubscriptionPlan => {
    return REQUIRED_PLAN_FOR_FEATURE[feature];
  };

  // Get feature display name
  const getFeatureName = (feature: PlanFeature): string => {
    return FEATURE_NAMES[feature];
  };

  // Get feature description
  const getFeatureDescription = (feature: PlanFeature): string => {
    return FEATURE_DESCRIPTIONS[feature];
  };

  // Get plan display name
  const getPlanName = (plan: SubscriptionPlan): string => {
    return PLAN_NAMES[plan];
  };

  // Get plan price
  const getPlanPrice = (plan: SubscriptionPlan): number => {
    return PLAN_PRICES[plan];
  };

  // Get all features for a plan
  const getPlanFeatures = (plan: SubscriptionPlan): PlanFeature[] => {
    return PLAN_FEATURES[plan];
  };

  // Check if a plan is higher than current
  const isPlanHigher = (plan: SubscriptionPlan): boolean => {
    return PLAN_HIERARCHY[plan] > PLAN_HIERARCHY[effectivePlan];
  };

  // Get upgrade message
  const getUpgradeMessage = (feature: PlanFeature): string => {
    const requiredPlan = getRequiredPlan(feature);
    const featureName = getFeatureName(feature);
    const planName = getPlanName(requiredPlan);
    
    if (!isPaymentActive) {
      return `Seu pagamento está ${state.paymentStatus === 'pending' ? 'pendente' : 'expirado'}. Regularize para acessar "${featureName}".`;
    }
    
    return `"${featureName}" requer o plano ${planName}. Faça upgrade para desbloquear.`;
  };

  // Get list of blocked features for current plan
  const getBlockedFeatures = (): PlanFeature[] => {
    const allFeatures = Object.keys(FEATURE_NAMES) as PlanFeature[];
    return allFeatures.filter(feature => !hasFeature(feature));
  };

  // Get features that would be unlocked with a specific plan
  const getUnlockableFeatures = (targetPlan: SubscriptionPlan): PlanFeature[] => {
    const currentFeatures = PLAN_FEATURES[effectivePlan];
    const targetFeatures = PLAN_FEATURES[targetPlan];
    return targetFeatures.filter(feature => !currentFeatures.includes(feature));
  };

  return {
    ...state,
    effectivePlan,
    isPaymentActive,
    hasFeature,
    requiresUpgrade,
    getRequiredPlan,
    getFeatureName,
    getFeatureDescription,
    getPlanName,
    getPlanPrice,
    getPlanFeatures,
    getUpgradeMessage,
    getBlockedFeatures,
    getUnlockableFeatures,
    isPlanHigher,
    refetch: fetchPlanData,
  };
};
