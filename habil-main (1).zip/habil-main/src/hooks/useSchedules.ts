import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/lib/logger';
import type { Database } from '@/integrations/supabase/types';

type Schedule = Database['public']['Tables']['schedules']['Row'];
type ScheduleInsert = Database['public']['Tables']['schedules']['Insert'];

interface ScheduleWithInstructor extends Schedule {
  instructor?: {
    id: string;
    full_name: string;
    avatar_url: string | null;
  };
}

interface ScheduleWithStudent extends Schedule {
  student?: {
    id: string;
    full_name: string;
    avatar_url: string | null;
  };
}

export const useSchedules = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [schedules, setSchedules] = useState<(ScheduleWithInstructor | ScheduleWithStudent)[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchSchedules = async () => {
    if (!user) return;

    setIsLoading(true);
    setError(null);

    try {
      let query = supabase
        .from('schedules')
        .select('*')
        .order('scheduled_date', { ascending: true })
        .order('scheduled_time', { ascending: true });

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      // Fetch related profiles
      if (data && data.length > 0) {
        const instructorIds = [...new Set(data.map(s => s.instructor_id))];
        const studentIds = [...new Set(data.map(s => s.student_id))];
        const allIds = [...new Set([...instructorIds, ...studentIds])];

        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, avatar_url')
          .in('id', allIds);

        const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

        const enrichedData = data.map(schedule => ({
          ...schedule,
          instructor: profileMap.get(schedule.instructor_id),
          student: profileMap.get(schedule.student_id),
        }));

        setSchedules(enrichedData);
      } else {
        setSchedules([]);
      }
    } catch (err) {
      logger.error('Error fetching schedules:', err);
      setError('Erro ao carregar agendamentos');
    } finally {
      setIsLoading(false);
    }
  };

  const createSchedule = async (scheduleData: Omit<ScheduleInsert, 'student_id'>) => {
    if (!user) return { success: false, error: 'Usuário não autenticado' };

    try {
      const { error: insertError } = await supabase
        .from('schedules')
        .insert({
          ...scheduleData,
          student_id: user.id,
        });

      if (insertError) throw insertError;

      toast({
        title: 'Aula agendada!',
        description: 'Seu agendamento foi realizado com sucesso.',
      });

      await fetchSchedules();
      return { success: true };
    } catch (err) {
      logger.error('Error creating schedule:', err);
      return { success: false, error: 'Erro ao agendar aula' };
    }
  };

  const updateScheduleStatus = async (scheduleId: string, status: Schedule['status']) => {
    try {
      const { error: updateError } = await supabase
        .from('schedules')
        .update({ status })
        .eq('id', scheduleId);

      if (updateError) throw updateError;

      await fetchSchedules();
      return { success: true };
    } catch (err) {
      logger.error('Error updating schedule:', err);
      return { success: false, error: 'Erro ao atualizar agendamento' };
    }
  };

  const rescheduleLesson = async (scheduleId: string, newDate: string, newTime: string, instructorId: string) => {
    try {
      // Check if the instructor already has a lesson at this time
      const { data: conflictingSchedules, error: checkError } = await supabase
        .from('schedules')
        .select('id')
        .eq('instructor_id', instructorId)
        .eq('scheduled_date', newDate)
        .eq('scheduled_time', newTime)
        .neq('id', scheduleId) // Exclude the current schedule
        .neq('status', 'cancelled'); // Ignore cancelled lessons

      if (checkError) throw checkError;

      if (conflictingSchedules && conflictingSchedules.length > 0) {
        return { 
          success: false, 
          error: 'Este horário já está ocupado pelo instrutor. Escolha outro horário.' 
        };
      }

      const { error: updateError } = await supabase
        .from('schedules')
        .update({ 
          scheduled_date: newDate, 
          scheduled_time: newTime,
          status: 'pending' // Reset to pending when rescheduled
        })
        .eq('id', scheduleId);

      if (updateError) throw updateError;

      await fetchSchedules();
      return { success: true };
    } catch (err) {
      logger.error('Error rescheduling lesson:', err);
      return { success: false, error: 'Erro ao reagendar aula' };
    }
  };

  const getNextSchedule = () => {
    const now = new Date();
    const upcoming = schedules.filter(s => {
      const scheduleDate = new Date(`${s.scheduled_date}T${s.scheduled_time}`);
      return scheduleDate > now && s.status !== 'cancelled';
    });
    return upcoming[0] || null;
  };

  useEffect(() => {
    if (user) {
      fetchSchedules();
    }
  }, [user]);

  return {
    schedules,
    isLoading,
    error,
    createSchedule,
    updateScheduleStatus,
    rescheduleLesson,
    getNextSchedule,
    refetch: fetchSchedules,
  };
};
