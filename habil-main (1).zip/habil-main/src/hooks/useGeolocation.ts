import { useState, useCallback } from 'react';

export type GeolocationErrorType = 
  | 'permission_denied' 
  | 'position_unavailable' 
  | 'timeout' 
  | 'not_supported'
  | null;

interface GeolocationState {
  latitude: number | null;
  longitude: number | null;
  loading: boolean;
  error: string | null;
  errorType: GeolocationErrorType;
}

interface UseGeolocationReturn extends GeolocationState {
  getCurrentPosition: () => Promise<{ latitude: number; longitude: number } | null>;
  clearError: () => void;
}

export const getErrorMessage = (errorType: GeolocationErrorType): string => {
  switch (errorType) {
    case 'permission_denied':
      return 'Permissão de localização negada. Clique no cadeado na barra de endereço do navegador para permitir.';
    case 'position_unavailable':
      return 'Localização indisponível. Verifique se o GPS/localização está ativado no seu dispositivo.';
    case 'timeout':
      return 'Tempo esgotado ao buscar localização. Verifique sua conexão e tente novamente.';
    case 'not_supported':
      return 'Seu navegador não suporta geolocalização. Use CEP ou selecione manualmente.';
    default:
      return 'Erro ao obter localização.';
  }
};

export const getErrorInstructions = (errorType: GeolocationErrorType): string[] => {
  switch (errorType) {
    case 'permission_denied':
      return [
        'Clique no ícone de cadeado/informação na barra de endereço',
        'Encontre "Localização" nas permissões',
        'Altere para "Permitir"',
        'Recarregue a página e tente novamente'
      ];
    case 'position_unavailable':
      return [
        'Verifique se a localização está ativada no dispositivo',
        'No celular: Configurações > Privacidade > Localização',
        'No computador: Configurações do sistema > Privacidade > Localização',
        'Após ativar, tente novamente'
      ];
    case 'timeout':
      return [
        'Verifique sua conexão com a internet',
        'Se estiver em ambiente fechado, vá para perto de uma janela',
        'Tente novamente em alguns segundos'
      ];
    default:
      return ['Use as alternativas: CEP ou seleção manual'];
  }
};

export const useGeolocation = (): UseGeolocationReturn => {
  const [state, setState] = useState<GeolocationState>({
    latitude: null,
    longitude: null,
    loading: false,
    error: null,
    errorType: null,
  });

  const clearError = useCallback(() => {
    setState((prev) => ({ ...prev, error: null, errorType: null }));
  }, []);

  const getCurrentPosition = useCallback(async (): Promise<{ latitude: number; longitude: number } | null> => {
    // Check if geolocation is supported
    if (!navigator.geolocation) {
      const errorType: GeolocationErrorType = 'not_supported';
      setState((prev) => ({
        ...prev,
        error: getErrorMessage(errorType),
        errorType,
        loading: false,
      }));
      return null;
    }

    setState((prev) => ({ ...prev, loading: true, error: null, errorType: null }));

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setState({
            latitude,
            longitude,
            loading: false,
            error: null,
            errorType: null,
          });
          resolve({ latitude, longitude });
        },
        (error) => {
          let errorType: GeolocationErrorType = null;
          
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorType = 'permission_denied';
              break;
            case error.POSITION_UNAVAILABLE:
              errorType = 'position_unavailable';
              break;
            case error.TIMEOUT:
              errorType = 'timeout';
              break;
          }

          setState({
            latitude: null,
            longitude: null,
            loading: false,
            error: getErrorMessage(errorType),
            errorType,
          });
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000, // 5 minutes cache
        }
      );
    });
  }, []);

  return {
    ...state,
    getCurrentPosition,
    clearError,
  };
};
