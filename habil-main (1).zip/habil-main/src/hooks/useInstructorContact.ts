import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/lib/logger';

interface InstructorContact {
  whatsapp: string | null;
  name: string;
}

export const useInstructorContact = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const getContact = useCallback(async (instructorId: string): Promise<InstructorContact | null> => {
    if (!instructorId) return null;

    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        toast({
          title: 'Não autenticado',
          description: 'Faça login para acessar o contato do instrutor.',
          variant: 'destructive'
        });
        return null;
      }

      const { data, error } = await supabase.functions.invoke('get-instructor-contact', {
        body: { instructorId },
      });

      if (error) {
        logger.error('Error fetching instructor contact:', error);
        toast({
          title: 'Erro ao obter contato',
          description: 'Não foi possível obter o contato do instrutor.',
          variant: 'destructive'
        });
        return null;
      }

      return data as InstructorContact;
    } catch (err) {
      logger.error('Error in getInstructorContact:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const openWhatsApp = useCallback(async (instructorId: string): Promise<void> => {
    const contact = await getContact(instructorId);
    
    if (contact?.whatsapp) {
      const phone = contact.whatsapp.replace(/\D/g, '');
      // Garantir que o número tenha o código do país
      const formattedPhone = phone.startsWith('55') ? phone : `55${phone}`;
      window.open(`https://wa.me/${formattedPhone}`, '_blank', 'noopener,noreferrer');
    } else {
      toast({
        title: 'WhatsApp não disponível',
        description: 'Este instrutor não possui WhatsApp cadastrado.',
        variant: 'destructive'
      });
    }
  }, [getContact, toast]);

  return {
    getContact,
    openWhatsApp,
    isLoading
  };
};
