import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

// Interface for public instructor data (from secure VIEW)
export interface PublicInstructorProfile {
  id: string;
  full_name: string;
  bio: string | null;
  avatar_url: string | null;
  uf: string;
  city: string;
  neighborhood: string | null;
  years_of_experience: number;
  price_per_hour: number | null;
  available_days: string[] | null;
  available_start_time: string | null;
  available_end_time: string | null;
  cnh_category: 'A' | 'B' | 'AB' | null;
  certifications: string[] | null;
  latitude: number | null;
  longitude: number | null;
  subscription_plan: 'basic' | 'professional' | 'premium' | null;
  // Computed fields
  approvalRate: number;
  totalStudents: number;
  approvedStudents: number;
  rating: number;
  reviewCount: number;
  categories: ('A' | 'B' | 'AB')[];
  distance_km: number | null;
}

interface UseInstructorsOptions {
  showAll?: boolean; // If true, shows all instructors regardless of approval/subscription status (for admin)
  userLat?: number;
  userLng?: number;
  sortByProximity?: boolean;
}

export const useInstructors = (uf?: string, city?: string, options?: UseInstructorsOptions) => {
  const [instructors, setInstructors] = useState<PublicInstructorProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchInstructors = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      let profiles: any[] = [];
      
      if (options?.showAll) {
        // Admin mode: use profiles table directly (RLS will ensure admin access)
        const { data: instructorRoles, error: rolesError } = await supabase
          .from('user_roles')
          .select('user_id')
          .eq('role', 'instructor');

        if (rolesError) throw rolesError;

        if (!instructorRoles || instructorRoles.length === 0) {
          setInstructors([]);
          setIsLoading(false);
          return;
        }

        const instructorIds = instructorRoles.map(r => r.user_id);

        // Admin mode: fetch from profiles table - includes whatsapp for admin purposes only
        let query = supabase
          .from('profiles')
          .select('id, full_name, bio, avatar_url, uf, city, neighborhood, years_of_experience, price_per_hour, available_days, available_start_time, available_end_time, cnh_category, certifications, registration_status, subscription_plan, latitude, longitude')
          .in('id', instructorIds);

        if (uf) query = query.eq('uf', uf);
        if (city) query = query.eq('city', city);

        const { data, error: profilesError } = await query;
        if (profilesError) throw profilesError;
        profiles = data || [];
      } else if (options?.userLat && options?.userLng && options?.sortByProximity) {
        // Use proximity function when coordinates are available
        const { data, error: rpcError } = await supabase
          .rpc('get_instructors_by_proximity', {
            user_lat: options.userLat,
            user_lon: options.userLng,
            filter_uf: uf || null,
            filter_city: city || null,
            max_distance_km: null,
          });

        if (rpcError) throw rpcError;
        profiles = data || [];
      } else {
        // Public mode: use secure VIEW (no sensitive data exposed)
        let query = supabase
          .from('public_instructor_profiles')
          .select('*');

        if (uf) query = query.eq('uf', uf);
        if (city) query = query.eq('city', city);

        const { data, error: viewError } = await query;
        if (viewError) throw viewError;
        profiles = data || [];
      }

      if (profiles.length === 0) {
        setInstructors([]);
        setIsLoading(false);
        return;
      }

      const profileIds = profiles.map(p => p.id);

      // Fetch exam stats, reviews, and schedules in parallel
      const [examsResult, reviewsResult, schedulesResult] = await Promise.all([
        supabase
          .from('exams')
          .select('instructor_id, status, confirmed_by_student, confirmed_by_instructor')
          .in('instructor_id', profileIds)
          .eq('confirmed_by_student', true)
          .eq('confirmed_by_instructor', true),
        supabase
          .from('public_reviews')
          .select('instructor_id, rating')
          .in('instructor_id', profileIds),
        supabase
          .from('schedules')
          .select('instructor_id, student_id')
          .in('instructor_id', profileIds)
      ]);

      const exams = examsResult.data || [];
      const reviews = reviewsResult.data || [];
      const schedules = schedulesResult.data || [];

      // Calculate stats
      const enrichedProfiles: PublicInstructorProfile[] = profiles.map(profile => {
        // Exam stats
        const instructorExams = exams.filter(e => e.instructor_id === profile.id);
        const approved = instructorExams.filter(e => e.status === 'approved').length;
        const totalExams = instructorExams.length;
        const rate = totalExams > 0 ? Math.round((approved / totalExams) * 100) : 0;

        // Review stats
        const instructorReviews = reviews.filter(r => r.instructor_id === profile.id);
        const avgRating = instructorReviews.length > 0
          ? instructorReviews.reduce((sum, r) => sum + r.rating, 0) / instructorReviews.length
          : 0;

        // Student count from schedules
        const instructorSchedules = schedules.filter(s => s.instructor_id === profile.id);
        const uniqueStudents = new Set(instructorSchedules.map(s => s.student_id)).size;

        // Convert cnh_category to categories array
        const categories: ('A' | 'B' | 'AB')[] = profile.cnh_category 
          ? [profile.cnh_category as 'A' | 'B' | 'AB'] 
          : ['B'];

        return {
          id: profile.id,
          full_name: profile.full_name,
          bio: profile.bio,
          avatar_url: profile.avatar_url,
          uf: profile.uf,
          city: profile.city,
          neighborhood: profile.neighborhood,
          years_of_experience: profile.years_of_experience || 0,
          price_per_hour: profile.price_per_hour,
          available_days: profile.available_days,
          available_start_time: profile.available_start_time,
          available_end_time: profile.available_end_time,
          cnh_category: profile.cnh_category,
          certifications: profile.certifications,
          latitude: profile.latitude || null,
          longitude: profile.longitude || null,
          subscription_plan: profile.subscription_plan || null,
          approvalRate: rate,
          totalStudents: uniqueStudents,
          approvedStudents: approved,
          rating: avgRating,
          reviewCount: instructorReviews.length,
          categories,
          distance_km: profile.distance_km || null,
        };
      });

      // Plan priority for sorting: premium > professional > basic > null
      const planPriority = (plan: string | null): number => {
        if (plan === 'premium') return 3;
        if (plan === 'professional') return 2;
        if (plan === 'basic') return 1;
        return 0;
      };

      // Sort by plan first, then by proximity if enabled
      enrichedProfiles.sort((a, b) => {
        // First sort by plan priority (premium first)
        const planDiff = planPriority(b.subscription_plan) - planPriority(a.subscription_plan);
        if (planDiff !== 0) return planDiff;

        // Then by proximity if enabled
        if (options?.sortByProximity && options?.userLat && options?.userLng) {
          if (a.distance_km === null && b.distance_km === null) return 0;
          if (a.distance_km === null) return 1;
          if (b.distance_km === null) return -1;
          return a.distance_km - b.distance_km;
        }

        // Finally by rating
        return b.rating - a.rating;
      });

      setInstructors(enrichedProfiles);
    } catch (err) {
      logger.error('Error fetching instructors:', err);
      setError('Erro ao carregar instrutores');
    } finally {
      setIsLoading(false);
    }
  }, [uf, city, options?.showAll, options?.userLat, options?.userLng, options?.sortByProximity]);

  useEffect(() => {
    fetchInstructors();
  }, [fetchInstructors]);

  // Subscribe to realtime changes on profiles table for instructor approvals
  useEffect(() => {
    const channel = supabase
      .channel('instructor-approvals')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: 'registration_status=eq.approved',
        },
        () => {
          // Refetch instructors when an instructor gets approved
          fetchInstructors();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchInstructors]);

  return {
    instructors,
    isLoading,
    error,
    refetch: fetchInstructors,
  };
};
