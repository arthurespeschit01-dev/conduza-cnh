import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface BackupCodeStatus {
  total: number;
  used: number;
  available: number;
}

export const useBackupCodes = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Generate random backup codes
  const generateCodes = useCallback((): string[] => {
    const codes: string[] = [];
    for (let i = 0; i < 10; i++) {
      // Generate 8-character alphanumeric codes
      const code = Array.from({ length: 8 }, () => 
        'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]
      ).join('');
      codes.push(code);
    }
    return codes;
  }, []);

  // Save backup codes to database (hashed)
  const saveBackupCodes = useCallback(async (codes: string[]): Promise<boolean> => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      // Delete existing backup codes
      await supabase
        .from('mfa_backup_codes')
        .delete()
        .eq('user_id', user.id);

      // Insert new codes (hashed in the database using the hash function)
      const codeInserts = codes.map(code => ({
        user_id: user.id,
        code_hash: code, // Will be hashed by trigger or we hash client-side
      }));

      // We need to hash client-side since we can't use the DB function directly
      // We'll store the hash using the RPC function
      for (const code of codes) {
        const { error: insertError } = await supabase.rpc('hash_backup_code', { plain_code: code })
          .then(async ({ data: hashedCode }) => {
            if (!hashedCode) return { error: new Error('Failed to hash code') };
            return supabase.from('mfa_backup_codes').insert({
              user_id: user.id,
              code_hash: hashedCode,
            });
          });

        if (insertError) throw insertError;
      }

      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Get backup codes status
  const getBackupCodesStatus = useCallback(async (): Promise<BackupCodeStatus | null> => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error: fetchError } = await supabase
        .from('mfa_backup_codes')
        .select('used_at')
        .eq('user_id', user.id);

      if (fetchError) throw fetchError;

      const total = data?.length || 0;
      const used = data?.filter(c => c.used_at !== null).length || 0;
      const available = total - used;

      return { total, used, available };
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Verify a backup code
  const verifyBackupCode = useCallback(async (code: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error: verifyError } = await supabase.rpc('verify_backup_code', {
        p_user_id: user.id,
        p_code: code,
      });

      if (verifyError) throw verifyError;

      return data === true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Regenerate backup codes
  const regenerateBackupCodes = useCallback(async (): Promise<string[] | null> => {
    try {
      setIsLoading(true);
      setError(null);

      const newCodes = generateCodes();
      const success = await saveBackupCodes(newCodes);

      if (!success) return null;

      return newCodes;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [generateCodes, saveBackupCodes]);

  return {
    isLoading,
    error,
    generateCodes,
    saveBackupCodes,
    getBackupCodesStatus,
    verifyBackupCode,
    regenerateBackupCodes,
    clearError: () => setError(null),
  };
};