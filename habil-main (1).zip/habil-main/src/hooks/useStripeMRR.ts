import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

export interface MRRData {
  totalMRR: number;
  activeSubscribers: number;
  breakdown: {
    newMRR: number;
    newCount: number;
    expansion: number;
    contraction: number;
    churn: number;
    churnCount: number;
    netMRR: number;
  };
  planBreakdown: {
    basic: { count: number; mrr: number };
    professional: { count: number; mrr: number };
    premium: { count: number; mrr: number };
  };
  payments: {
    completed: number;
    completedAmount: number;
    failed: number;
  };
  subscriptions: {
    active: number;
    canceled: number;
    canceledRecent: number;
    upgrades: number;
    downgrades: number;
  };
  rates: {
    conversion: number;
    retention: number;
    churn: number;
  };
}

export const useStripeMRR = () => {
  const [mrrData, setMrrData] = useState<MRRData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchMRRData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) {
        throw new Error('Usuário não autenticado');
      }

      const { data, error: fnError } = await supabase.functions.invoke('get-mrr-data');

      if (fnError) {
        throw new Error(fnError.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      setMrrData(data);
      return data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro ao buscar dados de MRR';
      logger.error('Error fetching MRR data:', err);
      setError(message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    mrrData,
    isLoading,
    error,
    fetchMRRData,
  };
};
