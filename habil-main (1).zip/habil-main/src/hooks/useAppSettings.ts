import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AppSettings {
  ltvRetentionMonths: number;
}

export const useAppSettings = () => {
  const { toast } = useToast();
  const [settings, setSettings] = useState<AppSettings>({
    ltvRetentionMonths: 18,
  });
  const [isLoading, setIsLoading] = useState(true);

  const fetchSettings = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('key, value');

      if (error) throw error;

      const settingsMap: Record<string, string> = {};
      data?.forEach(item => {
        settingsMap[item.key] = item.value;
      });

      setSettings({
        ltvRetentionMonths: parseInt(settingsMap['ltv_retention_months'] || '18', 10),
      });
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateLtvRetentionMonths = async (months: number) => {
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({ value: months.toString() })
        .eq('key', 'ltv_retention_months');

      if (error) throw error;

      setSettings(prev => ({ ...prev, ltvRetentionMonths: months }));
      
      toast({
        title: 'Configuração salva',
        description: `Retenção LTV atualizada para ${months} meses.`,
      });

      return { success: true };
    } catch (error) {
      console.error('Error updating LTV retention:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível salvar a configuração.',
        variant: 'destructive',
      });
      return { success: false };
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  return {
    settings,
    isLoading,
    updateLtvRetentionMonths,
    refetch: fetchSettings,
  };
};
