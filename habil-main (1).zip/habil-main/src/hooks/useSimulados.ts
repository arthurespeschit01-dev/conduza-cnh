import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface ExamQuestion {
  id: string;
  question: string;
  options: string[];
  correct_option: number;
  category: string;
  difficulty: string;
  explanation: string | null;
}

export interface SimulationAttempt {
  id: string;
  total_questions: number;
  correct_answers: number;
  score: number;
  passed: boolean;
  time_taken_seconds: number | null;
  answers: Record<string, number> | null;
  created_at: string;
}

export interface SimuladoType {
  id: string;
  name: string;
  description: string;
  questionsCount: number;
  category: string | null;
  completed: boolean;
  bestScore: number | null;
}

const CATEGORY_NAMES: Record<string, string> = {
  legislacao: 'Legislação de Trânsito',
  direcao_defensiva: 'Direção Defensiva',
  primeiros_socorros: 'Primeiros Socorros',
  mecanica: 'Mecânica Básica',
  meio_ambiente: 'Meio Ambiente',
};

export const useSimulados = () => {
  const { user } = useAuth();
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [attempts, setAttempts] = useState<SimulationAttempt[]>([]);
  const [simulados, setSimulados] = useState<SimuladoType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch all questions
        const { data: questionsData } = await supabase
          .from('exam_questions')
          .select('*');

        if (questionsData) {
          const formattedQuestions = questionsData.map(q => ({
            ...q,
            options: typeof q.options === 'string' ? JSON.parse(q.options) : q.options,
          }));
          setQuestions(formattedQuestions);

          // Group questions by category
          const categories = [...new Set(formattedQuestions.map(q => q.category))];
          
          // Fetch user attempts if logged in
          let userAttempts: SimulationAttempt[] = [];
          if (user) {
            const { data: attemptsData } = await supabase
              .from('simulation_attempts')
              .select('*')
              .eq('user_id', user.id)
              .order('created_at', { ascending: false });

            if (attemptsData) {
              const formattedAttempts: SimulationAttempt[] = attemptsData.map(a => ({
                ...a,
                answers: a.answers as Record<string, number> | null,
              }));
              userAttempts = formattedAttempts;
              setAttempts(formattedAttempts);
            }
          }

          // Create simulados list
          const simuladosList: SimuladoType[] = [
            {
              id: 'completo',
              name: 'Simulado Completo',
              description: 'Todas as 25 questões do DETRAN',
              questionsCount: formattedQuestions.length,
              category: null,
              completed: userAttempts.some(a => a.total_questions === formattedQuestions.length && a.passed),
              bestScore: userAttempts.filter(a => a.total_questions === formattedQuestions.length)
                .reduce((best, curr) => Math.max(best, Number(curr.score)), 0) || null,
            },
            ...categories.map(cat => {
              const catQuestions = formattedQuestions.filter(q => q.category === cat);
              const catAttempts = userAttempts.filter(a => {
                const answers = a.answers as Record<string, unknown> | null;
                return answers && Object.keys(answers).length === catQuestions.length;
              });
              
              return {
                id: cat,
                name: CATEGORY_NAMES[cat] || cat,
                description: `${catQuestions.length} questões sobre ${CATEGORY_NAMES[cat]?.toLowerCase() || cat}`,
                questionsCount: catQuestions.length,
                category: cat,
                completed: catAttempts.some(a => a.passed),
                bestScore: catAttempts.reduce((best, curr) => Math.max(best, Number(curr.score)), 0) || null,
              };
            }),
          ];

          setSimulados(simuladosList);
        }
      } catch (error) {
        console.error('Error fetching simulados data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const getQuestionsForSimulado = (simuladoId: string): ExamQuestion[] => {
    if (simuladoId === 'completo') {
      return questions;
    }
    return questions.filter(q => q.category === simuladoId);
  };

  const saveAttempt = async (
    totalQuestions: number,
    correctAnswers: number,
    timeTakenSeconds: number,
    answers: Record<string, number>
  ) => {
    if (!user) return null;

    const score = (correctAnswers / totalQuestions) * 100;
    const passed = score >= 70;

    const { data, error } = await supabase
      .from('simulation_attempts')
      .insert({
        user_id: user.id,
        total_questions: totalQuestions,
        correct_answers: correctAnswers,
        score,
        passed,
        time_taken_seconds: timeTakenSeconds,
        answers,
      })
      .select()
      .single();

    if (error) {
      console.error('Error saving attempt:', error);
      return null;
    }

    const formattedData: SimulationAttempt = {
      ...data,
      answers: data.answers as Record<string, number> | null,
    };

    setAttempts(prev => [formattedData, ...prev]);
    return formattedData;
  };

  return {
    simulados,
    questions,
    attempts,
    loading,
    getQuestionsForSimulado,
    saveAttempt,
  };
};
