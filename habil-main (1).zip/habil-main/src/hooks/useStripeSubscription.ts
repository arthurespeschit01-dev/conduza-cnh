import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { SubscriptionPlan } from './useInstructorPlan';

interface SubscriptionData {
  subscribed: boolean;
  plan: SubscriptionPlan | null;
  subscription_end: string | null;
  subscription_id?: string;
}

export const useStripeSubscription = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingSubscription, setIsCheckingSubscription] = useState(false);

  const createCheckoutSession = useCallback(async (planId: SubscriptionPlan) => {
    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Você precisa estar logado para assinar um plano');
        return null;
      }

      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: { planId },
      });

      if (error) throw error;
      if (!data?.url) throw new Error('URL de checkout não recebida');

      // Open checkout in new tab
      window.open(data.url, '_blank');
      return data.url;
    } catch (error) {
      console.error('Error creating checkout session:', error);
      toast.error('Erro ao iniciar checkout. Tente novamente.');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const checkSubscription = useCallback(async (): Promise<SubscriptionData | null> => {
    setIsCheckingSubscription(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        return null;
      }

      const { data, error } = await supabase.functions.invoke('check-subscription');

      if (error) throw error;
      return data as SubscriptionData;
    } catch (error) {
      console.error('Error checking subscription:', error);
      return null;
    } finally {
      setIsCheckingSubscription(false);
    }
  }, []);

  const openCustomerPortal = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Você precisa estar logado para gerenciar sua assinatura');
        return null;
      }

      const { data, error } = await supabase.functions.invoke('customer-portal');

      if (error) throw error;
      if (!data?.url) throw new Error('URL do portal não recebida');

      // Open portal in new tab
      window.open(data.url, '_blank');
      return data.url;
    } catch (error) {
      console.error('Error opening customer portal:', error);
      toast.error('Erro ao abrir portal de gerenciamento. Tente novamente.');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    isLoading,
    isCheckingSubscription,
    createCheckoutSession,
    checkSubscription,
    openCustomerPortal,
  };
};
