import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

interface OperationalMetrics {
  avgApprovalTime: {
    days: number;
    hours: number;
    previousPeriodDays: number;
    trend: 'up' | 'down' | 'stable';
  };
  rejectionRate: {
    percentage: number;
    total: number;
    rejected: number;
  };
  documentResubmissions: number;
  inactiveInstructors: {
    count: number;
    instructors: Array<{
      id: string;
      full_name: string;
      lastActivity: Date | null;
      daysSinceActivity: number;
    }>;
  };
  instructorsByRegion: Array<{
    region: string;
    count: number;
    type: 'city' | 'state';
  }>;
}

export interface PeriodComparison {
  approvals: { current: number; previous: number };
  rejections: { current: number; previous: number };
  newInstructors: { current: number; previous: number };
  schedules: { current: number; previous: number };
  avgApprovalDays: { current: number; previous: number };
  rejectionRate: { current: number; previous: number };
}

interface Insight {
  id: string;
  type: 'info' | 'warning' | 'critical';
  title: string;
  description: string;
  category: string;
  createdAt: Date;
}

interface InstructorProfile {
  id: string;
  full_name: string;
  registration_status: string | null;
  created_at: string;
  updated_at: string;
  city: string;
  uf: string;
}

interface InstructorSensitiveData {
  user_id: string;
  cnh_document_path: string | null;
  rg_document_path: string | null;
  proof_of_residence_path: string | null;
  instructor_certificate_path: string | null;
}

export interface OperationalMetricsPeriod {
  startDate: Date;
  endDate: Date;
}

export interface MetricsEvolutionData {
  date: Date;
  approvals: number;
  rejections: number;
  newInstructors: number;
  schedules: number;
}

export const useOperationalMetrics = (period?: OperationalMetricsPeriod) => {
  const [metrics, setMetrics] = useState<OperationalMetrics>({
    avgApprovalTime: { days: 0, hours: 0, previousPeriodDays: 0, trend: 'stable' },
    rejectionRate: { percentage: 0, total: 0, rejected: 0 },
    documentResubmissions: 0,
    inactiveInstructors: { count: 0, instructors: [] },
    instructorsByRegion: [],
  });
  const [insights, setInsights] = useState<Insight[]>([]);
  const [evolutionData, setEvolutionData] = useState<MetricsEvolutionData[]>([]);
  const [periodComparison, setPeriodComparison] = useState<PeriodComparison>({
    approvals: { current: 0, previous: 0 },
    rejections: { current: 0, previous: 0 },
    newInstructors: { current: 0, previous: 0 },
    schedules: { current: 0, previous: 0 },
    avgApprovalDays: { current: 0, previous: 0 },
    rejectionRate: { current: 0, previous: 0 },
  });
  const [isLoading, setIsLoading] = useState(true);

  const generateInsights = useCallback((
    instructors: InstructorProfile[],
    metrics: OperationalMetrics,
    schedules: any[],
    sensitiveDataMap: Map<string, InstructorSensitiveData>
  ) => {
    const newInsights: Insight[] = [];
    const now = new Date();

    // 1. Instructors pending for more than 5 days
    const pendingInstructors = instructors.filter(i => i.registration_status === 'pending');
    pendingInstructors.forEach(instructor => {
      const createdAt = new Date(instructor.created_at);
      const daysPending = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysPending > 5) {
        newInsights.push({
          id: `pending-${instructor.id}`,
          type: daysPending > 10 ? 'critical' : 'warning',
          title: 'Aprovação pendente há muito tempo',
          description: `${instructor.full_name} está aguardando aprovação há ${daysPending} dias.`,
          category: 'Aprovação',
          createdAt: now,
        });
      }
    });

    // 2. Inactive instructors (30+ days without activity)
    if (metrics.inactiveInstructors.count > 0) {
      const count = metrics.inactiveInstructors.count;
      newInsights.push({
        id: 'inactive-instructors',
        type: count > 5 ? 'warning' : 'info',
        title: `${count} instrutor${count > 1 ? 'es' : ''} inativo${count > 1 ? 's' : ''}`,
        description: `Instrutores aprovados sem atividade nos últimos 30 dias podem precisar de suporte.`,
        category: 'Engajamento',
        createdAt: now,
      });
    }

    // 3. High demand regions with few instructors
    const regionCounts = metrics.instructorsByRegion;
    const lowCoverageRegions = regionCounts.filter(r => r.count < 3 && r.type === 'city');
    if (lowCoverageRegions.length > 0) {
      newInsights.push({
        id: 'low-coverage-regions',
        type: 'info',
        title: 'Oportunidade de expansão',
        description: `${lowCoverageRegions.length} cidade${lowCoverageRegions.length > 1 ? 's' : ''} com poucos instrutores: ${lowCoverageRegions.slice(0, 3).map(r => r.region).join(', ')}${lowCoverageRegions.length > 3 ? '...' : ''}.`,
        category: 'Crescimento',
        createdAt: now,
      });
    }

    // 4. High rejection rate
    if (metrics.rejectionRate.percentage > 30 && metrics.rejectionRate.total >= 5) {
      newInsights.push({
        id: 'high-rejection-rate',
        type: 'warning',
        title: 'Alta taxa de rejeição',
        description: `${metrics.rejectionRate.percentage.toFixed(0)}% dos instrutores foram rejeitados. Verifique os critérios de aprovação.`,
        category: 'Qualidade',
        createdAt: now,
      });
    }

    // 5. Slow approval time
    if (metrics.avgApprovalTime.days > 3) {
      newInsights.push({
        id: 'slow-approval',
        type: metrics.avgApprovalTime.days > 7 ? 'critical' : 'warning',
        title: 'Tempo de aprovação elevado',
        description: `O tempo médio de aprovação está em ${metrics.avgApprovalTime.days} dias. Considere revisar o processo.`,
        category: 'Operacional',
        createdAt: now,
      });
    }

    // 6. Documents pending review - use sensitiveDataMap passed as parameter
    const instructorsWithMissingDocs = instructors.filter(i => {
      const docs = sensitiveDataMap.get(i.id);
      return i.registration_status === 'pending' && 
        (!docs?.cnh_document_path || !docs?.rg_document_path || !docs?.proof_of_residence_path || !docs?.instructor_certificate_path);
    });
    if (instructorsWithMissingDocs.length > 0) {
      newInsights.push({
        id: 'missing-documents',
        type: 'info',
        title: 'Documentos incompletos',
        description: `${instructorsWithMissingDocs.length} instrutor${instructorsWithMissingDocs.length > 1 ? 'es' : ''} com documentação incompleta aguardando reenvio.`,
        category: 'Documentação',
        createdAt: now,
      });
    }

    // 7. Approval time trend
    if (metrics.avgApprovalTime.trend === 'up' && metrics.avgApprovalTime.previousPeriodDays > 0) {
      const increase = ((metrics.avgApprovalTime.days - metrics.avgApprovalTime.previousPeriodDays) / metrics.avgApprovalTime.previousPeriodDays) * 100;
      if (increase > 20) {
        newInsights.push({
          id: 'approval-time-increasing',
          type: 'warning',
          title: 'Tempo de aprovação aumentando',
          description: `O tempo de aprovação aumentou ${increase.toFixed(0)}% em relação ao mês anterior.`,
          category: 'Tendência',
          createdAt: now,
        });
      }
    }

    // Sort by priority
    const priorityOrder = { critical: 0, warning: 1, info: 2 };
    newInsights.sort((a, b) => priorityOrder[a.type] - priorityOrder[b.type]);

    return newInsights;
  }, []);

  const fetchMetrics = useCallback(async () => {
    setIsLoading(true);
    try {
      const now = new Date();
      const periodEnd = period?.endDate || now;
      const periodStart = period?.startDate || new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const periodLength = periodEnd.getTime() - periodStart.getTime();
      const previousPeriodEnd = new Date(periodStart.getTime() - 1);
      const previousPeriodStart = new Date(previousPeriodEnd.getTime() - periodLength);

      // Fetch all instructor roles
      const { data: roles } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'instructor');

      const instructorIds = roles?.map(r => r.user_id) || [];

      if (instructorIds.length === 0) {
        setIsLoading(false);
        return;
      }

      // Fetch instructor profiles
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*')
        .in('id', instructorIds);

      const instructors = (profiles || []) as InstructorProfile[];

      // Fetch schedules for activity tracking
      const { data: schedules } = await supabase
        .from('schedules')
        .select('*')
        .in('instructor_id', instructorIds);

      // 1. Calculate average approval time
      const approvedInstructors = instructors.filter(i => i.registration_status === 'approved');
      const approvedThisPeriod = approvedInstructors.filter(i => 
        new Date(i.updated_at) >= periodStart && new Date(i.updated_at) <= periodEnd
      );
      const approvedPreviousPeriod = approvedInstructors.filter(i => 
        new Date(i.updated_at) >= previousPeriodStart && new Date(i.updated_at) <= previousPeriodEnd
      );

      const calculateAvgApprovalTime = (instructorList: InstructorProfile[]) => {
        if (instructorList.length === 0) return 0;
        
        const totalMs = instructorList.reduce((acc, i) => {
          const created = new Date(i.created_at).getTime();
          const updated = new Date(i.updated_at).getTime();
          return acc + (updated - created);
        }, 0);
        
        return totalMs / instructorList.length / (1000 * 60 * 60 * 24); // Convert to days
      };

      const currentAvgDays = calculateAvgApprovalTime(approvedThisPeriod.length > 0 ? approvedThisPeriod : approvedInstructors);
      const previousAvgDays = calculateAvgApprovalTime(approvedPreviousPeriod);
      
      const trend: 'up' | 'down' | 'stable' = 
        previousAvgDays === 0 ? 'stable' :
        currentAvgDays > previousAvgDays * 1.1 ? 'up' :
        currentAvgDays < previousAvgDays * 0.9 ? 'down' : 'stable';

      // 2. Calculate rejection rate
      const analyzedInstructors = instructors.filter(i => 
        i.registration_status === 'approved' || i.registration_status === 'rejected'
      );
      const rejectedCount = instructors.filter(i => i.registration_status === 'rejected').length;
      const rejectionRate = analyzedInstructors.length > 0 
        ? (rejectedCount / analyzedInstructors.length) * 100 
        : 0;

      // 3. Document resubmissions - check from sensitive data
      const sensitiveDataForResubs = new Map((await supabase
        .from('user_sensitive_data')
        .select('user_id, cnh_document_path, rg_document_path, proof_of_residence_path, instructor_certificate_path')
        .in('user_id', instructorIds)
        .then(r => r.data || [])).map(s => [s.user_id, s]));

      const documentResubmissions = instructors.filter(i => {
        const docs = sensitiveDataForResubs.get(i.id);
        const created = new Date(i.created_at).getTime();
        const updated = new Date(i.updated_at).getTime();
        const hasDocuments = docs?.cnh_document_path || docs?.rg_document_path || docs?.proof_of_residence_path || docs?.instructor_certificate_path;
        // If updated more than 1 day after creation and has documents, likely a resubmission
        return hasDocuments && (updated - created) > 24 * 60 * 60 * 1000;
      }).length;

      // 4. Inactive instructors (approved but no activity in period)
      const activeInstructorIds = new Set(
        (schedules || [])
          .filter(s => new Date(s.created_at) >= periodStart && new Date(s.created_at) <= periodEnd)
          .map(s => s.instructor_id)
      );

      const inactiveList = approvedInstructors
        .filter(i => !activeInstructorIds.has(i.id))
        .map(i => {
          const lastSchedule = (schedules || [])
            .filter(s => s.instructor_id === i.id)
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
          
          const lastActivity = lastSchedule ? new Date(lastSchedule.created_at) : null;
          const daysSinceActivity = lastActivity 
            ? Math.floor((now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60 * 24))
            : 999;

          return {
            id: i.id,
            full_name: i.full_name,
            lastActivity,
            daysSinceActivity,
          };
        })
        .sort((a, b) => b.daysSinceActivity - a.daysSinceActivity);

      // 5. Instructors by region
      const regionMap = new Map<string, number>();
      const stateMap = new Map<string, number>();
      
      approvedInstructors.forEach(i => {
        const cityKey = `${i.city}, ${i.uf}`;
        regionMap.set(cityKey, (regionMap.get(cityKey) || 0) + 1);
        stateMap.set(i.uf, (stateMap.get(i.uf) || 0) + 1);
      });

      const instructorsByRegion = [
        ...Array.from(stateMap.entries())
          .map(([region, count]) => ({ region, count, type: 'state' as const }))
          .sort((a, b) => b.count - a.count),
        ...Array.from(regionMap.entries())
          .map(([region, count]) => ({ region, count, type: 'city' as const }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 10),
      ];

      const newMetrics: OperationalMetrics = {
        avgApprovalTime: {
          days: Math.floor(currentAvgDays),
          hours: Math.round((currentAvgDays % 1) * 24),
          previousPeriodDays: Math.floor(previousAvgDays),
          trend,
        },
        rejectionRate: {
          percentage: rejectionRate,
          total: analyzedInstructors.length,
          rejected: rejectedCount,
        },
        documentResubmissions,
        inactiveInstructors: {
          count: inactiveList.length,
          instructors: inactiveList.slice(0, 10),
        },
        instructorsByRegion,
      };

      setMetrics(newMetrics);

      // Generate evolution data for chart
      const evolutionMap = new Map<string, MetricsEvolutionData>();
      
      // Initialize days in period
      const currentDate = new Date(periodStart);
      while (currentDate <= periodEnd) {
        const dateKey = currentDate.toISOString().split('T')[0];
        evolutionMap.set(dateKey, {
          date: new Date(currentDate),
          approvals: 0,
          rejections: 0,
          newInstructors: 0,
          schedules: 0,
        });
        currentDate.setDate(currentDate.getDate() + 1);
      }

      // Count approvals and rejections by day
      instructors.forEach(i => {
        const updatedDate = new Date(i.updated_at).toISOString().split('T')[0];
        const entry = evolutionMap.get(updatedDate);
        if (entry) {
          if (i.registration_status === 'approved') {
            entry.approvals++;
          } else if (i.registration_status === 'rejected') {
            entry.rejections++;
          }
        }
      });

      // Count new instructors by creation date
      instructors.forEach(i => {
        const createdDate = new Date(i.created_at).toISOString().split('T')[0];
        const entry = evolutionMap.get(createdDate);
        if (entry) {
          entry.newInstructors++;
        }
      });

      // Count schedules by date
      (schedules || []).forEach(s => {
        const scheduleDate = new Date(s.created_at).toISOString().split('T')[0];
        const entry = evolutionMap.get(scheduleDate);
        if (entry) {
          entry.schedules++;
        }
      });

      const evolutionArray = Array.from(evolutionMap.values()).sort(
        (a, b) => a.date.getTime() - b.date.getTime()
      );
      setEvolutionData(evolutionArray);

      // Calculate period comparison metrics
      const currentApprovals = instructors.filter(i => 
        i.registration_status === 'approved' &&
        new Date(i.updated_at) >= periodStart && 
        new Date(i.updated_at) <= periodEnd
      ).length;
      
      const previousApprovals = instructors.filter(i => 
        i.registration_status === 'approved' &&
        new Date(i.updated_at) >= previousPeriodStart && 
        new Date(i.updated_at) <= previousPeriodEnd
      ).length;

      const currentRejections = instructors.filter(i => 
        i.registration_status === 'rejected' &&
        new Date(i.updated_at) >= periodStart && 
        new Date(i.updated_at) <= periodEnd
      ).length;
      
      const previousRejections = instructors.filter(i => 
        i.registration_status === 'rejected' &&
        new Date(i.updated_at) >= previousPeriodStart && 
        new Date(i.updated_at) <= previousPeriodEnd
      ).length;

      const currentNewInstructors = instructors.filter(i => 
        new Date(i.created_at) >= periodStart && 
        new Date(i.created_at) <= periodEnd
      ).length;
      
      const previousNewInstructors = instructors.filter(i => 
        new Date(i.created_at) >= previousPeriodStart && 
        new Date(i.created_at) <= previousPeriodEnd
      ).length;

      const currentSchedules = (schedules || []).filter(s => 
        new Date(s.created_at) >= periodStart && 
        new Date(s.created_at) <= periodEnd
      ).length;
      
      const previousSchedules = (schedules || []).filter(s => 
        new Date(s.created_at) >= previousPeriodStart && 
        new Date(s.created_at) <= previousPeriodEnd
      ).length;

      const currentRejectionRate = (currentApprovals + currentRejections) > 0 
        ? (currentRejections / (currentApprovals + currentRejections)) * 100 
        : 0;
      
      const previousRejectionRate = (previousApprovals + previousRejections) > 0 
        ? (previousRejections / (previousApprovals + previousRejections)) * 100 
        : 0;

      setPeriodComparison({
        approvals: { current: currentApprovals, previous: previousApprovals },
        rejections: { current: currentRejections, previous: previousRejections },
        newInstructors: { current: currentNewInstructors, previous: previousNewInstructors },
        schedules: { current: currentSchedules, previous: previousSchedules },
        avgApprovalDays: { current: Math.floor(currentAvgDays), previous: Math.floor(previousAvgDays) },
        rejectionRate: { current: currentRejectionRate, previous: previousRejectionRate },
      });

      // Generate insights based on data (pass sensitive data map for document checks)
      const generatedInsights = generateInsights(instructors, newMetrics, schedules || [], sensitiveDataForResubs);
      setInsights(generatedInsights);

    } catch (error) {
      logger.error('Error fetching operational metrics:', error);
    } finally {
      setIsLoading(false);
    }
  }, [generateInsights, period?.startDate?.getTime(), period?.endDate?.getTime()]);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  // Subscribe to realtime changes
  useEffect(() => {
    const channel = supabase
      .channel('operational-metrics')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, fetchMetrics)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'schedules' }, fetchMetrics)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchMetrics]);

  return {
    metrics,
    insights,
    evolutionData,
    periodComparison,
    isLoading,
    refetch: fetchMetrics,
  };
};
