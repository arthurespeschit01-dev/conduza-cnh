export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      access_attempts: {
        Row: {
          attempted_at: string
          endpoint: string
          id: string
          ip_address: string
          success: boolean | null
          user_id: string | null
        }
        Insert: {
          attempted_at?: string
          endpoint: string
          id?: string
          ip_address: string
          success?: boolean | null
          user_id?: string | null
        }
        Update: {
          attempted_at?: string
          endpoint?: string
          id?: string
          ip_address?: string
          success?: boolean | null
          user_id?: string | null
        }
        Relationships: []
      }
      achievements: {
        Row: {
          code: string
          created_at: string
          description: string | null
          icon: string
          id: string
          lessons_required: number | null
          points_required: number | null
          streak_required: number | null
          title: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          icon: string
          id?: string
          lessons_required?: number | null
          points_required?: number | null
          streak_required?: number | null
          title: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          icon?: string
          id?: string
          lessons_required?: number | null
          points_required?: number | null
          streak_required?: number | null
          title?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          record_id: string | null
          table_name: string
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          record_id?: string | null
          table_name: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          record_id?: string | null
          table_name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      exam_questions: {
        Row: {
          category: string
          correct_option: number
          created_at: string
          difficulty: string
          explanation: string | null
          id: string
          options: Json
          question: string
        }
        Insert: {
          category: string
          correct_option: number
          created_at?: string
          difficulty?: string
          explanation?: string | null
          id?: string
          options: Json
          question: string
        }
        Update: {
          category?: string
          correct_option?: number
          created_at?: string
          difficulty?: string
          explanation?: string | null
          id?: string
          options?: Json
          question?: string
        }
        Relationships: []
      }
      exams: {
        Row: {
          category: Database["public"]["Enums"]["cnh_category"]
          confirmed_by_instructor: boolean
          confirmed_by_student: boolean
          created_at: string
          document_url: string | null
          exam_date: string
          exam_type: Database["public"]["Enums"]["exam_type"]
          id: string
          instructor_id: string
          status: Database["public"]["Enums"]["exam_status"]
          student_id: string
          student_passed: boolean | null
          updated_at: string
        }
        Insert: {
          category: Database["public"]["Enums"]["cnh_category"]
          confirmed_by_instructor?: boolean
          confirmed_by_student?: boolean
          created_at?: string
          document_url?: string | null
          exam_date: string
          exam_type: Database["public"]["Enums"]["exam_type"]
          id?: string
          instructor_id: string
          status?: Database["public"]["Enums"]["exam_status"]
          student_id: string
          student_passed?: boolean | null
          updated_at?: string
        }
        Update: {
          category?: Database["public"]["Enums"]["cnh_category"]
          confirmed_by_instructor?: boolean
          confirmed_by_student?: boolean
          created_at?: string
          document_url?: string | null
          exam_date?: string
          exam_type?: Database["public"]["Enums"]["exam_type"]
          id?: string
          instructor_id?: string
          status?: Database["public"]["Enums"]["exam_status"]
          student_id?: string
          student_passed?: boolean | null
          updated_at?: string
        }
        Relationships: []
      }
      gamification_stats: {
        Row: {
          created_at: string
          current_streak: number
          id: string
          last_access_date: string | null
          longest_streak: number
          points: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_streak?: number
          id?: string
          last_access_date?: string | null
          longest_streak?: number
          points?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_streak?: number
          id?: string
          last_access_date?: string | null
          longest_streak?: number
          points?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      instructor_blocked_slots: {
        Row: {
          blocked_date: string
          blocked_time: string
          created_at: string
          id: string
          instructor_id: string
          reason: string | null
        }
        Insert: {
          blocked_date: string
          blocked_time: string
          created_at?: string
          id?: string
          instructor_id: string
          reason?: string | null
        }
        Update: {
          blocked_date?: string
          blocked_time?: string
          created_at?: string
          id?: string
          instructor_id?: string
          reason?: string | null
        }
        Relationships: []
      }
      instructor_packages: {
        Row: {
          created_at: string
          description: string | null
          duration_type: string
          id: string
          instructor_id: string
          is_active: boolean
          lesson_count: number
          name: string
          price: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_type?: string
          id?: string
          instructor_id: string
          is_active?: boolean
          lesson_count: number
          name: string
          price: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_type?: string
          id?: string
          instructor_id?: string
          is_active?: boolean
          lesson_count?: number
          name?: string
          price?: number
          updated_at?: string
        }
        Relationships: []
      }
      instructor_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          instructor_id: string
          rating: number
          student_id: string
          updated_at: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          instructor_id: string
          rating: number
          student_id: string
          updated_at?: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          instructor_id?: string
          rating?: number
          student_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      mfa_backup_codes: {
        Row: {
          code_hash: string
          created_at: string
          id: string
          used_at: string | null
          user_id: string
        }
        Insert: {
          code_hash: string
          created_at?: string
          id?: string
          used_at?: string | null
          user_id: string
        }
        Update: {
          code_hash?: string
          created_at?: string
          id?: string
          used_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          related_id: string | null
          related_type: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          related_id?: string | null
          related_type?: string | null
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          related_id?: string | null
          related_type?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address: string | null
          available_days: string[] | null
          available_end_time: string | null
          available_start_time: string | null
          avatar_url: string | null
          bio: string | null
          certifications: string[] | null
          city: string
          cnh_category: Database["public"]["Enums"]["cnh_category"] | null
          created_at: string
          email: string
          full_name: string
          id: string
          is_independent: boolean | null
          latitude: number | null
          linked_at: string | null
          linked_instructor_id: string | null
          longitude: number | null
          neighborhood: string | null
          payment_status: string
          pending_contact_at: string | null
          pending_instructor_id: string | null
          pending_instructor_name: string | null
          phone: string | null
          price_per_hour: number | null
          registration_status: string | null
          subscription_plan: string | null
          uf: string
          updated_at: string
          weekly_lesson_frequency: number | null
          whatsapp: string | null
          years_of_experience: number | null
        }
        Insert: {
          address?: string | null
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          created_at?: string
          email: string
          full_name: string
          id: string
          is_independent?: boolean | null
          latitude?: number | null
          linked_at?: string | null
          linked_instructor_id?: string | null
          longitude?: number | null
          neighborhood?: string | null
          payment_status?: string
          pending_contact_at?: string | null
          pending_instructor_id?: string | null
          pending_instructor_name?: string | null
          phone?: string | null
          price_per_hour?: number | null
          registration_status?: string | null
          subscription_plan?: string | null
          uf?: string
          updated_at?: string
          weekly_lesson_frequency?: number | null
          whatsapp?: string | null
          years_of_experience?: number | null
        }
        Update: {
          address?: string | null
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          is_independent?: boolean | null
          latitude?: number | null
          linked_at?: string | null
          linked_instructor_id?: string | null
          longitude?: number | null
          neighborhood?: string | null
          payment_status?: string
          pending_contact_at?: string | null
          pending_instructor_id?: string | null
          pending_instructor_name?: string | null
          phone?: string | null
          price_per_hour?: number | null
          registration_status?: string | null
          subscription_plan?: string | null
          uf?: string
          updated_at?: string
          weekly_lesson_frequency?: number | null
          whatsapp?: string | null
          years_of_experience?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_linked_instructor_id_fkey"
            columns: ["linked_instructor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_linked_instructor_id_fkey"
            columns: ["linked_instructor_id"]
            isOneToOne: false
            referencedRelation: "public_instructor_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_linked_instructor_id_fkey"
            columns: ["linked_instructor_id"]
            isOneToOne: false
            referencedRelation: "safe_public_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_pending_instructor_id_fkey"
            columns: ["pending_instructor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_pending_instructor_id_fkey"
            columns: ["pending_instructor_id"]
            isOneToOne: false
            referencedRelation: "public_instructor_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_pending_instructor_id_fkey"
            columns: ["pending_instructor_id"]
            isOneToOne: false
            referencedRelation: "safe_public_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      rate_limits: {
        Row: {
          action_type: string
          attempted_at: string | null
          id: string
          ip_address: string | null
          success: boolean | null
          user_id: string | null
        }
        Insert: {
          action_type: string
          attempted_at?: string | null
          id?: string
          ip_address?: string | null
          success?: boolean | null
          user_id?: string | null
        }
        Update: {
          action_type?: string
          attempted_at?: string | null
          id?: string
          ip_address?: string | null
          success?: boolean | null
          user_id?: string | null
        }
        Relationships: []
      }
      schedules: {
        Row: {
          created_at: string
          id: string
          instructor_id: string
          lesson_type: Database["public"]["Enums"]["lesson_type"]
          notes: string | null
          price: number
          scheduled_date: string
          scheduled_time: string
          status: Database["public"]["Enums"]["schedule_status"]
          student_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          instructor_id: string
          lesson_type: Database["public"]["Enums"]["lesson_type"]
          notes?: string | null
          price: number
          scheduled_date: string
          scheduled_time: string
          status?: Database["public"]["Enums"]["schedule_status"]
          student_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          instructor_id?: string
          lesson_type?: Database["public"]["Enums"]["lesson_type"]
          notes?: string | null
          price?: number
          scheduled_date?: string
          scheduled_time?: string
          status?: Database["public"]["Enums"]["schedule_status"]
          student_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      simulation_attempts: {
        Row: {
          answers: Json | null
          correct_answers: number
          created_at: string
          id: string
          passed: boolean
          score: number
          time_taken_seconds: number | null
          total_questions: number
          user_id: string
        }
        Insert: {
          answers?: Json | null
          correct_answers: number
          created_at?: string
          id?: string
          passed: boolean
          score: number
          time_taken_seconds?: number | null
          total_questions: number
          user_id: string
        }
        Update: {
          answers?: Json | null
          correct_answers?: number
          created_at?: string
          id?: string
          passed?: boolean
          score?: number
          time_taken_seconds?: number | null
          total_questions?: number
          user_id?: string
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          id?: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_sensitive_data: {
        Row: {
          accessed_by: string | null
          cnh: string | null
          cnh_document_path: string | null
          cpf_encrypted: string | null
          cpf_masked: string | null
          created_at: string
          id: string
          instructor_certificate_path: string | null
          last_accessed_at: string | null
          proof_of_residence_path: string | null
          rg: string | null
          rg_document_path: string | null
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          accessed_by?: string | null
          cnh?: string | null
          cnh_document_path?: string | null
          cpf_encrypted?: string | null
          cpf_masked?: string | null
          created_at?: string
          id?: string
          instructor_certificate_path?: string | null
          last_accessed_at?: string | null
          proof_of_residence_path?: string | null
          rg?: string | null
          rg_document_path?: string | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          accessed_by?: string | null
          cnh?: string | null
          cnh_document_path?: string | null
          cpf_encrypted?: string | null
          cpf_masked?: string | null
          created_at?: string
          id?: string
          instructor_certificate_path?: string | null
          last_accessed_at?: string | null
          proof_of_residence_path?: string | null
          rg?: string | null
          rg_document_path?: string | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          brand: string
          color: string | null
          created_at: string
          id: string
          instructor_id: string
          model: string
          plate: string
          updated_at: string
          vehicle_type: string
          year: number
        }
        Insert: {
          brand: string
          color?: string | null
          created_at?: string
          id?: string
          instructor_id: string
          model: string
          plate: string
          updated_at?: string
          vehicle_type?: string
          year: number
        }
        Update: {
          brand?: string
          color?: string | null
          created_at?: string
          id?: string
          instructor_id?: string
          model?: string
          plate?: string
          updated_at?: string
          vehicle_type?: string
          year?: number
        }
        Relationships: []
      }
    }
    Views: {
      public_instructor_profiles: {
        Row: {
          available_days: string[] | null
          available_end_time: string | null
          available_start_time: string | null
          avatar_url: string | null
          bio: string | null
          certifications: string[] | null
          city: string | null
          cnh_category: Database["public"]["Enums"]["cnh_category"] | null
          full_name: string | null
          id: string | null
          latitude: number | null
          longitude: number | null
          neighborhood: string | null
          price_per_hour: number | null
          uf: string | null
          years_of_experience: number | null
        }
        Insert: {
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string | null
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          full_name?: string | null
          id?: string | null
          latitude?: never
          longitude?: never
          neighborhood?: string | null
          price_per_hour?: number | null
          uf?: string | null
          years_of_experience?: number | null
        }
        Update: {
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string | null
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          full_name?: string | null
          id?: string | null
          latitude?: never
          longitude?: never
          neighborhood?: string | null
          price_per_hour?: number | null
          uf?: string | null
          years_of_experience?: number | null
        }
        Relationships: []
      }
      public_reviews: {
        Row: {
          comment: string | null
          created_at: string | null
          id: string | null
          instructor_id: string | null
          rating: number | null
          reviewer_name: string | null
        }
        Relationships: []
      }
      safe_public_profiles: {
        Row: {
          available_days: string[] | null
          available_end_time: string | null
          available_start_time: string | null
          avatar_url: string | null
          bio: string | null
          certifications: string[] | null
          city: string | null
          cnh_category: Database["public"]["Enums"]["cnh_category"] | null
          full_name: string | null
          id: string | null
          latitude: number | null
          longitude: number | null
          neighborhood: string | null
          price_per_hour: number | null
          subscription_plan: string | null
          uf: string | null
          years_of_experience: number | null
        }
        Insert: {
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string | null
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          full_name?: string | null
          id?: string | null
          latitude?: never
          longitude?: never
          neighborhood?: string | null
          price_per_hour?: number | null
          subscription_plan?: string | null
          uf?: string | null
          years_of_experience?: number | null
        }
        Update: {
          available_days?: string[] | null
          available_end_time?: string | null
          available_start_time?: string | null
          avatar_url?: string | null
          bio?: string | null
          certifications?: string[] | null
          city?: string | null
          cnh_category?: Database["public"]["Enums"]["cnh_category"] | null
          full_name?: string | null
          id?: string | null
          latitude?: never
          longitude?: never
          neighborhood?: string | null
          price_per_hour?: number | null
          subscription_plan?: string | null
          uf?: string | null
          years_of_experience?: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      calculate_distance_km: {
        Args: { lat1: number; lat2: number; lon1: number; lon2: number }
        Returns: number
      }
      can_access_instructor_contact: {
        Args: { instructor_id: string }
        Returns: boolean
      }
      can_view_instructor_profile: {
        Args: { profile_id: string }
        Returns: boolean
      }
      cleanup_expired_data: { Args: never; Returns: undefined }
      cleanup_old_rate_limits: { Args: never; Returns: undefined }
      create_system_notification: {
        Args: {
          p_message: string
          p_related_id?: string
          p_related_type?: string
          p_title: string
          p_type?: string
          p_user_id: string
        }
        Returns: string
      }
      decrypt_cpf: { Args: { encrypted_cpf: string }; Returns: string }
      encrypt_cpf: { Args: { plain_cpf: string }; Returns: string }
      generate_secure_document_path: {
        Args: { doc_type: string; user_id: string }
        Returns: string
      }
      get_instructors_by_proximity: {
        Args: {
          filter_city?: string
          filter_uf?: string
          max_distance_km?: number
          user_lat: number
          user_lon: number
        }
        Returns: {
          available_days: string[]
          available_end_time: string
          available_start_time: string
          avatar_url: string
          bio: string
          certifications: string[]
          city: string
          cnh_category: string
          distance_km: number
          full_name: string
          id: string
          latitude: number
          longitude: number
          neighborhood: string
          price_per_hour: number
          uf: string
          years_of_experience: number
        }[]
      }
      get_user_instructor_ids: {
        Args: { user_id: string }
        Returns: {
          linked_id: string
          pending_id: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hash_backup_code: { Args: { plain_code: string }; Returns: string }
      verify_backup_code: {
        Args: { p_code: string; p_user_id: string }
        Returns: boolean
      }
      verify_mfa_code_secure: {
        Args: { p_code: string; p_user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "student" | "instructor" | "admin"
      cnh_category: "A" | "B" | "AB"
      exam_status: "pending" | "approved" | "failed"
      exam_type: "theoretical" | "practical"
      lesson_type: "theoretical" | "practical_car" | "practical_motorcycle"
      schedule_status: "pending" | "confirmed" | "completed" | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["student", "instructor", "admin"],
      cnh_category: ["A", "B", "AB"],
      exam_status: ["pending", "approved", "failed"],
      exam_type: ["theoretical", "practical"],
      lesson_type: ["theoretical", "practical_car", "practical_motorcycle"],
      schedule_status: ["pending", "confirmed", "completed", "cancelled"],
    },
  },
} as const
