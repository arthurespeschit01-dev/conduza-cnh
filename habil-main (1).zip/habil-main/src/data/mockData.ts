export interface Instructor {
  id: string;
  name: string;
  email: string;
  cpf: string;
  cnh: string;
  categories: ('A' | 'B' | 'AB')[];
  certifications: string[];
  approved: boolean;
  approvalRate: number;
  totalStudents: number;
  approvedStudents: number;
  avatar?: string;
  bio: string;
  pricePerHour: number;
  rating: number;
  reviewCount: number;
  uf: string;
  city: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  cnhType: 'A' | 'B' | 'AB';
  instructorId?: string;
  avatar?: string;
  uf: string;
  city: string;
}

export interface Exam {
  id: string;
  studentId: string;
  instructorId: string;
  type: 'theoretical' | 'practical';
  status: 'pending' | 'approved' | 'failed';
  confirmedByStudent: boolean;
  confirmedByInstructor: boolean;
  date: string;
  category: 'A' | 'B';
}

export const mockInstructors: Instructor[] = [
  {
    id: 'inst-1',
    name: 'Carlos Eduardo Silva',
    email: 'carlos@instrutor.com',
    cpf: '123.456.789-00',
    cnh: '12345678900',
    categories: ['A', 'B'],
    certifications: ['Instrutor Credenciado DETRAN-SP', 'Curso de Direção Defensiva'],
    approved: true,
    approvalRate: 94,
    totalStudents: 156,
    approvedStudents: 147,
    bio: 'Instrutor com mais de 10 anos de experiência. Especialista em primeira habilitação e renovação de CNH.',
    pricePerHour: 80,
    rating: 4.9,
    reviewCount: 89,
    uf: 'SP',
    city: 'São Paulo',
  },
  {
    id: 'inst-2',
    name: 'Ana Paula Rodrigues',
    email: 'ana@instrutor.com',
    cpf: '987.654.321-00',
    cnh: '98765432100',
    categories: ['B'],
    certifications: ['Instrutor Credenciado DETRAN-SP'],
    approved: true,
    approvalRate: 88,
    totalStudents: 92,
    approvedStudents: 81,
    bio: 'Especialista em alunos com medo de dirigir. Metodologia paciente e acolhedora.',
    pricePerHour: 90,
    rating: 4.8,
    reviewCount: 67,
    uf: 'SP',
    city: 'São Paulo',
  },
  {
    id: 'inst-3',
    name: 'Roberto Mendes',
    email: 'roberto@instrutor.com',
    cpf: '456.789.123-00',
    cnh: '45678912300',
    categories: ['A'],
    certifications: ['Instrutor Credenciado DETRAN-RJ', 'Pilotagem Avançada'],
    approved: true,
    approvalRate: 91,
    totalStudents: 78,
    approvedStudents: 71,
    bio: 'Ex-piloto profissional. Especialista em habilitação categoria A (motos).',
    pricePerHour: 70,
    rating: 4.7,
    reviewCount: 45,
    uf: 'RJ',
    city: 'Rio de Janeiro',
  },
  {
    id: 'inst-4',
    name: 'Fernanda Costa',
    email: 'fernanda@instrutor.com',
    cpf: '321.654.987-00',
    cnh: '32165498700',
    categories: ['A', 'B'],
    certifications: ['Instrutor Credenciado DETRAN-MG', 'Direção Defensiva', 'Mecânica Básica'],
    approved: true,
    approvalRate: 96,
    totalStudents: 203,
    approvedStudents: 195,
    bio: 'Instrutora há 15 anos. Maior taxa de aprovação da região. Aulas teóricas e práticas.',
    pricePerHour: 100,
    rating: 5.0,
    reviewCount: 156,
    uf: 'MG',
    city: 'Belo Horizonte',
  },
];

export const mockStudents: Student[] = [
  {
    id: 'stud-1',
    name: 'Lucas Oliveira',
    email: 'lucas@aluno.com',
    cnhType: 'B',
    instructorId: 'inst-1',
    uf: 'SP',
    city: 'São Paulo',
  },
  {
    id: 'stud-2',
    name: 'Mariana Santos',
    email: 'mariana@aluno.com',
    cnhType: 'A',
    instructorId: 'inst-3',
    uf: 'RJ',
    city: 'Rio de Janeiro',
  },
];

export const mockExams: Exam[] = [
  {
    id: 'exam-1',
    studentId: 'stud-1',
    instructorId: 'inst-1',
    type: 'theoretical',
    status: 'approved',
    confirmedByStudent: true,
    confirmedByInstructor: true,
    date: '2024-01-15',
    category: 'B',
  },
  {
    id: 'exam-2',
    studentId: 'stud-1',
    instructorId: 'inst-1',
    type: 'practical',
    status: 'pending',
    confirmedByStudent: false,
    confirmedByInstructor: false,
    date: '2024-02-20',
    category: 'B',
  },
  {
    id: 'exam-3',
    studentId: 'stud-2',
    instructorId: 'inst-3',
    type: 'theoretical',
    status: 'approved',
    confirmedByStudent: true,
    confirmedByInstructor: true,
    date: '2024-01-10',
    category: 'A',
  },
];
